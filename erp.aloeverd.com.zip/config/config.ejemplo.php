<?php
/*
 * Ejemplo de configuración del ERP Aloeve.
 * Normalmente NO necesitas tocar este archivo: el instalador (/setup) crea config.php solo.
 * Úsalo únicamente si el instalador te pide crear config.php a mano.
 */
return [
    'app' => [
        'url' => 'https://erp.aloeverd.com',
        'llave' => 'GENERADA_POR_EL_INSTALADOR', // 32 bytes en base64; no la cambies después de instalar
    ],
    'db' => [
        'host' => 'localhost',
        'puerto' => 3306,
        'nombre' => 'u334112631_erpaloeverd',
        'usuario' => 'u334112631_aloeveadmin',
        'clave' => 'TU_CONTRASEÑA',
    ],
];
