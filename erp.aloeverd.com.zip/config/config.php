<?php
// Configuración del ERP Aloeve. Generado por el instalador el 2026-10-02 13:29.
// No compartas este archivo: contiene claves.

return array (
  'app' => 
  array (
    'url' => 'https://erp.aloeverd.com',
    'llave' => 'AUhD1h7xftd4o2NmDhIIRmY7sxpovvLt7F9HsJwfnho=',
  ),
  'db' => 
  array (
    'host' => 'localhost',
    'puerto' => 3306,
    'nombre' => 'u334112631_erpaloeverd',
    'usuario' => 'u334112631_aloeveadmin',
    'clave' => 'Acer2026@1@2',
  ),
);
