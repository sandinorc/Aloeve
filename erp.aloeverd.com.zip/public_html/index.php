<?php
/**
 * ERP Aloeve · punto de entrada único.
 * Todo el código vive un nivel arriba de public_html.
 */
declare(strict_types=1);

$raiz = dirname(__DIR__);

if (!is_file($raiz . '/app/bootstrap.php')) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><title>ERP Aloeve</title>'
        . '<body style="font-family:system-ui;max-width:560px;margin:60px auto;padding:0 16px;line-height:1.6">'
        . '<h1>Falta la carpeta del sistema</h1>'
        . '<p>No se encontró <code>app/bootstrap.php</code> junto a <code>public_html</code>.</p>'
        . '<p>Las carpetas <code>app</code>, <code>config</code>, <code>database</code>, <code>storage</code> y <code>vendor</code> '
        . 'deben quedar al mismo nivel que <code>public_html</code>, no adentro. Revisa el paso 5 de INSTRUCCIONES.md.</p></body>';
    exit;
}

require $raiz . '/app/bootstrap.php';

App\Core\App::ejecutar();
