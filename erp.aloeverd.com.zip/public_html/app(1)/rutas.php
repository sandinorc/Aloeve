<?php
declare(strict_types=1);

use App\Core\Router;
use App\Modulos\Actividad\ActividadControlador as Actividad;
use App\Modulos\Auth\AuthControlador as Auth;
use App\Modulos\Configuracion\ConfiguracionControlador as Config;
use App\Modulos\Configuracion\ComprobantesControlador as Comprobantes;
use App\Modulos\Configuracion\EcfControlador as Ecf;
use App\Modulos\Panorama\PanoramaControlador as Panorama;
use App\Modulos\Roles\RolesControlador as Roles;
use App\Modulos\Setup\SetupControlador as Setup;
use App\Modulos\Usuarios\UsuariosControlador as Usuarios;

return static function (Router $r): void {
    $libre = ['auth' => false];

    // Instalación y actualizaciones
    $r->get('/setup', [Setup::class, 'inicio'], $libre);
    $r->post('/setup/base-datos', [Setup::class, 'baseDatos'], $libre);
    $r->post('/setup/admin', [Setup::class, 'admin'], $libre);
    $r->get('/setup/actualizar', [Setup::class, 'actualizar'], ['permiso' => 'configuracion.editar']);
    $r->post('/setup/actualizar', [Setup::class, 'aplicar'], ['permiso' => 'configuracion.editar']);

    // Sesión
    $r->get('/login', [Auth::class, 'formulario'], $libre);
    $r->post('/login', [Auth::class, 'entrar'], $libre);
    $r->post('/salir', [Auth::class, 'salir']);
    $r->get('/perfil/clave', [Auth::class, 'formularioClave']);
    $r->post('/perfil/clave', [Auth::class, 'cambiarClave']);

    // Panorama
    $r->get('/', [Panorama::class, 'inicio']);

    // Usuarios
    $r->get('/usuarios', [Usuarios::class, 'lista'], ['permiso' => 'usuarios.ver']);
    $r->get('/usuarios/nuevo', [Usuarios::class, 'nuevo'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios', [Usuarios::class, 'crear'], ['permiso' => 'usuarios.editar']);
    $r->get('/usuarios/{id}', [Usuarios::class, 'editar'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios/{id}', [Usuarios::class, 'guardar'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios/{id}/clave', [Usuarios::class, 'restablecerClave'], ['permiso' => 'usuarios.editar']);

    // Roles y permisos
    $r->get('/roles', [Roles::class, 'lista'], ['permiso' => ['roles.editar', 'usuarios.ver']]);
    $r->get('/roles/{id}', [Roles::class, 'editar'], ['permiso' => ['roles.editar', 'usuarios.ver']]);
    $r->post('/roles/{id}', [Roles::class, 'guardar'], ['permiso' => 'roles.editar']);

    // Actividad
    $r->get('/actividad', [Actividad::class, 'lista'], ['permiso' => 'actividad.ver']);
    $r->get('/actividad/exportar', [Actividad::class, 'exportar'], ['permiso' => 'actividad.ver']);

    // Configuración
    $r->get('/configuracion', [Config::class, 'inicio'], ['permiso' => ['configuracion.editar', 'fiscal.ver']]);
    $r->get('/configuracion/negocio', [Config::class, 'negocio'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/negocio', [Config::class, 'guardarNegocio'], ['permiso' => 'configuracion.editar']);
    $r->get('/configuracion/sedes', [Config::class, 'sedes'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/sedes', [Config::class, 'crearSede'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/sedes/{id}', [Config::class, 'guardarSede'], ['permiso' => 'configuracion.editar']);

    // Comprobantes fiscales
    $r->get('/configuracion/comprobantes', [Comprobantes::class, 'inicio'], ['permiso' => 'fiscal.ver']);
    $r->post('/configuracion/comprobantes/secuencias', [Comprobantes::class, 'cargar'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/comprobantes/secuencias/{id}', [Comprobantes::class, 'editar'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/comprobantes/tipos', [Comprobantes::class, 'tipos'], ['permiso' => 'fiscal.editar']);

    // Facturación electrónica
    $r->get('/configuracion/ecf', [Ecf::class, 'inicio'], ['permiso' => 'fiscal.ver']);
    $r->post('/configuracion/ecf/modo', [Ecf::class, 'modo'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/ecf/{ambiente}/credenciales', [Ecf::class, 'credenciales'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/ecf/{ambiente}/probar', [Ecf::class, 'probar'], ['permiso' => 'fiscal.editar']);
};
