<?php $u = usuario(); ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Hola, ' . explode(' ', $u['nombre'])[0],
    'descripcion' => 'Tu rol es ' . $u['rol_nombre'] . '. Usa el menú para ir a tus módulos.',
]) ?>
<div class="tarjeta tarjeta-cuerpo max-w-2xl">
    <p class="text-texto-suave">Los módulos de caja, agenda y clientes se activan en la Fase 2. Mientras tanto puedes cambiar tu contraseña desde tu nombre, abajo en el menú.</p>
    <a href="<?= e(url('/perfil/clave')) ?>" class="btn-secundario mt-4"><?= icono('llave', 'h-4 w-4') ?> Cambiar mi contraseña</a>
</div>
