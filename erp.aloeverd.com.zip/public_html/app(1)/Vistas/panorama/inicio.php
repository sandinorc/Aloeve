<?php
$chips = [
    'sin_datos' => ['chip-gris', 'Sin datos'],
    'sin_meta' => ['chip-dorado', 'Sin meta'],
    'parcial' => ['chip-ambar', 'Parcial'],
];
$hechos = count(array_filter($pasos, static fn($p) => $p[3]));
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Panorama',
    'descripcion' => 'Cuánto se vendió, cómo va la ocupación y qué necesita atención.',
]) ?>

<?php foreach ($alertas as $a): ?>
    <div class="mb-3 flex items-start gap-3 rounded-xl border px-4 py-3 text-[15px] <?= $a['nivel'] === 'rojo' ? 'border-red-200 bg-red-50 text-red-800' : 'border-amber-200 bg-amber-50 text-amber-900' ?>">
        <?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?>
        <span class="flex-1"><?= e($a['texto']) ?></span>
        <a href="<?= e(url('/configuracion/comprobantes')) ?>" class="shrink-0 font-medium underline underline-offset-2">Revisar</a>
    </div>
<?php endforeach; ?>

<div class="mb-6 flex items-start gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-[15px] text-sky-900">
    <?= icono('info', 'mt-0.5 h-5 w-5 shrink-0') ?>
    <p>Los indicadores se llenan solos cuando empiecen a registrarse ventas, sesiones y clientes (Fase 2) y lleguen las reservas de aloeverd.com (Fase 3). Mientras no haya datos, cada tarjeta lo dice: el ERP no muestra cifras de ejemplo.</p>
</div>

<form method="get" class="tarjeta mb-6 grid gap-4 bg-[#f8f5ff] p-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_auto] lg:items-end">
    <div>
        <label for="desde" class="etiqueta">Desde</label>
        <input id="desde" name="desde" type="date" class="input" value="<?= e($desde) ?>">
    </div>
    <div>
        <label for="hasta" class="etiqueta">Hasta</label>
        <input id="hasta" name="hasta" type="date" class="input" value="<?= e($hasta) ?>">
    </div>
    <div>
        <label for="sede" class="etiqueta">Sede</label>
        <select id="sede" name="sede" class="input">
            <option value="">Todas</option>
            <?php foreach ($sedes as $s): ?>
                <option value="<?= (int) $s['id'] ?>" <?= get('sede') === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="flex gap-2 sm:col-span-2 lg:col-span-1">
        <button class="btn-primario flex-1 lg:flex-none"><?= icono('filtro', 'h-4 w-4') ?> Aplicar</button>
        <a href="<?= e(url('/')) ?>" class="btn-secundario">Limpiar</a>
    </div>
</form>

<?php if ($pasos && $hechos < count($pasos)): ?>
<section class="tarjeta mb-8 overflow-hidden">
    <div class="flex flex-wrap items-center justify-between gap-3 border-b border-linea px-5 py-4 sm:px-6">
        <div>
            <h2 class="text-lg font-semibold">Primeros pasos</h2>
            <p class="text-[15px] text-texto-suave">Lo que falta para empezar a facturar con el ERP.</p>
        </div>
        <span class="chip-morado"><?= $hechos ?> de <?= count($pasos) ?> listos</span>
    </div>
    <ul class="divide-y divide-linea">
        <?php foreach ($pasos as [$texto, $detalle, $ruta, $hecho]): ?>
            <li>
                <a href="<?= e(url($ruta)) ?>" class="flex items-center gap-4 px-5 py-4 hover:bg-fondo sm:px-6">
                    <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full <?= $hecho ? 'bg-emerald-600 text-white' : 'border-2 border-dashed border-linea text-texto-suave' ?>">
                        <?= $hecho ? icono('check', 'h-4 w-4') : '' ?>
                    </span>
                    <span class="min-w-0 flex-1">
                        <span class="block font-medium <?= $hecho ? 'text-texto-suave line-through decoration-texto-suave/40' : '' ?>"><?= e($texto) ?></span>
                        <span class="block text-[14px] text-texto-suave"><?= e($detalle) ?></span>
                    </span>
                    <?= icono('derecha', 'h-5 w-5 shrink-0 text-texto-suave') ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
<?php endif; ?>

<div class="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
    <?php foreach ($kpis as [$nombre, $valor, $estado, $formula]): [$chipClase, $chipTexto] = $chips[$estado]; ?>
        <article class="tarjeta p-5">
            <div class="flex items-start justify-between gap-3">
                <h2 class="text-[15px] text-texto-suave"><?= e($nombre) ?></h2>
                <span class="<?= $chipClase ?>"><?= e($chipTexto) ?></span>
            </div>
            <p class="mt-3 font-display text-[32px] leading-none text-texto/40" aria-label="Sin valor">—</p>
            <details class="mt-4 text-[13px] text-texto-suave">
                <summary class="cursor-pointer select-none list-none inline-flex items-center gap-1 hover:text-texto"><?= icono('info', 'h-4 w-4') ?> Cómo se calcula</summary>
                <p class="mt-2"><?= e($formula) ?></p>
            </details>
        </article>
    <?php endforeach; ?>
</div>


