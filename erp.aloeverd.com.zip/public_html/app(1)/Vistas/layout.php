<?php
/** @var string $contenido */
$u = usuario();
$titulo = $titulo ?? 'ERP';
$rutaActual = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$menu = require APP . '/menu.php';
$migas = $migas ?? [];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#231942">
    <title><?= e($titulo) ?> · Aloeve ERP</title>
    <link rel="icon" href="<?= e(asset('img/favicon.png')) ?>">
    <link rel="preload" href="<?= e(url('assets/fuentes/outfit.woff2')) ?>" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</head>
<body data-csrf="<?= e(\App\Core\Csrf::token()) ?>">
<a href="#principal" class="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 btn-primario">Ir al contenido</a>

<aside id="menu" class="fixed inset-y-0 left-0 z-40 flex w-[280px] -translate-x-full flex-col bg-menu text-white transition-transform duration-200 lg:translate-x-0" aria-label="Menú principal">
    <div class="flex items-center gap-3 px-5 pt-5 pb-4 border-b border-menu-borde">
        <span class="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white ring-2 ring-dorado/60">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="" class="h-10 w-10 rounded-full">
        </span>
        <div class="min-w-0">
            <div class="font-display text-xl leading-tight">Aloeve</div>
            <div class="text-[11px] uppercase tracking-[0.18em] text-white/60">Art Studio · ERP</div>
        </div>
        <button type="button" class="ml-auto grid h-10 w-10 place-items-center rounded-lg text-white/70 hover:bg-white/10 lg:hidden" data-menu-cerrar aria-label="Cerrar menú">
            <?= icono('cerrar') ?>
        </button>
    </div>

    <nav class="flex-1 overflow-y-auto px-3 pb-6">
        <?php foreach ($menu as $grupo => $items):
            $visibles = array_filter($items, static function ($i) {
                foreach ($i['permiso'] as $p) { if (puede($p)) { return true; } }
                return false;
            });
            if (!$visibles) { continue; }
            $idGrupo = 'grupo-' . preg_replace('/[^a-z]/', '', mb_strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $grupo)));
        ?>
            <div data-grupo="<?= e($idGrupo) ?>">
                <button type="button" class="menu-grupo" aria-expanded="true" aria-controls="<?= e($idGrupo) ?>" data-grupo-boton>
                    <span><?= e($grupo) ?></span>
                    <?= icono('abajo', 'h-4 w-4 transition-transform') ?>
                </button>
                <ul id="<?= e($idGrupo) ?>" class="space-y-0.5">
                    <?php foreach ($visibles as $item):
                        $activo = $item['ruta'] === '/' ? $rutaActual === '/' : ($rutaActual === $item['ruta'] || str_starts_with($rutaActual, $item['ruta'] . '/'));
                        if ($item['ruta'] === '/configuracion' && preg_match('#^/configuracion/(comprobantes|ecf)#', $rutaActual)) { $activo = false; }
                    ?>
                        <li>
                            <?php if (!empty($item['fase'])): ?>
                                <span class="menu-item-off" title="Disponible en la Fase <?= (int) $item['fase'] ?>">
                                    <?= icono($item['icono']) ?>
                                    <span class="flex-1"><?= e($item['texto']) ?></span>
                                    <span class="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white/50">Fase <?= (int) $item['fase'] ?></span>
                                </span>
                            <?php else: ?>
                                <a href="<?= e(url($item['ruta'])) ?>" class="menu-item" <?= $activo ? 'aria-current="page"' : '' ?>>
                                    <?= icono($item['icono']) ?>
                                    <span><?= e($item['texto']) ?></span>
                                </a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </nav>

    <?php if ($u): ?>
    <div class="flex items-center gap-3 border-t border-menu-borde px-4 py-4">
        <a href="<?= e(url('/perfil/clave')) ?>" class="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-1 hover:bg-white/10" title="Cambiar mi contraseña">
            <span class="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-dorado text-sm font-semibold text-menu"><?= e(iniciales($u['nombre'])) ?></span>
            <span class="min-w-0">
                <span class="block truncate text-[15px] font-medium"><?= e($u['nombre']) ?></span>
                <span class="block truncate text-[13px] text-white/60"><?= e($u['rol_nombre']) ?></span>
            </span>
        </a>
        <form method="post" action="<?= e(url('/salir')) ?>">
            <?= csrf_campo() ?>
            <button class="grid h-10 w-10 place-items-center rounded-lg text-white/70 hover:bg-white/10 hover:text-white" aria-label="Salir" title="Salir">
                <?= icono('salir') ?>
            </button>
        </form>
    </div>
    <?php endif; ?>
</aside>

<div id="velo" class="fixed inset-0 z-30 bg-menu/50 lg:hidden" hidden data-menu-cerrar></div>

<div class="min-h-dvh lg:pl-[280px]">
    <header class="sticky top-0 z-20 border-b border-linea bg-white/95 backdrop-blur">
        <div class="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6 lg:px-10">
            <button type="button" class="-ml-2 grid h-11 w-11 place-items-center rounded-lg text-texto hover:bg-fondo lg:hidden" data-menu-abrir aria-label="Abrir menú" aria-controls="menu" aria-expanded="false">
                <?= icono('menu', 'h-6 w-6') ?>
            </button>
            <nav aria-label="Migas" class="flex min-w-0 items-center gap-2 text-[15px]">
                <a href="<?= e(url('/')) ?>" class="text-texto-suave hover:text-texto" aria-label="Inicio"><?= icono('casa', 'h-5 w-5') ?></a>
                <?php foreach ($migas as $texto => $enlace): ?>
                    <span class="text-texto-suave/60">/</span>
                    <?php if ($enlace): ?>
                        <a href="<?= e(url($enlace)) ?>" class="truncate text-texto-suave hover:text-texto"><?= e($texto) ?></a>
                    <?php else: ?>
                        <span class="truncate font-semibold text-texto"><?= e($texto) ?></span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>
            <span class="ml-auto hidden text-[13px] text-texto-suave sm:block"><?= e(date('d/m/Y')) ?></span>
        </div>
    </header>

    <main id="principal" class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
        <?= \App\Core\View::parcial('parciales/flash') ?>
        <?= $contenido ?>
    </main>

    <footer class="mx-auto max-w-7xl px-4 pb-8 text-[13px] text-texto-suave sm:px-6 lg:px-10">
        ERP Aloeve <?= e(VERSION_ERP) ?> · Desarrollado por Black Sheep Marketing
    </footer>
</div>
</body>
</html>
