<?php
declare(strict_types=1);

namespace App\Modulos\Panorama;

use App\Core\Ajustes;
use App\Core\DB;
use App\Core\View;
use App\Modulos\Configuracion\ComprobantesControlador;

final class PanoramaControlador
{
    public function inicio(): never
    {
        if (!puede('panorama.ver')) {
            View::mostrar('panorama/bienvenida', ['titulo' => 'Inicio', 'migas' => ['Inicio' => null]]);
        }

        $desde = get('desde') ?: date('Y-m-01');
        $hasta = get('hasta') ?: date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) { $desde = date('Y-m-01'); }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) { $hasta = date('Y-m-d'); }

        // Indicadores: en la Fase 1 todavía no hay fuentes (ventas, sesiones, clientes).
        // Cada tarjeta declara su fórmula y su estado; nunca se muestran cifras de ejemplo.
        $kpis = [
            ['Ingresos del periodo', null, 'sin_datos', 'Suma de ingresos registrados en el rango. Se llena con ventas, reservas e inscripciones (Fase 2).'],
            ['Margen neto', null, 'sin_datos', '(Ingresos − Gastos) ÷ Ingresos.'],
            ['Ocupación promedio', null, 'sin_datos', 'Participantes confirmados ÷ capacidad de las sesiones realizadas.'],
            ['Clientes recurrentes', null, 'sin_datos', 'Clientes con 2 o más visitas en 12 meses ÷ clientes con al menos una.'],
            ['Cumplimiento de meta', null, 'sin_meta', 'Ingresos ÷ meta de ingresos del mes. Las metas se cargan en Finanzas (Fase 2).'],
            ['Reservas web nuevas', null, 'parcial', 'Reservas que llegan de Amelia en el rango. Requiere la conexión con aloeverd.com (Fase 3).'],
        ];

        $pasos = [
            [
                'Completa los datos fiscales del negocio',
                'Razón social y RNC salen en cada comprobante.',
                '/configuracion/negocio',
                Ajustes::get('negocio.razon_social') !== '' && Ajustes::get('negocio.rnc') !== '',
                'configuracion.editar',
            ],
            [
                'Carga tus secuencias de comprobantes',
                'Como mínimo B01 y B02 con el rango que autorizó la DGII.',
                '/configuracion/comprobantes',
                (int) DB::valor('SELECT COUNT(*) FROM secuencias_ncf WHERE activa = 1') > 0,
                'fiscal.editar',
            ],
            [
                'Crea los usuarios de tu equipo',
                'Cada persona con su rol: Fundadora, Gerente, Caja o Facilitador.',
                '/usuarios/nuevo',
                (int) DB::valor('SELECT COUNT(*) FROM usuarios') > 1,
                'usuarios.editar',
            ],
            [
                'Prueba la conexión de facturación electrónica',
                'En ambiente de Prueba (TesteCF) con tu certificado digital.',
                '/configuracion/ecf',
                (int) DB::valor("SELECT COUNT(*) FROM ecf_conexiones WHERE estado = 'conectado'") > 0,
                'fiscal.editar',
            ],
        ];
        $pasos = array_values(array_filter($pasos, static fn($p) => puede($p[4])));

        $alertas = puede('fiscal.ver') ? ComprobantesControlador::alertas() : [];

        View::mostrar('panorama/inicio', [
            'titulo' => 'Panorama',
            'migas' => ['Panorama' => null],
            'desde' => $desde,
            'hasta' => $hasta,
            'kpis' => $kpis,
            'pasos' => $pasos,
            'alertas' => $alertas,
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
        ]);
    }
}
