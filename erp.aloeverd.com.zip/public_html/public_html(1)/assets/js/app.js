/* ERP Aloeve · comportamiento de la interfaz (sin framework) */
(function () {
  'use strict';

  var csrf = document.body ? document.body.getAttribute('data-csrf') : '';

  function guardar(clave, valor) { try { localStorage.setItem(clave, valor); } catch (e) { /* sin almacenamiento */ } }
  function leer(clave) { try { return localStorage.getItem(clave); } catch (e) { return null; } }

  /* ---------- Menú lateral en celular ---------- */
  var menu = document.getElementById('menu');
  var velo = document.getElementById('velo');
  var botonAbrir = document.querySelector('[data-menu-abrir]');

  function abrirMenu() {
    if (!menu) return;
    menu.classList.remove('-translate-x-full');
    if (velo) velo.hidden = false;
    if (botonAbrir) botonAbrir.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }
  function cerrarMenu() {
    if (!menu) return;
    if (window.matchMedia('(min-width: 1024px)').matches) return;
    menu.classList.add('-translate-x-full');
    if (velo) velo.hidden = true;
    if (botonAbrir) botonAbrir.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }
  if (botonAbrir) botonAbrir.addEventListener('click', abrirMenu);
  document.querySelectorAll('[data-menu-cerrar]').forEach(function (el) { el.addEventListener('click', cerrarMenu); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') cerrarMenu(); });

  /* ---------- Grupos plegables del menú (se recuerdan por navegador) ---------- */
  document.querySelectorAll('[data-grupo]').forEach(function (grupo) {
    var id = grupo.getAttribute('data-grupo');
    var boton = grupo.querySelector('[data-grupo-boton]');
    var lista = document.getElementById(id);
    if (!boton || !lista) return;
    var tieneActivo = !!lista.querySelector('[aria-current="page"]');
    function aplicar(abierto) {
      lista.hidden = !abierto;
      boton.setAttribute('aria-expanded', abierto ? 'true' : 'false');
      var flecha = boton.querySelector('svg');
      if (flecha) flecha.style.transform = abierto ? '' : 'rotate(-90deg)';
    }
    aplicar(tieneActivo || leer('menu:' + id) !== 'cerrado');
    boton.addEventListener('click', function () {
      var abrir = lista.hidden;
      aplicar(abrir);
      guardar('menu:' + id, abrir ? 'abierto' : 'cerrado');
    });
  });

  /* ---------- Ventanas modales ---------- */
  document.querySelectorAll('[data-dialogo-abrir]').forEach(function (b) {
    b.addEventListener('click', function () {
      var d = document.getElementById(b.getAttribute('data-dialogo-abrir'));
      if (d && typeof d.showModal === 'function') {
        d.showModal();
        var f = d.querySelector('[data-secuencia-form]');
        if (f) actualizarVista(f);
      }
    });
  });
  document.querySelectorAll('dialog').forEach(function (d) {
    d.querySelectorAll('[data-dialogo-cerrar]').forEach(function (b) {
      b.addEventListener('click', function () { d.close(); });
    });
    d.addEventListener('click', function (ev) { if (ev.target === d) d.close(); });
  });

  /* ---------- Vista previa de secuencias NCF / e-NCF ---------- */
  var digitosGlobal = null;
  function formatear(tipo, n, digitos) {
    var s = String(n);
    while (s.length < digitos) s = '0' + s;
    return tipo + s;
  }
  function actualizarVista(form) {
    var salida = form.querySelector('[data-vista-previa]');
    if (!salida) return;
    var tipoEl = form.querySelector('[data-tipo]') || form.querySelector('input[name="tipo"]');
    var desdeEl = form.querySelector('[data-desde]') || form.querySelector('input[name="desde"]');
    var cantEl = form.querySelector('[data-cantidad]') || form.querySelector('input[name="cantidad"]');
    var tipo = tipoEl ? tipoEl.value : '';
    var desde = parseInt(desdeEl ? desdeEl.value : '1', 10);
    var cant = parseInt(cantEl ? cantEl.value : '0', 10);
    var digitos = tipo.charAt(0) === 'E' ? 10 : 8;
    if (!tipo || !(desde >= 1) || !(cant >= 1)) { salida.textContent = 'Completa el número inicial y la cantidad.'; return; }
    var hasta = desde + cant - 1;
    if (String(hasta).length > digitos) { salida.textContent = 'El rango pasa del máximo permitido para ' + tipo + '.'; return; }
    salida.innerHTML = '';
    salida.append('Del ');
    var a = document.createElement('strong'); a.className = 'font-mono'; a.textContent = formatear(tipo, desde, digitos);
    var b = document.createElement('strong'); b.className = 'font-mono'; b.textContent = formatear(tipo, hasta, digitos);
    salida.append(a, ' al ', b, ' · ' + cant.toLocaleString('es-DO') + ' comprobantes');
  }
  document.querySelectorAll('[data-secuencia-form]').forEach(function (form) {
    var sugeridos = {};
    try { sugeridos = JSON.parse(form.getAttribute('data-sugeridos') || '{}'); } catch (e) { sugeridos = {}; }
    form.addEventListener('input', function () { actualizarVista(form); });
    var tipo = form.querySelector('[data-tipo]');
    var desde = form.querySelector('[data-desde]');
    if (tipo && desde) {
      tipo.addEventListener('change', function () {
        if (sugeridos[tipo.value]) desde.value = sugeridos[tipo.value];
        actualizarVista(form);
      });
    }
    actualizarVista(form);
  });

  /* ---------- Probar conexión e-CF ---------- */
  document.querySelectorAll('[data-probar]').forEach(function (boton) {
    boton.addEventListener('click', function () {
      var tarjeta = boton.closest('article');
      var salida = tarjeta ? tarjeta.querySelector('[data-probar-resultado]') : null;
      var chip = tarjeta ? tarjeta.querySelector('[data-estado-chip]') : null;
      var cuerpo = new FormData();
      cuerpo.append('_csrf', csrf);
      cuerpo.append('conector', boton.getAttribute('data-conector') || '');
      boton.disabled = true;
      var textoOriginal = boton.innerHTML;
      boton.textContent = 'Probando con la DGII…';
      if (salida) { salida.className = 'min-h-[1.25rem] text-[13px] text-texto-suave'; salida.textContent = 'Pidiendo semilla, firmando y validando…'; }
      fetch(boton.getAttribute('data-probar'), {
        method: 'POST',
        body: cuerpo,
        headers: { 'X-Requested-With': 'fetch', 'X-CSRF-Token': csrf, 'Accept': 'application/json' },
        credentials: 'same-origin'
      })
        .then(function (r) { return r.json().catch(function () { return { ok: false, mensaje: 'Respuesta inesperada del servidor (' + r.status + ').' }; }); })
        .then(function (d) {
          if (salida) {
            salida.className = 'min-h-[1.25rem] text-[13px] ' + (d.ok ? 'text-emerald-700' : 'text-red-700');
            salida.textContent = d.mensaje || (d.ok ? 'Conectado.' : 'No se pudo conectar.');
          }
          if (chip && d.estado) {
            chip.className = d.ok ? 'chip-verde' : 'chip-rojo';
            chip.textContent = d.ok ? 'Conectado' : 'Error';
          }
        })
        .catch(function () {
          if (salida) { salida.className = 'min-h-[1.25rem] text-[13px] text-red-700'; salida.textContent = 'Sin conexión con el ERP. Revisa tu internet.'; }
        })
        .finally(function () { boton.disabled = false; boton.innerHTML = textoOriginal; });
    });
  });

  /* ---------- Confirmaciones ---------- */
  document.querySelectorAll('form[data-confirmar]').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (!window.confirm(f.getAttribute('data-confirmar'))) ev.preventDefault();
    });
  });

  /* ---------- Mostrar contraseña ---------- */
  document.querySelectorAll('[data-ver-clave]').forEach(function (b) {
    b.addEventListener('click', function () {
      var campo = document.getElementById(b.getAttribute('data-ver-clave'));
      if (!campo) return;
      var ver = campo.type === 'password';
      campo.type = ver ? 'text' : 'password';
      b.setAttribute('aria-label', ver ? 'Ocultar contraseña' : 'Mostrar contraseña');
    });
  });

  /* ---------- Copiar al portapapeles ---------- */
  document.querySelectorAll('[data-copiar]').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.getAttribute('data-copiar'));
      if (!el) return;
      var texto = el.textContent.trim();
      var listo = function () { var t = b.innerHTML; b.textContent = 'Copiado'; setTimeout(function () { b.innerHTML = t; }, 1500); };
      if (navigator.clipboard) {
        navigator.clipboard.writeText(texto).then(listo, function () { seleccionar(el); });
      } else { seleccionar(el); }
    });
  });
  function seleccionar(el) {
    var r = document.createRange(); r.selectNodeContents(el);
    var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
  }
  document.querySelectorAll('[data-seleccionar]').forEach(function (t) { t.addEventListener('focus', function () { t.select(); }); });

  /* ---------- Evitar doble envío ---------- */
  document.querySelectorAll('form').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (ev.defaultPrevented) return;
      var b = f.querySelector('button:not([type="button"])');
      if (b) setTimeout(function () { b.disabled = true; }, 0);
    });
  });
})();
