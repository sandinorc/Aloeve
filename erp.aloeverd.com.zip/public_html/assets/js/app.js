/* ERP Aloeve · comportamiento de la interfaz (sin framework) */
(function () {
  'use strict';

  var csrf = document.body ? document.body.getAttribute('data-csrf') : '';

  function guardar(clave, valor) { try { localStorage.setItem(clave, valor); } catch (e) { /* sin almacenamiento */ } }
  function leer(clave) { try { return localStorage.getItem(clave); } catch (e) { return null; } }

  /* ---------- Menú lateral en celular ---------- */
  var menu = document.getElementById('menu');
  var velo = document.getElementById('velo');
  var botonAbrir = document.querySelector('[data-menu-abrir]');

  function abrirMenu() {
    if (!menu) return;
    menu.classList.remove('-translate-x-full');
    if (velo) velo.hidden = false;
    if (botonAbrir) botonAbrir.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }
  function cerrarMenu() {
    if (!menu) return;
    if (window.matchMedia('(min-width: 1024px)').matches) return;
    menu.classList.add('-translate-x-full');
    if (velo) velo.hidden = true;
    if (botonAbrir) botonAbrir.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }
  if (botonAbrir) botonAbrir.addEventListener('click', abrirMenu);
  document.querySelectorAll('[data-menu-cerrar]').forEach(function (el) { el.addEventListener('click', cerrarMenu); });
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') cerrarMenu(); });

  /* ---------- Grupos plegables del menú (se recuerdan por navegador) ---------- */
  document.querySelectorAll('[data-grupo]').forEach(function (grupo) {
    var id = grupo.getAttribute('data-grupo');
    var boton = grupo.querySelector('[data-grupo-boton]');
    var lista = document.getElementById(id);
    if (!boton || !lista) return;
    var tieneActivo = !!lista.querySelector('[aria-current="page"]');
    function aplicar(abierto) {
      lista.hidden = !abierto;
      boton.setAttribute('aria-expanded', abierto ? 'true' : 'false');
      var flecha = boton.querySelector('svg');
      if (flecha) flecha.style.transform = abierto ? '' : 'rotate(-90deg)';
    }
    aplicar(tieneActivo || leer('menu:' + id) !== 'cerrado');
    boton.addEventListener('click', function () {
      var abrir = lista.hidden;
      aplicar(abrir);
      guardar('menu:' + id, abrir ? 'abierto' : 'cerrado');
    });
  });

  /* ---------- Ventanas modales ---------- */
  document.querySelectorAll('[data-dialogo-abrir]').forEach(function (b) {
    b.addEventListener('click', function () {
      var d = document.getElementById(b.getAttribute('data-dialogo-abrir'));
      if (d && typeof d.showModal === 'function') {
        d.showModal();
        var f = d.querySelector('[data-secuencia-form]');
        if (f) actualizarVista(f);
      }
    });
  });
  document.querySelectorAll('dialog').forEach(function (d) {
    d.querySelectorAll('[data-dialogo-cerrar]').forEach(function (b) {
      b.addEventListener('click', function () { d.close(); });
    });
    d.addEventListener('click', function (ev) { if (ev.target === d) d.close(); });
  });

  /* ---------- Vista previa de secuencias NCF / e-NCF ---------- */
  var digitosGlobal = null;
  function formatear(tipo, n, digitos) {
    var s = String(n);
    while (s.length < digitos) s = '0' + s;
    return tipo + s;
  }
  function actualizarVista(form) {
    var salida = form.querySelector('[data-vista-previa]');
    if (!salida) return;
    var tipoEl = form.querySelector('[data-tipo]') || form.querySelector('input[name="tipo"]');
    var desdeEl = form.querySelector('[data-desde]') || form.querySelector('input[name="desde"]');
    var cantEl = form.querySelector('[data-cantidad]') || form.querySelector('input[name="cantidad"]');
    var tipo = tipoEl ? tipoEl.value : '';
    var desde = parseInt(desdeEl ? desdeEl.value : '1', 10);
    var cant = parseInt(cantEl ? cantEl.value : '0', 10);
    var digitos = tipo.charAt(0) === 'E' ? 10 : 8;
    if (!tipo || !(desde >= 1) || !(cant >= 1)) { salida.textContent = 'Completa el número inicial y la cantidad.'; return; }
    var hasta = desde + cant - 1;
    if (String(hasta).length > digitos) { salida.textContent = 'El rango pasa del máximo permitido para ' + tipo + '.'; return; }
    salida.innerHTML = '';
    salida.append('Del ');
    var a = document.createElement('strong'); a.className = 'font-mono'; a.textContent = formatear(tipo, desde, digitos);
    var b = document.createElement('strong'); b.className = 'font-mono'; b.textContent = formatear(tipo, hasta, digitos);
    salida.append(a, ' al ', b, ' · ' + cant.toLocaleString('es-DO') + ' comprobantes');
  }
  document.querySelectorAll('[data-secuencia-form]').forEach(function (form) {
    var sugeridos = {};
    try { sugeridos = JSON.parse(form.getAttribute('data-sugeridos') || '{}'); } catch (e) { sugeridos = {}; }
    form.addEventListener('input', function () { actualizarVista(form); });
    var tipo = form.querySelector('[data-tipo]');
    var desde = form.querySelector('[data-desde]');
    if (tipo && desde) {
      tipo.addEventListener('change', function () {
        if (sugeridos[tipo.value]) desde.value = sugeridos[tipo.value];
        actualizarVista(form);
      });
    }
    actualizarVista(form);
  });

  /* ---------- Probar conexión e-CF ---------- */
  document.querySelectorAll('[data-probar]').forEach(function (boton) {
    boton.addEventListener('click', function () {
      var tarjeta = boton.closest('article');
      var salida = tarjeta ? tarjeta.querySelector('[data-probar-resultado]') : null;
      var chip = tarjeta ? tarjeta.querySelector('[data-estado-chip]') : null;
      var cuerpo = new FormData();
      cuerpo.append('_csrf', csrf);
      cuerpo.append('conector', boton.getAttribute('data-conector') || '');
      boton.disabled = true;
      var textoOriginal = boton.innerHTML;
      boton.textContent = 'Probando con la DGII…';
      if (salida) { salida.className = 'min-h-[1.25rem] text-[13px] text-texto-suave'; salida.textContent = 'Pidiendo semilla, firmando y validando…'; }
      fetch(boton.getAttribute('data-probar'), {
        method: 'POST',
        body: cuerpo,
        headers: { 'X-Requested-With': 'fetch', 'X-CSRF-Token': csrf, 'Accept': 'application/json' },
        credentials: 'same-origin'
      })
        .then(function (r) { return r.json().catch(function () { return { ok: false, mensaje: 'Respuesta inesperada del servidor (' + r.status + ').' }; }); })
        .then(function (d) {
          if (salida) {
            salida.className = 'min-h-[1.25rem] text-[13px] ' + (d.ok ? 'text-emerald-700' : 'text-red-700');
            salida.textContent = d.mensaje || (d.ok ? 'Conectado.' : 'No se pudo conectar.');
          }
          if (chip && d.estado) {
            chip.className = d.ok ? 'chip-verde' : 'chip-rojo';
            chip.textContent = d.ok ? 'Conectado' : 'Error';
          }
        })
        .catch(function () {
          if (salida) { salida.className = 'min-h-[1.25rem] text-[13px] text-red-700'; salida.textContent = 'Sin conexión con el ERP. Revisa tu internet.'; }
        })
        .finally(function () { boton.disabled = false; boton.innerHTML = textoOriginal; });
    });
  });

  /* ---------- Confirmaciones ---------- */
  document.querySelectorAll('form[data-confirmar]').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (!window.confirm(f.getAttribute('data-confirmar'))) ev.preventDefault();
    });
  });

  /* ---------- Mostrar contraseña ---------- */
  document.querySelectorAll('[data-ver-clave]').forEach(function (b) {
    b.addEventListener('click', function () {
      var campo = document.getElementById(b.getAttribute('data-ver-clave'));
      if (!campo) return;
      var ver = campo.type === 'password';
      campo.type = ver ? 'text' : 'password';
      b.setAttribute('aria-label', ver ? 'Ocultar contraseña' : 'Mostrar contraseña');
    });
  });

  /* ---------- Copiar al portapapeles ---------- */
  document.querySelectorAll('[data-copiar]').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.getAttribute('data-copiar'));
      if (!el) return;
      var texto = el.textContent.trim();
      var listo = function () { var t = b.innerHTML; b.textContent = 'Copiado'; setTimeout(function () { b.innerHTML = t; }, 1500); };
      if (navigator.clipboard) {
        navigator.clipboard.writeText(texto).then(listo, function () { seleccionar(el); });
      } else { seleccionar(el); }
    });
  });
  function seleccionar(el) {
    var r = document.createRange(); r.selectNodeContents(el);
    var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
  }
  document.querySelectorAll('[data-seleccionar]').forEach(function (t) { t.addEventListener('focus', function () { t.select(); }); });


  /* ---------- Buscador de clientes ---------- */
  document.querySelectorAll('[data-buscador-cliente]').forEach(function (caja) {
    var url = caja.getAttribute('data-buscador-cliente');
    var texto = caja.querySelector('[data-texto]');
    var valor = caja.querySelector('[data-valor]');
    var lista = caja.querySelector('[data-lista]');
    var temporizador = null;
    var activo = -1;
    function cerrar() { lista.hidden = true; texto.setAttribute('aria-expanded', 'false'); activo = -1; }
    function pintar(items) {
      lista.innerHTML = '';
      if (!items.length) {
        var li = document.createElement('li');
        li.className = 'px-3 py-2 text-[14px] text-texto-suave';
        li.textContent = 'Sin resultados';
        lista.appendChild(li);
      }
      items.forEach(function (it, i) {
        var li = document.createElement('li');
        li.setAttribute('role', 'option');
        li.className = 'cursor-pointer px-3 py-2 hover:bg-primario-50';
        li.dataset.indice = String(i);
        var n = document.createElement('span'); n.className = 'block font-medium'; n.textContent = it.nombre;
        var d = document.createElement('span'); d.className = 'block text-[13px] text-texto-suave'; d.textContent = it.detalle || '';
        li.append(n, d);
        li.addEventListener('mousedown', function (ev) { ev.preventDefault(); elegir(it); });
        lista.appendChild(li);
      });
      lista.hidden = false;
      texto.setAttribute('aria-expanded', 'true');
      caja._items = items;
    }
    function elegir(it) {
      valor.value = it.id;
      texto.value = it.nombre;
      cerrar();
      caja.dispatchEvent(new CustomEvent('cliente-elegido', { detail: it, bubbles: true }));
    }
    texto.addEventListener('input', function () {
      valor.value = '';
      clearTimeout(temporizador);
      var q = texto.value.trim();
      if (q.length < 2) { cerrar(); return; }
      temporizador = setTimeout(function () {
        fetch(url + '?q=' + encodeURIComponent(q), { headers: { 'X-Requested-With': 'fetch', 'Accept': 'application/json' }, credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (d) { pintar(d.resultados || []); })
          .catch(function () { cerrar(); });
      }, 250);
    });
    texto.addEventListener('keydown', function (ev) {
      var items = caja._items || [];
      if (lista.hidden || !items.length) return;
      if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
        ev.preventDefault();
        activo = (activo + (ev.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
        lista.querySelectorAll('[role=option]').forEach(function (li, i) { li.classList.toggle('bg-primario-50', i === activo); });
      } else if (ev.key === 'Enter' && activo >= 0) {
        ev.preventDefault(); elegir(items[activo]);
      } else if (ev.key === 'Escape') { cerrar(); }
    });
    texto.addEventListener('blur', function () { setTimeout(cerrar, 150); });
  });

  /* ---------- Formulario de cliente: mostrar campos según la elección ---------- */
  document.querySelectorAll('[data-form-cliente]').forEach(function (f) {
    var tipo = f.querySelector('[data-tipo-documento]');
    var fuente = f.querySelector('[data-fuente]');
    function aplicar() {
      var t = tipo ? tipo.value : 'ninguno';
      f.querySelectorAll('[data-solo-documento]').forEach(function (el) { el.hidden = t === 'ninguno'; });
      f.querySelectorAll('[data-solo-rnc]').forEach(function (el) { el.hidden = t !== 'rnc'; });
      f.querySelectorAll('[data-solo-referido]').forEach(function (el) { el.hidden = !fuente || fuente.value !== 'referido'; });
    }
    if (tipo) tipo.addEventListener('change', aplicar);
    if (fuente) fuente.addEventListener('change', aplicar);
    aplicar();
  });

  /* ---------- Formulario de producto: precio final y control de stock ---------- */
  function dinero(n) { return 'RD$ ' + n.toLocaleString('es-DO', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function numero(v) { v = String(v || '').replace(/\s/g, '').replace(',', '.'); var n = parseFloat(v); return isNaN(n) ? NaN : n; }
  document.querySelectorAll('[data-form-producto]').forEach(function (f) {
    var tasa = parseFloat(f.getAttribute('data-itbis') || '18') / 100;
    var precio = f.querySelector('[data-precio]');
    var lleva = f.querySelector('[data-lleva-itbis]');
    var incluye = f.querySelector('[data-con-itbis]');
    var salida = f.querySelector('[data-precio-final]');
    function calcular() {
      var p = numero(precio.value);
      if (isNaN(p)) { salida.textContent = 'Escribe el precio.'; return; }
      var base = (lleva.checked && incluye.checked) ? p / (1 + tasa) : p;
      var final = lleva.checked ? base * (1 + tasa) : base;
      salida.textContent = lleva.checked
        ? 'Precio sin ITBIS ' + dinero(base) + ' + ITBIS ' + dinero(final - base) + ' = el cliente paga ' + dinero(final)
        : 'El cliente paga ' + dinero(final) + ' (sin ITBIS)';
    }
    [precio, lleva, incluye].forEach(function (el) { if (el) el.addEventListener('input', calcular); if (el) el.addEventListener('change', calcular); });
    calcular();
    function control() {
      var elegido = f.querySelector('[data-control]:checked');
      var v = elegido ? elegido.value : 'propio';
      f.querySelectorAll('[data-solo-control]').forEach(function (el) { el.hidden = el.getAttribute('data-solo-control') !== v; });
    }
    f.querySelectorAll('[data-control]').forEach(function (r) { r.addEventListener('change', control); });
    control();
  });

  /* ---------- Movimiento de inventario: vista previa del resultado ---------- */
  document.querySelectorAll('[data-form-movimiento]').forEach(function (f) {
    var stock = parseFloat(f.getAttribute('data-stock') || '0');
    var unidad = f.getAttribute('data-unidad') || '';
    var cant = f.querySelector('[name=cantidad]');
    var salida = f.querySelector('[data-resultado-mov]');
    var etq = f.querySelector('[data-etiqueta-cantidad]');
    var opcional = f.querySelector('[data-motivo-opcional]');
    function fmt(n) { return (Math.round(n * 1000) / 1000).toLocaleString('es-DO', { maximumFractionDigits: 3 }); }
    function aplicar() {
      var t = (f.querySelector('[data-tipo-mov]:checked') || {}).value || 'entrada';
      f.querySelectorAll('[data-solo-mov]').forEach(function (el) { el.hidden = el.getAttribute('data-solo-mov') !== t; });
      etq.textContent = t === 'ajuste' ? 'Cantidad contada (' + unidad + ')' : 'Cantidad (' + unidad + ')';
      if (opcional) opcional.textContent = t === 'entrada' ? '(opcional)' : '(obligatorio)';
      var c = numero(cant.value);
      if (isNaN(c)) { salida.textContent = 'Hay ' + fmt(stock) + ' ' + unidad + '.'; return; }
      var nuevo = t === 'entrada' ? stock + c : (t === 'salida' ? stock - c : c);
      var dif = nuevo - stock;
      salida.textContent = 'Hay ' + fmt(stock) + ' → quedarán ' + fmt(nuevo) + ' ' + unidad + ' (' + (dif >= 0 ? '+' : '') + fmt(dif) + ')';
      salida.className = 'mt-2 rounded-xl px-3 py-2 text-[14px] ' + (nuevo < 0 ? 'bg-red-50 text-red-800' : 'bg-fondo');
    }
    f.addEventListener('input', aplicar);
    f.addEventListener('change', aplicar);
    aplicar();
  });


  /* ---------- Filtros que se aplican al cambiar ---------- */
  document.querySelectorAll('[data-enviar-al-cambiar]').forEach(function (sel) {
    sel.addEventListener('change', function () { if (sel.form) sel.form.submit(); });
  });

  /* ---------- Formulario de sesión: completar con la experiencia ---------- */
  function sumarMinutos(hora, min) {
    var p = (hora || '').split(':'); if (p.length < 2) return '';
    var t = parseInt(p[0], 10) * 60 + parseInt(p[1], 10) + min;
    t = Math.min(t, 23 * 60 + 45);
    return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0');
  }
  document.querySelectorAll('[data-form-sesion]').forEach(function (f) {
    var datos = {};
    try { datos = JSON.parse(f.getAttribute('data-servicios') || '{}'); } catch (e) { datos = {}; }
    var serv = f.querySelector('[data-servicio]'), ini = f.querySelector('[data-inicio]'), fin = f.querySelector('[data-fin]');
    var cap = f.querySelector('[data-capacidad]'), precio = f.querySelector('[data-precio-persona]');
    function duracion() { var d = datos[serv.value]; return d ? d.duracion : 120; }
    serv.addEventListener('change', function () {
      var d = datos[serv.value]; if (!d) return;
      cap.value = d.capacidad; precio.value = d.precio.toFixed(2);
      if (ini.value) fin.value = sumarMinutos(ini.value, d.duracion);
    });
    ini.addEventListener('change', function () { if (ini.value) fin.value = sumarMinutos(ini.value, duracion()); });
    if (!fin.value && ini.value && serv.value) { fin.value = sumarMinutos(ini.value, duracion()); }
    if (serv.value && !cap.value) { serv.dispatchEvent(new Event('change')); }
  });

  /* ---------- Agregar participante: total según personas ---------- */
  document.querySelectorAll('[data-form-reserva]').forEach(function (f) {
    var precio = parseFloat(f.getAttribute('data-precio') || '0');
    var personas = f.querySelector('[data-personas]'), monto = f.querySelector('[data-monto]');
    var tocado = false;
    monto.addEventListener('input', function () { tocado = true; });
    personas.addEventListener('input', function () {
      var n = parseInt(personas.value, 10);
      if (!tocado && n > 0) monto.value = (precio * n).toFixed(2);
    });
  });

  /* ---------- Check-in (llegada) sin recargar ---------- */
  document.querySelectorAll('[data-asistencia]').forEach(function (chk) {
    chk.addEventListener('change', function () {
      var cuerpo = new FormData();
      cuerpo.append('_csrf', csrf);
      cuerpo.append('asistio', chk.checked ? '1' : '0');
      chk.disabled = true;
      fetch(chk.getAttribute('data-asistencia'), { method: 'POST', body: cuerpo, credentials: 'same-origin',
        headers: { 'X-Requested-With': 'fetch', 'X-CSRF-Token': csrf, 'Accept': 'application/json' } })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (!d.ok) { chk.checked = !chk.checked; window.alert(d.mensaje || 'No se pudo guardar.'); return; }
          var total = document.querySelector('[data-asistentes]');
          if (total && typeof d.asistentes !== 'undefined') total.textContent = d.asistentes;
        })
        .catch(function () { chk.checked = !chk.checked; window.alert('Sin conexión. Intenta de nuevo.'); })
        .finally(function () { chk.disabled = false; });
    });
  });

  /* ---------- Cierre de sesión: recalcular materiales según asistentes ---------- */
  document.querySelectorAll('[data-form-cierre]').forEach(function (f) {
    var totalEl = f.querySelector('[data-total-asistentes]');
    var tocados = new WeakSet();
    f.querySelectorAll('[data-por-persona]').forEach(function (inp) { inp.addEventListener('input', function () { tocados.add(inp); }); });
    function recalcular() {
      var n = 0;
      f.querySelectorAll('input[type=checkbox][data-personas]').forEach(function (c) { if (c.checked) n += parseInt(c.getAttribute('data-personas'), 10) || 0; });
      if (totalEl) totalEl.textContent = n;
      f.querySelectorAll('[data-por-persona]').forEach(function (inp) {
        if (tocados.has(inp)) return;
        var v = parseFloat(inp.getAttribute('data-por-persona')) * n;
        inp.value = String(Math.round(v * 1000) / 1000);
      });
    }
    f.querySelectorAll('input[type=checkbox][data-personas]').forEach(function (c) { c.addEventListener('change', recalcular); });
  });

  /* ---------- Impresión de recibos ---------- */
  document.querySelectorAll('[data-imprimir]').forEach(function (b) {
    b.addEventListener('click', function () { window.print(); });
  });
  if (document.body && document.body.hasAttribute('data-auto-imprimir')) {
    window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });
  }

  /* ---------- Punto de venta ---------- */
  (function () {
    var raiz = document.querySelector('[data-pos]');
    var fuente = document.getElementById('pos-datos');
    if (!raiz || !fuente) return;
    var D = JSON.parse(fuente.textContent || '{}');
    var porId = {};
    (D.productos || []).forEach(function (p) { porId[p.id] = p; });
    var carrito = []; // {id, cantidad}
    var ultimoTotal = 0;
    var r2 = function (n) { return Math.round((n + Number.EPSILON) * 100) / 100; };
    var fmt = function (n) { return 'RD$ ' + r2(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var num = function (v) { v = parseFloat(String(v || '').replace(/,/g, '')); return isFinite(v) ? v : 0; };
    var $ = function (sel, base) { return (base || document).querySelector(sel); };

    var panel = $('[data-pos-carrito]');
    var fondo = $('[data-pos-fondo]');
    var lista = $('[data-pos-lineas]');
    var vacio = $('[data-pos-sin-items]');
    var inputDesc = $('[data-pos-descuento]');
    var btnCobrar = $('[data-pos-cobrar]');
    var credito = $('[data-pos-credito]');
    var clienteCaja = panel.querySelector('[data-buscador-cliente]');
    var clienteId = clienteCaja ? clienteCaja.querySelector('[data-valor]') : null;
    var clienteTexto = clienteCaja ? clienteCaja.querySelector('[data-texto]') : null;
    var clienteElegido = null;

    function abrirPanel() { panel.classList.add('abierto'); fondo.hidden = false; }
    function cerrarPanel() { panel.classList.remove('abierto'); fondo.hidden = true; }
    $('[data-pos-abrir]').addEventListener('click', abrirPanel);
    $('[data-pos-cerrar]').addEventListener('click', cerrarPanel);
    fondo.addEventListener('click', cerrarPanel);

    function calcular() {
      var pct = inputDesc ? Math.min(100, Math.max(0, num(inputDesc.value))) : 0;
      var sub = 0, desc = 0, itb = 0;
      carrito.forEach(function (l) {
        var p = porId[l.id];
        var bruto = r2(p.precio * l.cantidad);
        var d = r2(bruto * pct / 100);
        var base = bruto - d;
        var i = p.itbis ? r2(base * D.tasa / 100) : 0;
        l.total = r2(base + i);
        sub += base; desc += d; itb += i;
      });
      return { subtotal: r2(sub), descuento: r2(desc), itbis: r2(itb), total: r2(sub + itb), pct: pct };
    }

    function pintar() {
      lista.querySelectorAll('[data-linea]').forEach(function (li) { li.remove(); });
      vacio.hidden = carrito.length > 0;
      var t = calcular();
      carrito.forEach(function (l, idx) {
        var p = porId[l.id];
        var li = document.createElement('li');
        li.setAttribute('data-linea', '');
        li.className = 'grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-2 px-5 py-3';
        var info = document.createElement('div');
        info.className = 'col-span-2 min-w-0';
        var n = document.createElement('p'); n.className = 'font-medium leading-snug'; n.textContent = p.nombre;
        var d = document.createElement('p'); d.className = 'text-[13px] text-texto-suave tabular-nums'; d.textContent = fmt(p.precio) + (p.itbis ? ' + ITBIS' : ' · exento');
        info.append(n, d);
        var ctrl = document.createElement('div');
        ctrl.className = 'flex items-center gap-1';
        var menos = document.createElement('button');
        menos.type = 'button'; menos.className = 'grid h-9 w-9 place-items-center rounded-lg border border-linea text-lg hover:bg-fondo';
        menos.setAttribute('aria-label', 'Quitar uno de ' + p.nombre); menos.textContent = '−';
        var cant = document.createElement('input');
        cant.className = 'h-9 w-14 rounded-lg border border-linea text-center tabular-nums';
        cant.inputMode = 'decimal'; cant.value = String(l.cantidad);
        cant.setAttribute('aria-label', 'Cantidad de ' + p.nombre);
        var mas = document.createElement('button');
        mas.type = 'button'; mas.className = 'grid h-9 w-9 place-items-center rounded-lg border border-linea text-lg hover:bg-fondo';
        mas.setAttribute('aria-label', 'Agregar uno de ' + p.nombre); mas.textContent = '+';
        ctrl.append(menos, cant, mas);
        var tot = document.createElement('span');
        tot.className = 'w-24 text-right font-medium tabular-nums'; tot.textContent = fmt(l.total);
        li.append(info, ctrl, tot);
        menos.addEventListener('click', function () { cambiar(idx, l.cantidad - 1); });
        mas.addEventListener('click', function () { cambiar(idx, l.cantidad + 1); });
        cant.addEventListener('change', function () { cambiar(idx, num(cant.value)); });
        lista.appendChild(li);
      });
      $('[data-pos-subtotal]').textContent = fmt(t.subtotal + t.descuento);
      $('[data-pos-fila-desc]').hidden = t.descuento <= 0;
      $('[data-pos-desc]').textContent = '− ' + fmt(t.descuento);
      $('[data-pos-itbis]').textContent = fmt(t.itbis);
      $('[data-pos-total]').textContent = fmt(t.total);
      $('[data-pos-total-barra]').textContent = fmt(t.total);
      var unidades = carrito.reduce(function (a, l) { return a + l.cantidad; }, 0);
      $('[data-pos-cuenta]').textContent = unidades + (unidades === 1 ? ' artículo' : ' artículos');
      btnCobrar.disabled = !carrito.length || btnCobrar.hasAttribute('data-sin-ncf');
      ultimoTotal = t.total;
    }

    function cambiar(idx, cantidad) {
      var l = carrito[idx];
      var p = porId[l.id];
      cantidad = Math.round(cantidad * 1000) / 1000;
      if (cantidad <= 0) { carrito.splice(idx, 1); pintar(); return; }
      if (p.disponible !== null && cantidad > p.disponible) {
        cantidad = p.disponible;
        avisar('Solo hay ' + p.disponible + ' disponibles de ' + p.nombre + '.');
      }
      l.cantidad = cantidad;
      pintar();
    }

    function avisar(texto) {
      var a = document.createElement('div');
      a.className = 'fixed left-1/2 top-4 z-[60] -translate-x-1/2 rounded-xl bg-menu px-4 py-3 text-white shadow-modal';
      a.setAttribute('role', 'status');
      a.textContent = texto;
      document.body.appendChild(a);
      setTimeout(function () { a.remove(); }, 2600);
    }

    raiz.querySelectorAll('[data-pos-producto]').forEach(function (b) {
      b.addEventListener('click', function () {
        var id = parseInt(b.getAttribute('data-pos-producto'), 10);
        var idx = -1;
        carrito.forEach(function (l, i) { if (l.id === id) idx = i; });
        if (idx >= 0) { cambiar(idx, carrito[idx].cantidad + 1); }
        else {
          var p = porId[id];
          if (p.disponible !== null && p.disponible < 1) { carrito.push({ id: id, cantidad: p.disponible }); }
          else carrito.push({ id: id, cantidad: 1 });
          pintar();
        }
        b.classList.add('ring-2', 'ring-primario');
        setTimeout(function () { b.classList.remove('ring-2', 'ring-primario'); }, 180);
      });
    });

    // Búsqueda y categorías
    var buscar = $('[data-pos-buscar]');
    var catActual = '';
    function filtrar() {
      var q = (buscar ? buscar.value : '').trim().toLowerCase();
      var visibles = 0;
      raiz.querySelectorAll('[data-pos-producto]').forEach(function (b) {
        var ok = (!catActual || b.getAttribute('data-cat') === catActual) && (!q || b.getAttribute('data-busqueda').indexOf(q) !== -1);
        b.hidden = !ok;
        if (ok) visibles++;
      });
      var v = $('[data-pos-vacio]'); if (v) v.classList.toggle('hidden', visibles > 0);
    }
    if (buscar) {
      buscar.addEventListener('input', filtrar);
      buscar.addEventListener('keydown', function (ev) {
        if (ev.key !== 'Enter') return;
        ev.preventDefault();
        var q = buscar.value.trim().toLowerCase();
        var exacto = (D.productos || []).filter(function (p) { return p.sku.toLowerCase() === q; })[0];
        var b = exacto ? raiz.querySelector('[data-pos-producto="' + exacto.id + '"]') : raiz.querySelector('[data-pos-producto]:not([hidden]):not([disabled])');
        if (b && !b.disabled) { b.click(); buscar.value = ''; filtrar(); }
      });
    }
    raiz.querySelectorAll('[data-pos-cat]').forEach(function (b) {
      b.addEventListener('click', function () {
        catActual = b.getAttribute('data-pos-cat');
        raiz.querySelectorAll('[data-pos-cat]').forEach(function (o) {
          var on = o === b;
          o.setAttribute('aria-pressed', on ? 'true' : 'false');
          o.classList.toggle('bg-primario', on); o.classList.toggle('text-white', on);
          o.classList.toggle('bg-white', !on); o.classList.toggle('border', !on); o.classList.toggle('text-texto', !on);
        });
        filtrar();
      });
    });

    if (inputDesc) inputDesc.addEventListener('input', pintar);
    $('[data-pos-vaciar]').addEventListener('click', function () {
      if (carrito.length && !window.confirm('¿Vaciar la venta actual?')) return;
      carrito = []; pintar();
    });
    if (clienteCaja) {
      clienteCaja.addEventListener('cliente-elegido', function (ev) { clienteElegido = ev.detail; });
      clienteTexto.addEventListener('input', function () { clienteElegido = null; });
    }

    // Cobro
    var dlg = document.getElementById('dlg-cobro');
    var dlgListo = document.getElementById('dlg-listo');
    var campos = dlg.querySelectorAll('[data-pago]');
    var btnConfirmar = $('[data-pos-confirmar]');
    var cajaError = $('[data-pos-error]');
    function mostrarError(t) { cajaError.textContent = t; cajaError.classList.toggle('hidden', !t); }
    function pagos() {
      var r = {};
      campos.forEach(function (c) { r[c.getAttribute('data-pago')] = r2(num(c.value)); });
      return r;
    }
    function revisarPago() {
      var p = pagos();
      var otros = r2(p.tarjeta + p.transferencia);
      var recibido = r2(p.efectivo + otros);
      var dif = r2(recibido - ultimoTotal);
      var caja = $('[data-pos-resultado]');
      var ok = dif >= 0 && otros <= ultimoTotal;
      $('[data-pos-resultado-texto]').textContent = otros > ultimoTotal ? 'Tarjeta/transferencia excede' : (dif >= 0 ? 'Cambio' : 'Falta');
      $('[data-pos-resultado-monto]').textContent = fmt(Math.abs(dif));
      caja.classList.toggle('bg-emerald-50', ok); caja.classList.toggle('border-emerald-200', ok);
      caja.classList.toggle('bg-red-50', !ok && recibido > 0); caja.classList.toggle('border-red-200', !ok && recibido > 0);
      btnConfirmar.disabled = !ok;
    }
    campos.forEach(function (c) { c.addEventListener('input', revisarPago); });
    dlg.querySelectorAll('[data-pago-todo]').forEach(function (b) {
      b.addEventListener('click', function () {
        campos.forEach(function (c) { c.value = ''; });
        dlg.querySelector('[data-pago="' + b.getAttribute('data-pago-todo') + '"]').value = ultimoTotal.toFixed(2);
        revisarPago();
      });
    });

    btnCobrar.addEventListener('click', function () {
      if (!carrito.length) return;
      if (credito && credito.checked) {
        if (!clienteId || !clienteId.value) { avisar('Elige el cliente para la factura de crédito fiscal.'); abrirPanel(); if (clienteTexto) clienteTexto.focus(); return; }
        if (clienteElegido && (!clienteElegido.documento || ['rnc', 'cedula'].indexOf(clienteElegido.tipo_documento) === -1)) {
          avisar('Ese cliente no tiene RNC o cédula. Edítalo o quita el crédito fiscal.'); return;
        }
      }
      calcular();
      campos.forEach(function (c) { c.value = ''; });
      $('[data-pago-ref]').value = '';
      mostrarError('');
      $('[data-pos-pago-total]').textContent = fmt(ultimoTotal);
      $('[data-pos-pago-tipo]').textContent = (credito && credito.checked ? 'Factura de crédito fiscal' : 'Factura de consumo') +
        (clienteTexto && clienteId && clienteId.value ? ' · ' + clienteTexto.value : '');
      var rapidos = $('[data-pos-rapidos]');
      rapidos.innerHTML = '';
      var opciones = [ultimoTotal];
      [100, 200, 500, 1000, 2000, 5000].forEach(function (b) { var v = Math.ceil(ultimoTotal / b) * b; if (v > ultimoTotal && opciones.indexOf(v) === -1) opciones.push(v); });
      opciones.slice(0, 5).forEach(function (v, i) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'btn-secundario btn-sm';
        b.textContent = i === 0 ? 'Exacto' : fmt(v).replace('.00', '');
        b.addEventListener('click', function () {
          campos.forEach(function (c) { c.value = ''; });
          dlg.querySelector('[data-pago="efectivo"]').value = v.toFixed(2);
          revisarPago();
        });
        rapidos.appendChild(b);
      });
      revisarPago();
      dlg.showModal();
      setTimeout(function () { dlg.querySelector('[data-pago="efectivo"]').focus(); }, 50);
    });

    btnConfirmar.addEventListener('click', function () {
      var p = pagos();
      var ref = $('[data-pago-ref]').value.trim();
      var lista = [];
      Object.keys(p).forEach(function (m) { if (p[m] > 0) lista.push({ metodo: m, monto: p[m], referencia: m === 'efectivo' ? '' : ref }); });
      var cuerpo = {
        carrito: carrito.map(function (l) { return { producto_id: l.id, cantidad: l.cantidad }; }),
        cliente_id: clienteId && clienteId.value ? parseInt(clienteId.value, 10) : null,
        credito_fiscal: !!(credito && credito.checked),
        descuento: inputDesc ? num(inputDesc.value) : 0,
        pagos: lista
      };
      btnConfirmar.disabled = true;
      var textoOriginal = btnConfirmar.innerHTML;
      btnConfirmar.textContent = 'Procesando…';
      mostrarError('');
      fetch(D.cobrar, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch', 'X-CSRF-Token': csrf, 'Accept': 'application/json' },
        body: JSON.stringify(cuerpo)
      }).then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Error del servidor (' + r.status + ').' }; }); })
        .then(function (d) {
          btnConfirmar.innerHTML = textoOriginal;
          if (!d.ok) { mostrarError(d.error || d.mensaje || 'No se pudo cobrar.'); btnConfirmar.disabled = false; return; }
          dlg.close();
          $('[data-listo-numero]', dlgListo).textContent = d.venta.numero;
          $('[data-listo-tipo]', dlgListo).textContent = d.comprobante.nombre;
          $('[data-listo-ncf]', dlgListo).textContent = d.comprobante.ncf;
          $('[data-listo-fila-ecf]', dlgListo).hidden = !d.ecf;
          if (d.ecf) $('[data-listo-ecf]', dlgListo).textContent = d.ecf.texto;
          $('[data-listo-fila-cambio]', dlgListo).hidden = !(d.venta.cambio > 0);
          $('[data-listo-cambio]', dlgListo).textContent = fmt(d.venta.cambio);
          $('[data-listo-recibo]', dlgListo).href = d.recibo + '?imprimir=1';
          // Descontar disponibilidad localmente
          carrito.forEach(function (l) { var pr = porId[l.id]; if (pr.disponible !== null) pr.disponible = Math.round((pr.disponible - l.cantidad) * 1000) / 1000; });
          dlgListo.showModal();
        })
        .catch(function () { btnConfirmar.innerHTML = textoOriginal; btnConfirmar.disabled = false; mostrarError('Sin conexión. Revisa el internet e intenta de nuevo.'); });
    });

    $('[data-pos-nueva]').addEventListener('click', function () { window.location.reload(); });
    pintar();
  })();

  /* ---------- Evitar doble envío ---------- */
  document.querySelectorAll('form').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (ev.defaultPrevented) return;
      var b = f.querySelector('button:not([type="button"])');
      if (b) setTimeout(function () { b.disabled = true; }, 0);
    });
  });
})();
