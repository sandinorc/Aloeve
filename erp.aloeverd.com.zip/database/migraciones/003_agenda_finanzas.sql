-- ERP Aloeve · Fase 2C: agenda (experiencias, facilitadores, sesiones, reservas) y finanzas

CREATE TABLE IF NOT EXISTS facilitadores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(160) NOT NULL,
    email VARCHAR(160) NULL,
    telefono VARCHAR(20) NULL,
    especialidad VARCHAR(120) NULL,
    anos_experiencia TINYINT UNSIGNED NULL,
    bio VARCHAR(1000) NULL,
    color CHAR(7) NOT NULL DEFAULT '#6a47dc',
    usuario_id INT UNSIGNED NULL,
    amelia_employee_id INT UNSIGNED NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_facilitadores_email (email),
    UNIQUE KEY uq_facilitadores_usuario (usuario_id),
    UNIQUE KEY uq_facilitadores_amelia (amelia_employee_id),
    CONSTRAINT fk_facilitadores_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS servicios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(160) NOT NULL,
    linea_negocio ENUM('privados','corporativo','experiencias','formacion','turismo') NOT NULL DEFAULT 'experiencias',
    descripcion VARCHAR(1000) NULL,
    duracion_min SMALLINT UNSIGNED NOT NULL DEFAULT 120,
    precio DECIMAL(12,2) NOT NULL DEFAULT 0,
    lleva_itbis TINYINT(1) NOT NULL DEFAULT 1,
    capacidad SMALLINT UNSIGNED NOT NULL DEFAULT 12,
    edad_min TINYINT UNSIGNED NULL,
    edad_max TINYINT UNSIGNED NULL,
    color CHAR(7) NOT NULL DEFAULT '#6a47dc',
    amelia_service_id INT UNSIGNED NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_servicios_nombre (nombre),
    UNIQUE KEY uq_servicios_amelia (amelia_service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Receta: cuánto material usa cada persona en una experiencia (sugerencia al cerrar la sesión)
CREATE TABLE IF NOT EXISTS servicio_materiales (
    servicio_id INT UNSIGNED NOT NULL,
    material_id INT UNSIGNED NOT NULL,
    cantidad_por_persona DECIMAL(12,3) NOT NULL,
    PRIMARY KEY (servicio_id, material_id),
    CONSTRAINT fk_sm_servicio FOREIGN KEY (servicio_id) REFERENCES servicios(id) ON DELETE CASCADE,
    CONSTRAINT fk_sm_material FOREIGN KEY (material_id) REFERENCES materiales(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sesiones (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    servicio_id INT UNSIGNED NOT NULL,
    facilitador_id INT UNSIGNED NULL,
    sede_id INT UNSIGNED NULL,
    fecha DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    capacidad SMALLINT UNSIGNED NOT NULL,
    precio_persona DECIMAL(12,2) NOT NULL DEFAULT 0,
    estado ENUM('programada','confirmada','realizada','cerrada','cancelada') NOT NULL DEFAULT 'programada',
    notas VARCHAR(1000) NULL,
    notas_cierre VARCHAR(1000) NULL,
    motivo_cancelacion VARCHAR(255) NULL,
    cerrada_por INT UNSIGNED NULL,
    cerrada_en DATETIME NULL,
    amelia_appointment_id INT UNSIGNED NULL,
    amelia_event_period_id INT UNSIGNED NULL,
    creado_por INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_sesiones_fecha (fecha, hora_inicio),
    KEY ix_sesiones_facilitador (facilitador_id, fecha),
    KEY ix_sesiones_estado (estado, fecha),
    UNIQUE KEY uq_sesiones_amelia_app (amelia_appointment_id),
    UNIQUE KEY uq_sesiones_amelia_evt (amelia_event_period_id),
    CONSTRAINT fk_sesiones_servicio FOREIGN KEY (servicio_id) REFERENCES servicios(id),
    CONSTRAINT fk_sesiones_facilitador FOREIGN KEY (facilitador_id) REFERENCES facilitadores(id) ON DELETE SET NULL,
    CONSTRAINT fk_sesiones_sede FOREIGN KEY (sede_id) REFERENCES sedes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reservas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sesion_id INT UNSIGNED NOT NULL,
    cliente_id INT UNSIGNED NOT NULL,
    personas SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    estado ENUM('pendiente','confirmada','cancelada','no_show') NOT NULL DEFAULT 'confirmada',
    asistio TINYINT(1) NULL,
    monto DECIMAL(12,2) NOT NULL DEFAULT 0,
    pagado DECIMAL(12,2) NOT NULL DEFAULT 0,
    cortesia TINYINT(1) NOT NULL DEFAULT 0,
    origen ENUM('manual','amelia','pos') NOT NULL DEFAULT 'manual',
    amelia_booking_id INT UNSIGNED NULL,
    notas VARCHAR(500) NULL,
    creado_por INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_reservas_sesion (sesion_id),
    KEY ix_reservas_cliente (cliente_id),
    UNIQUE KEY uq_reservas_amelia (amelia_booking_id),
    CONSTRAINT fk_reservas_sesion FOREIGN KEY (sesion_id) REFERENCES sesiones(id) ON DELETE CASCADE,
    CONSTRAINT fk_reservas_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sesion_materiales (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sesion_id INT UNSIGNED NOT NULL,
    material_id INT UNSIGNED NOT NULL,
    cantidad DECIMAL(12,3) NOT NULL,
    movimiento_id BIGINT UNSIGNED NULL,
    KEY ix_smat_sesion (sesion_id),
    CONSTRAINT fk_smat_sesion FOREIGN KEY (sesion_id) REFERENCES sesiones(id) ON DELETE CASCADE,
    CONSTRAINT fk_smat_material FOREIGN KEY (material_id) REFERENCES materiales(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ingresos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    concepto VARCHAR(255) NOT NULL,
    linea_negocio ENUM('privados','corporativo','experiencias','formacion','turismo','tienda','otros') NOT NULL DEFAULT 'otros',
    monto DECIMAL(12,2) NOT NULL,
    metodo ENUM('efectivo','tarjeta','transferencia','enlace','otro') NOT NULL DEFAULT 'efectivo',
    origen_tipo ENUM('manual','reserva','venta','inscripcion') NOT NULL DEFAULT 'manual',
    origen_id INT UNSIGNED NULL,
    cliente_id INT UNSIGNED NULL,
    sede_id INT UNSIGNED NULL,
    referencia VARCHAR(80) NULL,
    usuario_id INT UNSIGNED NULL,
    anulado TINYINT(1) NOT NULL DEFAULT 0,
    motivo_anulacion VARCHAR(255) NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_ingresos_fecha (fecha, anulado),
    KEY ix_ingresos_origen (origen_tipo, origen_id),
    KEY ix_ingresos_linea (linea_negocio, fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gastos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    tipo ENUM('fijo','variable') NOT NULL DEFAULT 'variable',
    categoria VARCHAR(60) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    proveedor_id INT UNSIGNED NULL,
    monto DECIMAL(12,2) NOT NULL,
    itbis DECIMAL(12,2) NOT NULL DEFAULT 0,
    ncf_proveedor VARCHAR(13) NULL,
    metodo ENUM('efectivo','tarjeta','transferencia','cheque','otro') NOT NULL DEFAULT 'transferencia',
    sede_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NULL,
    anulado TINYINT(1) NOT NULL DEFAULT 0,
    motivo_anulacion VARCHAR(255) NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_gastos_fecha (fecha, anulado),
    KEY ix_gastos_categoria (categoria, fecha),
    CONSTRAINT fk_gastos_proveedor FOREIGN KEY (proveedor_id) REFERENCES proveedores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reserva_caja (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    tipo ENUM('entrada','salida') NOT NULL,
    monto DECIMAL(12,2) NOT NULL,
    nota VARCHAR(255) NOT NULL,
    usuario_id INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_rc_fecha (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS metas (
    periodo CHAR(7) NOT NULL PRIMARY KEY,
    meta_ingresos DECIMAL(12,2) NULL,
    meta_ocupacion DECIMAL(5,2) NULL,
    meta_recurrentes DECIMAL(5,2) NULL,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO configuracion (clave, valor) VALUES
    ('finanzas.categorias_gasto', 'Alquiler,Nómina,Servicios (luz, agua, internet),Materiales,Marketing,Mantenimiento,Impuestos,Bancos y comisiones,Transporte,Otros')
ON DUPLICATE KEY UPDATE clave = clave;
