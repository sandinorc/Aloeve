-- ERP Aloeve · Fase 1: base, usuarios, roles, actividad, configuración y comprobantes fiscales

CREATE TABLE IF NOT EXISTS sedes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    direccion VARCHAR(255) NULL,
    telefono VARCHAR(30) NULL,
    activa TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sedes_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS roles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    clave VARCHAR(40) NOT NULL,
    nombre VARCHAR(80) NOT NULL,
    descripcion VARCHAR(255) NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_roles_clave (clave)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rol_permisos (
    rol_id INT UNSIGNED NOT NULL,
    permiso VARCHAR(60) NOT NULL,
    PRIMARY KEY (rol_id, permiso),
    CONSTRAINT fk_rp_rol FOREIGN KEY (rol_id) REFERENCES roles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    email VARCHAR(160) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol_id INT UNSIGNED NOT NULL,
    sede_id INT UNSIGNED NULL,
    facilitador_id INT UNSIGNED NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    debe_cambiar_clave TINYINT(1) NOT NULL DEFAULT 0,
    ultimo_acceso DATETIME NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_usuarios_email (email),
    KEY ix_usuarios_rol (rol_id),
    CONSTRAINT fk_usuarios_rol FOREIGN KEY (rol_id) REFERENCES roles(id),
    CONSTRAINT fk_usuarios_sede FOREIGN KEY (sede_id) REFERENCES sedes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_intentos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(160) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    exito TINYINT(1) NOT NULL,
    fecha DATETIME NOT NULL,
    KEY ix_li_email (email, fecha),
    KEY ix_li_ip (ip, fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS actividad (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NULL,
    modulo VARCHAR(40) NOT NULL,
    accion VARCHAR(40) NOT NULL,
    entidad VARCHAR(60) NULL,
    entidad_id BIGINT UNSIGNED NULL,
    descripcion VARCHAR(500) NOT NULL DEFAULT '',
    antes JSON NULL,
    despues JSON NULL,
    ip VARCHAR(45) NULL,
    fecha DATETIME NOT NULL,
    KEY ix_act_fecha (fecha),
    KEY ix_act_usuario (usuario_id, fecha),
    KEY ix_act_modulo (modulo, fecha),
    KEY ix_act_entidad (entidad, entidad_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracion (
    clave VARCHAR(80) NOT NULL PRIMARY KEY,
    valor TEXT NULL,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS secuencias_ncf (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    clase ENUM('papel','electronico') NOT NULL,
    tipo CHAR(3) NOT NULL,
    desde BIGINT UNSIGNED NOT NULL,
    hasta BIGINT UNSIGNED NOT NULL,
    proximo BIGINT UNSIGNED NOT NULL,
    vence_en DATE NULL,
    activa TINYINT(1) NOT NULL DEFAULT 1,
    nota VARCHAR(255) NULL,
    creado_por INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY ix_sec_tipo (tipo, activa),
    CONSTRAINT ck_sec_rango CHECK (hasta >= desde AND proximo >= desde AND proximo <= hasta + 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ecf_conexiones (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ambiente ENUM('testecf','certecf','ecf') NOT NULL,
    conector ENUM('dgii','proveedor') NOT NULL,
    certificado_ruta VARCHAR(255) NULL,
    certificado_clave_cifrada TEXT NULL,
    certificado_titular VARCHAR(255) NULL,
    certificado_vence DATE NULL,
    correo VARCHAR(160) NULL,
    clave_cifrada TEXT NULL,
    api_key_cifrada TEXT NULL,
    api_key_final VARCHAR(8) NULL,
    estado ENUM('sin_verificar','conectado','error') NOT NULL DEFAULT 'sin_verificar',
    mensaje VARCHAR(500) NULL,
    verificado_en DATETIME NULL,
    token_cache TEXT NULL,
    token_vence DATETIME NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ecf_amb_con (ambiente, conector)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO configuracion (clave, valor) VALUES
    ('negocio.razon_social', ''),
    ('negocio.nombre_comercial', 'Aloeve Art Studio'),
    ('negocio.rnc', ''),
    ('negocio.direccion', ''),
    ('negocio.telefono', ''),
    ('negocio.correo', ''),
    ('negocio.pie_recibo', 'Gracias por crear con nosotros.'),
    ('fiscal.itbis', '18'),
    ('fiscal.tipos_extra', ''),
    ('ecf.activo', '0'),
    ('ecf.conector', 'simulador'),
    ('ecf.ambiente', 'testecf')
ON DUPLICATE KEY UPDATE clave = clave;

INSERT INTO sedes (nombre) VALUES ('Plaza La Nube')
ON DUPLICATE KEY UPDATE nombre = nombre;
