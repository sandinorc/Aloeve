-- ERP Aloeve · Fase 2B: punto de venta, comprobantes fiscales y facturación electrónica

CREATE TABLE IF NOT EXISTS ventas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(20) NULL,
    fecha DATETIME NOT NULL,
    cliente_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NULL,
    sede_id INT UNSIGNED NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    descuento DECIMAL(12,2) NOT NULL DEFAULT 0,
    itbis DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL,
    cambio DECIMAL(12,2) NOT NULL DEFAULT 0,
    estado ENUM('completada','anulada') NOT NULL DEFAULT 'completada',
    motivo_anulacion VARCHAR(255) NULL,
    anulada_por INT UNSIGNED NULL,
    anulada_en DATETIME NULL,
    notas VARCHAR(255) NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_ventas_numero (numero),
    KEY ix_ventas_fecha (fecha, estado),
    KEY ix_ventas_cliente (cliente_id),
    CONSTRAINT fk_ventas_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS venta_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venta_id INT UNSIGNED NOT NULL,
    producto_id INT UNSIGNED NULL,
    descripcion VARCHAR(160) NOT NULL,
    cantidad DECIMAL(12,3) NOT NULL,
    precio_unitario DECIMAL(12,2) NOT NULL,
    descuento DECIMAL(12,2) NOT NULL DEFAULT 0,
    tasa_itbis DECIMAL(5,2) NOT NULL DEFAULT 0,
    itbis DECIMAL(12,2) NOT NULL DEFAULT 0,
    total DECIMAL(12,2) NOT NULL,
    es_servicio TINYINT(1) NOT NULL DEFAULT 0,
    KEY ix_vi_venta (venta_id),
    CONSTRAINT fk_vi_venta FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS venta_pagos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venta_id INT UNSIGNED NOT NULL,
    metodo ENUM('efectivo','tarjeta','transferencia','enlace','otro') NOT NULL,
    monto DECIMAL(12,2) NOT NULL,
    referencia VARCHAR(80) NULL,
    KEY ix_vp_venta (venta_id),
    CONSTRAINT fk_vp_venta FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comprobantes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ncf VARCHAR(13) NOT NULL,
    clase ENUM('papel','electronico') NOT NULL,
    tipo CHAR(3) NOT NULL,
    secuencia_id INT UNSIGNED NULL,
    vence_secuencia DATE NULL,
    venta_id INT UNSIGNED NULL,
    comprobante_origen_id INT UNSIGNED NULL,
    cliente_id INT UNSIGNED NULL,
    rnc_cedula VARCHAR(20) NULL,
    razon_social VARCHAR(200) NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    itbis DECIMAL(12,2) NOT NULL,
    total DECIMAL(12,2) NOT NULL,
    fecha DATETIME NOT NULL,
    estado ENUM('emitido','anulado') NOT NULL DEFAULT 'emitido',
    motivo_anulacion VARCHAR(255) NULL,
    ecf_estado ENUM('pendiente','en_proceso','aceptado','aceptado_condicional','rechazado','error') NULL,
    ecf_ambiente ENUM('testecf','certecf','ecf') NULL,
    ecf_simulado TINYINT(1) NOT NULL DEFAULT 0,
    codigo_seguridad CHAR(6) NULL,
    fecha_firma DATETIME NULL,
    track_id VARCHAR(80) NULL,
    usuario_id INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_comprobantes_ncf (ncf),
    KEY ix_comp_fecha (fecha, tipo),
    KEY ix_comp_venta (venta_id),
    KEY ix_comp_ecf (ecf_estado),
    CONSTRAINT fk_comp_venta FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE SET NULL,
    CONSTRAINT fk_comp_origen FOREIGN KEY (comprobante_origen_id) REFERENCES comprobantes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ecf_envios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    comprobante_id INT UNSIGNED NOT NULL,
    ambiente ENUM('testecf','certecf','ecf') NOT NULL,
    conector ENUM('simulador','dgii','proveedor') NOT NULL,
    documento ENUM('ecf','rfce') NOT NULL DEFAULT 'ecf',
    xml_firmado MEDIUMTEXT NULL,
    track_id VARCHAR(80) NULL,
    estado ENUM('pendiente','en_proceso','aceptado','aceptado_condicional','rechazado','error') NOT NULL DEFAULT 'pendiente',
    mensajes TEXT NULL,
    intentos SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    siguiente_intento DATETIME NULL,
    enviado_en DATETIME NULL,
    respondido_en DATETIME NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_envios_comp (comprobante_id),
    KEY ix_envios_estado (estado, siguiente_intento),
    CONSTRAINT fk_envios_comp FOREIGN KEY (comprobante_id) REFERENCES comprobantes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO configuracion (clave, valor) VALUES ('ventas.ultimo_numero', '0')
ON DUPLICATE KEY UPDATE clave = clave;
