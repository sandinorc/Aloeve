-- ERP Aloeve · Fase 2A: clientes, proveedores e inventario

CREATE TABLE IF NOT EXISTS clientes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(160) NOT NULL,
    tipo_documento ENUM('cedula','rnc','pasaporte','ninguno') NOT NULL DEFAULT 'ninguno',
    documento VARCHAR(20) NULL,
    razon_social VARCHAR(200) NULL,
    email VARCHAR(160) NULL,
    telefono VARCHAR(20) NULL,
    whatsapp VARCHAR(20) NULL,
    direccion VARCHAR(255) NULL,
    fecha_nacimiento DATE NULL,
    fuente ENUM('plaza','digital','referido','amelia','formulario','otro') NOT NULL DEFAULT 'plaza',
    referido_por_id INT UNSIGNED NULL,
    sede_id INT UNSIGNED NULL,
    notas TEXT NULL,
    origen ENUM('manual','amelia','formulario','migracion') NOT NULL DEFAULT 'manual',
    amelia_customer_id INT UNSIGNED NULL,
    fusionado_en_id INT UNSIGNED NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_por INT UNSIGNED NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_clientes_documento (documento),
    UNIQUE KEY uq_clientes_email (email),
    UNIQUE KEY uq_clientes_amelia (amelia_customer_id),
    KEY ix_clientes_telefono (telefono),
    KEY ix_clientes_nombre (nombre),
    KEY ix_clientes_activo (activo, nombre),
    CONSTRAINT fk_clientes_referido FOREIGN KEY (referido_por_id) REFERENCES clientes(id) ON DELETE SET NULL,
    CONSTRAINT fk_clientes_sede FOREIGN KEY (sede_id) REFERENCES sedes(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS proveedores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(160) NOT NULL,
    rnc VARCHAR(20) NULL,
    contacto VARCHAR(120) NULL,
    telefono VARCHAR(20) NULL,
    email VARCHAR(160) NULL,
    notas VARCHAR(500) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_proveedores_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS materiales (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(40) NOT NULL,
    nombre VARCHAR(160) NOT NULL,
    categoria VARCHAR(60) NOT NULL DEFAULT 'Otros',
    unidad VARCHAR(20) NOT NULL DEFAULT 'Unidad',
    stock DECIMAL(12,3) NOT NULL DEFAULT 0,
    stock_minimo DECIMAL(12,3) NOT NULL DEFAULT 0,
    costo_unitario DECIMAL(12,2) NOT NULL DEFAULT 0,
    proveedor_id INT UNSIGNED NULL,
    descripcion VARCHAR(500) NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_materiales_codigo (codigo),
    KEY ix_materiales_categoria (categoria),
    CONSTRAINT fk_materiales_proveedor FOREIGN KEY (proveedor_id) REFERENCES proveedores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS productos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(40) NOT NULL,
    nombre VARCHAR(160) NOT NULL,
    categoria VARCHAR(60) NOT NULL DEFAULT 'Otros',
    descripcion VARCHAR(500) NULL,
    precio DECIMAL(12,2) NOT NULL,
    lleva_itbis TINYINT(1) NOT NULL DEFAULT 1,
    costo DECIMAL(12,2) NULL,
    control_stock ENUM('ninguno','propio','material') NOT NULL DEFAULT 'propio',
    material_id INT UNSIGNED NULL,
    factor_material DECIMAL(12,3) NULL,
    stock DECIMAL(12,3) NOT NULL DEFAULT 0,
    stock_minimo DECIMAL(12,3) NOT NULL DEFAULT 0,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_productos_sku (sku),
    KEY ix_productos_categoria (categoria, activo),
    CONSTRAINT fk_productos_material FOREIGN KEY (material_id) REFERENCES materiales(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS movimientos_inventario (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tipo_item ENUM('material','producto') NOT NULL,
    item_id INT UNSIGNED NOT NULL,
    tipo ENUM('inicial','entrada','salida','ajuste','consumo_sesion','venta','anulacion_venta') NOT NULL,
    cantidad DECIMAL(12,3) NOT NULL,
    stock_anterior DECIMAL(12,3) NOT NULL,
    stock_resultante DECIMAL(12,3) NOT NULL,
    costo_unitario DECIMAL(12,2) NULL,
    proveedor_id INT UNSIGNED NULL,
    referencia VARCHAR(80) NULL,
    motivo VARCHAR(255) NULL,
    sesion_id INT UNSIGNED NULL,
    venta_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NULL,
    fecha DATETIME NOT NULL,
    KEY ix_mov_item (tipo_item, item_id, fecha),
    KEY ix_mov_fecha (fecha),
    KEY ix_mov_venta (venta_id),
    KEY ix_mov_sesion (sesion_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO configuracion (clave, valor) VALUES
    ('inventario.categorias', 'Pinturas,Lienzos,Pinceles,Papeles,Lápices,Marcadores,Accesorios,Bebidas,Comida,Decoración,Kits,Otros'),
    ('inventario.unidades', 'Unidad,Litro,Mililitro,Galón,Kg,Gramo,Paquete,Caja,Metro,Juego')
ON DUPLICATE KEY UPDATE clave = clave;
