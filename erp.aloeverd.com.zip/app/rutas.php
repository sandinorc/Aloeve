<?php
declare(strict_types=1);

use App\Core\Router;
use App\Modulos\Actividad\ActividadControlador as Actividad;
use App\Modulos\Auth\AuthControlador as Auth;
use App\Modulos\Configuracion\ConfiguracionControlador as Config;
use App\Modulos\Configuracion\ComprobantesControlador as Comprobantes;
use App\Modulos\Configuracion\EcfControlador as Ecf;
use App\Modulos\Clientes\ClientesControlador as Clientes;
use App\Modulos\Inventario\InventarioControlador as Inventario;
use App\Modulos\Agenda\AgendaControlador as Agenda;
use App\Modulos\Agenda\ServiciosControlador as Experiencias;
use App\Modulos\Agenda\FacilitadoresControlador as Facilitadores;
use App\Modulos\Finanzas\FinanzasControlador as Finanzas;
use App\Modulos\Panorama\PanoramaControlador as Panorama;
use App\Modulos\Roles\RolesControlador as Roles;
use App\Modulos\Setup\SetupControlador as Setup;
use App\Modulos\Usuarios\UsuariosControlador as Usuarios;
use App\Modulos\Ventas\PosControlador as Pos;
use App\Modulos\Ventas\VentasControlador as Ventas;

return static function (Router $r): void {
    $libre = ['auth' => false];

    // Instalación y actualizaciones
    $r->get('/setup', [Setup::class, 'inicio'], $libre);
    $r->post('/setup/base-datos', [Setup::class, 'baseDatos'], $libre);
    $r->post('/setup/admin', [Setup::class, 'admin'], $libre);
    $r->get('/setup/actualizar', [Setup::class, 'actualizar'], ['permiso' => 'configuracion.editar']);
    $r->post('/setup/actualizar', [Setup::class, 'aplicar'], ['permiso' => 'configuracion.editar']);

    // Sesión
    $r->get('/login', [Auth::class, 'formulario'], $libre);
    $r->post('/login', [Auth::class, 'entrar'], $libre);
    $r->post('/salir', [Auth::class, 'salir']);
    $r->get('/perfil/clave', [Auth::class, 'formularioClave']);
    $r->post('/perfil/clave', [Auth::class, 'cambiarClave']);

    // Panorama
    $r->get('/', [Panorama::class, 'inicio']);

    // Clientes
    $r->get('/clientes', [Clientes::class, 'lista'], ['permiso' => 'clientes.ver']);
    $r->get('/clientes/buscar', [Clientes::class, 'buscar'], ['permiso' => ['clientes.ver', 'pos.cobrar']]);
    $r->get('/clientes/exportar', [Clientes::class, 'exportar'], ['permiso' => 'clientes.editar']);
    $r->get('/clientes/segmentos', [Clientes::class, 'segmentos'], ['permiso' => 'clientes.ver']);
    $r->get('/clientes/nuevo', [Clientes::class, 'nuevo'], ['permiso' => 'clientes.crear']);
    $r->post('/clientes', [Clientes::class, 'crear'], ['permiso' => 'clientes.crear']);
    $r->get('/clientes/{id}', [Clientes::class, 'ver'], ['permiso' => 'clientes.ver']);
    $r->get('/clientes/{id}/editar', [Clientes::class, 'editar'], ['permiso' => 'clientes.editar']);
    $r->post('/clientes/{id}', [Clientes::class, 'guardar'], ['permiso' => 'clientes.editar']);
    $r->post('/clientes/{id}/estado', [Clientes::class, 'estado'], ['permiso' => 'clientes.editar']);
    $r->post('/clientes/{id}/fusionar', [Clientes::class, 'fusionar'], ['permiso' => 'clientes.editar']);

    // Punto de venta y ventas
    $caja = ['permiso' => 'pos.cobrar'];
    $histVentas = ['permiso' => ['pos.cobrar', 'finanzas.ver']];
    $r->get('/pos', [Pos::class, 'inicio'], $caja);
    $r->post('/pos/cobrar', [Pos::class, 'cobrar'], $caja);
    $r->get('/ventas', [Ventas::class, 'lista'], $histVentas);
    $r->get('/ventas/{id}', [Ventas::class, 'ver'], $histVentas);
    $r->get('/ventas/{id}/recibo', [Ventas::class, 'recibo'], $histVentas);
    $r->post('/ventas/{id}/anular', [Ventas::class, 'anular'], ['permiso' => 'comprobantes.anular']);

    // Comprobantes emitidos y cola e-CF
    $fiscal = ['permiso' => ['fiscal.ver', 'finanzas.ver']];
    $r->get('/comprobantes', [Ventas::class, 'comprobantes'], $fiscal);
    $r->post('/comprobantes/cola', [Ventas::class, 'procesarCola'], ['permiso' => ['comprobantes.emitir', 'fiscal.editar']]);
    $r->post('/comprobantes/{id}/reenviar', [Ventas::class, 'reenviar'], ['permiso' => ['comprobantes.emitir', 'fiscal.editar']]);
    $r->get('/comprobantes/envios/{id}/xml', [Ventas::class, 'xml'], ['permiso' => 'fiscal.ver']);
    $r->get('/cron/ecf', [Ventas::class, 'cron'], $libre);

    // Inventario
    $ver = ['permiso' => ['inventario.ver', 'inventario.editar']];
    $editar = ['permiso' => 'inventario.editar'];
    $r->get('/inventario', [Inventario::class, 'materiales'], $ver);
    $r->get('/inventario/materiales/nuevo', [Inventario::class, 'nuevoMaterial'], $editar);
    $r->post('/inventario/materiales', [Inventario::class, 'crearMaterial'], $editar);
    $r->get('/inventario/materiales/{id}', [Inventario::class, 'editarMaterial'], $editar);
    $r->post('/inventario/materiales/{id}', [Inventario::class, 'guardarMaterial'], $editar);
    $r->get('/inventario/productos', [Inventario::class, 'productos'], $ver);
    $r->get('/inventario/productos/nuevo', [Inventario::class, 'nuevoProducto'], $editar);
    $r->post('/inventario/productos', [Inventario::class, 'crearProducto'], $editar);
    $r->get('/inventario/productos/{id}', [Inventario::class, 'editarProducto'], $editar);
    $r->post('/inventario/productos/{id}', [Inventario::class, 'guardarProducto'], $editar);
    $r->get('/inventario/movimiento/{tipo}/{id}', [Inventario::class, 'formularioMovimiento'], $editar);
    $r->post('/inventario/movimiento/{tipo}/{id}', [Inventario::class, 'registrarMovimiento'], $editar);
    $r->get('/inventario/movimientos', [Inventario::class, 'movimientos'], $ver);
    $r->get('/inventario/movimientos/exportar', [Inventario::class, 'exportarMovimientos'], $ver);
    $r->get('/inventario/proveedores', [Inventario::class, 'proveedoresLista'], $ver);
    $r->post('/inventario/proveedores', [Inventario::class, 'crearProveedor'], $editar);
    $r->post('/inventario/proveedores/{id}', [Inventario::class, 'guardarProveedor'], $editar);

    // Agenda
    $agenda = ['permiso' => ['agenda.ver', 'agenda.dia', 'agenda.propias']];
    $agEditar = ['permiso' => 'agenda.editar'];
    $r->get('/agenda', [Agenda::class, 'calendario'], $agenda);
    $r->get('/agenda/sesiones', [Agenda::class, 'lista'], $agenda);
    $r->get('/agenda/sesiones/nueva', [Agenda::class, 'nueva'], $agEditar);
    $r->post('/agenda/sesiones', [Agenda::class, 'crear'], $agEditar);
    $r->get('/agenda/sesiones/{id}', [Agenda::class, 'ver'], $agenda);
    $r->get('/agenda/sesiones/{id}/editar', [Agenda::class, 'editar'], $agEditar);
    $r->post('/agenda/sesiones/{id}', [Agenda::class, 'guardar'], $agEditar);
    $r->post('/agenda/sesiones/{id}/estado', [Agenda::class, 'estado'], $agEditar);
    $r->post('/agenda/sesiones/{id}/reservas', [Agenda::class, 'agregarReserva'], $agenda);
    $r->get('/agenda/sesiones/{id}/cerrar', [Agenda::class, 'formularioCierre'], $agenda);
    $r->post('/agenda/sesiones/{id}/cerrar', [Agenda::class, 'cerrar'], $agenda);
    $r->post('/agenda/reservas/{id}/asistencia', [Agenda::class, 'asistencia'], $agenda);
    $r->post('/agenda/reservas/{id}/pago', [Agenda::class, 'pago'], $agenda);
    $r->post('/agenda/reservas/{id}/cancelar', [Agenda::class, 'cancelarReserva'], $agenda);
    $r->get('/agenda/reportes', [Agenda::class, 'reportes'], ['permiso' => 'agenda.ver']);
    $r->get('/agenda/experiencias', [Experiencias::class, 'lista'], ['permiso' => 'agenda.ver']);
    $r->get('/agenda/experiencias/nueva', [Experiencias::class, 'nuevo'], $agEditar);
    $r->post('/agenda/experiencias', [Experiencias::class, 'crear'], $agEditar);
    $r->get('/agenda/experiencias/{id}', [Experiencias::class, 'editar'], $agEditar);
    $r->post('/agenda/experiencias/{id}', [Experiencias::class, 'guardar'], $agEditar);
    $r->get('/facilitadores', [Facilitadores::class, 'lista'], ['permiso' => 'agenda.ver']);
    $r->get('/facilitadores/nuevo', [Facilitadores::class, 'nuevo'], $agEditar);
    $r->post('/facilitadores', [Facilitadores::class, 'crear'], $agEditar);
    $r->get('/facilitadores/{id}', [Facilitadores::class, 'editar'], $agEditar);
    $r->post('/facilitadores/{id}', [Facilitadores::class, 'guardar'], $agEditar);

    // Finanzas
    $fin = ['permiso' => 'finanzas.ver'];
    $finEditar = ['permiso' => 'finanzas.editar'];
    $r->get('/finanzas', [Finanzas::class, 'resumen'], $fin);
    $r->get('/finanzas/ingresos', [Finanzas::class, 'ingresos'], $fin);
    $r->post('/finanzas/ingresos', [Finanzas::class, 'crearIngreso'], $finEditar);
    $r->post('/finanzas/ingresos/{id}/anular', [Finanzas::class, 'anularIngreso'], $finEditar);
    $r->get('/finanzas/gastos', [Finanzas::class, 'gastos'], $fin);
    $r->post('/finanzas/gastos', [Finanzas::class, 'crearGasto'], $finEditar);
    $r->post('/finanzas/gastos/{id}/anular', [Finanzas::class, 'anularGasto'], $finEditar);
    $r->get('/finanzas/caja', [Finanzas::class, 'caja'], $fin);
    $r->post('/finanzas/caja', [Finanzas::class, 'movimientoCaja'], $finEditar);
    $r->get('/finanzas/reportes', [Finanzas::class, 'reportes'], $fin);
    $r->post('/finanzas/metas', [Finanzas::class, 'guardarMeta'], $finEditar);

    // Usuarios
    $r->get('/usuarios', [Usuarios::class, 'lista'], ['permiso' => 'usuarios.ver']);
    $r->get('/usuarios/nuevo', [Usuarios::class, 'nuevo'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios', [Usuarios::class, 'crear'], ['permiso' => 'usuarios.editar']);
    $r->get('/usuarios/{id}', [Usuarios::class, 'editar'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios/{id}', [Usuarios::class, 'guardar'], ['permiso' => 'usuarios.editar']);
    $r->post('/usuarios/{id}/clave', [Usuarios::class, 'restablecerClave'], ['permiso' => 'usuarios.editar']);

    // Roles y permisos
    $r->get('/roles', [Roles::class, 'lista'], ['permiso' => ['roles.editar', 'usuarios.ver']]);
    $r->get('/roles/{id}', [Roles::class, 'editar'], ['permiso' => ['roles.editar', 'usuarios.ver']]);
    $r->post('/roles/{id}', [Roles::class, 'guardar'], ['permiso' => 'roles.editar']);

    // Actividad
    $r->get('/actividad', [Actividad::class, 'lista'], ['permiso' => 'actividad.ver']);
    $r->get('/actividad/exportar', [Actividad::class, 'exportar'], ['permiso' => 'actividad.ver']);

    // Configuración
    $r->get('/configuracion', [Config::class, 'inicio'], ['permiso' => ['configuracion.editar', 'fiscal.ver']]);
    $r->get('/configuracion/negocio', [Config::class, 'negocio'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/negocio', [Config::class, 'guardarNegocio'], ['permiso' => 'configuracion.editar']);
    $r->get('/configuracion/sedes', [Config::class, 'sedes'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/sedes', [Config::class, 'crearSede'], ['permiso' => 'configuracion.editar']);
    $r->post('/configuracion/sedes/{id}', [Config::class, 'guardarSede'], ['permiso' => 'configuracion.editar']);

    // Comprobantes fiscales
    $r->get('/configuracion/comprobantes', [Comprobantes::class, 'inicio'], ['permiso' => 'fiscal.ver']);
    $r->post('/configuracion/comprobantes/secuencias', [Comprobantes::class, 'cargar'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/comprobantes/secuencias/{id}', [Comprobantes::class, 'editar'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/comprobantes/tipos', [Comprobantes::class, 'tipos'], ['permiso' => 'fiscal.editar']);

    // Facturación electrónica
    $r->get('/configuracion/ecf', [Ecf::class, 'inicio'], ['permiso' => 'fiscal.ver']);
    $r->post('/configuracion/ecf/modo', [Ecf::class, 'modo'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/ecf/{ambiente}/credenciales', [Ecf::class, 'credenciales'], ['permiso' => 'fiscal.editar']);
    $r->post('/configuracion/ecf/{ambiente}/probar', [Ecf::class, 'probar'], ['permiso' => 'fiscal.editar']);
};
