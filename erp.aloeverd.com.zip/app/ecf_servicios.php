<?php
/**
 * Servicios web de la DGII para e-CF (PRD §8.7.4).
 * {ambiente} se reemplaza por testecf, certecf o ecf.
 * Si la DGII cambia una ruta, se corrige solo aquí.
 */
return [
    'semilla' => 'https://ecf.dgii.gov.do/{ambiente}/autenticacion/api/autenticacion/semilla',
    'validar_semilla' => 'https://ecf.dgii.gov.do/{ambiente}/autenticacion/api/autenticacion/validarsemilla',
    'recepcion' => 'https://ecf.dgii.gov.do/{ambiente}/recepcion/api/facturaselectronicas',
    'consulta_resultado' => 'https://ecf.dgii.gov.do/{ambiente}/consultaresultado/api/consultas/estado',
    'consulta_estado' => 'https://ecf.dgii.gov.do/{ambiente}/consultaestado/api/consultas/estado',
    'consulta_trackids' => 'https://ecf.dgii.gov.do/{ambiente}/consultatrackids/api/trackids/consulta',
    'recepcion_fc' => 'https://fc.dgii.gov.do/{ambiente}/recepcionfc/api/recepcion/ecf',
    'consulta_fc' => 'https://fc.dgii.gov.do/{ambiente}/consultarfce/api/Consultas/Consulta',
    'anulacion_rangos' => 'https://ecf.dgii.gov.do/{ambiente}/anulacionrangos/api/operaciones/anularrango',
    'aprobacion_comercial' => 'https://ecf.dgii.gov.do/{ambiente}/aprobacioncomercial/api/aprobacioncomercial',
    'timbre' => 'https://ecf.dgii.gov.do/{ambiente}/ConsultaTimbre',
    'timbre_fc' => 'https://fc.dgii.gov.do/{ambiente}/ConsultaTimbreFC',
    'estado_servicios' => 'https://statusecf.dgii.gov.do/api/estatusservicios/obtenerestatus',

    // Monto desde el cual una factura de consumo (E32) se envía completa y no como resumen (RFCE)
    'limite_rfce' => 250000,
];
