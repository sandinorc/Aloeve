<?php
declare(strict_types=1);

define('RAIZ', dirname(__DIR__));
define('APP', RAIZ . '/app');
define('STORAGE', RAIZ . '/storage');
define('VERSION_ERP', '1.3.0-fase2b');

date_default_timezone_set('America/Santo_Domingo');
mb_internal_encoding('UTF-8');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// Autocarga: librerías de vendor + clases propias en App\
if (is_file(RAIZ . '/vendor/autoload.php')) {
    require RAIZ . '/vendor/autoload.php';
}
spl_autoload_register(static function (string $clase): void {
    if (str_starts_with($clase, 'App\\')) {
        $ruta = APP . '/' . str_replace('\\', '/', substr($clase, 4)) . '.php';
        if (is_file($ruta)) {
            require $ruta;
        }
    }
});

require APP . '/helpers.php';
