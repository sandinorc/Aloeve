<?php
/**
 * Catálogo de permisos y permisos por defecto de cada rol (PRD §5).
 * El Administrador puede ajustar los permisos de cada rol desde la pantalla de Roles.
 */
return [
    'catalogo' => [
        'Panorama' => [
            'panorama.ver' => 'Ver el panorama del negocio',
        ],
        'Clientes' => [
            'clientes.ver' => 'Ver clientes',
            'clientes.crear' => 'Crear clientes',
            'clientes.editar' => 'Editar y fusionar clientes',
        ],
        'Agenda' => [
            'agenda.ver' => 'Ver toda la agenda',
            'agenda.dia' => 'Ver la agenda del día y hacer check-in',
            'agenda.propias' => 'Ver solo sus propias sesiones (facilitador)',
            'agenda.editar' => 'Crear y editar sesiones',
        ],
        'Cursos y talleres' => [
            'cursos.ver' => 'Ver cursos e inscripciones',
            'cursos.editar' => 'Crear y editar cursos e inscripciones',
            'solicitudes.ver' => 'Ver y atender solicitudes web',
        ],
        'Inventario' => [
            'inventario.ver' => 'Ver inventario',
            'inventario.consumo' => 'Registrar consumo de materiales',
            'inventario.editar' => 'Crear, editar y ajustar inventario',
        ],
        'Ventas' => [
            'pos.cobrar' => 'Cobrar en el punto de venta',
            'pos.descuento' => 'Aplicar descuentos',
            'comprobantes.emitir' => 'Emitir comprobantes fiscales',
            'comprobantes.anular' => 'Anular ventas y comprobantes',
        ],
        'Finanzas' => [
            'finanzas.ver' => 'Ver finanzas y reportes',
            'finanzas.editar' => 'Registrar ingresos, gastos y metas',
        ],
        'Administración' => [
            'usuarios.ver' => 'Ver usuarios',
            'usuarios.editar' => 'Crear y editar usuarios',
            'roles.editar' => 'Editar permisos de los roles',
            'actividad.ver' => 'Ver el registro de actividad',
            'fiscal.ver' => 'Ver secuencias y conexión e-CF',
            'fiscal.editar' => 'Cargar secuencias y configurar e-CF',
            'configuracion.editar' => 'Editar datos del negocio y sedes',
            'integraciones.editar' => 'Configurar integraciones con WordPress',
        ],
    ],

    'roles' => [
        'admin' => [
            'nombre' => 'Administrador',
            'descripcion' => 'Acceso completo, incluida configuración técnica e integraciones.',
            'permisos' => '*',
        ],
        'fundadora' => [
            'nombre' => 'Fundadora',
            'descripcion' => 'Todo excepto configuración técnica e integraciones.',
            'permisos' => [
                'panorama.ver', 'clientes.ver', 'clientes.crear', 'clientes.editar',
                'agenda.ver', 'agenda.dia', 'agenda.editar', 'cursos.ver', 'cursos.editar', 'solicitudes.ver',
                'inventario.ver', 'inventario.consumo', 'inventario.editar',
                'pos.cobrar', 'pos.descuento', 'comprobantes.emitir', 'comprobantes.anular',
                'finanzas.ver', 'finanzas.editar', 'usuarios.ver', 'actividad.ver', 'fiscal.ver',
                'configuracion.editar',
            ],
        ],
        'gerente' => [
            'nombre' => 'Gerente de estudio',
            'descripcion' => 'Operación diaria de la sede. No anula comprobantes ni cambia la configuración.',
            'permisos' => [
                'panorama.ver', 'clientes.ver', 'clientes.crear', 'clientes.editar',
                'agenda.ver', 'agenda.dia', 'agenda.editar', 'cursos.ver', 'cursos.editar', 'solicitudes.ver',
                'inventario.ver', 'inventario.consumo', 'inventario.editar',
                'pos.cobrar', 'pos.descuento', 'comprobantes.emitir', 'finanzas.ver',
            ],
        ],
        'caja' => [
            'nombre' => 'Caja',
            'descripcion' => 'Mostrador: cobra, busca y crea clientes, hace check-in.',
            'permisos' => [
                'clientes.ver', 'clientes.crear', 'agenda.dia', 'cursos.ver', 'inventario.ver',
                'pos.cobrar', 'comprobantes.emitir',
            ],
        ],
        'facilitador' => [
            'nombre' => 'Facilitador',
            'descripcion' => 'Ve solo sus sesiones, marca asistencia y registra materiales usados.',
            'permisos' => ['agenda.propias', 'inventario.consumo'],
        ],
    ],
];
