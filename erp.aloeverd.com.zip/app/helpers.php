<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Config;
use App\Core\Csrf;

/** Escapa texto para HTML. Usar en TODA salida. */
function e(mixed $valor): string
{
    return htmlspecialchars((string) ($valor ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** URL absoluta dentro del ERP. */
function url(string $ruta = '/'): string
{
    $base = rtrim((string) Config::get('app.url', ''), '/');
    return $base . '/' . ltrim($ruta, '/');
}

/** Archivo estático con versión para romper caché. */
function asset(string $ruta): string
{
    $archivo = RAIZ . '/public_html/assets/' . ltrim($ruta, '/');
    $v = is_file($archivo) ? (string) filemtime($archivo) : VERSION_ERP;
    return url('assets/' . ltrim($ruta, '/')) . '?v=' . $v;
}

/** Ícono SVG en línea. */
function icono(string $nombre, string $clases = 'w-5 h-5'): string
{
    static $iconos = null;
    $iconos ??= require APP . '/iconos.php';
    $cuerpo = $iconos[$nombre] ?? $iconos['punto'];
    return '<svg xmlns="http://www.w3.org/2000/svg" class="' . e($clases) . '" viewBox="0 0 24 24" fill="none" '
        . 'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . $cuerpo . '</svg>';
}

function csrf_campo(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function usuario(): ?array
{
    return Auth::usuario();
}

function puede(string $permiso): bool
{
    return Auth::puede($permiso);
}

function redirigir(string $ruta): never
{
    header('Location: ' . (str_starts_with($ruta, 'http') ? $ruta : url($ruta)));
    exit;
}

function json(mixed $datos, int $codigo = 200): never
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dinero(float|int|string|null $monto): string
{
    return 'RD$ ' . number_format((float) $monto, 2, '.', ',');
}

/** Fecha legible: 02/10/2026 o 02/10/2026 14:05 */
function fecha(?string $valor, bool $conHora = false): string
{
    if (!$valor) {
        return '—';
    }
    $t = strtotime($valor);
    return $t ? date($conHora ? 'd/m/Y H:i' : 'd/m/Y', $t) : '—';
}

/** Valor anterior de un formulario (tras un error de validación). */
function viejo(string $campo, mixed $porDefecto = ''): string
{
    $v = $_SESSION['_viejo'][$campo] ?? $porDefecto;
    return is_scalar($v) ? (string) $v : '';
}

function post(string $campo, string $porDefecto = ''): string
{
    $v = $_POST[$campo] ?? $porDefecto;
    return is_string($v) ? trim($v) : $porDefecto;
}

function get(string $campo, string $porDefecto = ''): string
{
    $v = $_GET[$campo] ?? $porDefecto;
    return is_string($v) ? trim($v) : $porDefecto;
}

function es_ajax(): bool
{
    return ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch'
        || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');
}

function iniciales(string $nombre): string
{
    $partes = preg_split('/\s+/', trim($nombre)) ?: [];
    $ini = '';
    foreach (array_slice($partes, 0, 2) as $p) {
        $ini .= mb_strtoupper(mb_substr($p, 0, 1));
    }
    return $ini ?: '?';
}

function registrar_error(string $mensaje): void
{
    $dir = STORAGE . '/logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    @file_put_contents(
        $dir . '/app-' . date('Y-m-d') . '.log',
        '[' . date('Y-m-d H:i:s') . '] ' . $mensaje . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}
