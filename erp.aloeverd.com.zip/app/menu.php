<?php
/**
 * Menú lateral (PRD §6.3). Cada opción se muestra solo si el usuario tiene alguno de sus permisos.
 * 'fase' marca opciones que todavía no existen: se muestran atenuadas con la etiqueta de la fase.
 */
return [
    'Vista general' => [
        ['texto' => 'Panorama', 'ruta' => '/', 'icono' => 'panel', 'permiso' => ['panorama.ver']],
    ],
    'Clientes' => [
        ['texto' => 'Directorio', 'ruta' => '/clientes', 'icono' => 'clientes', 'permiso' => ['clientes.ver']],
        ['texto' => 'Segmentos e inactivos', 'ruta' => '/clientes/segmentos', 'icono' => 'filtro', 'permiso' => ['clientes.ver']],
    ],
    'Agenda' => [
        ['texto' => 'Calendario', 'ruta' => '/agenda', 'icono' => 'agenda', 'permiso' => ['agenda.ver', 'agenda.dia', 'agenda.propias']],
        ['texto' => 'Sesiones', 'ruta' => '/agenda/sesiones', 'icono' => 'reloj', 'permiso' => ['agenda.ver', 'agenda.dia', 'agenda.propias']],
        ['texto' => 'Experiencias', 'ruta' => '/agenda/experiencias', 'icono' => 'etiqueta', 'permiso' => ['agenda.ver']],
        ['texto' => 'Facilitadores', 'ruta' => '/facilitadores', 'icono' => 'usuario', 'permiso' => ['agenda.ver']],
        ['texto' => 'Reportes de agenda', 'ruta' => '/agenda/reportes', 'icono' => 'grafico', 'permiso' => ['agenda.ver']],
        ['texto' => 'Reservas web', 'ruta' => '/agenda/reservas-web', 'icono' => 'bandeja', 'permiso' => ['agenda.ver'], 'fase' => 3],
    ],
    'Cursos y talleres' => [
        ['texto' => 'Cursos', 'ruta' => '/cursos', 'icono' => 'cursos', 'permiso' => ['cursos.ver'], 'fase' => 3],
        ['texto' => 'Solicitudes web', 'ruta' => '/solicitudes', 'icono' => 'bandeja', 'permiso' => ['solicitudes.ver'], 'fase' => 3],
    ],
    'Ventas' => [
        ['texto' => 'Punto de venta', 'ruta' => '/pos', 'icono' => 'venta', 'permiso' => ['pos.cobrar']],
        ['texto' => 'Historial de ventas', 'ruta' => '/ventas', 'icono' => 'recibo', 'permiso' => ['pos.cobrar', 'finanzas.ver']],
        ['texto' => 'Comprobantes emitidos', 'ruta' => '/comprobantes', 'icono' => 'archivo', 'permiso' => ['fiscal.ver', 'finanzas.ver']],
    ],
    'Inventario' => [
        ['texto' => 'Materiales y productos', 'ruta' => '/inventario', 'icono' => 'inventario', 'permiso' => ['inventario.ver', 'inventario.editar']],
        ['texto' => 'Movimientos', 'ruta' => '/inventario/movimientos', 'icono' => 'refrescar', 'permiso' => ['inventario.ver', 'inventario.editar']],
        ['texto' => 'Proveedores', 'ruta' => '/inventario/proveedores', 'icono' => 'tienda', 'permiso' => ['inventario.ver', 'inventario.editar']],
    ],
    'Finanzas' => [
        ['texto' => 'Resumen', 'ruta' => '/finanzas', 'icono' => 'finanzas', 'permiso' => ['finanzas.ver']],
        ['texto' => 'Ingresos', 'ruta' => '/finanzas/ingresos', 'icono' => 'tarjeta', 'permiso' => ['finanzas.ver']],
        ['texto' => 'Gastos', 'ruta' => '/finanzas/gastos', 'icono' => 'recibo', 'permiso' => ['finanzas.ver']],
        ['texto' => 'Reportes y metas', 'ruta' => '/finanzas/reportes', 'icono' => 'grafico', 'permiso' => ['finanzas.ver']],
    ],
    'Administración' => [
        ['texto' => 'Usuarios', 'ruta' => '/usuarios', 'icono' => 'usuario', 'permiso' => ['usuarios.ver']],
        ['texto' => 'Roles y permisos', 'ruta' => '/roles', 'icono' => 'escudo', 'permiso' => ['roles.editar', 'usuarios.ver']],
        ['texto' => 'Actividad', 'ruta' => '/actividad', 'icono' => 'actividad', 'permiso' => ['actividad.ver']],
        ['texto' => 'Comprobantes fiscales', 'ruta' => '/configuracion/comprobantes', 'icono' => 'archivo', 'permiso' => ['fiscal.ver']],
        ['texto' => 'Facturación electrónica', 'ruta' => '/configuracion/ecf', 'icono' => 'rayo', 'permiso' => ['fiscal.ver']],
        ['texto' => 'Configuración', 'ruta' => '/configuracion', 'icono' => 'ajustes', 'permiso' => ['configuracion.editar']],
    ],
];
