<?php
declare(strict_types=1);

namespace App\Core;

/** Sesión, inicio de sesión, bloqueo por intentos y permisos. */
final class Auth
{
    public const MAX_INTENTOS = 5;
    public const MINUTOS_BLOQUEO = 15;
    public const MINUTOS_INACTIVIDAD = 60;
    public const HORAS_SESION = 8;

    private static ?array $usuario = null;
    private static ?array $permisos = null;

    public static function iniciarSesion(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $https = str_starts_with((string) Config::get('app.url'), 'https');
        session_name('aloeve_erp');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $https,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.gc_maxlifetime', (string) (self::HORAS_SESION * 3600));
        session_start();

        // Vencimiento por inactividad o por duración total
        $ahora = time();
        if (isset($_SESSION['uid'])) {
            $inactivo = $ahora - (int) ($_SESSION['ultimo_uso'] ?? $ahora);
            $total = $ahora - (int) ($_SESSION['inicio'] ?? $ahora);
            if ($inactivo > self::MINUTOS_INACTIVIDAD * 60 || $total > self::HORAS_SESION * 3600) {
                self::cerrar();
                Flash::aviso('Tu sesión venció. Vuelve a entrar.');
                return;
            }
        }
        $_SESSION['ultimo_uso'] = $ahora;
    }

    public static function usuario(): ?array
    {
        if (self::$usuario !== null) {
            return self::$usuario;
        }
        $id = (int) ($_SESSION['uid'] ?? 0);
        if ($id <= 0) {
            return null;
        }
        $u = DB::uno(
            'SELECT u.*, r.clave AS rol_clave, r.nombre AS rol_nombre
               FROM usuarios u JOIN roles r ON r.id = u.rol_id
              WHERE u.id = ? AND u.activo = 1',
            [$id]
        );
        if (!$u) {
            self::cerrar();
            return null;
        }
        unset($u['password_hash']);
        return self::$usuario = $u;
    }

    public static function id(): ?int
    {
        $u = self::usuario();
        return $u ? (int) $u['id'] : null;
    }

    public static function permisos(): array
    {
        if (self::$permisos !== null) {
            return self::$permisos;
        }
        $u = self::usuario();
        if (!$u) {
            return self::$permisos = [];
        }
        if ($u['rol_clave'] === 'admin') {
            return self::$permisos = ['*'];
        }
        $filas = DB::todos('SELECT permiso FROM rol_permisos WHERE rol_id = ?', [$u['rol_id']]);
        return self::$permisos = array_column($filas, 'permiso');
    }

    public static function puede(string $permiso): bool
    {
        $p = self::permisos();
        return in_array('*', $p, true) || in_array($permiso, $p, true);
    }

    public static function ip(): string
    {
        return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    }

    /**
     * Intenta entrar. Devuelve null si entró, o el mensaje de error.
     * El mensaje no revela si el correo existe.
     */
    public static function intentar(string $email, string $clave): ?string
    {
        $email = mb_strtolower(trim($email));
        $ip = self::ip();
        $ventana = date('Y-m-d H:i:s', time() - self::MINUTOS_BLOQUEO * 60);

        $fallosCorreo = (int) DB::valor(
            'SELECT COUNT(*) FROM login_intentos WHERE email = ? AND exito = 0 AND fecha > ?',
            [$email, $ventana]
        );
        $fallosIp = (int) DB::valor(
            'SELECT COUNT(*) FROM login_intentos WHERE ip = ? AND exito = 0 AND fecha > ?',
            [$ip, $ventana]
        );
        if ($fallosCorreo >= self::MAX_INTENTOS || $fallosIp >= self::MAX_INTENTOS * 4) {
            return 'Demasiados intentos. Espera ' . self::MINUTOS_BLOQUEO . ' minutos y vuelve a probar.';
        }

        $u = DB::uno('SELECT * FROM usuarios WHERE email = ?', [$email]);
        $ok = $u && (int) $u['activo'] === 1 && password_verify($clave, (string) $u['password_hash']);

        DB::insertar('login_intentos', [
            'email' => $email,
            'ip' => $ip,
            'exito' => $ok ? 1 : 0,
            'fecha' => date('Y-m-d H:i:s'),
        ]);

        if (!$ok) {
            return 'Correo o contraseña incorrectos.';
        }

        if (password_needs_rehash((string) $u['password_hash'], PASSWORD_DEFAULT)) {
            DB::actualizar('usuarios', ['password_hash' => password_hash($clave, PASSWORD_DEFAULT)], 'id = ?', [$u['id']]);
        }

        session_regenerate_id(true);
        $_SESSION['uid'] = (int) $u['id'];
        $_SESSION['inicio'] = time();
        $_SESSION['ultimo_uso'] = time();
        unset($_SESSION['_csrf']);
        self::$usuario = null;
        self::$permisos = null;

        DB::actualizar('usuarios', ['ultimo_acceso' => date('Y-m-d H:i:s')], 'id = ?', [$u['id']]);
        Actividad::registrar('sesion', 'entrar', 'usuarios', (int) $u['id'], 'Inició sesión');
        return null;
    }

    public static function cerrar(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        self::$usuario = null;
        self::$permisos = null;
        // Sesión limpia para mensajes posteriores
        session_start();
    }

    public static function validarClave(string $clave): ?string
    {
        if (mb_strlen($clave) < 10) {
            return 'La contraseña debe tener al menos 10 caracteres.';
        }
        if (!preg_match('/[a-záéíóúñ]/u', $clave) || !preg_match('/[A-ZÁÉÍÓÚÑ]/u', $clave) || !preg_match('/\d/', $clave)) {
            return 'La contraseña debe tener mayúsculas, minúsculas y al menos un número.';
        }
        return null;
    }

    public static function claveTemporal(): string
    {
        $alfabeto = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        $c = '';
        for ($i = 0; $i < 12; $i++) {
            $c .= $alfabeto[random_int(0, strlen($alfabeto) - 1)];
        }
        // Garantiza mayúscula, minúscula y número
        return 'A' . $c . 'a7';
    }
}
