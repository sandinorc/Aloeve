<?php
declare(strict_types=1);

namespace App\Core;

/** Configuración del negocio guardada en la tabla `configuracion` (clave → valor). */
final class Ajustes
{
    private static ?array $cache = null;

    public static function todos(): array
    {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (DB::todos('SELECT clave, valor FROM configuracion') as $f) {
                self::$cache[$f['clave']] = $f['valor'];
            }
        }
        return self::$cache;
    }

    public static function get(string $clave, ?string $porDefecto = null): ?string
    {
        return self::todos()[$clave] ?? $porDefecto;
    }

    public static function set(string $clave, ?string $valor): void
    {
        DB::q(
            'INSERT INTO configuracion (clave, valor, actualizado_en) VALUES (?, ?, NOW())
             ON DUPLICATE KEY UPDATE valor = VALUES(valor), actualizado_en = NOW()',
            [$clave, $valor]
        );
        self::$cache = null;
    }
}
