<?php
declare(strict_types=1);

namespace App\Core;

/** Aplica en orden y una sola vez los archivos de database/migraciones/*.sql */
final class Migrador
{
    public static function archivos(): array
    {
        $lista = glob(RAIZ . '/database/migraciones/*.sql') ?: [];
        sort($lista, SORT_STRING);
        return $lista;
    }

    public static function aplicadas(): array
    {
        try {
            return array_column(DB::todos('SELECT version FROM migraciones'), 'version');
        } catch (\PDOException) {
            return [];
        }
    }

    public static function pendientes(): array
    {
        $hechas = self::aplicadas();
        return array_values(array_filter(
            self::archivos(),
            static fn($f) => !in_array(basename($f, '.sql'), $hechas, true)
        ));
    }

    /** @return string[] versiones aplicadas */
    public static function aplicar(): array
    {
        DB::pdo()->exec(
            'CREATE TABLE IF NOT EXISTS migraciones (
                version VARCHAR(100) NOT NULL PRIMARY KEY,
                aplicada_en DATETIME NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
        $hechas = [];
        foreach (self::pendientes() as $archivo) {
            $version = basename($archivo, '.sql');
            foreach (self::sentencias((string) file_get_contents($archivo)) as $sql) {
                DB::pdo()->exec($sql);
            }
            DB::insertar('migraciones', ['version' => $version, 'aplicada_en' => date('Y-m-d H:i:s')]);
            $hechas[] = $version;
        }
        return $hechas;
    }

    /** Divide un archivo SQL en sentencias (las sentencias terminan en ";" al final de línea). */
    public static function sentencias(string $sql): array
    {
        $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? '';
        $partes = preg_split('/;\s*$/m', $sql) ?: [];
        return array_values(array_filter(array_map('trim', $partes), static fn($s) => $s !== ''));
    }
}
