<?php
declare(strict_types=1);

namespace App\Core;

/** Plantillas PHP en app/Vistas. */
final class View
{
    public static function render(string $vista, array $datos = [], ?string $layout = 'layout'): string
    {
        $contenido = self::parcial($vista, $datos);
        if ($layout === null) {
            return $contenido;
        }
        return self::parcial($layout, [...$datos, 'contenido' => $contenido]);
    }

    public static function parcial(string $vista, array $datos = []): string
    {
        $archivo = APP . '/Vistas/' . $vista . '.php';
        if (!is_file($archivo)) {
            throw new \RuntimeException("Vista no encontrada: $vista");
        }
        extract($datos, EXTR_SKIP);
        ob_start();
        require $archivo;
        return (string) ob_get_clean();
    }

    public static function mostrar(string $vista, array $datos = [], ?string $layout = 'layout', int $codigo = 200): never
    {
        http_response_code($codigo);
        header('Content-Type: text/html; charset=utf-8');
        echo self::render($vista, $datos, $layout);
        Flash::limpiarFormulario();
        exit;
    }
}
