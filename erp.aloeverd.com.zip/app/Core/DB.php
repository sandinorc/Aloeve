<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOStatement;
use Throwable;

/** Acceso a MySQL con PDO. Siempre sentencias preparadas. */
final class DB
{
    private static ?PDO $pdo = null;

    public static function conectar(array $c): PDO
    {
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $c['host'] ?? 'localhost',
            (int) ($c['puerto'] ?? 3306),
            $c['nombre'] ?? ''
        );
        $pdo = new PDO($dsn, (string) ($c['usuario'] ?? ''), (string) ($c['clave'] ?? ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ]);
        $pdo->exec("SET time_zone = '-04:00'");
        return $pdo;
    }

    public static function pdo(): PDO
    {
        return self::$pdo ??= self::conectar((array) Config::get('db', []));
    }

    public static function usar(PDO $pdo): void
    {
        self::$pdo = $pdo;
    }

    public static function q(string $sql, array $params = []): PDOStatement
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st;
    }

    public static function uno(string $sql, array $params = []): ?array
    {
        $fila = self::q($sql, $params)->fetch();
        return $fila === false ? null : $fila;
    }

    public static function todos(string $sql, array $params = []): array
    {
        return self::q($sql, $params)->fetchAll();
    }

    public static function valor(string $sql, array $params = []): mixed
    {
        $v = self::q($sql, $params)->fetchColumn();
        return $v === false ? null : $v;
    }

    /** Inserta y devuelve el id. Las columnas vienen del código, nunca del usuario. */
    public static function insertar(string $tabla, array $datos): int
    {
        $cols = array_keys($datos);
        $sql = sprintf(
            'INSERT INTO `%s` (`%s`) VALUES (%s)',
            $tabla,
            implode('`,`', $cols),
            implode(',', array_fill(0, count($cols), '?'))
        );
        self::q($sql, array_values($datos));
        return (int) self::pdo()->lastInsertId();
    }

    public static function actualizar(string $tabla, array $datos, string $donde, array $params = []): int
    {
        $sets = implode(', ', array_map(static fn($c) => "`$c` = ?", array_keys($datos)));
        $st = self::q("UPDATE `$tabla` SET $sets WHERE $donde", [...array_values($datos), ...$params]);
        return $st->rowCount();
    }

    /** Ejecuta dentro de una transacción. */
    public static function tx(callable $fn): mixed
    {
        $pdo = self::pdo();
        if ($pdo->inTransaction()) {
            return $fn();
        }
        $pdo->beginTransaction();
        try {
            $r = $fn();
            $pdo->commit();
            return $r;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
