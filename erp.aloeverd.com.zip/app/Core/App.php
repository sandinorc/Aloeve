<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

final class App
{
    public static function instalado(): bool
    {
        return Config::existe() && is_file(STORAGE . '/instalado.lock');
    }

    public static function ejecutar(): void
    {
        set_exception_handler([self::class, 'fallo']);
        self::encabezados();

        $metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $ruta = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
        $ruta = $ruta === '' ? '/' : $ruta;

        Auth::iniciarSesion();

        // Antes de instalar, todo va al instalador
        if (!self::instalado() && !str_starts_with($ruta, '/setup')) {
            redirigir('/setup');
        }

        $router = new Router();
        (require APP . '/rutas.php')($router);
        [$r, $params, $otroMetodo] = $router->buscar($metodo, $ruta);

        if ($r === null) {
            if ($otroMetodo) {
                http_response_code(405);
                exit('Método no permitido');
            }
            self::error(404);
        }

        $op = $r['opciones'];

        if ($metodo === 'POST' && ($op['csrf'] ?? true) && !Csrf::valido()) {
            if (es_ajax()) {
                json(['ok' => false, 'mensaje' => 'La página venció. Recárgala e intenta de nuevo.'], 419);
            }
            Flash::error('La página venció. Intenta de nuevo.');
            redirigir($ruta);
        }

        if ($op['auth'] ?? true) {
            if (!Auth::usuario()) {
                if (es_ajax()) {
                    json(['ok' => false, 'mensaje' => 'Tu sesión venció. Vuelve a entrar.'], 401);
                }
                if ($metodo === 'GET') {
                    $_SESSION['volver_a'] = $ruta;
                }
                redirigir('/login');
            }
            $u = Auth::usuario();
            if ((int) $u['debe_cambiar_clave'] === 1 && !in_array($ruta, ['/perfil/clave', '/salir'], true)) {
                redirigir('/perfil/clave');
            }
            // Si se subió una fase nueva y falta actualizar la base de datos
            if (!str_starts_with($ruta, '/setup') && $ruta !== '/salir' && Migrador::pendientes()) {
                if (in_array('*', Auth::permisos(), true)) {
                    Flash::aviso('Subiste una versión nueva. Aplica la actualización de la base de datos para continuar.');
                    redirigir('/setup/actualizar');
                }
                View::mostrar('errores/mantenimiento', ['titulo' => 'En actualización'], 'layout_simple', 503);
            }
            if (isset($op['permiso'])) {
                $permisos = (array) $op['permiso'];
                $ok = false;
                foreach ($permisos as $p) {
                    $ok = $ok || Auth::puede($p);
                }
                if (!$ok) {
                    self::error(403);
                }
            }
        }

        [$clase, $accion] = $r['accion'];
        (new $clase())->$accion(...array_values($params));
    }

    private static function encabezados(): void
    {
        header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
            . "script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header_remove('X-Powered-By');
    }

    public static function error(int $codigo): never
    {
        if (es_ajax()) {
            json(['ok' => false, 'mensaje' => $codigo === 403 ? 'No tienes permiso para esta acción.' : 'No encontrado.'], $codigo);
        }
        $layout = Auth::usuario() ? 'layout' : 'layout_simple';
        View::mostrar('errores/' . $codigo, ['titulo' => $codigo === 403 ? 'Sin permiso' : 'No encontrado'], $layout, $codigo);
    }

    public static function fallo(Throwable $e): void
    {
        $ref = strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        registrar_error("[$ref] " . get_class($e) . ': ' . $e->getMessage() . ' en ' . $e->getFile() . ':' . $e->getLine()
            . "\n" . $e->getTraceAsString());
        if (!headers_sent()) {
            http_response_code(500);
        }
        if (es_ajax()) {
            echo json_encode(['ok' => false, 'mensaje' => "Ocurrió un error. Referencia $ref."]);
            return;
        }
        try {
            echo View::render('errores/500', ['titulo' => 'Error', 'referencia' => $ref], 'layout_simple');
        } catch (Throwable) {
            echo "Ocurrió un error. Referencia $ref.";
        }
    }
}
