<?php
declare(strict_types=1);

namespace App\Core;

/** Lee config/config.php (fuera de public_html). */
final class Config
{
    private static ?array $datos = null;

    public static function archivo(): string
    {
        return RAIZ . '/config/config.php';
    }

    public static function existe(): bool
    {
        return is_file(self::archivo());
    }

    public static function cargar(): void
    {
        if (self::$datos === null) {
            self::$datos = self::existe() ? (array) require self::archivo() : [];
        }
    }

    public static function get(string $clave, mixed $porDefecto = null): mixed
    {
        self::cargar();
        $valor = self::$datos;
        foreach (explode('.', $clave) as $parte) {
            if (!is_array($valor) || !array_key_exists($parte, $valor)) {
                if ($clave === 'app.url') {
                    return self::urlDetectada();
                }
                return $porDefecto;
            }
            $valor = $valor[$parte];
        }
        return $valor;
    }

    /** URL base detectada desde la petición (se usa antes de instalar). */
    public static function urlDetectada(): string
    {
        $https = (($_SERVER['HTTPS'] ?? '') !== '' && ($_SERVER['HTTPS'] ?? '') !== 'off')
            || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return ($https ? 'https' : 'http') . '://' . $host;
    }

    /** Escribe el archivo de configuración. Devuelve false si no tiene permiso. */
    public static function escribir(array $datos): bool
    {
        $contenido = "<?php\n// Configuración del ERP Aloeve. Generado por el instalador el "
            . date('Y-m-d H:i') . ".\n// No compartas este archivo: contiene claves.\n\nreturn "
            . var_export($datos, true) . ";\n";
        $ok = @file_put_contents(self::archivo(), $contenido, LOCK_EX) !== false;
        if ($ok) {
            @chmod(self::archivo(), 0640);
            self::$datos = $datos;
        }
        return $ok;
    }

    public static function contenidoPara(array $datos): string
    {
        return "<?php\nreturn " . var_export($datos, true) . ";\n";
    }
}
