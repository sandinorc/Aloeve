<?php
declare(strict_types=1);

namespace App\Core;

/** Enrutador mínimo: método + patrón con {parametros}. */
final class Router
{
    /** @var array<int, array{metodo:string, patron:string, accion:array, opciones:array}> */
    private array $rutas = [];

    public function get(string $patron, array $accion, array $opciones = []): void
    {
        $this->agregar('GET', $patron, $accion, $opciones);
    }

    public function post(string $patron, array $accion, array $opciones = []): void
    {
        $this->agregar('POST', $patron, $accion, $opciones);
    }

    private function agregar(string $metodo, string $patron, array $accion, array $opciones): void
    {
        $this->rutas[] = compact('metodo', 'patron', 'accion', 'opciones');
    }

    /** @return array{0:?array,1:array,2:bool} [ruta, parámetros, existe-con-otro-método] */
    public function buscar(string $metodo, string $ruta): array
    {
        $otroMetodo = false;
        foreach ($this->rutas as $r) {
            $regex = '#^' . preg_replace('#\{([a-z_]+)\}#', '(?P<$1>[^/]+)', $r['patron']) . '$#';
            if (preg_match($regex, $ruta, $m)) {
                if ($r['metodo'] !== $metodo) {
                    $otroMetodo = true;
                    continue;
                }
                $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
                return [$r, $params, false];
            }
        }
        return [null, [], $otroMetodo];
    }
}
