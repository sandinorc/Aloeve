<?php
declare(strict_types=1);

namespace App\Core;

use Throwable;

/** Registro único de auditoría (tabla `actividad`). */
final class Actividad
{
    private const OCULTOS = ['password_hash', 'clave', 'certificado_clave_cifrada', 'clave_cifrada', 'api_key_cifrada', 'token_cache'];

    public static function registrar(
        string $modulo,
        string $accion,
        ?string $entidad = null,
        ?int $entidadId = null,
        string $descripcion = '',
        ?array $antes = null,
        ?array $despues = null
    ): void {
        try {
            DB::insertar('actividad', [
                'usuario_id' => $_SESSION['uid'] ?? null,
                'modulo' => $modulo,
                'accion' => $accion,
                'entidad' => $entidad,
                'entidad_id' => $entidadId,
                'descripcion' => mb_substr($descripcion, 0, 500),
                'antes' => $antes !== null ? json_encode(self::limpiar($antes), JSON_UNESCAPED_UNICODE) : null,
                'despues' => $despues !== null ? json_encode(self::limpiar($despues), JSON_UNESCAPED_UNICODE) : null,
                'ip' => Auth::ip(),
                'fecha' => date('Y-m-d H:i:s'),
            ]);
        } catch (Throwable $e) {
            registrar_error('No se pudo registrar actividad: ' . $e->getMessage());
        }
    }

    /** Devuelve solo los campos que cambiaron, sin secretos. */
    public static function diferencias(array $antes, array $despues): array
    {
        $a = [];
        $d = [];
        foreach ($despues as $k => $v) {
            if ((string) ($antes[$k] ?? '') !== (string) ($v ?? '')) {
                $a[$k] = $antes[$k] ?? null;
                $d[$k] = $v;
            }
        }
        return [self::limpiar($a), self::limpiar($d)];
    }

    private static function limpiar(array $datos): array
    {
        foreach ($datos as $k => $v) {
            if (in_array($k, self::OCULTOS, true)) {
                $datos[$k] = '••••';
            }
        }
        return $datos;
    }
}
