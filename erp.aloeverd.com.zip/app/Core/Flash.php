<?php
declare(strict_types=1);

namespace App\Core;

/** Mensajes de una sola vez y datos de formulario tras un error. */
final class Flash
{
    public static function ok(string $mensaje): void
    {
        $_SESSION['_flash'][] = ['tipo' => 'ok', 'texto' => $mensaje];
    }

    public static function error(string $mensaje): void
    {
        $_SESSION['_flash'][] = ['tipo' => 'error', 'texto' => $mensaje];
    }

    public static function aviso(string $mensaje): void
    {
        $_SESSION['_flash'][] = ['tipo' => 'aviso', 'texto' => $mensaje];
    }

    public static function tomar(): array
    {
        $m = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $m;
    }

    /** Guarda lo enviado para volver a llenar el formulario (nunca contraseñas). */
    public static function recordarFormulario(): void
    {
        $datos = $_POST;
        foreach (array_keys($datos) as $k) {
            if (str_contains((string) $k, 'clave') || $k === '_csrf') {
                unset($datos[$k]);
            }
        }
        $_SESSION['_viejo'] = $datos;
    }

    public static function limpiarFormulario(): void
    {
        unset($_SESSION['_viejo']);
    }
}
