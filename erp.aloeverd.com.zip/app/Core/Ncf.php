<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Comprobantes fiscales de la DGII.
 *  - NCF de papel:  B + tipo (2) + secuencial (8)  = 11 caracteres. Ej. B0200000001
 *  - e-NCF:         E + tipo (2) + secuencial (10) = 13 caracteres. Ej. E320000000001
 */
final class Ncf
{
    public const TIPOS = [
        'B01' => ['nombre' => 'Factura de Crédito Fiscal', 'clase' => 'papel', 'basico' => true],
        'B02' => ['nombre' => 'Factura de Consumo', 'clase' => 'papel', 'basico' => true],
        'B04' => ['nombre' => 'Nota de Crédito', 'clase' => 'papel', 'basico' => true],
        'B14' => ['nombre' => 'Regímenes Especiales', 'clase' => 'papel', 'basico' => false],
        'B15' => ['nombre' => 'Gubernamental', 'clase' => 'papel', 'basico' => false],
        'E31' => ['nombre' => 'Factura de Crédito Fiscal Electrónica', 'clase' => 'electronico', 'basico' => true],
        'E32' => ['nombre' => 'Factura de Consumo Electrónica', 'clase' => 'electronico', 'basico' => true],
        'E33' => ['nombre' => 'Nota de Débito Electrónica', 'clase' => 'electronico', 'basico' => false],
        'E34' => ['nombre' => 'Nota de Crédito Electrónica', 'clase' => 'electronico', 'basico' => true],
        'E41' => ['nombre' => 'Compras Electrónico', 'clase' => 'electronico', 'basico' => false],
        'E43' => ['nombre' => 'Gastos Menores Electrónico', 'clase' => 'electronico', 'basico' => false],
        'E44' => ['nombre' => 'Regímenes Especiales Electrónico', 'clase' => 'electronico', 'basico' => false],
        'E45' => ['nombre' => 'Gubernamental Electrónico', 'clase' => 'electronico', 'basico' => false],
        'E46' => ['nombre' => 'Comprobante de Exportaciones Electrónico', 'clase' => 'electronico', 'basico' => false],
        'E47' => ['nombre' => 'Comprobante para Pagos al Exterior Electrónico', 'clase' => 'electronico', 'basico' => false],
    ];

    /** Orden en el selector del modal (como la referencia). */
    public const ORDEN_MODAL = ['B02', 'B01', 'B04', 'E32', 'E31', 'E34'];

    public static function existe(string $tipo): bool
    {
        return isset(self::TIPOS[$tipo]);
    }

    public static function digitos(string $tipo): int
    {
        return str_starts_with($tipo, 'E') ? 10 : 8;
    }

    public static function maximo(string $tipo): int
    {
        return (int) str_repeat('9', self::digitos($tipo));
    }

    public static function formatear(string $tipo, int $numero): string
    {
        if (!self::existe($tipo)) {
            throw new RuntimeException("Tipo de comprobante desconocido: $tipo");
        }
        if ($numero < 1 || $numero > self::maximo($tipo)) {
            throw new RuntimeException('Número de comprobante fuera de rango.');
        }
        $ncf = $tipo . str_pad((string) $numero, self::digitos($tipo), '0', STR_PAD_LEFT);
        if (!self::valido($ncf)) {
            throw new RuntimeException("Se generó un comprobante inválido: $ncf");
        }
        return $ncf;
    }

    public static function valido(string $ncf): bool
    {
        return (bool) preg_match('/^(B(01|02|03|04|11|12|13|14|15|16|17)\d{8}|E(31|32|33|34|41|43|44|45|46|47)\d{10})$/', $ncf);
    }

    public static function nombre(string $tipo): string
    {
        return self::TIPOS[$tipo]['nombre'] ?? $tipo;
    }

    /**
     * Toma el próximo número de una secuencia activa del tipo pedido, con bloqueo de fila.
     * Debe llamarse dentro de DB::tx(). Se usa desde el POS (Fase 2).
     */
    public static function siguiente(string $tipo): array
    {
        $s = DB::uno(
            'SELECT * FROM secuencias_ncf
              WHERE tipo = ? AND activa = 1 AND proximo <= hasta AND (vence_en IS NULL OR vence_en >= CURDATE())
              ORDER BY desde ASC LIMIT 1 FOR UPDATE',
            [$tipo]
        );
        if (!$s) {
            throw new RuntimeException('No hay una secuencia ' . $tipo . ' disponible. Carga una nueva en Configuración → Comprobantes fiscales.');
        }
        $numero = (int) $s['proximo'];
        DB::actualizar('secuencias_ncf', ['proximo' => $numero + 1, 'actualizado_en' => date('Y-m-d H:i:s')], 'id = ?', [$s['id']]);
        return ['secuencia_id' => (int) $s['id'], 'ncf' => self::formatear($tipo, $numero)];
    }
}
