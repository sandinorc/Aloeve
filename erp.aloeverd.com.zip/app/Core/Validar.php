<?php
declare(strict_types=1);

namespace App\Core;

/** Validaciones dominicanas. */
final class Validar
{
    public static function soloDigitos(string $v): string
    {
        return preg_replace('/\D/', '', $v) ?? '';
    }

    /** RNC de 9 dígitos con dígito verificador (algoritmo de la DGII). */
    public static function rnc(string $valor): bool
    {
        $r = self::soloDigitos($valor);
        if (strlen($r) !== 9) {
            return false;
        }
        $pesos = [7, 9, 8, 6, 5, 4, 3, 2];
        $suma = 0;
        for ($i = 0; $i < 8; $i++) {
            $suma += (int) $r[$i] * $pesos[$i];
        }
        $resto = $suma % 11;
        $dv = match ($resto) {
            0 => 2,
            1 => 1,
            default => 11 - $resto,
        };
        return $dv === (int) $r[8];
    }

    /** Cédula de 11 dígitos con dígito verificador (Luhn). */
    public static function cedula(string $valor): bool
    {
        $c = self::soloDigitos($valor);
        if (strlen($c) !== 11) {
            return false;
        }
        $suma = 0;
        for ($i = 0; $i < 10; $i++) {
            $n = (int) $c[$i] * (($i % 2) === 0 ? 1 : 2);
            $suma += $n > 9 ? $n - 9 : $n;
        }
        $dv = (10 - ($suma % 10)) % 10;
        return $dv === (int) $c[10];
    }

    public static function rncOCedula(string $valor): bool
    {
        $d = self::soloDigitos($valor);
        return strlen($d) === 9 ? self::rnc($d) : self::cedula($d);
    }

    public static function email(string $v): bool
    {
        return filter_var($v, FILTER_VALIDATE_EMAIL) !== false;
    }
}
