<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/** Cifrado de secretos (contraseñas de certificados, API keys) con AES-256-GCM. */
final class Crypto
{
    private static function llave(): string
    {
        $llave = base64_decode((string) Config::get('app.llave', ''), true);
        if ($llave === false || strlen($llave) !== 32) {
            throw new RuntimeException('Falta la llave de cifrado en config.php (app.llave).');
        }
        return $llave;
    }

    public static function generarLlave(): string
    {
        return base64_encode(random_bytes(32));
    }

    public static function cifrar(string $texto): string
    {
        $iv = random_bytes(12);
        $tag = '';
        $c = openssl_encrypt($texto, 'aes-256-gcm', self::llave(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($c === false) {
            throw new RuntimeException('No se pudo cifrar.');
        }
        return 'v1:' . base64_encode($iv . $tag . $c);
    }

    public static function descifrar(?string $cifrado): ?string
    {
        if ($cifrado === null || $cifrado === '') {
            return null;
        }
        if (!str_starts_with($cifrado, 'v1:')) {
            throw new RuntimeException('Formato de dato cifrado desconocido.');
        }
        $bin = base64_decode(substr($cifrado, 3), true);
        if ($bin === false || strlen($bin) < 29) {
            throw new RuntimeException('Dato cifrado dañado.');
        }
        $t = openssl_decrypt(substr($bin, 28), 'aes-256-gcm', self::llave(), OPENSSL_RAW_DATA, substr($bin, 0, 12), substr($bin, 12, 16));
        if ($t === false) {
            throw new RuntimeException('No se pudo descifrar. ¿Cambió la llave en config.php?');
        }
        return $t;
    }
}
