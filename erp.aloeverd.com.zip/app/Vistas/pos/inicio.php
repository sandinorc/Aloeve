<?php
/**
 * @var array $productos @var array $categorias @var float $tasaItbis @var bool $ecf
 * @var string $tipoConsumo @var string $tipoCredito @var int $quedanConsumo @var int $quedanCredito @var array $ultimas
 */
$datos = [
    'productos' => $productos,
    'tasa' => $tasaItbis,
    'puedeDescuento' => puede('pos.descuento'),
    'cobrar' => url('/pos/cobrar'),
];
?>
<script type="application/json" id="pos-datos"><?= json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>

<div class="mb-5 flex flex-wrap items-end justify-between gap-3">
    <div>
        <h1 class="titulo-pagina">Punto de venta</h1>
        <p class="mt-1 text-texto-suave">
            Comprobante: <strong><?= e($tipoConsumo) ?></strong> consumo · <strong><?= e($tipoCredito) ?></strong> crédito fiscal
            <?= $ecf ? '<span class="chip-morado ml-1">e-CF activo</span>' : '' ?>
        </p>
    </div>
    <a href="<?= e(url('/ventas')) ?>" class="btn-secundario"><?= icono('recibo', 'h-4 w-4') ?> Ventas de hoy</a>
</div>

<?php if ($quedanConsumo === 0): ?>
    <div class="mb-4 flex gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-red-800" role="alert">
        <?= icono('alerta', 'h-5 w-5 shrink-0') ?>
        <p>No hay números <?= e($tipoConsumo) ?> disponibles. No podrás cobrar hasta cargar una secuencia en
            <?= puede('fiscal.editar') ? '<a class="font-medium underline" href="' . e(url('/configuracion/comprobantes')) . '">Comprobantes fiscales</a>' : 'Comprobantes fiscales (pídeselo a administración)' ?>.</p>
    </div>
<?php elseif ($quedanConsumo <= 50): ?>
    <div class="mb-4 flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-amber-900">
        <?= icono('alerta', 'h-5 w-5 shrink-0') ?><p>Quedan solo <?= (int) $quedanConsumo ?> números <?= e($tipoConsumo) ?>.</p>
    </div>
<?php endif; ?>

<div class="grid gap-6 pb-24 lg:grid-cols-[1fr_380px] lg:pb-0" data-pos>
    <!-- Productos -->
    <section aria-label="Productos" class="min-w-0">
        <div class="tarjeta mb-4 p-3">
            <div class="relative">
                <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
                <input type="search" class="input pl-10" placeholder="Buscar por nombre o código" aria-label="Buscar producto" data-pos-buscar autocomplete="off">
            </div>
            <?php if (count($categorias) > 1): ?>
                <div class="mt-3 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Categorías">
                    <button type="button" class="btn-sm btn shrink-0 bg-primario text-white" data-pos-cat="" aria-pressed="true">Todo</button>
                    <?php foreach ($categorias as $cat): ?>
                        <button type="button" class="btn-sm btn shrink-0 border border-linea bg-white text-texto" data-pos-cat="<?= e($cat) ?>" aria-pressed="false"><?= e($cat) ?></button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if (!$productos): ?>
            <div class="tarjeta p-10 text-center">
                <p class="text-texto-suave">Todavía no hay productos activos.</p>
                <?php if (puede('inventario.editar')): ?><a class="btn-primario mt-4" href="<?= e(url('/inventario/productos/nuevo')) ?>"><?= icono('mas', 'h-5 w-5') ?> Crear producto</a><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4" data-pos-grilla>
                <?php foreach ($productos as $p):
                    $agotado = $p['disponible'] !== null && $p['disponible'] <= 0; ?>
                    <button type="button" class="tarjeta flex min-h-[112px] flex-col p-3 text-left transition hover:border-primario-300 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-primario disabled:cursor-not-allowed disabled:opacity-50"
                            data-pos-producto="<?= (int) $p['id'] ?>" data-cat="<?= e($p['categoria']) ?>" data-busqueda="<?= e(mb_strtolower($p['nombre'] . ' ' . $p['sku'])) ?>" <?= $agotado ? 'disabled' : '' ?>>
                        <span class="line-clamp-2 font-medium leading-snug"><?= e($p['nombre']) ?></span>
                        <span class="mt-0.5 text-[12px] text-texto-suave"><?= e($p['sku']) ?></span>
                        <span class="mt-auto pt-2">
                            <span class="block whitespace-nowrap font-semibold tabular-nums text-primario-700"><?= e(dinero($p['precio'])) ?></span>
                            <?php if ($p['disponible'] !== null): ?>
                                <span class="block text-[12px] <?= $agotado ? 'text-red-700' : 'text-texto-suave' ?>"><?= $agotado ? 'Agotado' : e(\App\Modulos\Inventario\InventarioServicio::fmt($p['disponible'])) . ' disponibles' ?></span>
                            <?php endif; ?>
                        </span>
                    </button>
                <?php endforeach; ?>
            </div>
            <p class="mt-6 hidden text-center text-texto-suave" data-pos-vacio>Ningún producto coincide.</p>
        <?php endif; ?>

        <?php if ($ultimas): ?>
            <div class="tarjeta mt-6 overflow-hidden">
                <h2 class="border-b border-linea px-5 py-3 font-semibold">Tus últimas ventas de hoy</h2>
                <ul class="divide-y divide-linea">
                    <?php foreach ($ultimas as $u): ?>
                        <li class="flex items-center justify-between gap-3 px-5 py-2.5 text-[15px]">
                            <a class="font-medium text-primario-700 hover:underline" href="<?= e(url('/ventas/' . $u['id'])) ?>"><?= e($u['numero']) ?></a>
                            <span class="min-w-0 flex-1 truncate text-texto-suave"><?= e($u['cliente'] ?? 'Consumidor final') ?> · <?= e(date('H:i', strtotime($u['fecha']))) ?></span>
                            <?= $u['estado'] === 'anulada' ? '<span class="chip-rojo">Anulada</span>' : '' ?>
                            <span class="tabular-nums"><?= e(dinero($u['total'])) ?></span>
                            <a class="btn-secundario btn-sm" href="<?= e(url('/ventas/' . $u['id'] . '/recibo')) ?>" target="_blank" rel="noopener" aria-label="Recibo de <?= e($u['numero']) ?>"><?= icono('imprimir', 'h-4 w-4') ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </section>

    <!-- Carrito -->
    <aside class="pos-carrito" data-pos-carrito aria-label="Venta actual">
        <div class="flex items-center justify-between border-b border-linea px-5 py-3">
            <h2 class="text-lg font-semibold">Venta actual</h2>
            <div class="flex gap-1">
                <button type="button" class="btn-secundario btn-sm" data-pos-vaciar>Vaciar</button>
                <button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo lg:hidden" data-pos-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button>
            </div>
        </div>
        <div class="space-y-3 border-b border-linea px-5 py-4">
            <?= \App\Core\View::parcial('parciales/buscador_cliente', ['nombre' => 'cliente_id', 'idCampo' => 'pos_cliente', 'etiqueta' => 'Cliente (opcional)']) ?>
            <label class="flex items-start gap-2.5 text-[15px]">
                <input type="checkbox" class="check mt-0.5" data-pos-credito>
                <span>Factura con crédito fiscal (<?= e($tipoCredito) ?>)<span class="block text-[13px] text-texto-suave">El cliente debe tener RNC o cédula.</span></span>
            </label>
            <?php if ($quedanCredito === 0): ?><p class="text-[13px] text-amber-800">No hay números <?= e($tipoCredito) ?> cargados.</p><?php endif; ?>
        </div>
        <ul class="max-h-[40dvh] min-h-[96px] divide-y divide-linea overflow-y-auto lg:max-h-[46vh]" data-pos-lineas>
            <li class="px-5 py-8 text-center text-texto-suave" data-pos-sin-items>Toca un producto para agregarlo.</li>
        </ul>
        <div class="space-y-1.5 border-t border-linea px-5 py-4 text-[15px]">
            <?php if (puede('pos.descuento')): ?>
                <div class="mb-2 flex items-center justify-between gap-3">
                    <label for="pos_descuento" class="text-texto-suave">Descuento %</label>
                    <input id="pos_descuento" type="number" min="0" max="100" step="0.5" value="0" inputmode="decimal" class="input w-24 text-right tabular-nums" data-pos-descuento>
                </div>
            <?php endif; ?>
            <div class="flex justify-between"><span class="text-texto-suave">Subtotal</span><span class="tabular-nums" data-pos-subtotal>RD$ 0.00</span></div>
            <div class="flex justify-between" data-pos-fila-desc hidden><span class="text-texto-suave">Descuento</span><span class="tabular-nums text-red-700" data-pos-desc>RD$ 0.00</span></div>
            <div class="flex justify-between"><span class="text-texto-suave">ITBIS</span><span class="tabular-nums" data-pos-itbis>RD$ 0.00</span></div>
            <div class="flex items-baseline justify-between pt-1 text-xl font-semibold"><span>Total</span><span class="tabular-nums" data-pos-total>RD$ 0.00</span></div>
            <button type="button" class="btn-primario mt-3 w-full text-base" data-pos-cobrar disabled <?= $quedanConsumo === 0 ? 'data-sin-ncf' : '' ?>>
                <?= icono('tarjeta', 'h-5 w-5') ?> Cobrar
            </button>
        </div>
    </aside>
</div>

<!-- Barra inferior en móvil -->
<div class="fixed inset-x-0 bottom-0 z-30 border-t border-linea bg-white p-3 shadow-modal lg:hidden" data-pos-barra>
    <button type="button" class="btn-primario w-full justify-between text-base" data-pos-abrir>
        <span class="flex items-center gap-2"><?= icono('venta', 'h-5 w-5') ?> <span data-pos-cuenta>0 artículos</span></span>
        <span class="tabular-nums" data-pos-total-barra>RD$ 0.00</span>
    </button>
</div>
<div class="fixed inset-0 z-40 bg-menu/40 lg:hidden" data-pos-fondo hidden></div>

<!-- Cobro -->
<dialog id="dlg-cobro" class="dialogo" aria-labelledby="t-cobro">
    <div class="space-y-4" data-pos-pago>
        <div class="flex items-start justify-between gap-4">
            <div><h2 id="t-cobro" class="text-xl font-semibold">Cobrar</h2><p class="text-texto-suave" data-pos-pago-tipo></p></div>
            <button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button>
        </div>
        <div class="rounded-xl bg-primario-50 p-4 text-center">
            <p class="text-sm text-primario-800">Total a cobrar</p>
            <p class="font-display text-4xl tabular-nums text-primario-900" data-pos-pago-total>RD$ 0.00</p>
        </div>
        <div>
            <label class="etiqueta" for="pago_efectivo">Efectivo recibido</label>
            <input id="pago_efectivo" class="input text-lg tabular-nums" inputmode="decimal" data-pago="efectivo" placeholder="0.00">
            <div class="mt-2 flex flex-wrap gap-2" data-pos-rapidos></div>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div><label class="etiqueta" for="pago_tarjeta">Tarjeta</label><input id="pago_tarjeta" class="input tabular-nums" inputmode="decimal" data-pago="tarjeta" placeholder="0.00"></div>
            <div><label class="etiqueta" for="pago_transferencia">Transferencia</label><input id="pago_transferencia" class="input tabular-nums" inputmode="decimal" data-pago="transferencia" placeholder="0.00"></div>
        </div>
        <div class="flex gap-2">
            <button type="button" class="btn-secundario btn-sm flex-1" data-pago-todo="tarjeta">Todo con tarjeta</button>
            <button type="button" class="btn-secundario btn-sm flex-1" data-pago-todo="transferencia">Todo por transferencia</button>
        </div>
        <div><label class="etiqueta" for="pago_ref">Referencia (aprobación o transferencia)</label><input id="pago_ref" class="input" maxlength="80" data-pago-ref></div>
        <div class="flex items-center justify-between rounded-xl border border-linea px-4 py-3 text-lg" data-pos-resultado>
            <span data-pos-resultado-texto>Falta</span><strong class="tabular-nums" data-pos-resultado-monto>RD$ 0.00</strong>
        </div>
        <p class="hidden rounded-xl bg-red-50 p-3 text-[15px] text-red-800" role="alert" data-pos-error></p>
        <div class="grid grid-cols-[1fr_2fr] gap-3">
            <button type="button" class="btn-secundario" data-dialogo-cerrar>Volver</button>
            <button type="button" class="btn-primario" data-pos-confirmar disabled><?= icono('check', 'h-5 w-5') ?> Confirmar cobro</button>
        </div>
    </div>
</dialog>

<!-- Venta lista -->
<dialog id="dlg-listo" class="dialogo" aria-labelledby="t-listo">
    <div class="space-y-4 text-center">
        <span class="mx-auto grid h-14 w-14 place-items-center rounded-full bg-emerald-50 text-emerald-700"><?= icono('check', 'h-7 w-7') ?></span>
        <h2 id="t-listo" class="text-xl font-semibold">Venta registrada</h2>
        <dl class="space-y-1 text-[15px]">
            <div class="flex justify-between gap-3"><dt class="text-texto-suave">Venta</dt><dd class="font-medium" data-listo-numero></dd></div>
            <div class="flex justify-between gap-3"><dt class="text-texto-suave" data-listo-tipo>Comprobante</dt><dd class="font-mono font-medium" data-listo-ncf></dd></div>
            <div class="flex justify-between gap-3" data-listo-fila-ecf hidden><dt class="text-texto-suave">DGII</dt><dd data-listo-ecf></dd></div>
        </dl>
        <div class="rounded-xl bg-dorado-claro p-4" data-listo-fila-cambio>
            <p class="text-sm text-dorado-oscuro">Cambio a devolver</p>
            <p class="font-display text-3xl tabular-nums text-dorado-oscuro" data-listo-cambio>RD$ 0.00</p>
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
            <a href="#" class="btn-secundario" target="_blank" rel="noopener" data-listo-recibo><?= icono('imprimir', 'h-5 w-5') ?> Imprimir recibo</a>
            <button type="button" class="btn-primario" data-pos-nueva>Nueva venta</button>
        </div>
    </div>
</dialog>
