<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Usuarios',
    'descripcion' => 'Quién entra al ERP y con qué rol.',
    'acciones' => puede('usuarios.editar') ? '<a href="' . e(url('/usuarios/nuevo')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Crear usuario</a>' : '',
]) ?>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-[1fr_200px_180px_auto]">
    <label class="relative">
        <span class="sr-only">Buscar</span>
        <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
        <input name="q" value="<?= e(get('q')) ?>" class="input pl-10" placeholder="Buscar por nombre o correo">
    </label>
    <select name="rol" class="input" aria-label="Rol">
        <option value="">Todos los roles</option>
        <?php foreach ($roles as $r): ?>
            <option value="<?= (int) $r['id'] ?>" <?= get('rol') === (string) $r['id'] ? 'selected' : '' ?>><?= e($r['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="estado" class="input" aria-label="Estado">
        <option value="">Todos los estados</option>
        <option value="activos" <?= get('estado') === 'activos' ? 'selected' : '' ?>>Activos</option>
        <option value="inactivos" <?= get('estado') === 'inactivos' ? 'selected' : '' ?>>Inactivos</option>
    </select>
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <?php if (!$usuarios): ?>
        <p class="px-5 py-10 text-center text-texto-suave">No hay usuarios con esos filtros.</p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Nombre y correo</th><th>Rol</th><th>Sede</th><th>Estado</th><th>Último acceso</th><th class="text-right">Acciones</th></tr></thead>
            <tbody>
            <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td data-principal>
                        <div class="flex items-center gap-3">
                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primario-50 text-sm font-semibold text-primario-700"><?= e(iniciales($u['nombre'])) ?></span>
                            <span class="min-w-0">
                                <span class="block font-medium"><?= e($u['nombre']) ?></span>
                                <span class="block truncate text-[14px] font-normal text-texto-suave"><?= e($u['email']) ?></span>
                            </span>
                        </div>
                    </td>
                    <td data-etiqueta="Rol"><span class="chip-morado"><?= e($u['rol']) ?></span></td>
                    <td data-etiqueta="Sede"><?= e($u['sede'] ?? '—') ?></td>
                    <td data-etiqueta="Estado">
                        <?php if ((int) $u['activo'] !== 1): ?><span class="chip-gris">Inactivo</span>
                        <?php elseif ((int) $u['debe_cambiar_clave'] === 1): ?><span class="chip-ambar">Clave temporal</span>
                        <?php else: ?><span class="chip-verde">Activo</span><?php endif; ?>
                    </td>
                    <td data-etiqueta="Último acceso" class="tabular-nums"><?= e(fecha($u['ultimo_acceso'], true)) ?></td>
                    <td data-etiqueta="" class="text-right">
                        <?php if (puede('usuarios.editar')): ?>
                            <a href="<?= e(url('/usuarios/' . $u['id'])) ?>" class="enlace inline-flex items-center gap-1"><?= icono('lapiz', 'h-4 w-4') ?> Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
