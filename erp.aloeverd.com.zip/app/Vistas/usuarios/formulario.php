<?php
$u = $usuario;
$val = static fn(string $c, $def = '') => viejo($c, $u[$c] ?? $def);
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $u ? $u['nombre'] : 'Nuevo usuario',
    'descripcion' => $u ? $u['email'] : 'El sistema crea una contraseña temporal y le pedirá cambiarla al entrar por primera vez.',
    'volver' => ['texto' => 'Usuarios', 'ruta' => '/usuarios'],
]) ?>

<?php if (!empty($temporal)): ?>
    <div class="mb-6 rounded-2xl border-2 border-dorado bg-dorado-claro/60 p-5">
        <p class="font-medium">Contraseña temporal de <?= e($u['nombre']) ?></p>
        <div class="mt-2 flex flex-wrap items-center gap-3">
            <code class="rounded-lg bg-white px-3 py-2 font-mono text-lg tracking-wider" id="clave-temporal"><?= e($temporal) ?></code>
            <button type="button" class="btn-secundario btn-sm" data-copiar="clave-temporal"><?= icono('copiar', 'h-4 w-4') ?> Copiar</button>
        </div>
        <p class="mt-2 text-[14px] text-texto-suave">Solo se muestra esta vez. Entrégala en persona o por un canal privado.</p>
    </div>
<?php endif; ?>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
    <form method="post" action="<?= e(url($u ? '/usuarios/' . $u['id'] : '/usuarios')) ?>" class="tarjeta tarjeta-cuerpo space-y-5">
        <?= csrf_campo() ?>
        <div class="grid gap-4 sm:grid-cols-2">
            <div>
                <label for="nombre" class="etiqueta">Nombre completo</label>
                <input id="nombre" name="nombre" class="input" value="<?= e($val('nombre')) ?>" required>
            </div>
            <div>
                <label for="email" class="etiqueta">Correo</label>
                <input id="email" name="email" type="email" class="input" value="<?= e($val('email')) ?>" required>
            </div>
            <div>
                <label for="sede_id" class="etiqueta">Sede</label>
                <select id="sede_id" name="sede_id" class="input">
                    <option value="">Todas</option>
                    <?php foreach ($sedes as $s): ?>
                        <option value="<?= (int) $s['id'] ?>" <?= $val('sede_id') === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($u): ?>
            <div>
                <span class="etiqueta">Estado</span>
                <label class="flex min-h-[44px] items-center gap-3">
                    <input type="checkbox" name="activo" value="1" class="check" <?= $val('activo', '1') === '1' ? 'checked' : '' ?>>
                    <span>Puede entrar al ERP</span>
                </label>
            </div>
            <?php endif; ?>
        </div>

        <fieldset>
            <legend class="etiqueta">Rol</legend>
            <div class="grid gap-2 sm:grid-cols-2">
                <?php foreach ($roles as $r): ?>
                    <label class="flex cursor-pointer items-start gap-3 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50">
                        <input type="radio" name="rol_id" value="<?= (int) $r['id'] ?>" class="mt-0.5 h-5 w-5 text-primario focus:ring-primario-300" <?= $val('rol_id') === (string) $r['id'] ? 'checked' : '' ?> required>
                        <span>
                            <span class="block font-medium"><?= e($r['nombre']) ?></span>
                            <span class="block text-[14px] text-texto-suave"><?= e($r['descripcion']) ?></span>
                        </span>
                    </label>
                <?php endforeach; ?>
            </div>
        </fieldset>

        <div class="flex flex-wrap gap-3">
            <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $u ? 'Guardar cambios' : 'Crear usuario' ?></button>
            <a href="<?= e(url('/usuarios')) ?>" class="btn-secundario">Cancelar</a>
        </div>
    </form>

    <?php if ($u): ?>
    <aside class="space-y-4">
        <div class="tarjeta tarjeta-cuerpo">
            <h2 class="font-semibold">Contraseña</h2>
            <p class="mt-1 text-[14px] text-texto-suave">Genera una contraseña temporal nueva. La anterior deja de funcionar.</p>
            <form method="post" action="<?= e(url('/usuarios/' . $u['id'] . '/clave')) ?>" class="mt-3" data-confirmar="¿Restablecer la contraseña de <?= e($u['nombre']) ?>?">
                <?= csrf_campo() ?>
                <button class="btn-secundario w-full"><?= icono('llave', 'h-4 w-4') ?> Restablecer contraseña</button>
            </form>
        </div>
        <div class="tarjeta tarjeta-cuerpo text-[14px] text-texto-suave">
            <p>Creado: <?= e(fecha($u['creado_en'], true)) ?></p>
            <p>Último acceso: <?= e(fecha($u['ultimo_acceso'], true)) ?></p>
        </div>
    </aside>
    <?php endif; ?>
</div>
