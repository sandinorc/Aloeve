<?php $u = usuario(); ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Hola, ' . explode(' ', $u['nombre'])[0],
    'descripcion' => 'Tu rol es ' . $u['rol_nombre'] . '. Usa el menú para ir a tus módulos.',
]) ?>
<div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    <?php if (puede('agenda.ver') || puede('agenda.dia') || puede('agenda.propias')): ?>
        <a href="<?= e(url('/agenda')) ?>" class="tarjeta flex items-center gap-4 p-5 hover:ring-1 hover:ring-primario-300"><span class="grid h-11 w-11 place-items-center rounded-xl bg-primario-50 text-primario-700"><?= icono('agenda') ?></span><span><span class="block font-semibold">Agenda</span><span class="text-[14px] text-texto-suave"><?= puede('agenda.ver') ? 'Todas las sesiones' : (puede('agenda.propias') ? 'Tus sesiones' : 'Sesiones de hoy') ?></span></span></a>
    <?php endif; ?>
    <?php if (puede('clientes.ver')): ?>
        <a href="<?= e(url('/clientes')) ?>" class="tarjeta flex items-center gap-4 p-5 hover:ring-1 hover:ring-primario-300"><span class="grid h-11 w-11 place-items-center rounded-xl bg-primario-50 text-primario-700"><?= icono('clientes') ?></span><span><span class="block font-semibold">Clientes</span><span class="text-[14px] text-texto-suave">Buscar y registrar</span></span></a>
    <?php endif; ?>
    <a href="<?= e(url('/perfil/clave')) ?>" class="tarjeta flex items-center gap-4 p-5 hover:ring-1 hover:ring-primario-300"><span class="grid h-11 w-11 place-items-center rounded-xl bg-primario-50 text-primario-700"><?= icono('llave') ?></span><span><span class="block font-semibold">Mi contraseña</span><span class="text-[14px] text-texto-suave">Cambiarla</span></span></a>
</div>
