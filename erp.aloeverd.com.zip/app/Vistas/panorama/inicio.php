<?php
use App\Modulos\Agenda\AgendaServicio as A;
$chips = [
    'sin_datos' => ['chip-gris', 'Sin datos'],
    'sin_meta' => ['chip-dorado', 'Sin meta'],
    'parcial' => ['chip-ambar', 'Parcial'],
    'malo' => ['chip-rojo', 'Atención'],
    'ok' => null,
];
$hechos = count(array_filter($pasos, static fn($p) => $p[3]));
$maxSerie = $serie ? max(1, ...array_map(static fn($s) => max($s['ingresos'], $s['gastos']), $serie)) : 1;
$haySerie = $serie && array_sum(array_map(static fn($s) => $s['ingresos'] + $s['gastos'], $serie)) > 0;
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Panorama',
    'descripcion' => 'Cuánto se vendió, cómo va la ocupación y qué necesita atención.',
]) ?>

<?php foreach ($alertas as $a): ?>
    <div class="mb-3 flex items-start gap-3 rounded-xl border px-4 py-3 text-[15px] <?= $a['nivel'] === 'rojo' ? 'border-red-200 bg-red-50 text-red-800' : 'border-amber-200 bg-amber-50 text-amber-900' ?>">
        <?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?>
        <span class="flex-1"><?= e($a['texto']) ?></span>
        <a href="<?= e(url($a['enlace'] ?? '/configuracion/comprobantes')) ?>" class="shrink-0 font-medium underline underline-offset-2">Revisar</a>
    </div>
<?php endforeach; ?>
<?= \App\Core\View::parcial('agenda/_por_cerrar', ['porCerrar' => $porCerrar]) ?>

<form method="get" class="tarjeta mb-6 mt-3 grid gap-4 bg-[#f8f5ff] p-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_auto] lg:items-end">
    <div><label for="desde" class="etiqueta">Desde</label><input id="desde" name="desde" type="date" class="input" value="<?= e($desde) ?>"></div>
    <div><label for="hasta" class="etiqueta">Hasta</label><input id="hasta" name="hasta" type="date" class="input" value="<?= e($hasta) ?>"></div>
    <div>
        <label for="sede" class="etiqueta">Sede</label>
        <select id="sede" name="sede" class="input">
            <option value="">Todas</option>
            <?php foreach ($sedes as $s): ?><option value="<?= (int) $s['id'] ?>" <?= get('sede') === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['nombre']) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="flex gap-2 sm:col-span-2 lg:col-span-1">
        <button class="btn-primario flex-1 lg:flex-none"><?= icono('filtro', 'h-4 w-4') ?> Aplicar</button>
        <a href="<?= e(url('/')) ?>" class="btn-secundario">Limpiar</a>
    </div>
</form>

<?php if ($pasos && $hechos < count($pasos)): ?>
<section class="tarjeta mb-8 overflow-hidden">
    <div class="flex flex-wrap items-center justify-between gap-3 border-b border-linea px-5 py-4 sm:px-6">
        <div><h2 class="text-lg font-semibold">Primeros pasos</h2><p class="text-[15px] text-texto-suave">Lo que falta para trabajar todo desde el ERP.</p></div>
        <span class="chip-morado"><?= $hechos ?> de <?= count($pasos) ?> listos</span>
    </div>
    <ul class="divide-y divide-linea">
        <?php foreach ($pasos as [$texto, $detalle, $ruta, $hecho]): ?>
            <li><a href="<?= e(url($ruta)) ?>" class="flex items-center gap-4 px-5 py-4 hover:bg-fondo sm:px-6">
                <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full <?= $hecho ? 'bg-emerald-600 text-white' : 'border-2 border-dashed border-linea text-texto-suave' ?>"><?= $hecho ? icono('check', 'h-4 w-4') : '' ?></span>
                <span class="min-w-0 flex-1"><span class="block font-medium <?= $hecho ? 'text-texto-suave line-through decoration-texto-suave/40' : '' ?>"><?= e($texto) ?></span><span class="block text-[14px] text-texto-suave"><?= e($detalle) ?></span></span>
                <?= icono('derecha', 'h-5 w-5 shrink-0 text-texto-suave') ?>
            </a></li>
        <?php endforeach; ?>
    </ul>
</section>
<?php endif; ?>

<div class="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
    <?php foreach ($kpis as $k): $chip = $chips[$k['estado']]; ?>
        <article class="tarjeta p-5">
            <div class="flex items-start justify-between gap-3">
                <h2 class="text-[15px] text-texto-suave"><?= e($k['nombre']) ?></h2>
                <?php if ($chip): ?><span class="<?= $chip[0] ?>"><?= e($chip[1]) ?></span><?php endif; ?>
            </div>
            <?php if ($k['valor'] !== null): ?>
                <p class="mt-3 font-display text-[32px] leading-none tabular-nums <?= $k['estado'] === 'malo' ? 'text-red-700' : 'text-texto' ?>"><?= e($k['valor']) ?></p>
            <?php else: ?>
                <p class="mt-3 font-display text-[32px] leading-none text-texto/40" aria-label="Sin valor">—</p>
            <?php endif; ?>
            <?php if (isset($k['barra'])): ?><div class="barra mt-3"><span class="<?= $k['barra'] >= 100 ? 'bg-emerald-500' : 'bg-primario' ?>" style="width: <?= round($k['barra']) ?>%"></span></div><?php endif; ?>
            <?php if (!empty($k['detalle'])): ?><p class="mt-2 text-[13px] text-texto-suave"><?= e($k['detalle']) ?></p><?php endif; ?>
            <details class="mt-3 text-[13px] text-texto-suave">
                <summary class="inline-flex cursor-pointer select-none list-none items-center gap-1 hover:text-texto"><?= icono('info', 'h-4 w-4') ?> Cómo se calcula</summary>
                <p class="mt-2"><?= e($k['formula']) ?></p>
            </details>
        </article>
    <?php endforeach; ?>
</div>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
    <?php if (puede('finanzas.ver')): ?>
    <section class="tarjeta min-w-0">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-linea px-5 py-4">
            <h2 class="font-semibold">Ingresos contra gastos · últimos 6 meses</h2>
            <span class="flex gap-4 text-[13px] text-texto-suave"><span class="inline-flex items-center gap-1.5"><span class="h-3 w-3 rounded-sm bg-primario"></span>Ingresos</span><span class="inline-flex items-center gap-1.5"><span class="h-3 w-3 rounded-sm bg-cobre"></span>Gastos</span></span>
        </div>
        <?php if (!$haySerie): ?>
            <p class="px-5 py-10 text-center text-texto-suave">Sin ingresos ni gastos registrados en estos meses.</p>
        <?php else: ?>
        <div class="overflow-x-auto p-5">
            <div class="flex h-48 min-w-[420px] items-end gap-3 border-b border-linea" role="img" aria-label="Ingresos y gastos de los últimos 6 meses">
                <?php foreach ($serie as $s): ?>
                    <div class="flex h-full flex-1 items-end justify-center gap-1">
                        <div class="w-1/3 rounded-t bg-primario" style="height: <?= round($s['ingresos'] / $maxSerie * 100, 1) ?>%" title="Ingresos <?= e(dinero($s['ingresos'])) ?>"></div>
                        <div class="w-1/3 rounded-t bg-cobre" style="height: <?= round($s['gastos'] / $maxSerie * 100, 1) ?>%" title="Gastos <?= e(dinero($s['gastos'])) ?>"></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="flex min-w-[420px] gap-3 pt-2 text-center text-[12px] text-texto-suave">
                <?php foreach ($serie as $s): ?><div class="flex-1"><?= e($s['etiqueta']) ?></div><?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>
    <section class="tarjeta <?= puede('finanzas.ver') ? '' : 'lg:col-span-2' ?>">
        <div class="flex items-center justify-between border-b border-linea px-5 py-4">
            <h2 class="font-semibold">Hoy y mañana</h2>
            <a href="<?= e(url('/agenda')) ?>" class="enlace text-[14px]">Ver agenda</a>
        </div>
        <?php if (!$proximas): ?>
            <p class="px-5 py-8 text-center text-texto-suave">No hay sesiones programadas para hoy ni mañana.</p>
        <?php else: ?>
        <ul class="divide-y divide-linea">
            <?php foreach ($proximas as $s): ?>
                <li><a href="<?= e(url('/agenda/sesiones/' . $s['id'])) ?>" class="flex items-center gap-3 px-5 py-3 hover:bg-fondo">
                    <span class="h-10 w-1 shrink-0 rounded-full" style="background: <?= e($s['color']) ?>"></span>
                    <span class="w-20 shrink-0 text-[14px] tabular-nums"><span class="block font-semibold"><?= $s['fecha'] === date('Y-m-d') ? 'Hoy' : 'Mañana' ?></span><?= e(substr($s['hora_inicio'], 0, 5)) ?></span>
                    <span class="min-w-0 flex-1"><span class="block truncate font-medium"><?= e($s['servicio']) ?></span><span class="block truncate text-[13px] text-texto-suave"><?= e($s['facilitador'] ?? 'Sin facilitador') ?></span></span>
                    <span class="shrink-0 font-semibold tabular-nums"><?= (int) $s['ocupados'] ?>/<?= (int) $s['capacidad'] ?></span>
                </a></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
</div>
