<?php
use App\Modulos\Finanzas\FinanzasServicio as F;
$ruta = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$prev = date('Y-m', strtotime("$p-01 -1 month"));
$next = date('Y-m', strtotime("$p-01 +1 month"));
?>
<div class="mb-6 flex flex-wrap items-center gap-3">
    <div class="inline-flex items-center rounded-xl border border-linea bg-white">
        <a href="<?= e(url($ruta) . '?mes=' . $prev) ?>" class="grid h-11 w-11 place-items-center rounded-l-xl hover:bg-fondo" aria-label="Mes anterior"><?= icono('izquierda', 'h-5 w-5') ?></a>
        <span class="flex h-11 min-w-[11rem] items-center justify-center border-x border-linea px-4 font-semibold"><?= e(F::nombrePeriodo($p)) ?></span>
        <a href="<?= e(url($ruta) . '?mes=' . $next) ?>" class="grid h-11 w-11 place-items-center rounded-r-xl hover:bg-fondo" aria-label="Mes siguiente"><?= icono('derecha', 'h-5 w-5') ?></a>
    </div>
    <?php if ($p !== date('Y-m')): ?><a href="<?= e(url($ruta)) ?>" class="enlace text-[15px]">Ir al mes actual</a><?php endif; ?>
</div>
