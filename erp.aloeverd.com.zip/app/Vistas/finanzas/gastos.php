<?php
use App\Modulos\Finanzas\FinanzasServicio as F;
$csv = url('/finanzas/gastos') . '?' . http_build_query(array_merge($_GET, ['formato' => 'csv']));
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Finanzas',
    'descripcion' => 'Gastos fijos (alquiler, nómina) y variables (materiales, marketing). Con el NCF del proveedor se arma el 606.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>'
        . (puede('finanzas.editar') ? '<button type="button" class="btn-primario" data-dialogo-abrir="dlg-gasto">' . icono('mas', 'h-5 w-5') . ' Registrar gasto</button>' : ''),
]) ?>
<?= \App\Core\View::parcial('finanzas/_pestanas') ?>
<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[150px_150px_160px_1fr_auto_auto]">
    <input type="date" name="desde" value="<?= e($desde) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e($hasta) ?>" class="input" aria-label="Hasta">
    <select name="tipo" class="input" aria-label="Tipo"><option value="">Fijos y variables</option><option value="fijo" <?= get('tipo') === 'fijo' ? 'selected' : '' ?>>Fijos</option><option value="variable" <?= get('tipo') === 'variable' ? 'selected' : '' ?>>Variables</option></select>
    <select name="categoria" class="input" aria-label="Categoría"><option value="">Todas las categorías</option><?php foreach ($categorias as $c): ?><option <?= get('categoria') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?></select>
    <label class="flex min-h-[44px] items-center gap-2 rounded-xl border border-linea bg-white px-3 text-[15px]"><input type="checkbox" name="anulados" value="1" class="check" <?= get('anulados') === '1' ? 'checked' : '' ?>> Ver anulados</label>
    <button class="btn-secundario">Filtrar</button>
</form>
<div class="tarjeta overflow-hidden">
    <div class="flex justify-between border-b border-linea px-5 py-3 text-[15px]"><span class="text-texto-suave"><?= count($filas) ?> gastos</span><strong class="tabular-nums"><?= e(dinero($total)) ?></strong></div>
    <?php if (!$filas): ?><p class="px-5 py-10 text-center text-texto-suave">No hay gastos en ese rango.</p><?php else: ?>
    <div class="overflow-x-auto"><table class="tabla tabla-resp">
        <thead><tr><th>Fecha</th><th>Descripción</th><th>Categoría</th><th>Proveedor / NCF</th><th class="text-right">Monto</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($filas as $f): ?>
            <tr class="<?= $f['anulado'] ? 'opacity-50' : '' ?>">
                <td data-principal class="whitespace-nowrap tabular-nums"><?= e(fecha($f['fecha'])) ?></td>
                <td data-etiqueta="Descripción"><span class="<?= $f['anulado'] ? 'line-through' : '' ?>"><?= e($f['descripcion']) ?></span><?= $f['anulado'] ? ' <span class="chip-rojo">Anulado</span>' : '' ?></td>
                <td data-etiqueta="Categoría"><?= e($f['categoria']) ?> <span class="chip-gris"><?= e($f['tipo']) ?></span></td>
                <td data-etiqueta="Proveedor"><?= e($f['proveedor'] ?? '—') ?><?php if ($f['ncf_proveedor']): ?> <span class="block font-mono text-[13px] text-texto-suave"><?= e($f['ncf_proveedor']) ?></span><?php endif; ?></td>
                <td data-etiqueta="Monto" class="text-right font-medium tabular-nums"><?= e(dinero($f['monto'])) ?><?= (float) $f['itbis'] > 0 ? '<span class="block text-[12px] font-normal text-texto-suave">ITBIS ' . e(dinero($f['itbis'])) . '</span>' : '' ?></td>
                <td data-etiqueta="" class="text-right">
                    <?php if (!$f['anulado'] && puede('finanzas.editar')): ?>
                        <details class="inline-block text-left"><summary class="btn-secundario btn-sm cursor-pointer list-none">Anular</summary>
                            <form method="post" action="<?= e(url('/finanzas/gastos/' . $f['id'] . '/anular')) ?>" class="mt-2 flex gap-2"><?= csrf_campo() ?><input name="motivo" class="input" required placeholder="Motivo" aria-label="Motivo"><button class="btn-peligro btn-sm">Anular</button></form>
                        </details>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div>
<?php if (puede('finanzas.editar')): ?>
<dialog id="dlg-gasto" class="dialogo" aria-labelledby="t-gasto">
    <form method="post" action="<?= e(url('/finanzas/gastos')) ?>" class="space-y-4">
        <?= csrf_campo() ?>
        <div class="flex items-start justify-between gap-4"><h2 id="t-gasto" class="text-xl font-semibold">Registrar gasto</h2><button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button></div>
        <div><label class="etiqueta" for="g_desc">¿En qué se gastó?</label><input id="g_desc" name="descripcion" class="input" required value="<?= e(viejo('descripcion')) ?>" placeholder="Ej. Alquiler de octubre"></div>
        <div class="grid grid-cols-2 gap-3">
            <div><label class="etiqueta" for="g_fecha">Fecha</label><input id="g_fecha" name="fecha" type="date" class="input" value="<?= e(viejo('fecha', date('Y-m-d'))) ?>" required></div>
            <div><label class="etiqueta" for="g_monto">Monto total (RD$)</label><input id="g_monto" name="monto" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('monto')) ?>" required></div>
            <div><label class="etiqueta" for="g_tipo">Tipo</label><select id="g_tipo" name="tipo" class="input"><option value="variable">Variable</option><option value="fijo" <?= viejo('tipo') === 'fijo' ? 'selected' : '' ?>>Fijo (todos los meses)</option></select></div>
            <div><label class="etiqueta" for="g_cat">Categoría</label><select id="g_cat" name="categoria" class="input" required><option value="">Elige una</option><?php foreach ($categorias as $c): ?><option <?= viejo('categoria') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?></select></div>
            <div><label class="etiqueta" for="g_prov">Proveedor</label><select id="g_prov" name="proveedor_id" class="input"><option value="">Sin proveedor</option><?php foreach ($proveedores as $p): ?><option value="<?= (int) $p['id'] ?>"><?= e($p['nombre']) ?></option><?php endforeach; ?></select></div>
            <div><label class="etiqueta" for="g_met">Pagado con</label><select id="g_met" name="metodo" class="input"><?php foreach (F::METODOS_GASTO as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></div>
            <div><label class="etiqueta" for="g_ncf">NCF del proveedor</label><input id="g_ncf" name="ncf_proveedor" class="input font-mono uppercase" value="<?= e(viejo('ncf_proveedor')) ?>" placeholder="B0100000123"></div>
            <div><label class="etiqueta" for="g_itbis">ITBIS facturado</label><input id="g_itbis" name="itbis" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('itbis', '0')) ?>"></div>
        </div>
        <div class="grid grid-cols-[1fr_2fr] gap-3"><button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button><button class="btn-primario">Guardar</button></div>
    </form>
</dialog>
<?php endif; ?>
