<?php
use App\Modulos\Finanzas\FinanzasServicio as F;
$var = static function (float $a, float $b): string {
    if ($b == 0.0) { return '<span class="text-texto-suave">sin mes anterior</span>'; }
    $p = ($a - $b) / abs($b) * 100;
    return '<span class="' . ($p >= 0 ? 'text-emerald-700' : 'text-red-700') . '">' . ($p >= 0 ? '▲ ' : '▼ ') . number_format(abs($p), 0) . '%</span> vs mes anterior';
};
$metaIng = $meta['meta_ingresos'] ?? null;
?>
<?= \App\Core\View::parcial('parciales/encabezado', ['titulo' => 'Finanzas', 'descripcion' => 'Ingresos, gastos y resultado del mes.']) ?>
<?= \App\Core\View::parcial('finanzas/_pestanas') ?>
<?= \App\Core\View::parcial('finanzas/_selector_mes', ['p' => $p]) ?>

<div class="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
    <article class="tarjeta p-5">
        <div class="flex justify-between gap-2"><h2 class="text-[15px] text-texto-suave">Ingresos</h2><?= $t['ingresos'] == 0 ? '<span class="chip-gris">Sin datos</span>' : '' ?></div>
        <p class="mt-2 font-display text-[28px] leading-none tabular-nums"><?= e(dinero($t['ingresos'])) ?></p>
        <p class="mt-2 text-[13px]"><?= $var($t['ingresos'], $ant['ingresos']) ?></p>
    </article>
    <article class="tarjeta p-5">
        <h2 class="text-[15px] text-texto-suave">Gastos</h2>
        <p class="mt-2 font-display text-[28px] leading-none tabular-nums"><?= e(dinero($t['gastos'])) ?></p>
        <p class="mt-2 text-[13px] text-texto-suave">Fijos <?= e(dinero($t['fijos'])) ?> · Variables <?= e(dinero($t['variables'])) ?></p>
    </article>
    <article class="tarjeta p-5">
        <div class="flex justify-between gap-2"><h2 class="text-[15px] text-texto-suave">Resultado neto</h2><?= $t['margen'] === null ? '<span class="chip-gris">Sin datos</span>' : '' ?></div>
        <p class="mt-2 font-display text-[28px] leading-none tabular-nums <?= $t['neto'] < 0 ? 'text-red-700' : '' ?>"><?= e(dinero($t['neto'])) ?></p>
        <p class="mt-2 text-[13px] text-texto-suave">Margen <?= $t['margen'] === null ? '—' : number_format($t['margen'], 1) . '%' ?></p>
    </article>
    <article class="tarjeta p-5">
        <div class="flex justify-between gap-2"><h2 class="text-[15px] text-texto-suave">Meta del mes</h2><?= $metaIng ? '' : '<span class="chip-dorado">Sin meta</span>' ?></div>
        <?php if ($metaIng): $pc = $t['ingresos'] / (float) $metaIng * 100; ?>
            <p class="mt-2 font-display text-[28px] leading-none tabular-nums"><?= number_format($pc, 0) ?>%</p>
            <div class="barra mt-3"><span class="<?= $pc >= 100 ? 'bg-emerald-500' : 'bg-primario' ?>" style="width: <?= min(100, round($pc)) ?>%"></span></div>
            <p class="mt-2 text-[13px] text-texto-suave">de <?= e(dinero($metaIng)) ?></p>
        <?php else: ?>
            <p class="mt-2 font-display text-[28px] leading-none text-texto/40">—</p>
            <a href="<?= e(url('/finanzas/reportes?mes=' . $p)) ?>" class="enlace mt-2 inline-block text-[13px]">Definir meta</a>
        <?php endif; ?>
    </article>
</div>

<div class="mb-6 grid gap-6 lg:grid-cols-2">
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Ingresos por línea de negocio</h2>
        <?php if (!$porLinea): ?><p class="px-5 py-6 text-texto-suave">Sin ingresos este mes.</p><?php else: $max = max(array_column($porLinea, 'total')); ?>
        <ul class="space-y-3 p-5">
            <?php foreach ($porLinea as $l): ?>
                <li>
                    <div class="flex justify-between text-[15px]"><span><?= e(F::LINEAS[$l['linea_negocio']]) ?></span><span class="tabular-nums"><?= e(dinero($l['total'])) ?></span></div>
                    <div class="barra mt-1"><span class="bg-primario" style="width: <?= round((float) $l['total'] / max(1, (float) $max) * 100) ?>%"></span></div>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Gastos por categoría</h2>
        <?php if (!$porCategoria): ?><p class="px-5 py-6 text-texto-suave">Sin gastos este mes.</p><?php else: $max = max(array_column($porCategoria, 'total')); ?>
        <ul class="space-y-3 p-5">
            <?php foreach ($porCategoria as $c): ?>
                <li>
                    <div class="flex justify-between gap-2 text-[15px]"><span><?= e($c['categoria']) ?> <span class="chip-gris"><?= e($c['tipo']) ?></span></span><span class="tabular-nums"><?= e(dinero($c['total'])) ?></span></div>
                    <div class="barra mt-1"><span class="bg-cobre" style="width: <?= round((float) $c['total'] / max(1, (float) $max) * 100) ?>%"></span></div>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
</div>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Últimos movimientos del mes</h2>
        <?php if (!$ultimos): ?><p class="px-5 py-6 text-texto-suave">Sin movimientos.</p><?php else: ?>
        <ul class="divide-y divide-linea">
            <?php foreach ($ultimos as $u): ?>
                <li class="flex items-center justify-between gap-3 px-5 py-3 text-[15px]">
                    <span class="min-w-0"><span class="block truncate"><?= e($u['texto']) ?></span><span class="text-[13px] text-texto-suave"><?= e(fecha($u['fecha'])) ?></span></span>
                    <span class="shrink-0 tabular-nums <?= $u['clase'] === 'gasto' ? 'text-red-700' : 'text-emerald-700' ?>"><?= $u['clase'] === 'gasto' ? '−' : '+' ?><?= e(dinero($u['monto'])) ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
    <aside class="space-y-4">
        <section class="tarjeta p-5">
            <h2 class="text-[15px] text-texto-suave">Reserva de caja</h2>
            <p class="mt-2 font-display text-[28px] leading-none tabular-nums"><?= e(dinero($saldoCaja)) ?></p>
            <a href="<?= e(url('/finanzas/caja')) ?>" class="enlace mt-2 inline-block text-[14px]">Ver movimientos</a>
        </section>
        <section class="tarjeta p-5">
            <h2 class="text-[15px] text-texto-suave">Punto de equilibrio</h2>
            <?php if ($t['equilibrio'] === null): ?>
                <p class="mt-2 text-texto-suave">Se calcula cuando hay ingresos y gastos fijos en el mes.</p>
            <?php else: ?>
                <p class="mt-2 font-display text-2xl tabular-nums"><?= e(dinero($t['equilibrio'])) ?></p>
                <p class="mt-1 text-[13px] text-texto-suave">Ingresos necesarios para cubrir los gastos fijos con el margen actual.</p>
            <?php endif; ?>
        </section>
    </aside>
</div>
