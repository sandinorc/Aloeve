<?= \App\Core\View::parcial('parciales/encabezado', ['titulo' => 'Finanzas', 'descripcion' => 'Dinero apartado como colchón del negocio. Cada entrada y salida queda registrada.']) ?>
<?= \App\Core\View::parcial('finanzas/_pestanas') ?>
<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
    <section class="tarjeta overflow-hidden">
        <div class="flex items-baseline justify-between border-b border-linea px-5 py-4"><h2 class="font-semibold">Saldo</h2><p class="font-display text-3xl tabular-nums"><?= e(dinero($saldo)) ?></p></div>
        <?php if (!$filas): ?><p class="px-5 py-8 text-center text-texto-suave">Sin movimientos todavía.</p><?php else: ?>
        <ul class="divide-y divide-linea">
            <?php foreach ($filas as $f): ?>
                <li class="flex items-center justify-between gap-3 px-5 py-3 text-[15px]">
                    <span class="min-w-0"><span class="block"><?= e($f['nota']) ?></span><span class="text-[13px] text-texto-suave"><?= e(fecha($f['fecha'])) ?> · <?= e($f['usuario'] ?? '') ?></span></span>
                    <span class="shrink-0 tabular-nums <?= $f['tipo'] === 'salida' ? 'text-red-700' : 'text-emerald-700' ?>"><?= $f['tipo'] === 'salida' ? '−' : '+' ?><?= e(dinero($f['monto'])) ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
    <?php if (puede('finanzas.editar')): ?>
    <form method="post" action="<?= e(url('/finanzas/caja')) ?>" class="tarjeta tarjeta-cuerpo h-fit space-y-4">
        <?= csrf_campo() ?>
        <h2 class="font-semibold">Nuevo movimiento</h2>
        <div class="grid grid-cols-2 gap-2">
            <?php foreach (['entrada' => 'Aparté dinero', 'salida' => 'Usé dinero'] as $k => $t): ?>
                <label class="flex cursor-pointer items-center gap-2 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50"><input type="radio" name="tipo" value="<?= $k ?>" class="h-5 w-5 text-primario" <?= $k === 'entrada' ? 'checked' : '' ?>> <?= $t ?></label>
            <?php endforeach; ?>
        </div>
        <div><label class="etiqueta" for="c_fecha">Fecha</label><input id="c_fecha" name="fecha" type="date" class="input" value="<?= e(date('Y-m-d')) ?>" required></div>
        <div><label class="etiqueta" for="c_monto">Monto (RD$)</label><input id="c_monto" name="monto" class="input tabular-nums" inputmode="decimal" required></div>
        <div><label class="etiqueta" for="c_nota">Nota</label><input id="c_nota" name="nota" class="input" required placeholder="Ej. 10% de las ventas de septiembre"></div>
        <button class="btn-primario w-full">Guardar</button>
    </form>
    <?php endif; ?>
</div>
