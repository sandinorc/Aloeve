<?php
use App\Modulos\Finanzas\FinanzasServicio as F;
$max = max(1, ...array_map(static fn($s) => max($s['ingresos'], $s['gastos']), $serie));
$hayDatos = array_sum(array_map(static fn($s) => $s['ingresos'] + $s['gastos'], $serie)) > 0;
$comp = static function (float $a, float $b): string {
    if ($b == 0.0) { return '—'; }
    $p = ($a - $b) / abs($b) * 100;
    return ($p >= 0 ? '+' : '') . number_format($p, 0) . '%';
};
?>
<?= \App\Core\View::parcial('parciales/encabezado', ['titulo' => 'Finanzas', 'descripcion' => 'Estado de resultados, tendencia de 6 meses y metas del mes.']) ?>
<?= \App\Core\View::parcial('finanzas/_pestanas') ?>
<?= \App\Core\View::parcial('finanzas/_selector_mes', ['p' => $p]) ?>

<section class="tarjeta mb-6">
    <div class="flex flex-wrap items-center justify-between gap-3 border-b border-linea px-5 py-4">
        <h2 class="font-semibold">Ingresos contra gastos · últimos 6 meses</h2>
        <span class="flex gap-4 text-[13px] text-texto-suave"><span class="inline-flex items-center gap-1.5"><span class="h-3 w-3 rounded-sm bg-primario"></span>Ingresos</span><span class="inline-flex items-center gap-1.5"><span class="h-3 w-3 rounded-sm bg-cobre"></span>Gastos</span></span>
    </div>
    <?php if (!$hayDatos): ?>
        <p class="px-5 py-10 text-center text-texto-suave">Sin datos en estos meses. El gráfico aparece cuando haya ingresos o gastos registrados.</p>
    <?php else: ?>
    <div class="overflow-x-auto p-5">
        <div class="flex h-56 min-w-[480px] items-end gap-4 border-b border-linea" role="img" aria-label="Gráfico de barras de ingresos y gastos por mes">
            <?php foreach ($serie as $s): $hi = $s['ingresos'] / $max * 100; $hg = $s['gastos'] / $max * 100; ?>
                <div class="flex h-full flex-1 flex-col justify-end">
                    <div class="flex h-full items-end justify-center gap-1">
                        <div class="w-1/3 rounded-t bg-primario" style="height: <?= round($hi, 1) ?>%" title="Ingresos <?= e(dinero($s['ingresos'])) ?>"></div>
                        <div class="w-1/3 rounded-t bg-cobre" style="height: <?= round($hg, 1) ?>%" title="Gastos <?= e(dinero($s['gastos'])) ?>"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="flex min-w-[480px] gap-4 pt-2 text-center text-[12px] text-texto-suave">
            <?php foreach ($serie as $s): ?>
                <div class="flex-1 <?= $s['periodo'] === $p ? 'font-semibold text-texto' : '' ?>"><?= e($s['etiqueta']) ?><span class="block tabular-nums"><?= e(number_format($s['ingresos'] / 1000, 1)) ?>k / <?= e(number_format($s['gastos'] / 1000, 1)) ?>k</span></div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</section>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
    <section class="tarjeta overflow-hidden">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Estado de resultados · <?= e(F::nombrePeriodo($p)) ?></h2>
        <table class="tabla">
            <thead><tr><th>Concepto</th><th class="text-right">Este mes</th><th class="text-right">Mismo mes año anterior</th><th class="text-right">Cambio</th></tr></thead>
            <tbody>
                <tr><td>Ingresos</td><td class="text-right tabular-nums"><?= e(dinero($t['ingresos'])) ?></td><td class="text-right tabular-nums text-texto-suave"><?= e(dinero($tAnio['ingresos'])) ?></td><td class="text-right tabular-nums"><?= $comp($t['ingresos'], $tAnio['ingresos']) ?></td></tr>
                <tr><td class="pl-8 text-texto-suave">Gastos variables</td><td class="text-right tabular-nums">−<?= e(dinero($t['variables'])) ?></td><td class="text-right tabular-nums text-texto-suave">−<?= e(dinero($tAnio['variables'])) ?></td><td></td></tr>
                <tr><td class="font-medium">Margen de contribución</td><td class="text-right font-medium tabular-nums"><?= e(dinero($t['ingresos'] - $t['variables'])) ?></td><td class="text-right tabular-nums text-texto-suave"><?= e(dinero($tAnio['ingresos'] - $tAnio['variables'])) ?></td><td></td></tr>
                <tr><td class="pl-8 text-texto-suave">Gastos fijos</td><td class="text-right tabular-nums">−<?= e(dinero($t['fijos'])) ?></td><td class="text-right tabular-nums text-texto-suave">−<?= e(dinero($tAnio['fijos'])) ?></td><td></td></tr>
                <tr class="bg-fondo"><td class="font-semibold">Resultado neto</td><td class="text-right font-semibold tabular-nums <?= $t['neto'] < 0 ? 'text-red-700' : '' ?>"><?= e(dinero($t['neto'])) ?></td><td class="text-right tabular-nums text-texto-suave"><?= e(dinero($tAnio['neto'])) ?></td><td class="text-right tabular-nums"><?= $comp($t['neto'], $tAnio['neto']) ?></td></tr>
                <tr><td>Punto de equilibrio</td><td class="text-right tabular-nums" colspan="3"><?= $t['equilibrio'] === null ? '<span class="text-texto-suave">Sin datos suficientes</span>' : e(dinero($t['equilibrio'])) ?></td></tr>
            </tbody>
        </table>
    </section>
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Metas de <?= e(F::nombrePeriodo($p)) ?></h2>
        <?php if (puede('finanzas.editar')): ?>
        <form method="post" action="<?= e(url('/finanzas/metas')) ?>" class="space-y-4 p-5">
            <?= csrf_campo() ?><input type="hidden" name="periodo" value="<?= e($p) ?>">
            <div><label class="etiqueta" for="meta_ingresos">Ingresos del mes (RD$)</label><input id="meta_ingresos" name="meta_ingresos" class="input tabular-nums" inputmode="decimal" value="<?= e($meta['meta_ingresos'] ?? '') ?>"></div>
            <div class="grid grid-cols-2 gap-3">
                <div><label class="etiqueta" for="meta_ocupacion">Ocupación %</label><input id="meta_ocupacion" name="meta_ocupacion" class="input tabular-nums" inputmode="decimal" value="<?= e($meta['meta_ocupacion'] ?? '') ?>"></div>
                <div><label class="etiqueta" for="meta_recurrentes">Recurrentes %</label><input id="meta_recurrentes" name="meta_recurrentes" class="input tabular-nums" inputmode="decimal" value="<?= e($meta['meta_recurrentes'] ?? '') ?>"></div>
            </div>
            <button class="btn-primario w-full">Guardar metas</button>
        </form>
        <?php else: ?>
            <dl class="space-y-2 p-5 text-[15px]">
                <div class="flex justify-between"><dt>Ingresos</dt><dd class="tabular-nums"><?= isset($meta['meta_ingresos']) ? e(dinero($meta['meta_ingresos'])) : '—' ?></dd></div>
                <div class="flex justify-between"><dt>Ocupación</dt><dd><?= isset($meta['meta_ocupacion']) ? e($meta['meta_ocupacion']) . '%' : '—' ?></dd></div>
                <div class="flex justify-between"><dt>Recurrentes</dt><dd><?= isset($meta['meta_recurrentes']) ? e($meta['meta_recurrentes']) . '%' : '—' ?></dd></div>
            </dl>
        <?php endif; ?>
    </section>
</div>
