<?php
use App\Modulos\Agenda\AgendaServicio as A;
use App\Modulos\Finanzas\FinanzasServicio as F;
$csv = url('/finanzas/ingresos') . '?' . http_build_query(array_merge($_GET, ['formato' => 'csv']));
$origen = ['manual' => 'Manual', 'reserva' => 'Reserva', 'venta' => 'Venta', 'inscripcion' => 'Inscripción'];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Finanzas',
    'descripcion' => 'Los cobros de reservas entran solos. Aquí puedes registrar otros ingresos.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>'
        . (puede('finanzas.editar') ? '<button type="button" class="btn-primario" data-dialogo-abrir="dlg-ingreso">' . icono('mas', 'h-5 w-5') . ' Registrar ingreso</button>' : ''),
]) ?>
<?= \App\Core\View::parcial('finanzas/_pestanas') ?>
<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[150px_150px_1fr_1fr_auto_auto]">
    <input type="date" name="desde" value="<?= e($desde) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e($hasta) ?>" class="input" aria-label="Hasta">
    <select name="linea" class="input" aria-label="Línea"><option value="">Todas las líneas</option><?php foreach (F::LINEAS as $k => $t): ?><option value="<?= e($k) ?>" <?= get('linea') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
    <select name="metodo" class="input" aria-label="Método"><option value="">Todos los métodos</option><?php foreach (A::METODOS as $k => $t): ?><option value="<?= e($k) ?>" <?= get('metodo') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
    <label class="flex min-h-[44px] items-center gap-2 rounded-xl border border-linea bg-white px-3 text-[15px]"><input type="checkbox" name="anulados" value="1" class="check" <?= get('anulados') === '1' ? 'checked' : '' ?>> Ver anulados</label>
    <button class="btn-secundario">Filtrar</button>
</form>
<div class="tarjeta overflow-hidden">
    <div class="flex justify-between border-b border-linea px-5 py-3 text-[15px]"><span class="text-texto-suave"><?= count($filas) ?> ingresos</span><strong class="tabular-nums"><?= e(dinero($total)) ?></strong></div>
    <?php if (!$filas): ?><p class="px-5 py-10 text-center text-texto-suave">No hay ingresos en ese rango.</p><?php else: ?>
    <div class="overflow-x-auto"><table class="tabla tabla-resp">
        <thead><tr><th>Fecha</th><th>Concepto</th><th>Línea</th><th>Método</th><th class="text-right">Monto</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($filas as $f): ?>
            <tr class="<?= $f['anulado'] ? 'opacity-50' : '' ?>">
                <td data-principal class="whitespace-nowrap tabular-nums"><?= e(fecha($f['fecha'])) ?></td>
                <td data-etiqueta="Concepto"><span class="<?= $f['anulado'] ? 'line-through' : '' ?>"><?= e($f['concepto']) ?></span> <span class="chip-gris"><?= e($origen[$f['origen_tipo']]) ?></span><?= $f['anulado'] ? ' <span class="chip-rojo">Anulado</span>' : '' ?>
                    <?php if ($f['anulado'] && $f['motivo_anulacion']): ?><span class="block text-[13px] text-texto-suave"><?= e($f['motivo_anulacion']) ?></span><?php endif; ?></td>
                <td data-etiqueta="Línea"><?= e(F::LINEAS[$f['linea_negocio']]) ?></td>
                <td data-etiqueta="Método"><?= e(A::METODOS[$f['metodo']] ?? $f['metodo']) ?><?= $f['referencia'] ? ' <span class="text-[13px] text-texto-suave">· ' . e($f['referencia']) . '</span>' : '' ?></td>
                <td data-etiqueta="Monto" class="text-right font-medium tabular-nums"><?= e(dinero($f['monto'])) ?></td>
                <td data-etiqueta="" class="text-right">
                    <?php if (!$f['anulado'] && puede('finanzas.editar') && $f['origen_tipo'] !== 'venta'): ?>
                        <details class="inline-block text-left"><summary class="btn-secundario btn-sm cursor-pointer list-none">Anular</summary>
                            <form method="post" action="<?= e(url('/finanzas/ingresos/' . $f['id'] . '/anular')) ?>" class="mt-2 flex gap-2"><?= csrf_campo() ?><input name="motivo" class="input" required placeholder="Motivo" aria-label="Motivo"><button class="btn-peligro btn-sm">Anular</button></form>
                        </details>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div>
<?php if (puede('finanzas.editar')): ?>
<dialog id="dlg-ingreso" class="dialogo" aria-labelledby="t-ingreso">
    <form method="post" action="<?= e(url('/finanzas/ingresos')) ?>" class="space-y-4">
        <?= csrf_campo() ?>
        <div class="flex items-start justify-between gap-4"><h2 id="t-ingreso" class="text-xl font-semibold">Registrar ingreso</h2><button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button></div>
        <div><label class="etiqueta" for="i_concepto">Concepto</label><input id="i_concepto" name="concepto" class="input" required value="<?= e(viejo('concepto')) ?>" placeholder="Ej. Evento corporativo Banco X"></div>
        <div class="grid grid-cols-2 gap-3">
            <div><label class="etiqueta" for="i_fecha">Fecha</label><input id="i_fecha" name="fecha" type="date" class="input" value="<?= e(viejo('fecha', date('Y-m-d'))) ?>" required></div>
            <div><label class="etiqueta" for="i_monto">Monto (RD$)</label><input id="i_monto" name="monto" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('monto')) ?>" required></div>
            <div><label class="etiqueta" for="i_linea">Línea</label><select id="i_linea" name="linea_negocio" class="input"><?php foreach (F::LINEAS as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></div>
            <div><label class="etiqueta" for="i_metodo">Método</label><select id="i_metodo" name="metodo" class="input"><?php foreach (A::METODOS as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></div>
        </div>
        <div><label class="etiqueta" for="i_ref">Referencia (opcional)</label><input id="i_ref" name="referencia" class="input"></div>
        <div class="grid grid-cols-[1fr_2fr] gap-3"><button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button><button class="btn-primario">Guardar</button></div>
    </form>
</dialog>
<?php endif; ?>
