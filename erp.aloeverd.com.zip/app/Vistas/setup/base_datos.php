<?php $faltaObligatorio = false; foreach ($requisitos as $r) { if ($r[2] && !$r[1]) { $faltaObligatorio = true; } } ?>
<ol class="mb-6 flex items-center gap-3 text-[13px] font-medium text-texto-suave">
    <li class="flex items-center gap-2 text-primario-700"><span class="grid h-6 w-6 place-items-center rounded-full bg-primario text-white">1</span> Base de datos</li>
    <li class="h-px flex-1 bg-linea"></li>
    <li class="flex items-center gap-2"><span class="grid h-6 w-6 place-items-center rounded-full bg-white ring-1 ring-linea">2</span> Administrador</li>
</ol>

<section class="tarjeta mb-6">
    <div class="tarjeta-cuerpo">
        <h2 class="text-lg font-semibold">Revisión del servidor</h2>
        <ul class="mt-3 divide-y divide-linea">
            <?php foreach ($requisitos as [$texto, $ok, $obligatorio]): ?>
                <li class="flex items-center justify-between gap-4 py-2.5 text-[15px]">
                    <span><?= e($texto) ?></span>
                    <?php if ($ok): ?>
                        <span class="chip-verde"><?= icono('check', 'h-3.5 w-3.5') ?> Bien</span>
                    <?php elseif ($obligatorio): ?>
                        <span class="chip-rojo">Falta</span>
                    <?php else: ?>
                        <span class="chip-ambar">Revisar</span>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php if ($faltaObligatorio): ?>
            <p class="mt-4 rounded-xl bg-red-50 px-4 py-3 text-[15px] text-red-800">Hay requisitos en rojo. Toma una captura de esta lista y envíala a soporte antes de seguir.</p>
        <?php endif; ?>
    </div>
</section>

<form method="post" action="<?= e(url('/setup/base-datos')) ?>" class="tarjeta tarjeta-cuerpo space-y-4">
    <?= csrf_campo() ?>
    <div>
        <h2 class="text-lg font-semibold">Conexión a la base de datos</h2>
        <p class="mt-1 text-texto-suave">Copia estos datos desde hPanel → Databases → Management.</p>
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
        <div>
            <label for="db_nombre" class="etiqueta">Nombre de la base de datos</label>
            <input id="db_nombre" name="db_nombre" class="input font-mono" value="<?= e(viejo('db_nombre', 'u334112631_erpaloeverd')) ?>" required>
        </div>
        <div>
            <label for="db_usuario" class="etiqueta">Usuario</label>
            <input id="db_usuario" name="db_usuario" class="input font-mono" value="<?= e(viejo('db_usuario', 'u334112631_aloeveadmin')) ?>" required>
        </div>
        <div>
            <label for="db_clave" class="etiqueta">Contraseña de la base de datos</label>
            <input id="db_clave" name="db_clave" type="password" class="input" autocomplete="off" required>
        </div>
        <div>
            <label for="db_host" class="etiqueta">Servidor</label>
            <input id="db_host" name="db_host" class="input font-mono" value="<?= e(viejo('db_host', 'localhost')) ?>">
            <p class="ayuda">En Hostinger casi siempre es <span class="font-mono">localhost</span>.</p>
        </div>
    </div>
    <div>
        <label for="app_url" class="etiqueta">Dirección del ERP</label>
        <input id="app_url" name="app_url" class="input font-mono" value="<?= e(viejo('app_url', \App\Core\Config::urlDetectada())) ?>">
    </div>
    <input type="hidden" name="db_puerto" value="3306">
    <button class="btn-primario w-full sm:w-auto" <?= $faltaObligatorio ? 'disabled' : '' ?>>Conectar y crear tablas</button>
</form>
