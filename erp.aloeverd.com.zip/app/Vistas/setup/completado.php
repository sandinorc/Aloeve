<div class="tarjeta tarjeta-cuerpo text-center">
    <div class="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-emerald-50 text-emerald-700"><?= icono('check') ?></div>
    <h2 class="font-display text-2xl">Instalación completada</h2>
    <p class="mt-2 text-texto-suave">El instalador quedó bloqueado. Para aplicar actualizaciones, entra como Administrador y abre <span class="font-mono">/setup/actualizar</span>.</p>
    <a href="<?= e(url('/login')) ?>" class="btn-primario mt-6">Ir a iniciar sesión</a>
</div>
