<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Actualizar el sistema',
    'descripcion' => 'Después de subir una fase nueva, aplica aquí los cambios de la base de datos. Haz un respaldo antes.',
]) ?>
<div class="grid gap-6 lg:grid-cols-2">
    <section class="tarjeta tarjeta-cuerpo">
        <h2 class="text-lg font-semibold">Cambios pendientes</h2>
        <?php if ($pendientes): ?>
            <ul class="mt-3 space-y-2">
                <?php foreach ($pendientes as $p): ?>
                    <li class="flex items-center gap-2 font-mono text-[14px]"><span class="chip-ambar">Pendiente</span> <?= e($p) ?></li>
                <?php endforeach; ?>
            </ul>
            <form method="post" class="mt-5">
                <?= csrf_campo() ?>
                <button class="btn-primario">Aplicar <?= count($pendientes) ?> cambio<?= count($pendientes) === 1 ? '' : 's' ?></button>
            </form>
        <?php else: ?>
            <p class="mt-3 text-texto-suave">Todo está al día. Versión <?= e(VERSION_ERP) ?>.</p>
        <?php endif; ?>
    </section>
    <section class="tarjeta tarjeta-cuerpo">
        <h2 class="text-lg font-semibold">Ya aplicados</h2>
        <ul class="mt-3 space-y-2">
            <?php foreach ($aplicadas as $a): ?>
                <li class="flex items-center gap-2 font-mono text-[14px]"><span class="chip-verde">Hecho</span> <?= e($a) ?></li>
            <?php endforeach; ?>
        </ul>
    </section>
</div>
