<div class="tarjeta tarjeta-cuerpo space-y-4">
    <h2 class="font-display text-2xl">Crea el archivo de configuración a mano</h2>
    <p class="text-texto-suave">La conexión funcionó, pero el servidor no dejó escribir en la carpeta <span class="font-mono">config</span>. En el File Manager de Hostinger crea el archivo <span class="font-mono">config/config.php</span>, pega exactamente este contenido, guárdalo y luego presiona Continuar.</p>
    <textarea class="input h-72 font-mono text-[13px]" readonly data-seleccionar><?= e($contenido) ?></textarea>
    <a href="<?= e(url('/setup')) ?>" class="btn-primario">Continuar</a>
</div>
