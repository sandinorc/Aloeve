<div class="tarjeta tarjeta-cuerpo">
    <h2 class="font-display text-2xl">Falta la clave de instalación</h2>
    <p class="mt-2 text-texto-suave">No se encontró el archivo <span class="font-mono">config/setup.key</span>. Vuelve a subir la carpeta <span class="font-mono">config</span> del paquete y recarga esta página.</p>
</div>
