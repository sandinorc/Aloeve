<ol class="mb-6 flex items-center gap-3 text-[13px] font-medium text-texto-suave">
    <li class="flex items-center gap-2 text-emerald-700"><span class="grid h-6 w-6 place-items-center rounded-full bg-emerald-600 text-white"><?= icono('check', 'h-3.5 w-3.5') ?></span> Base de datos</li>
    <li class="h-px flex-1 bg-linea"></li>
    <li class="flex items-center gap-2 text-primario-700"><span class="grid h-6 w-6 place-items-center rounded-full bg-primario text-white">2</span> Administrador</li>
</ol>
<form method="post" action="<?= e(url('/setup/admin')) ?>" class="tarjeta tarjeta-cuerpo space-y-4">
    <?= csrf_campo() ?>
    <div>
        <h2 class="text-lg font-semibold">Tu usuario Administrador</h2>
        <p class="mt-1 text-texto-suave">Con este usuario entrarás al ERP y crearás a los demás.</p>
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
        <div>
            <label for="nombre" class="etiqueta">Tu nombre</label>
            <input id="nombre" name="nombre" class="input" value="<?= e(viejo('nombre')) ?>" autocomplete="name" required>
        </div>
        <div>
            <label for="email" class="etiqueta">Correo</label>
            <input id="email" name="email" type="email" class="input" value="<?= e(viejo('email')) ?>" autocomplete="email" required>
        </div>
        <div>
            <label for="clave" class="etiqueta">Contraseña</label>
            <input id="clave" name="clave" type="password" class="input" autocomplete="new-password" required minlength="10">
            <p class="ayuda">Mínimo 10 caracteres, con mayúsculas, minúsculas y un número.</p>
        </div>
        <div>
            <label for="clave2" class="etiqueta">Repite la contraseña</label>
            <input id="clave2" name="clave2" type="password" class="input" autocomplete="new-password" required>
        </div>
    </div>
    <div>
        <label for="negocio" class="etiqueta">Nombre del negocio</label>
        <input id="negocio" name="negocio" class="input" value="<?= e(viejo('negocio', 'Aloeve Art Studio')) ?>">
    </div>
    <button class="btn-primario w-full sm:w-auto">Terminar instalación</button>
</form>
