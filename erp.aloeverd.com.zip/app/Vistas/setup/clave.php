<form method="get" action="<?= e(url('/setup')) ?>" class="tarjeta tarjeta-cuerpo space-y-4">
    <div>
        <h2 class="font-display text-2xl">Instalar el ERP</h2>
        <p class="mt-1 text-texto-suave">Escribe la clave de instalación que recibiste con el paquete.</p>
    </div>
    <div>
        <label for="clave" class="etiqueta">Clave de instalación</label>
        <input id="clave" name="clave" class="input font-mono" autocomplete="off" required autofocus>
    </div>
    <button class="btn-primario w-full">Continuar</button>
</form>
