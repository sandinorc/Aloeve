<div class="tarjeta tarjeta-cuerpo mx-auto max-w-lg text-center">
    <div class="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('buscar') ?></div>
    <h1 class="font-display text-2xl">Esta página no existe</h1>
    <p class="mt-2 text-texto-suave">Revisa la dirección o vuelve al inicio.</p>
    <a href="<?= e(url('/')) ?>" class="btn-secundario mt-6">Volver al inicio</a>
</div>
