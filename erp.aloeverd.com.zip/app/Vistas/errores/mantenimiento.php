<div class="tarjeta tarjeta-cuerpo text-center">
    <div class="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('refrescar') ?></div>
    <h2 class="font-display text-2xl">El sistema se está actualizando</h2>
    <p class="mt-2 text-texto-suave">Un Administrador debe terminar la actualización. Vuelve a intentar en unos minutos.</p>
    <form method="post" action="<?= e(url('/salir')) ?>" class="mt-6"><?= csrf_campo() ?><button class="btn-secundario">Salir</button></form>
</div>
