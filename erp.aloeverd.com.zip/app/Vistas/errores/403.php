<div class="tarjeta tarjeta-cuerpo mx-auto max-w-lg text-center">
    <div class="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-amber-50 text-amber-700"><?= icono('candado') ?></div>
    <h1 class="font-display text-2xl">No tienes permiso para ver esto</h1>
    <p class="mt-2 text-texto-suave">Si lo necesitas para tu trabajo, pídele a un Administrador que ajuste los permisos de tu rol.</p>
    <a href="<?= e(url('/')) ?>" class="btn-secundario mt-6">Volver al inicio</a>
</div>
