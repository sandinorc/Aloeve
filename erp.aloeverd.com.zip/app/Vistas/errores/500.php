<div class="tarjeta tarjeta-cuerpo mx-auto max-w-lg text-center">
    <div class="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-red-50 text-red-700"><?= icono('alerta') ?></div>
    <h1 class="font-display text-2xl">Algo salió mal</h1>
    <p class="mt-2 text-texto-suave">El error quedó guardado. Si se repite, envía esta referencia a soporte:</p>
    <p class="mt-3 font-mono text-lg font-semibold tracking-wider"><?= e($referencia ?? '') ?></p>
    <a href="<?= e(url('/')) ?>" class="btn-secundario mt-6">Volver al inicio</a>
</div>
