<?php
/** Layout para login, instalador y errores sin sesión. */
$titulo = $titulo ?? 'ERP';
$ancho = $ancho ?? 'max-w-md';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#231942">
    <title><?= e($titulo) ?> · Aloeve ERP</title>
    <link rel="icon" href="<?= e(asset('img/favicon.png')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <script src="<?= e(asset('js/app.js')) ?>" defer></script>
</head>
<body class="min-h-dvh" data-csrf="<?= e(\App\Core\Csrf::token()) ?>">
<div class="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(60rem_40rem_at_10%_-10%,#e7e1fb_0%,transparent_60%),radial-gradient(50rem_30rem_at_110%_110%,#f6ead0_0%,transparent_60%)]"></div>
<main class="mx-auto <?= e($ancho) ?> px-4 py-10 sm:py-16">
    <div class="mb-8 text-center">
        <span class="mx-auto grid h-20 w-20 place-items-center rounded-full bg-white shadow-tarjeta ring-1 ring-linea">
            <img src="<?= e(asset('img/logo.png')) ?>" alt="Aloeve" class="h-[72px] w-[72px] rounded-full">
        </span>
        <h1 class="mt-4 font-display text-3xl text-texto">Aloeve Art Studio</h1>
        <p class="mt-1 text-texto-suave">Sistema de Gestión Integral</p>
    </div>
    <?= \App\Core\View::parcial('parciales/flash') ?>
    <?= $contenido ?>
    <p class="mt-8 text-center text-[13px] text-texto-suave">© <?= date('Y') ?> Aloeve Art Studio · Acceso restringido</p>
</main>
</body>
</html>
