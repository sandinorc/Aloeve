<?php
use App\Modulos\Agenda\AgendaServicio as A;
use App\Modulos\Clientes\ClientesServicio as C;
use App\Modulos\Inventario\InventarioServicio as I;
[$et, $chip] = A::ESTADOS[$s['estado']];
$abierta = !in_array($s['estado'], ['cerrada', 'cancelada'], true);
$libres = (int) $s['capacidad'] - (int) $s['ocupados'];
$yaPaso = $s['fecha'] < date('Y-m-d') || ($s['fecha'] === date('Y-m-d') && $s['hora_inicio'] <= date('H:i:s'));
$cobrado = 0.0; $porCobrar = 0.0;
foreach ($reservas as $r) {
    if ($r['estado'] === 'cancelada') { continue; }
    $cobrado += (float) $r['pagado'];
    if ((int) $r['cortesia'] !== 1) { $porCobrar += max(0, (float) $r['monto'] - (float) $r['pagado']); }
}
$acciones = '';
if ($puedeEditar && $abierta) {
    $acciones .= '<a href="' . e(url('/agenda/sesiones/' . $s['id'] . '/editar')) . '" class="btn-secundario">' . icono('lapiz', 'h-4 w-4') . ' Editar</a>';
}
if ($puedeOperar && $abierta && $s['fecha'] <= date('Y-m-d')) {
    $acciones .= '<a href="' . e(url('/agenda/sesiones/' . $s['id'] . '/cerrar')) . '" class="btn-primario">' . icono('check', 'h-5 w-5') . ' Cerrar sesión</a>';
}
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $s['servicio'],
    'descripcion' => fecha($s['fecha']) . ' · ' . substr($s['hora_inicio'], 0, 5) . ' a ' . substr($s['hora_fin'], 0, 5) . ' · ' . ($s['facilitador'] ?? 'Sin facilitador') . ($s['sede'] ? ' · ' . $s['sede'] : ''),
    'volver' => ['texto' => 'Agenda', 'ruta' => '/agenda?semana=' . $s['fecha']],
    'acciones' => $acciones,
]) ?>

<div class="mb-6 flex flex-wrap items-center gap-2">
    <span class="<?= $chip ?>"><?= e($et) ?></span>
    <span class="chip-gris"><?= e(A::LINEAS[$s['linea_negocio']]) ?></span>
    <?php if ($abierta && $yaPaso): ?><span class="chip-ambar">Por cerrar</span><?php endif; ?>
    <?php if ($s['estado'] === 'cancelada' && $s['motivo_cancelacion']): ?><span class="text-[14px] text-texto-suave">Motivo: <?= e($s['motivo_cancelacion']) ?></span><?php endif; ?>
</div>

<div class="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Reservados</p><p class="mt-1 font-display text-2xl tabular-nums"><?= (int) $s['ocupados'] ?><span class="text-base text-texto-suave"> / <?= (int) $s['capacidad'] ?></span></p></div>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Llegaron</p><p class="mt-1 font-display text-2xl tabular-nums" data-asistentes><?= (int) $s['asistentes'] ?></p></div>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Cobrado</p><p class="mt-1 text-lg font-semibold tabular-nums"><?= e(dinero($cobrado)) ?></p></div>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Por cobrar</p><p class="mt-1 text-lg font-semibold tabular-nums <?= $porCobrar > 0 ? 'text-red-700' : '' ?>"><?= e(dinero($porCobrar)) ?></p></div>
</div>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
    <section class="tarjeta min-w-0">
        <div class="flex items-center justify-between border-b border-linea px-5 py-4">
            <h2 class="font-semibold">Participantes</h2>
            <span class="text-[14px] text-texto-suave"><?= $libres > 0 ? "$libres cupo" . ($libres === 1 ? '' : 's') . ' libre' . ($libres === 1 ? '' : 's') : 'Sin cupos' ?></span>
        </div>
        <?php if (!$reservas): ?>
            <p class="px-5 py-8 text-center text-texto-suave">Todavía no hay participantes.</p>
        <?php else: ?>
        <ul class="divide-y divide-linea">
            <?php foreach ($reservas as $r): [$pt, $pc] = A::estadoPago($r); $cancel = $r['estado'] === 'cancelada'; $deuda = (int) $r['cortesia'] !== 1 ? max(0, (float) $r['monto'] - (float) $r['pagado']) : 0; ?>
                <li class="px-5 py-4 <?= $cancel ? 'opacity-50' : '' ?>">
                    <div class="flex flex-wrap items-start gap-3">
                        <?php if ($puedeOperar && !$cancel && $s['estado'] !== 'cancelada'): ?>
                            <label class="mt-0.5 flex h-11 w-11 shrink-0 cursor-pointer items-center justify-center rounded-xl border border-linea has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50" title="Marcar llegada">
                                <input type="checkbox" class="h-6 w-6 rounded text-emerald-600 focus:ring-emerald-300" <?= (int) $r['asistio'] === 1 ? 'checked' : '' ?>
                                       data-asistencia="<?= e(url('/agenda/reservas/' . $r['id'] . '/asistencia')) ?>" aria-label="Llegó <?= e($r['cliente']) ?>">
                            </label>
                        <?php endif; ?>
                        <div class="min-w-0 flex-1">
                            <a href="<?= e(url('/clientes/' . $r['cliente_id'])) ?>" class="font-medium hover:text-primario-700"><?= e($r['cliente']) ?></a>
                            <?php if ((int) $r['personas'] > 1): ?><span class="chip-gris ml-1"><?= (int) $r['personas'] ?> personas</span><?php endif; ?>
                            <p class="text-[14px] text-texto-suave"><?= e(implode(' · ', array_filter([C::formatearTelefono($r['telefono']), $r['origen'] === 'amelia' ? 'Reserva web' : null, $r['notas']]))) ?></p>
                            <p class="mt-1 flex flex-wrap items-center gap-2 text-[14px]">
                                <span class="<?= $pc ?>"><?= e($pt) ?></span>
                                <?php if ($cancel): ?><span class="chip-rojo">Cancelada</span>
                                <?php elseif ($r['estado'] === 'no_show'): ?><span class="chip-gris">No vino</span><?php endif; ?>
                                <span class="tabular-nums text-texto-suave"><?= e(dinero($r['pagado'])) ?> de <?= e(dinero($r['monto'])) ?></span>
                            </p>
                        </div>
                        <?php if ($puedeOperar && !$cancel && $abierta): ?>
                        <div class="flex shrink-0 gap-2">
                            <?php if ($deuda > 0): ?><button type="button" class="btn-secundario btn-sm" data-dialogo-abrir="pago-<?= (int) $r['id'] ?>">Cobrar</button><?php endif; ?>
                            <form method="post" action="<?= e(url('/agenda/reservas/' . $r['id'] . '/cancelar')) ?>" data-confirmar="¿Cancelar la reserva de <?= e($r['cliente']) ?>?">
                                <?= csrf_campo() ?><button class="btn-secundario btn-sm" aria-label="Cancelar reserva"><?= icono('cerrar', 'h-4 w-4') ?></button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($deuda > 0 && $puedeOperar && $abierta): ?>
                    <dialog id="pago-<?= (int) $r['id'] ?>" class="dialogo" aria-labelledby="tp-<?= (int) $r['id'] ?>">
                        <form method="post" action="<?= e(url('/agenda/reservas/' . $r['id'] . '/pago')) ?>" class="space-y-4">
                            <?= csrf_campo() ?>
                            <div class="flex items-start justify-between gap-4">
                                <h2 id="tp-<?= (int) $r['id'] ?>" class="text-xl font-semibold">Cobrar a <?= e($r['cliente']) ?></h2>
                                <button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button>
                            </div>
                            <p class="text-texto-suave">Pendiente: <strong class="text-texto"><?= e(dinero($deuda)) ?></strong></p>
                            <div class="grid grid-cols-2 gap-3">
                                <div><label class="etiqueta" for="pm<?= (int) $r['id'] ?>">Monto</label><input id="pm<?= (int) $r['id'] ?>" name="monto" class="input tabular-nums" inputmode="decimal" value="<?= e(number_format($deuda, 2, '.', '')) ?>" required></div>
                                <div><label class="etiqueta" for="pmt<?= (int) $r['id'] ?>">Método</label>
                                    <select id="pmt<?= (int) $r['id'] ?>" name="metodo" class="input"><?php foreach (A::METODOS as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></div>
                            </div>
                            <div><label class="etiqueta" for="pr<?= (int) $r['id'] ?>">Referencia (opcional)</label><input id="pr<?= (int) $r['id'] ?>" name="referencia" class="input" placeholder="Número de transferencia o voucher"></div>
                            <p class="text-[13px] text-texto-suave">Queda registrado como ingreso en Finanzas. Si el cliente pide factura con NCF, cobra la experiencia en el Punto de venta en lugar de aquí.</p>
                            <div class="grid grid-cols-[1fr_2fr] gap-3"><button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button><button class="btn-primario">Registrar pago</button></div>
                        </form>
                    </dialog>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <?php if ($puedeOperar && $abierta): ?>
        <form id="agregar" method="post" action="<?= e(url('/agenda/sesiones/' . $s['id'] . '/reservas')) ?>" class="space-y-4 border-t border-linea bg-fondo/50 p-5" data-form-reserva data-precio="<?= e((string) (float) $s['precio_persona']) ?>">
            <?= csrf_campo() ?>
            <h3 class="font-semibold">Agregar participante</h3>
            <?php if ($aviso): ?>
                <div class="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-[14px] text-amber-900"><?= e($aviso) ?>
                    <label class="mt-2 flex items-center gap-2"><input type="checkbox" name="confirmar_cupo" value="1" class="check"> Pasar de la capacidad</label></div>
            <?php endif; ?>
            <?= \App\Core\View::parcial('parciales/buscador_cliente', ['nombre' => 'cliente_id', 'idCampo' => 'participante', 'etiqueta' => 'Cliente', 'actual' => null]) ?>
            <details class="text-[14px]" <?= viejo('nuevo_nombre') !== '' ? 'open' : '' ?>>
                <summary class="cursor-pointer text-primario-700">¿No está registrado? Crear al vuelo</summary>
                <div class="mt-3 grid gap-3 sm:grid-cols-2">
                    <div><label class="etiqueta" for="nuevo_nombre">Nombre</label><input id="nuevo_nombre" name="nuevo_nombre" class="input" value="<?= e(viejo('nuevo_nombre')) ?>"></div>
                    <div><label class="etiqueta" for="nuevo_telefono">Teléfono</label><input id="nuevo_telefono" name="nuevo_telefono" class="input" inputmode="tel" value="<?= e(viejo('nuevo_telefono')) ?>"></div>
                </div>
            </details>
            <div class="grid gap-3 sm:grid-cols-3">
                <div><label class="etiqueta" for="personas">Personas</label><input id="personas" name="personas" type="number" min="1" class="input tabular-nums" value="<?= e(viejo('personas', '1')) ?>" data-personas></div>
                <div><label class="etiqueta" for="monto">Total a pagar</label><input id="monto" name="monto" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('monto', number_format((float) $s['precio_persona'], 2, '.', ''))) ?>" data-monto></div>
                <div><label class="etiqueta" for="pago">Paga ahora</label><input id="pago" name="pago" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('pago', '0')) ?>"></div>
            </div>
            <div class="grid gap-3 sm:grid-cols-2">
                <div><label class="etiqueta" for="metodo">Método de pago</label><select id="metodo" name="metodo" class="input"><?php foreach (A::METODOS as $k => $t): ?><option value="<?= e($k) ?>"><?= e($t) ?></option><?php endforeach; ?></select></div>
                <div><label class="etiqueta" for="notas_r">Nota</label><input id="notas_r" name="notas" class="input" value="<?= e(viejo('notas')) ?>" placeholder="Cumpleaños, alergia…"></div>
            </div>
            <label class="flex items-center gap-3 text-[15px]"><input type="checkbox" name="cortesia" value="1" class="check"> Cortesía (no paga)</label>
            <button class="btn-primario"><?= icono('mas', 'h-5 w-5') ?> Agregar</button>
        </form>
        <?php endif; ?>
    </section>

    <aside class="space-y-4">
        <section class="tarjeta tarjeta-cuerpo space-y-2 text-[15px]">
            <h2 class="font-semibold">Detalles</h2>
            <p>Precio por persona: <strong class="tabular-nums"><?= e(dinero($s['precio_persona'])) ?></strong></p>
            <?php if ($s['notas']): ?><p class="whitespace-pre-line text-texto-suave"><?= e($s['notas']) ?></p><?php endif; ?>
            <?php if ($s['estado'] === 'cerrada'): ?>
                <p class="text-texto-suave">Cerrada el <?= e(fecha($s['cerrada_en'], true)) ?>.</p>
                <?php if ($s['notas_cierre']): ?><p class="whitespace-pre-line">"<?= e($s['notas_cierre']) ?>"</p><?php endif; ?>
            <?php endif; ?>
        </section>
        <?php if ($consumo): ?>
        <section class="tarjeta tarjeta-cuerpo text-[15px]">
            <h2 class="font-semibold">Materiales usados</h2>
            <ul class="mt-2 space-y-1"><?php foreach ($consumo as $c): ?><li class="flex justify-between gap-2"><span><?= e($c['nombre']) ?></span><span class="tabular-nums text-texto-suave"><?= e(I::fmt($c['cantidad']) . ' ' . $c['unidad']) ?></span></li><?php endforeach; ?></ul>
        </section>
        <?php endif; ?>
        <?php if ($puedeEditar && $abierta): ?>
        <section class="tarjeta tarjeta-cuerpo space-y-3">
            <?php if ($s['estado'] === 'programada'): ?>
            <form method="post" action="<?= e(url('/agenda/sesiones/' . $s['id'] . '/estado')) ?>">
                <?= csrf_campo() ?><input type="hidden" name="accion" value="confirmar">
                <button class="btn-secundario w-full"><?= icono('check', 'h-4 w-4') ?> Confirmar sesión</button>
            </form>
            <?php endif; ?>
            <details>
                <summary class="btn-peligro w-full cursor-pointer list-none">Cancelar sesión</summary>
                <form method="post" action="<?= e(url('/agenda/sesiones/' . $s['id'] . '/estado')) ?>" class="mt-3 space-y-3">
                    <?= csrf_campo() ?><input type="hidden" name="accion" value="cancelar">
                    <label class="etiqueta" for="motivo">Motivo</label>
                    <input id="motivo" name="motivo" class="input" required placeholder="Ej. pocos inscritos, lluvia">
                    <p class="text-[13px] text-texto-suave">Se cancelan también todas sus reservas.</p>
                    <button class="btn-peligro w-full">Confirmar cancelación</button>
                </form>
            </details>
        </section>
        <?php endif; ?>
    </aside>
</div>
