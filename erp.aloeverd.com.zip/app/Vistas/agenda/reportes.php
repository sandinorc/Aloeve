<?php
$csv = url('/agenda/reportes') . '?' . http_build_query(['desde' => $desde, 'hasta' => $hasta, 'formato' => 'csv']);
$pct = static fn(array $g) => $g['capacidad'] > 0 ? round($g['asistentes'] / $g['capacidad'] * 100) . '%' : '—';
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Agenda',
    'descripcion' => 'Ocupación = asistentes ÷ capacidad, solo de sesiones cerradas.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>',
]) ?>
<?= \App\Core\View::parcial('agenda/_pestanas') ?>
<form method="get" class="mb-6 flex flex-wrap items-end gap-3">
    <div><label for="desde" class="etiqueta">Desde</label><input id="desde" type="date" name="desde" value="<?= e($desde) ?>" class="input"></div>
    <div><label for="hasta" class="etiqueta">Hasta</label><input id="hasta" type="date" name="hasta" value="<?= e($hasta) ?>" class="input"></div>
    <button class="btn-secundario">Aplicar</button>
</form>
<?php if (!$filas): ?>
    <div class="tarjeta px-5 py-10 text-center text-texto-suave">No hay sesiones en ese rango.</div>
<?php else: ?>
<div class="mb-6 grid gap-6 lg:grid-cols-2">
    <?php foreach (['Por experiencia' => $porServicio, 'Por facilitador' => $porFacilitador] as $titulo => $grupo): ?>
    <section class="tarjeta overflow-hidden">
        <h2 class="border-b border-linea px-5 py-4 font-semibold"><?= e($titulo) ?></h2>
        <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th><?= $titulo === 'Por experiencia' ? 'Experiencia' : 'Facilitador' ?></th><th class="text-right">Sesiones</th><th class="text-right">Ocupación</th><th class="text-right">Ingresos</th></tr></thead>
            <tbody>
            <?php foreach ($grupo as $nombre => $g): $p = $g['capacidad'] > 0 ? $g['asistentes'] / $g['capacidad'] * 100 : null; ?>
                <tr>
                    <td data-principal><?= e($nombre) ?></td>
                    <td data-etiqueta="Sesiones" class="text-right tabular-nums"><?= (int) $g['sesiones'] ?></td>
                    <td data-etiqueta="Ocupación" class="text-right tabular-nums">
                        <?php if ($p === null): ?><span class="text-texto-suave">Sin cerrar</span><?php else: ?>
                            <span class="inline-flex items-center gap-2"><span class="barra w-16"><span class="<?= $p >= 70 ? 'bg-emerald-500' : ($p >= 50 ? 'bg-amber-500' : 'bg-red-500') ?>" style="width: <?= min(100, round($p)) ?>%"></span></span><?= round($p) ?>%</span>
                        <?php endif; ?>
                    </td>
                    <td data-etiqueta="Ingresos" class="text-right tabular-nums"><?= e(dinero($g['ingresos'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </section>
    <?php endforeach; ?>
</div>
<section class="tarjeta overflow-hidden">
    <h2 class="border-b border-linea px-5 py-4 font-semibold">Sesiones del periodo</h2>
    <div class="overflow-x-auto">
    <table class="tabla tabla-resp">
        <thead><tr><th>Fecha</th><th>Experiencia</th><th>Facilitador</th><th class="text-right">Reservados</th><th class="text-right">Asistieron</th><th class="text-right">Ocupación</th><th class="text-right">Ingresos</th></tr></thead>
        <tbody>
        <?php foreach ($filas as $f): $cerrada = $f['estado'] === 'cerrada'; ?>
            <tr>
                <td data-principal class="whitespace-nowrap tabular-nums"><a class="hover:text-primario-700" href="<?= e(url('/agenda/sesiones/' . $f['id'])) ?>"><?= e(fecha($f['fecha'])) ?> <?= e(substr($f['hora_inicio'], 0, 5)) ?></a></td>
                <td data-etiqueta="Experiencia"><?= e($f['servicio']) ?></td>
                <td data-etiqueta="Facilitador"><?= e($f['facilitador'] ?? '—') ?></td>
                <td data-etiqueta="Reservados" class="text-right tabular-nums"><?= (int) $f['reservados'] ?> / <?= (int) $f['capacidad'] ?></td>
                <td data-etiqueta="Asistieron" class="text-right tabular-nums"><?= $cerrada ? (int) $f['asistentes'] : '<span class="text-texto-suave">—</span>' ?></td>
                <td data-etiqueta="Ocupación" class="text-right tabular-nums"><?= $cerrada ? round($f['asistentes'] / max(1, $f['capacidad']) * 100) . '%' : '<span class="chip-gris">Sin cerrar</span>' ?></td>
                <td data-etiqueta="Ingresos" class="text-right tabular-nums"><?= e(dinero($f['ingresos'])) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</section>
<?php endif; ?>
