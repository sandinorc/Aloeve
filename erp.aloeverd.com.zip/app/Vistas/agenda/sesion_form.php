<?php
$v = static fn(string $c, $d = '') => viejo($c, isset($s[$c]) ? (in_array($c, ['hora_inicio', 'hora_fin'], true) ? substr((string) $s[$c], 0, 5) : $s[$c]) : $d);
$fechaInicial = get('fecha') ?: date('Y-m-d');
$horaInicial = preg_match('/^\d{2}:\d{2}$/', get('hora')) ? get('hora') : '18:00';
$tasa = (float) \App\Core\Ajustes::get('fiscal.itbis', '18') / 100;
$datosServicios = [];
foreach ($servicios as $x) {
    $final = (float) $x['precio'] * ((int) $x['lleva_itbis'] === 1 ? 1 + $tasa : 1);
    $datosServicios[$x['id']] = ['duracion' => (int) $x['duracion_min'], 'capacidad' => (int) $x['capacidad'], 'precio' => round($final, 2)];
}
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $s ? 'Editar sesión' : 'Nueva sesión',
    'descripcion' => $s ? $s['servicio'] . ' · ' . fecha($s['fecha']) : 'Al elegir la experiencia se completan la duración, la capacidad y el precio.',
    'volver' => $s ? ['texto' => 'Sesión', 'ruta' => '/agenda/sesiones/' . $s['id']] : ['texto' => 'Agenda', 'ruta' => '/agenda'],
]) ?>
<?php if ($choque): ?>
    <div class="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-[15px] text-amber-900">
        <p class="flex items-start gap-2"><?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?> El facilitador ya tiene a esa hora: <?= e(implode('; ', $choque)) ?>.</p>
        <p class="mt-1 pl-7 text-[14px]">Si de verdad dará las dos, marca la casilla de abajo y guarda de nuevo.</p>
    </div>
<?php endif; ?>
<form method="post" action="<?= e(url($s ? '/agenda/sesiones/' . $s['id'] : '/agenda/sesiones')) ?>" class="tarjeta tarjeta-cuerpo max-w-3xl space-y-5"
      data-form-sesion data-servicios='<?= e(json_encode($datosServicios)) ?>'>
    <?= csrf_campo() ?>
    <div>
        <label for="servicio_id" class="etiqueta">Experiencia <span class="text-red-600">*</span></label>
        <select id="servicio_id" name="servicio_id" class="input" required data-servicio>
            <option value="">Elige una experiencia</option>
            <?php foreach ($servicios as $x): ?><option value="<?= (int) $x['id'] ?>" <?= $v('servicio_id') === (string) $x['id'] ? 'selected' : '' ?>><?= e($x['nombre']) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="grid gap-4 sm:grid-cols-3">
        <div>
            <label for="fecha" class="etiqueta">Fecha</label>
            <input id="fecha" name="fecha" type="date" class="input" value="<?= e($v('fecha', $fechaInicial)) ?>" required>
        </div>
        <div>
            <label for="hora_inicio" class="etiqueta">Empieza</label>
            <input id="hora_inicio" name="hora_inicio" type="time" step="900" class="input" value="<?= e($v('hora_inicio', $horaInicial)) ?>" required data-inicio>
        </div>
        <div>
            <label for="hora_fin" class="etiqueta">Termina</label>
            <input id="hora_fin" name="hora_fin" type="time" step="900" class="input" value="<?= e($v('hora_fin')) ?>" required data-fin>
        </div>
    </div>
    <div class="grid gap-4 sm:grid-cols-2">
        <div>
            <label for="facilitador_id" class="etiqueta">Facilitador</label>
            <select id="facilitador_id" name="facilitador_id" class="input">
                <option value="">Sin asignar</option>
                <?php foreach ($facilitadores as $x): ?><option value="<?= (int) $x['id'] ?>" <?= $v('facilitador_id') === (string) $x['id'] ? 'selected' : '' ?>><?= e($x['nombre']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="sede_id" class="etiqueta">Sede</label>
            <select id="sede_id" name="sede_id" class="input">
                <?php foreach ($sedes as $x): ?><option value="<?= (int) $x['id'] ?>" <?= $v('sede_id', (string) ($sedes[0]['id'] ?? '')) === (string) $x['id'] ? 'selected' : '' ?>><?= e($x['nombre']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="capacidad" class="etiqueta">Capacidad (personas)</label>
            <input id="capacidad" name="capacidad" type="number" min="1" class="input tabular-nums" value="<?= e($v('capacidad')) ?>" required data-capacidad>
        </div>
        <div>
            <label for="precio_persona" class="etiqueta">Precio por persona (RD$)</label>
            <input id="precio_persona" name="precio_persona" class="input tabular-nums" inputmode="decimal" value="<?= e($v('precio_persona')) ?>" data-precio-persona>
            <p class="ayuda">Precio final que paga cada persona.</p>
        </div>
    </div>
    <div>
        <label for="notas" class="etiqueta">Notas</label>
        <textarea id="notas" name="notas" rows="2" class="input" placeholder="Obra a pintar, ocasión especial, empresa…"><?= e($v('notas')) ?></textarea>
    </div>
    <?php if ($choque): ?>
        <label class="flex items-start gap-3 rounded-xl bg-amber-50 p-3 text-amber-900"><input type="checkbox" name="confirmar_choque" value="1" class="check mt-0.5"> Confirmo el horario aunque el facilitador tenga otra sesión.</label>
    <?php endif; ?>
    <?php if (!$s): ?>
        <label class="flex items-start gap-3 text-[14px] text-texto-suave"><input type="checkbox" name="confirmar_pasada" value="1" class="check mt-0.5"> Es una sesión que ya ocurrió (para registrarla después)</label>
    <?php endif; ?>
    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $s ? 'Guardar cambios' : 'Programar sesión' ?></button>
        <a href="<?= e(url($s ? '/agenda/sesiones/' . $s['id'] : '/agenda')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
