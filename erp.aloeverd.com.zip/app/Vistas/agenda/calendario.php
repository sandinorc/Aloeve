<?php
use App\Modulos\Agenda\AgendaServicio as A;
$meses = ['', 'ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
$nombresDia = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
$hoy = date('Y-m-d');
$ini = 7; $fin = 23; $px = 52; // horas visibles y alto por hora
$q = array_filter(['facilitador' => get('facilitador'), 'sede' => get('sede')]);
$enlaceSemana = static fn(int $ts) => url('/agenda') . '?' . http_build_query(['semana' => date('Y-m-d', $ts)] + $q);
$rango = date('j', $lunes) . ' ' . $meses[(int) date('n', $lunes)] . ' – ' . date('j', strtotime('+6 day', $lunes)) . ' ' . $meses[(int) date('n', strtotime('+6 day', $lunes))] . ' ' . date('Y', strtotime('+6 day', $lunes));
$editar = puede('agenda.editar');
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Agenda',
    'descripcion' => 'Sesiones de la semana. Toca una sesión para ver participantes, cobrar o cerrarla.',
    'acciones' => $editar ? '<a href="' . e(url('/agenda/sesiones/nueva')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nueva sesión</a>' : '',
]) ?>
<?= \App\Core\View::parcial('agenda/_pestanas') ?>
<?= \App\Core\View::parcial('agenda/_por_cerrar', ['porCerrar' => $porCerrar]) ?>

<?php if ($editar && $experiencias === 0): ?>
    <div class="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-[15px] text-sky-900">
        <?= icono('info', 'h-5 w-5 shrink-0') ?>
        <span class="flex-1">Para programar sesiones, primero crea tus experiencias (Paint &amp; Wine, Café &amp; Paint…) con su precio, duración y capacidad.</span>
        <a href="<?= e(url('/agenda/experiencias/nueva')) ?>" class="font-medium underline">Crear experiencia</a>
    </div>
<?php endif; ?>

<div class="mb-4 flex flex-wrap items-center gap-3">
    <div class="inline-flex items-center rounded-xl border border-linea bg-white">
        <a href="<?= e($enlaceSemana(strtotime('-7 day', $lunes))) ?>" class="grid h-11 w-11 place-items-center rounded-l-xl hover:bg-fondo" aria-label="Semana anterior"><?= icono('izquierda', 'h-5 w-5') ?></a>
        <a href="<?= e($enlaceSemana(time())) ?>" class="flex h-11 items-center border-x border-linea px-4 text-[15px] font-medium hover:bg-fondo">Hoy</a>
        <a href="<?= e($enlaceSemana(strtotime('+7 day', $lunes))) ?>" class="grid h-11 w-11 place-items-center rounded-r-xl hover:bg-fondo" aria-label="Semana siguiente"><?= icono('derecha', 'h-5 w-5') ?></a>
    </div>
    <h2 class="text-lg font-semibold"><?= e($rango) ?></h2>
    <form method="get" class="ml-auto flex flex-wrap gap-2">
        <input type="hidden" name="semana" value="<?= e(date('Y-m-d', $lunes)) ?>">
        <?php if (puede('agenda.ver')): ?>
        <select name="facilitador" class="input w-auto" aria-label="Facilitador" data-enviar-al-cambiar>
            <option value="">Todos los facilitadores</option>
            <?php foreach ($facilitadores as $f): ?><option value="<?= (int) $f['id'] ?>" <?= get('facilitador') === (string) $f['id'] ? 'selected' : '' ?>><?= e($f['nombre']) ?></option><?php endforeach; ?>
        </select>
        <?php endif; ?>
        <?php if (count($sedes) > 1): ?>
        <select name="sede" class="input w-auto" aria-label="Sede" data-enviar-al-cambiar>
            <option value="">Todas las sedes</option>
            <?php foreach ($sedes as $s): ?><option value="<?= (int) $s['id'] ?>" <?= get('sede') === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['nombre']) ?></option><?php endforeach; ?>
        </select>
        <?php endif; ?>
        <noscript><button class="btn-secundario">Filtrar</button></noscript>
    </form>
</div>

<!-- Escritorio: cuadrícula semanal -->
<div class="tarjeta hidden overflow-hidden lg:block">
    <div class="grid grid-cols-[64px_repeat(7,minmax(0,1fr))] border-b border-linea bg-fondo/60">
        <div></div>
        <?php foreach ($dias as $i => $d): ?>
            <div class="border-l border-linea px-2 py-2 text-center <?= $d === $hoy ? 'bg-primario-50' : '' ?>">
                <div class="text-[11px] font-semibold uppercase tracking-wider text-texto-suave"><?= $nombresDia[$i] ?></div>
                <div class="text-lg font-semibold tabular-nums <?= $d === $hoy ? 'text-primario-700' : '' ?>"><?= (int) date('j', strtotime($d)) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="grid grid-cols-[64px_repeat(7,minmax(0,1fr))]">
        <div>
            <?php for ($h = $ini; $h < $fin; $h++): ?>
                <div class="relative border-b border-linea/70 pr-2 text-right text-[12px] text-texto-suave tabular-nums" style="height: <?= $px ?>px"><span class="relative -top-2"><?= sprintf('%02d:00', $h) ?></span></div>
            <?php endfor; ?>
        </div>
        <?php foreach ($dias as $d): ?>
            <div class="relative border-l border-linea <?= $d === $hoy ? 'bg-primario-50/40' : '' ?>">
                <?php for ($h = $ini; $h < $fin; $h++): ?>
                    <?php if ($editar): ?>
                        <a href="<?= e(url('/agenda/sesiones/nueva?fecha=' . $d . '&hora=' . sprintf('%02d:00', $h))) ?>" class="block border-b border-linea/70 hover:bg-primario-50" style="height: <?= $px ?>px" aria-label="Crear sesión el <?= e(fecha($d)) ?> a las <?= $h ?>:00" tabindex="-1"></a>
                    <?php else: ?>
                        <div class="border-b border-linea/70" style="height: <?= $px ?>px"></div>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php
                // Carriles: sesiones que se cruzan se muestran lado a lado
                $carriles = []; $finCarril = [];
                foreach ($porDia[$d] as $k => $x) {
                    $ia = A::minutos($x['hora_inicio']);
                    $c = 0;
                    while (isset($finCarril[$c]) && $finCarril[$c] > $ia) { $c++; }
                    $finCarril[$c] = A::minutos($x['hora_fin']);
                    $carriles[$k] = $c;
                }
                $nCarriles = max(1, count($finCarril));
                foreach ($porDia[$d] as $k => $s):
                    $ancho = 100 / $nCarriles;
                    $izq = $carriles[$k] * $ancho;
                    $a = max($ini * 60, A::minutos($s['hora_inicio']));
                    $b = min($fin * 60, max($a + 30, A::minutos($s['hora_fin'])));
                    $top = ($a - $ini * 60) * $px / 60;
                    $alto = max(28, ($b - $a) * $px / 60 - 2);
                    $cancelada = $s['estado'] === 'cancelada';
                ?>
                    <a href="<?= e(url('/agenda/sesiones/' . $s['id'])) ?>"
                       class="absolute overflow-hidden rounded-lg border-l-4 bg-white px-2 py-1 text-[12px] leading-tight shadow-tarjeta ring-1 ring-linea hover:ring-primario-300 <?= $cancelada ? 'opacity-50 line-through' : '' ?>"
                       style="top: <?= round($top, 1) ?>px; height: <?= round($alto, 1) ?>px; left: calc(<?= round($izq, 2) ?>% + 3px); width: calc(<?= round($ancho, 2) ?>% - 6px); border-left-color: <?= e($s['color']) ?>">
                        <span class="block truncate font-semibold text-texto"><?= e(substr($s['hora_inicio'], 0, 5)) ?> <?= e($s['servicio']) ?></span>
                        <span class="block truncate text-texto-suave"><?= e($s['facilitador'] ?? 'Sin facilitador') ?></span>
                        <span class="block truncate tabular-nums text-texto-suave"><?= (int) $s['ocupados'] ?>/<?= (int) $s['capacidad'] ?> · <?= e(A::ESTADOS[$s['estado']][0]) ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php if ($editar): ?><p class="mt-2 hidden text-[13px] text-texto-suave lg:block">Haz clic en un espacio vacío para crear una sesión a esa hora.</p><?php endif; ?>

<!-- Celular y tablet: lista por día -->
<div class="space-y-4 lg:hidden">
    <?php foreach ($dias as $i => $d): ?>
        <section>
            <h3 class="mb-2 flex items-baseline gap-2 text-[15px] font-semibold <?= $d === $hoy ? 'text-primario-700' : '' ?>">
                <?= $nombresDia[$i] ?> <?= (int) date('j', strtotime($d)) ?> <?= $meses[(int) date('n', strtotime($d))] ?>
                <?php if ($d === $hoy): ?><span class="chip-morado">Hoy</span><?php endif; ?>
            </h3>
            <?php if (!$porDia[$d]): ?>
                <p class="rounded-xl border border-dashed border-linea px-4 py-3 text-[14px] text-texto-suave">Sin sesiones.</p>
            <?php else: ?>
                <ul class="space-y-2">
                    <?php foreach ($porDia[$d] as $s): [$et, $chip] = A::ESTADOS[$s['estado']]; ?>
                        <li>
                            <a href="<?= e(url('/agenda/sesiones/' . $s['id'])) ?>" class="tarjeta flex items-center gap-3 border-l-4 p-3" style="border-left-color: <?= e($s['color']) ?>">
                                <span class="w-14 shrink-0 text-center tabular-nums">
                                    <span class="block font-semibold"><?= e(substr($s['hora_inicio'], 0, 5)) ?></span>
                                    <span class="block text-[12px] text-texto-suave"><?= e(substr($s['hora_fin'], 0, 5)) ?></span>
                                </span>
                                <span class="min-w-0 flex-1">
                                    <span class="block truncate font-medium"><?= e($s['servicio']) ?></span>
                                    <span class="block truncate text-[14px] text-texto-suave"><?= e($s['facilitador'] ?? 'Sin facilitador') ?></span>
                                </span>
                                <span class="shrink-0 text-right">
                                    <span class="block font-semibold tabular-nums"><?= (int) $s['ocupados'] ?>/<?= (int) $s['capacidad'] ?></span>
                                    <span class="<?= $chip ?>"><?= e($et) ?></span>
                                </span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</div>
