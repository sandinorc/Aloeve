<?php use App\Modulos\Agenda\AgendaServicio as A; ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Agenda',
    'descripcion' => 'Las experiencias que se programan: precio, duración, capacidad y materiales por persona.',
    'acciones' => puede('agenda.editar') ? '<a href="' . e(url('/agenda/experiencias/nueva')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nueva experiencia</a>' : '',
]) ?>
<?= \App\Core\View::parcial('agenda/_pestanas') ?>
<?php if (!$filas): ?>
    <div class="tarjeta px-5 py-12 text-center">
        <p class="font-medium">Todavía no hay experiencias</p>
        <p class="mt-1 text-texto-suave">Crea Paint &amp; Wine, Café &amp; Paint, Adolescentes, Corporativo, Turismo… y luego prográmalas en la agenda.</p>
    </div>
<?php else: ?>
<div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
    <?php foreach ($filas as $x): $tasa = (float) \App\Core\Ajustes::get('fiscal.itbis', '18') / 100; $final = (float) $x['precio'] * ((int) $x['lleva_itbis'] === 1 ? 1 + $tasa : 1); ?>
        <a href="<?= e(url('/agenda/experiencias/' . $x['id'])) ?>" class="tarjeta flex flex-col border-t-4 p-5 hover:ring-1 hover:ring-primario-300 <?= (int) $x['activo'] === 1 ? '' : 'opacity-60' ?>" style="border-top-color: <?= e($x['color']) ?>">
            <div class="flex items-start justify-between gap-2">
                <h2 class="text-lg font-semibold"><?= e($x['nombre']) ?></h2>
                <span class="chip-gris"><?= e(A::LINEAS[$x['linea_negocio']]) ?></span>
            </div>
            <p class="mt-1 text-[14px] text-texto-suave"><?= e(floor($x['duracion_min'] / 60) . ' h' . ($x['duracion_min'] % 60 ? ' ' . $x['duracion_min'] % 60 . ' min' : '')) ?> · hasta <?= (int) $x['capacidad'] ?> personas<?= $x['edad_min'] !== null ? ' · ' . (int) $x['edad_min'] . ($x['edad_max'] !== null ? '–' . (int) $x['edad_max'] : '+') . ' años' : '' ?></p>
            <p class="mt-3 font-display text-2xl tabular-nums"><?= e(dinero($final)) ?> <span class="font-sans text-[13px] text-texto-suave">por persona</span></p>
            <p class="mt-3 flex gap-3 text-[13px] text-texto-suave"><span><?= (int) $x['materiales'] ?> materiales en receta</span><span><?= (int) $x['proximas'] ?> sesiones próximas</span></p>
            <?php if ((int) $x['activo'] !== 1): ?><span class="chip-gris mt-2 self-start">Inactiva</span><?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>
