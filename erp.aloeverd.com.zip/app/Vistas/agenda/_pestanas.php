<?php
$ruta = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$pestanas = ['/agenda' => 'Calendario', '/agenda/sesiones' => 'Sesiones'];
if (puede('agenda.ver')) {
    $pestanas += ['/agenda/experiencias' => 'Experiencias', '/facilitadores' => 'Facilitadores', '/agenda/reportes' => 'Reportes'];
}
?>
<nav class="-mx-4 mb-6 overflow-x-auto px-4 sm:mx-0 sm:px-0" aria-label="Secciones de agenda">
    <ul class="inline-flex min-w-full gap-1 border-b border-linea sm:min-w-0">
        <?php foreach ($pestanas as $r => $t): $activa = $ruta === $r || ($r !== '/agenda' && str_starts_with($ruta, $r)); ?>
            <li><a href="<?= e(url($r)) ?>" class="-mb-px inline-flex min-h-[44px] items-center whitespace-nowrap border-b-2 px-3 text-[15px] font-medium <?= $activa ? 'border-primario text-primario-700' : 'border-transparent text-texto-suave hover:text-texto' ?>" <?= $activa ? 'aria-current="page"' : '' ?>><?= e($t) ?></a></li>
        <?php endforeach; ?>
    </ul>
</nav>
