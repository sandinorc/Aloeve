<?php use App\Modulos\Inventario\InventarioServicio as I; ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Cerrar sesión',
    'descripcion' => $s['servicio'] . ' · ' . fecha($s['fecha']) . ' · ' . substr($s['hora_inicio'], 0, 5),
    'volver' => ['texto' => 'Sesión', 'ruta' => '/agenda/sesiones/' . $s['id']],
]) ?>
<form method="post" class="max-w-3xl space-y-6" data-form-cierre>
    <?= csrf_campo() ?>
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">1. ¿Quién vino?</h2>
        <?php if (!$reservas): ?>
            <p class="px-5 py-4 text-texto-suave">No hubo participantes registrados.</p>
        <?php else: ?>
        <ul class="divide-y divide-linea">
            <?php foreach ($reservas as $r): $marcado = (int) $r['asistio'] === 1 || ($r['asistio'] === null && $r['estado'] !== 'no_show'); ?>
                <li>
                    <label class="flex min-h-[52px] cursor-pointer items-center gap-3 px-5 py-2 hover:bg-fondo">
                        <input type="hidden" name="asistio[<?= (int) $r['id'] ?>]" value="0">
                        <input type="checkbox" name="asistio[<?= (int) $r['id'] ?>]" value="1" class="h-6 w-6 rounded text-emerald-600" <?= $marcado ? 'checked' : '' ?> data-personas="<?= (int) $r['personas'] ?>">
                        <span class="flex-1"><?= e($r['cliente']) ?><?= (int) $r['personas'] > 1 ? ' <span class="chip-gris">' . (int) $r['personas'] . ' personas</span>' : '' ?></span>
                    </label>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <p class="border-t border-linea px-5 py-3 text-[15px]">Asistentes: <strong class="tabular-nums" data-total-asistentes><?= (int) $asistentesSugeridos ?></strong> de <?= (int) $s['capacidad'] ?></p>
    </section>

    <section class="tarjeta">
        <div class="border-b border-linea px-5 py-4">
            <h2 class="font-semibold">2. Materiales usados</h2>
            <p class="text-[14px] text-texto-suave"><?= $receta ? 'Sugeridos según la receta de la experiencia y el número de asistentes. Ajusta si se usó otra cantidad.' : 'Esta experiencia no tiene receta. Agrega lo que se usó (o configura la receta en Experiencias).' ?></p>
        </div>
        <div class="space-y-3 p-5" data-lineas-material>
            <?php foreach ($receta as $m): ?>
                <div class="grid grid-cols-[1fr_140px] items-end gap-3" data-linea>
                    <div>
                        <input type="hidden" name="material_id[]" value="<?= (int) $m['id'] ?>">
                        <p class="font-medium"><?= e($m['nombre']) ?></p>
                        <p class="text-[13px] text-texto-suave"><?= e(I::fmt($m['cantidad_por_persona'])) ?> <?= e($m['unidad']) ?> por persona · hay <?= e(I::fmt($m['stock'])) ?></p>
                    </div>
                    <label class="block"><span class="sr-only">Cantidad de <?= e($m['nombre']) ?></span>
                        <input name="material_cantidad[]" class="input text-right tabular-nums" inputmode="decimal" data-por-persona="<?= e((string) (float) $m['cantidad_por_persona']) ?>"
                               value="<?= e(I::fmt((float) $m['cantidad_por_persona'] * $asistentesSugeridos)) ?>">
                    </label>
                </div>
            <?php endforeach; ?>
            <div class="grid grid-cols-[1fr_140px] items-end gap-3">
                <label class="block"><span class="etiqueta">Otro material</span>
                    <select name="material_id[]" class="input">
                        <option value="">Ninguno</option>
                        <?php foreach ($materiales as $m): ?><option value="<?= (int) $m['id'] ?>"><?= e($m['nombre'] . ' (' . I::fmt($m['stock']) . ' ' . $m['unidad'] . ')') ?></option><?php endforeach; ?>
                    </select>
                </label>
                <label class="block"><span class="etiqueta">Cantidad</span><input name="material_cantidad[]" class="input text-right tabular-nums" inputmode="decimal"></label>
            </div>
        </div>
    </section>

    <section class="tarjeta tarjeta-cuerpo">
        <label for="notas_cierre" class="etiqueta">3. Notas del facilitador (opcional)</label>
        <textarea id="notas_cierre" name="notas_cierre" rows="3" class="input" placeholder="Cómo salió, qué faltó, qué repetir"></textarea>
    </section>

    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Cerrar sesión y descontar materiales</button>
        <a href="<?= e(url('/agenda/sesiones/' . $s['id'])) ?>" class="btn-secundario">Volver</a>
    </div>
</form>
