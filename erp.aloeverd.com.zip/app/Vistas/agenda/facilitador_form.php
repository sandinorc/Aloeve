<?php
use App\Modulos\Clientes\ClientesServicio as C;
$v = static fn(string $c, $d = '') => viejo($c, isset($f[$c]) ? ($c === 'telefono' ? C::formatearTelefono($f[$c]) : $f[$c]) : $d);
$colores = ['#6a47dc', '#cb9a3a', '#c88e51', '#1f8f4e', '#2f7fd1', '#d14a6b', '#0f8b8d', '#7a5c3e'];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $f ? $f['nombre'] : 'Nuevo facilitador',
    'volver' => ['texto' => 'Facilitadores', 'ruta' => '/facilitadores'],
]) ?>
<form method="post" action="<?= e(url($f ? '/facilitadores/' . $f['id'] : '/facilitadores')) ?>" class="tarjeta tarjeta-cuerpo max-w-3xl space-y-5">
    <?= csrf_campo() ?>
    <div class="grid gap-4 sm:grid-cols-2">
        <div class="sm:col-span-2"><label for="nombre" class="etiqueta">Nombre <span class="text-red-600">*</span></label><input id="nombre" name="nombre" class="input" value="<?= e($v('nombre')) ?>" required></div>
        <div><label for="telefono" class="etiqueta">Teléfono</label><input id="telefono" name="telefono" class="input" inputmode="tel" value="<?= e($v('telefono')) ?>"></div>
        <div><label for="email" class="etiqueta">Correo</label><input id="email" name="email" type="email" class="input" value="<?= e($v('email')) ?>"></div>
        <div><label for="especialidad" class="etiqueta">Especialidad</label><input id="especialidad" name="especialidad" class="input" value="<?= e($v('especialidad')) ?>" placeholder="Acrílico, acuarela, niños…"></div>
        <div><label for="anos_experiencia" class="etiqueta">Años de experiencia</label><input id="anos_experiencia" name="anos_experiencia" type="number" min="0" class="input tabular-nums" value="<?= e($v('anos_experiencia')) ?>"></div>
        <div class="sm:col-span-2"><label for="bio" class="etiqueta">Biografía corta</label><textarea id="bio" name="bio" rows="3" class="input"><?= e($v('bio')) ?></textarea></div>
        <div class="sm:col-span-2"><label for="usuario_id" class="etiqueta">Usuario del ERP</label>
            <select id="usuario_id" name="usuario_id" class="input">
                <option value="">Sin acceso al ERP</option>
                <?php foreach ($usuarios as $u): ?><option value="<?= (int) $u['id'] ?>" <?= $v('usuario_id') === (string) $u['id'] ? 'selected' : '' ?>><?= e($u['nombre'] . ' · ' . $u['email']) ?></option><?php endforeach; ?>
            </select>
            <p class="ayuda">Crea primero un usuario con rol Facilitador en Administración → Usuarios. Con eso verá solo sus sesiones y podrá marcar asistencia y cerrarlas.</p>
        </div>
        <fieldset class="sm:col-span-2"><legend class="etiqueta">Color</legend>
            <div class="flex flex-wrap gap-2">
                <?php foreach ($colores as $c): ?>
                    <label class="cursor-pointer"><input type="radio" name="color" value="<?= e($c) ?>" class="peer sr-only" <?= $v('color', '#6a47dc') === $c ? 'checked' : '' ?>>
                        <span class="block h-9 w-9 rounded-full ring-2 ring-transparent ring-offset-2 peer-checked:ring-texto peer-focus-visible:ring-primario-400" style="background: <?= e($c) ?>"></span><span class="sr-only"><?= e($c) ?></span></label>
                <?php endforeach; ?>
            </div>
        </fieldset>
        <?php if ($f): ?><label class="flex items-center gap-3"><input type="checkbox" name="activo" value="1" class="check" <?= $v('activo', '1') === '1' ? 'checked' : '' ?>> Activo</label><?php endif; ?>
    </div>
    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $f ? 'Guardar' : 'Agregar facilitador' ?></button>
        <a href="<?= e(url('/facilitadores')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
