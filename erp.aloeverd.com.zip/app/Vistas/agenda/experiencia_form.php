<?php
use App\Modulos\Agenda\AgendaServicio as A;
use App\Modulos\Inventario\InventarioServicio as I;
$v = static fn(string $c, $d = '') => viejo($c, $s[$c] ?? $d);
$colores = ['#6a47dc', '#cb9a3a', '#c88e51', '#1f8f4e', '#2f7fd1', '#d14a6b', '#0f8b8d', '#7a5c3e'];
$filasReceta = $receta ?: [];
$filasReceta[] = ['material_id' => '', 'cantidad_por_persona' => ''];
$filasReceta[] = ['material_id' => '', 'cantidad_por_persona' => ''];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $s ? $s['nombre'] : 'Nueva experiencia',
    'descripcion' => 'Lo que se escriba aquí se usa al programar cada sesión; luego se puede ajustar sesión por sesión.',
    'volver' => ['texto' => 'Experiencias', 'ruta' => '/agenda/experiencias'],
]) ?>
<form method="post" action="<?= e(url($s ? '/agenda/experiencias/' . $s['id'] : '/agenda/experiencias')) ?>" class="tarjeta tarjeta-cuerpo max-w-3xl space-y-6">
    <?= csrf_campo() ?>
    <section class="grid gap-4 sm:grid-cols-2">
        <div class="sm:col-span-2"><label for="nombre" class="etiqueta">Nombre <span class="text-red-600">*</span></label><input id="nombre" name="nombre" class="input" value="<?= e($v('nombre')) ?>" required placeholder="Ej. Paint & Wine"></div>
        <div><label for="linea_negocio" class="etiqueta">Línea de negocio</label>
            <select id="linea_negocio" name="linea_negocio" class="input"><?php foreach (A::LINEAS as $k => $t): ?><option value="<?= e($k) ?>" <?= $v('linea_negocio', 'experiencias') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select></div>
        <div><label for="duracion_min" class="etiqueta">Duración (minutos)</label><input id="duracion_min" name="duracion_min" type="number" min="15" step="15" class="input tabular-nums" value="<?= e($v('duracion_min', '120')) ?>"></div>
        <div><label for="precio" class="etiqueta">Precio por persona sin ITBIS (RD$)</label><input id="precio" name="precio" class="input tabular-nums" inputmode="decimal" value="<?= e($v('precio', '0')) ?>"></div>
        <div class="pt-1 sm:pt-8"><label class="flex items-center gap-3"><input type="checkbox" name="lleva_itbis" value="1" class="check" <?= $v('lleva_itbis', '1') === '1' ? 'checked' : '' ?>> Lleva ITBIS</label></div>
        <div><label for="capacidad" class="etiqueta">Capacidad</label><input id="capacidad" name="capacidad" type="number" min="1" class="input tabular-nums" value="<?= e($v('capacidad', '12')) ?>"></div>
        <div class="grid grid-cols-2 gap-3">
            <div><label for="edad_min" class="etiqueta">Edad mínima</label><input id="edad_min" name="edad_min" type="number" min="0" class="input tabular-nums" value="<?= e($v('edad_min')) ?>"></div>
            <div><label for="edad_max" class="etiqueta">Edad máxima</label><input id="edad_max" name="edad_max" type="number" min="0" class="input tabular-nums" value="<?= e($v('edad_max')) ?>"></div>
        </div>
        <div class="sm:col-span-2"><label for="descripcion" class="etiqueta">Descripción</label><textarea id="descripcion" name="descripcion" rows="2" class="input"><?= e($v('descripcion')) ?></textarea></div>
        <fieldset class="sm:col-span-2"><legend class="etiqueta">Color en la agenda</legend>
            <div class="flex flex-wrap gap-2">
                <?php foreach ($colores as $c): ?>
                    <label class="cursor-pointer"><input type="radio" name="color" value="<?= e($c) ?>" class="peer sr-only" <?= $v('color', '#6a47dc') === $c ? 'checked' : '' ?>>
                        <span class="block h-9 w-9 rounded-full ring-2 ring-transparent ring-offset-2 peer-checked:ring-texto peer-focus-visible:ring-primario-400" style="background: <?= e($c) ?>"></span><span class="sr-only"><?= e($c) ?></span></label>
                <?php endforeach; ?>
            </div>
        </fieldset>
    </section>

    <section class="border-t border-linea pt-6">
        <h2 class="font-semibold">Receta de materiales</h2>
        <p class="mb-3 text-[14px] text-texto-suave">Cuánto usa cada persona. Al cerrar una sesión, el ERP multiplica por los asistentes y sugiere cuánto descontar.</p>
        <?php if (!$materiales): ?>
            <p class="rounded-xl bg-fondo px-3 py-2 text-[14px] text-texto-suave">Primero crea materiales en Inventario.</p>
        <?php else: ?>
        <div class="space-y-2">
            <?php foreach ($filasReceta as $i => $fila): ?>
                <div class="grid grid-cols-[1fr_120px] gap-3">
                    <select name="receta_material[]" class="input" aria-label="Material <?= $i + 1 ?>">
                        <option value="">Sin material</option>
                        <?php foreach ($materiales as $m): ?><option value="<?= (int) $m['id'] ?>" <?= (string) $fila['material_id'] === (string) $m['id'] ? 'selected' : '' ?>><?= e($m['nombre'] . ' (' . $m['unidad'] . ')') ?></option><?php endforeach; ?>
                    </select>
                    <input name="receta_cantidad[]" class="input text-right tabular-nums" inputmode="decimal" placeholder="por persona" aria-label="Cantidad por persona <?= $i + 1 ?>" value="<?= e($fila['cantidad_por_persona'] !== '' ? I::fmt($fila['cantidad_por_persona']) : '') ?>">
                </div>
            <?php endforeach; ?>
        </div>
        <p class="mt-2 text-[13px] text-texto-suave">Para agregar más materiales, guarda y vuelve a abrir: siempre quedan dos filas libres.</p>
        <?php endif; ?>
    </section>

    <?php if ($s): ?><label class="flex items-center gap-3"><input type="checkbox" name="activo" value="1" class="check" <?= $v('activo', '1') === '1' ? 'checked' : '' ?>> Activa (se puede programar)</label><?php endif; ?>
    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $s ? 'Guardar' : 'Crear experiencia' ?></button>
        <a href="<?= e(url('/agenda/experiencias')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
