<?php if (!empty($porCerrar)): ?>
<div class="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-[15px] text-amber-900">
    <?= icono('alerta', 'h-5 w-5 shrink-0') ?>
    <span class="flex-1"><?= count($porCerrar) ?> sesión<?= count($porCerrar) === 1 ? '' : 'es' ?> ya pasó y no se ha cerrado. Al cerrarla se marca la asistencia y se descuentan los materiales.</span>
    <a href="<?= e(url('/agenda/sesiones?estado=por_cerrar')) ?>" class="font-medium underline underline-offset-2">Ver cuáles</a>
</div>
<?php endif; ?>
