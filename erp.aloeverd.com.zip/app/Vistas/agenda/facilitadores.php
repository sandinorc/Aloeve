<?php use App\Modulos\Clientes\ClientesServicio as C; ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Agenda',
    'descripcion' => 'Instructores que dan las sesiones. Si tienen usuario con rol Facilitador, al entrar ven solo sus sesiones.',
    'acciones' => puede('agenda.editar') ? '<a href="' . e(url('/facilitadores/nuevo')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Agregar facilitador</a>' : '',
]) ?>
<?= \App\Core\View::parcial('agenda/_pestanas') ?>
<?php if (!$filas): ?>
    <div class="tarjeta px-5 py-12 text-center text-texto-suave">Todavía no hay facilitadores.</div>
<?php else: ?>
<div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
    <?php foreach ($filas as $f): ?>
        <a href="<?= e(url('/facilitadores/' . $f['id'])) ?>" class="tarjeta flex gap-4 p-5 hover:ring-1 hover:ring-primario-300 <?= (int) $f['activo'] === 1 ? '' : 'opacity-60' ?>">
            <span class="grid h-12 w-12 shrink-0 place-items-center rounded-full text-sm font-semibold text-white" style="background: <?= e($f['color']) ?>"><?= e(iniciales($f['nombre'])) ?></span>
            <span class="min-w-0 flex-1">
                <span class="block font-semibold"><?= e($f['nombre']) ?></span>
                <span class="block text-[14px] text-texto-suave"><?= e(implode(' · ', array_filter([$f['especialidad'], $f['anos_experiencia'] !== null ? $f['anos_experiencia'] . ' años de experiencia' : null]))) ?: 'Sin especialidad' ?></span>
                <span class="mt-1 block truncate text-[14px] text-texto-suave"><?= e(implode(' · ', array_filter([C::formatearTelefono($f['telefono']), $f['email']]))) ?></span>
                <span class="mt-2 flex flex-wrap gap-2">
                    <span class="chip-morado"><?= (int) $f['proximas'] ?> próximas</span>
                    <span class="chip-gris"><?= (int) $f['ultimas30'] ?> cerradas en 30 días</span>
                    <?php if ($f['usuario_email']): ?><span class="chip-verde">Tiene acceso</span><?php endif; ?>
                    <?php if ((int) $f['activo'] !== 1): ?><span class="chip-gris">Inactivo</span><?php endif; ?>
                </span>
            </span>
        </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>
