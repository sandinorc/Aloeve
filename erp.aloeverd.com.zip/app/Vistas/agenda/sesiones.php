<?php use App\Modulos\Agenda\AgendaServicio as A; ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Agenda',
    'descripcion' => 'Todas las sesiones con su ocupación y estado.',
    'acciones' => puede('agenda.editar') ? '<a href="' . e(url('/agenda/sesiones/nueva')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nueva sesión</a>' : '',
]) ?>
<?= \App\Core\View::parcial('agenda/_pestanas') ?>
<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[180px_1fr_1fr_150px_150px_auto]">
    <select name="estado" class="input" aria-label="Estado">
        <option value="">Todos los estados</option>
        <option value="por_cerrar" <?= get('estado') === 'por_cerrar' ? 'selected' : '' ?>>Por cerrar</option>
        <?php foreach (A::ESTADOS as $k => [$t]): ?><option value="<?= e($k) ?>" <?= get('estado') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
    </select>
    <select name="experiencia" class="input" aria-label="Experiencia">
        <option value="">Todas las experiencias</option>
        <?php foreach ($experiencias as $x): ?><option value="<?= (int) $x['id'] ?>" <?= get('experiencia') === (string) $x['id'] ? 'selected' : '' ?>><?= e($x['nombre']) ?></option><?php endforeach; ?>
    </select>
    <select name="facilitador" class="input" aria-label="Facilitador">
        <option value="">Todos los facilitadores</option>
        <?php foreach ($facilitadores as $x): ?><option value="<?= (int) $x['id'] ?>" <?= get('facilitador') === (string) $x['id'] ? 'selected' : '' ?>><?= e($x['nombre']) ?></option><?php endforeach; ?>
    </select>
    <input type="date" name="desde" value="<?= e(get('desde')) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e(get('hasta')) ?>" class="input" aria-label="Hasta">
    <button class="btn-secundario">Filtrar</button>
</form>
<div class="tarjeta overflow-hidden">
    <?php if (!$filas): ?>
        <p class="px-5 py-10 text-center text-texto-suave">No hay sesiones con esos filtros.</p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Fecha y hora</th><th>Experiencia</th><th>Facilitador</th><th class="text-right">Ocupación</th><th>Estado</th></tr></thead>
            <tbody>
            <?php foreach ($filas as $s):
                [$et, $chip] = A::ESTADOS[$s['estado']];
                $pasada = in_array($s['estado'], ['programada', 'confirmada', 'realizada'], true) && ($s['fecha'] < date('Y-m-d') || ($s['fecha'] === date('Y-m-d') && $s['hora_fin'] < date('H:i:s')));
                $n = $s['estado'] === 'cerrada' ? (int) $s['asistentes'] : (int) $s['ocupados'];
            ?>
                <tr>
                    <td data-principal class="whitespace-nowrap">
                        <a href="<?= e(url('/agenda/sesiones/' . $s['id'])) ?>" class="font-medium hover:text-primario-700"><?= e(fecha($s['fecha'])) ?></a>
                        <span class="block text-[14px] font-normal text-texto-suave tabular-nums"><?= e(substr($s['hora_inicio'], 0, 5) . ' – ' . substr($s['hora_fin'], 0, 5)) ?></span>
                    </td>
                    <td data-etiqueta="Experiencia"><span class="mr-1 inline-block h-2.5 w-2.5 rounded-full" style="background: <?= e($s['color']) ?>"></span><?= e($s['servicio']) ?></td>
                    <td data-etiqueta="Facilitador"><?= e($s['facilitador'] ?? '—') ?></td>
                    <td data-etiqueta="Ocupación" class="text-right tabular-nums"><?= $n ?> / <?= (int) $s['capacidad'] ?><?= $s['estado'] === 'cerrada' ? ' <span class="text-[12px] text-texto-suave">asistieron</span>' : '' ?></td>
                    <td data-etiqueta="Estado"><span class="<?= $chip ?>"><?= e($et) ?></span><?= $pasada ? ' <span class="chip-ambar">Por cerrar</span>' : '' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
