<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Roles y permisos',
    'descripcion' => 'Cinco roles fijos. Cada usuario tiene uno; los permisos de cada rol se ajustan aquí.',
]) ?>
<div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
    <?php foreach ($roles as $r): $esAdmin = $r['clave'] === 'admin'; ?>
        <a href="<?= e(url('/roles/' . $r['id'])) ?>" class="tarjeta flex flex-col p-5 transition hover:border-primario-300">
            <div class="flex items-start justify-between gap-3">
                <h2 class="text-lg font-semibold"><?= e($r['nombre']) ?></h2>
                <span class="chip-morado"><?= $esAdmin ? 'Completo' : (int) $r['permisos'] . ' de ' . $totalPermisos ?></span>
            </div>
            <p class="mt-1 flex-1 text-[15px] text-texto-suave"><?= e($r['descripcion']) ?></p>
            <p class="mt-4 flex items-center gap-2 text-[14px] text-texto-suave"><?= icono('clientes', 'h-4 w-4') ?> <?= (int) $r['usuarios'] ?> usuario<?= (int) $r['usuarios'] === 1 ? '' : 's' ?> activo<?= (int) $r['usuarios'] === 1 ? '' : 's' ?></p>
        </a>
    <?php endforeach; ?>
</div>
