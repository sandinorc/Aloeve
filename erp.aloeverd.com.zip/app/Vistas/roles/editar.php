<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $rol['nombre'],
    'descripcion' => $rol['descripcion'],
    'volver' => ['texto' => 'Roles y permisos', 'ruta' => '/roles'],
]) ?>

<?php if ($rol['clave'] === 'admin'): ?>
    <div class="tarjeta tarjeta-cuerpo max-w-2xl">
        <p>El Administrador tiene acceso completo a todo el sistema y no se puede limitar. Debe existir siempre al menos un Administrador activo.</p>
    </div>
<?php else: ?>
<form method="post" class="space-y-4">
    <?= csrf_campo() ?>
    <div class="grid gap-4 lg:grid-cols-2">
        <?php foreach ($catalogo as $grupo => $permisos): ?>
            <fieldset class="tarjeta p-5">
                <legend class="sr-only"><?= e($grupo) ?></legend>
                <h2 class="mb-2 text-[13px] font-semibold uppercase tracking-wider text-texto-suave"><?= e($grupo) ?></h2>
                <?php foreach ($permisos as $clave => $texto): ?>
                    <label class="flex min-h-[40px] cursor-pointer items-center gap-3 rounded-lg px-1 hover:bg-fondo">
                        <input type="checkbox" name="permisos[]" value="<?= e($clave) ?>" class="check" <?= in_array($clave, $activos, true) ? 'checked' : '' ?> <?= $editable ? '' : 'disabled' ?>>
                        <span class="text-[15px]"><?= e($texto) ?></span>
                    </label>
                <?php endforeach; ?>
            </fieldset>
        <?php endforeach; ?>
    </div>
    <?php if ($editable): ?>
        <div class="sticky bottom-0 -mx-4 border-t border-linea bg-white/95 px-4 py-3 backdrop-blur sm:mx-0 sm:rounded-2xl sm:border">
            <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Guardar permisos</button>
        </div>
    <?php endif; ?>
</form>
<?php endif; ?>
