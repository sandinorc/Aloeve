<form method="post" action="<?= e(url('/login')) ?>" class="tarjeta tarjeta-cuerpo space-y-5" novalidate>
    <?= csrf_campo() ?>
    <div class="text-center">
        <h2 class="text-xl font-semibold">Iniciar sesión</h2>
        <p class="mt-1 text-texto-suave">Ingresa tus credenciales para continuar</p>
    </div>
    <div>
        <label for="email" class="etiqueta">Correo electrónico</label>
        <div class="relative">
            <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('correo', 'h-5 w-5') ?></span>
            <input id="email" name="email" type="email" class="input pl-10" placeholder="nombre@aloeverd.com" value="<?= e(viejo('email')) ?>" autocomplete="username" required autofocus>
        </div>
    </div>
    <div>
        <label for="clave" class="etiqueta">Contraseña</label>
        <div class="relative">
            <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('candado', 'h-5 w-5') ?></span>
            <input id="clave" name="clave" type="password" class="input px-10" autocomplete="current-password" required>
            <button type="button" class="absolute inset-y-0 right-1 grid w-10 place-items-center text-texto-suave hover:text-texto" data-ver-clave="clave" aria-label="Mostrar contraseña">
                <?= icono('ojo', 'h-5 w-5') ?>
            </button>
        </div>
    </div>
    <button class="btn-primario w-full">Ingresar al sistema</button>
</form>
