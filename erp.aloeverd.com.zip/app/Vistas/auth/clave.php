<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Cambiar contraseña',
    'descripcion' => $obligatorio ? 'Antes de seguir, cambia la contraseña temporal que te dieron.' : 'Usa una contraseña que no uses en otros sitios.',
]) ?>
<form method="post" class="tarjeta tarjeta-cuerpo max-w-xl space-y-4">
    <?= csrf_campo() ?>
    <div>
        <label for="actual" class="etiqueta"><?= $obligatorio ? 'Contraseña temporal' : 'Contraseña actual' ?></label>
        <input id="actual" name="actual" type="password" class="input" autocomplete="current-password" required>
    </div>
    <div>
        <label for="nueva" class="etiqueta">Contraseña nueva</label>
        <input id="nueva" name="nueva" type="password" class="input" autocomplete="new-password" required minlength="10">
        <p class="ayuda">Mínimo 10 caracteres, con mayúsculas, minúsculas y un número.</p>
    </div>
    <div>
        <label for="nueva2" class="etiqueta">Repite la contraseña nueva</label>
        <input id="nueva2" name="nueva2" type="password" class="input" autocomplete="new-password" required>
    </div>
    <button class="btn-primario">Guardar contraseña</button>
</form>
