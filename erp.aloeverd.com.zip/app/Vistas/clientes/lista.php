<?php
use App\Modulos\Clientes\ClientesServicio as S;
$acciones = '<a href="' . e(url('/clientes/exportar') . ($_GET ? '?' . http_build_query($_GET) : '')) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>';
if (puede('clientes.crear')) {
    $acciones .= '<a href="' . e(url('/clientes/nuevo')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nuevo cliente</a>';
}
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Clientes',
    'descripcion' => 'Directorio de personas y empresas que compran, reservan o se inscriben.',
    'acciones' => $acciones,
]) ?>

<div class="mb-6 grid grid-cols-3 gap-3 sm:gap-4">
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave sm:text-[15px]">Activos</p><p class="mt-1 font-display text-2xl tabular-nums sm:text-3xl"><?= number_format($totalActivos) ?></p></div>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave sm:text-[15px]">Nuevos este mes</p><p class="mt-1 font-display text-2xl tabular-nums sm:text-3xl"><?= number_format($nuevosMes) ?></p></div>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave sm:text-[15px]">Empresas</p><p class="mt-1 font-display text-2xl tabular-nums sm:text-3xl"><?= number_format($empresas) ?></p></div>
</div>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_220px_170px_170px_auto]">
    <label class="relative sm:col-span-2 lg:col-span-1">
        <span class="sr-only">Buscar</span>
        <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
        <input name="q" value="<?= e(get('q')) ?>" class="input pl-10" placeholder="Nombre, teléfono, correo, cédula o RNC">
    </label>
    <select name="fuente" class="input" aria-label="Fuente">
        <option value="">Todas las fuentes</option>
        <?php foreach (S::FUENTES as $k => $t): ?>
            <option value="<?= e($k) ?>" <?= get('fuente') === $k ? 'selected' : '' ?>><?= e(explode(' (', $t)[0]) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="tipo" class="input" aria-label="Tipo">
        <option value="">Personas y empresas</option>
        <option value="empresas" <?= get('tipo') === 'empresas' ? 'selected' : '' ?>>Solo empresas</option>
    </select>
    <select name="estado" class="input" aria-label="Estado">
        <option value="activos" <?= get('estado', 'activos') === 'activos' ? 'selected' : '' ?>>Activos</option>
        <option value="inactivos" <?= get('estado') === 'inactivos' ? 'selected' : '' ?>>Inactivos</option>
        <option value="todos" <?= get('estado') === 'todos' ? 'selected' : '' ?>>Todos</option>
    </select>
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <?php if (!$clientes): ?>
        <div class="px-5 py-12 text-center">
            <div class="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('clientes') ?></div>
            <?php if (get('q') !== '' || get('fuente') !== '' || get('tipo') !== ''): ?>
                <p class="text-texto-suave">Ningún cliente coincide con esa búsqueda.</p>
            <?php else: ?>
                <p class="font-medium">Todavía no hay clientes</p>
                <p class="mt-1 text-texto-suave">Se crean aquí, desde la caja al cobrar, o llegan solos con las reservas de aloeverd.com (Fase 3).</p>
                <?php if (puede('clientes.crear')): ?><a href="<?= e(url('/clientes/nuevo')) ?>" class="btn-primario mt-5"><?= icono('mas', 'h-5 w-5') ?> Nuevo cliente</a><?php endif; ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Cliente</th><th>Contacto</th><th>Segmento</th><th>Fuente</th><th>Registrado</th></tr></thead>
            <tbody>
            <?php foreach ($clientes as $c): [$segTexto, $segChip] = S::SEGMENTOS[$c['segmento']]; ?>
                <tr class="<?= (int) $c['activo'] === 1 ? '' : 'opacity-60' ?>">
                    <td data-principal>
                        <a href="<?= e(url('/clientes/' . $c['id'])) ?>" class="flex items-center gap-3 hover:text-primario-700">
                            <span class="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primario-50 text-sm font-semibold text-primario-700"><?= e(iniciales($c['nombre'])) ?></span>
                            <span class="min-w-0">
                                <span class="block font-medium"><?= e($c['nombre']) ?></span>
                                <?php if ($c['documento']): ?><span class="block font-mono text-[13px] font-normal text-texto-suave"><?= e(strtoupper($c['tipo_documento']) . ' ' . $c['documento']) ?></span><?php endif; ?>
                            </span>
                        </a>
                    </td>
                    <td data-etiqueta="Contacto" class="text-[14px]">
                        <span class="block"><?= e(S::formatearTelefono($c['telefono']) ?: '—') ?></span>
                        <span class="block truncate text-texto-suave"><?= e($c['email'] ?? '') ?></span>
                    </td>
                    <td data-etiqueta="Segmento"><span class="<?= $segChip ?>"><?= e($segTexto) ?></span><?= (int) $c['activo'] === 1 ? '' : ' <span class="chip-gris">Inactivo</span>' ?></td>
                    <td data-etiqueta="Fuente" class="text-[14px]"><?= e(explode(' (', S::FUENTES[$c['fuente']])[0]) ?></td>
                    <td data-etiqueta="Registrado" class="tabular-nums text-[14px]"><?= e(fecha($c['creado_en'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
