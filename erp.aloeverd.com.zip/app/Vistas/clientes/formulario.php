<?php
use App\Modulos\Clientes\ClientesServicio as S;
$c = $cliente;
$v = static function (string $campo, $def = '') use ($c) {
    $base = $c[$campo] ?? $def;
    if (in_array($campo, ['telefono', 'whatsapp'], true)) { $base = S::formatearTelefono($base); }
    return viejo($campo, $base ?? '');
};
$tipoDoc = $v('tipo_documento', 'ninguno');
$fuente = $v('fuente', 'plaza');
$accion = $c ? url('/clientes/' . $c['id']) : url('/clientes');
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $c ? 'Editar cliente' : 'Nuevo cliente',
    'descripcion' => $c ? $c['nombre'] : 'Solo el nombre es obligatorio. El correo y la cédula no se pueden repetir.',
    'volver' => $c ? ['texto' => $c['nombre'], 'ruta' => '/clientes/' . $c['id']] : ['texto' => 'Clientes', 'ruta' => '/clientes'],
]) ?>

<?php if ($aviso): ?>
    <div class="mb-6 flex items-start gap-3 rounded-xl border px-4 py-3 text-[15px] <?= $aviso['bloquea'] ? 'border-red-200 bg-red-50 text-red-800' : 'border-amber-200 bg-amber-50 text-amber-900' ?>">
        <?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?>
        <div>
            <p>Ya existe <strong><?= e($aviso['nombre']) ?></strong> con <?= e($aviso['motivo']) ?>.
                <a href="<?= e(url('/clientes/' . $aviso['id'])) ?>" class="font-medium underline">Abrir ese cliente</a>.</p>
            <?php if ($aviso['bloquea']): ?>
                <p class="mt-1 text-[14px]">No se puede repetir. Si es la misma persona, usa el cliente existente.</p>
            <?php else: ?>
                <p class="mt-1 text-[14px]">Si son personas distintas (por ejemplo, comparten teléfono), marca la casilla de abajo y guarda de nuevo.</p>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<form method="post" action="<?= e($accion) ?>" class="tarjeta tarjeta-cuerpo max-w-4xl space-y-6" data-form-cliente>
    <?= csrf_campo() ?>
    <section class="grid gap-4 sm:grid-cols-2">
        <div class="sm:col-span-2">
            <label for="nombre" class="etiqueta">Nombre completo <span class="text-red-600">*</span></label>
            <input id="nombre" name="nombre" class="input" value="<?= e($v('nombre')) ?>" required autocomplete="off">
        </div>
        <div>
            <label for="tipo_documento" class="etiqueta">Documento</label>
            <select id="tipo_documento" name="tipo_documento" class="input" data-tipo-documento>
                <?php foreach (S::DOCUMENTOS as $k => $t): ?>
                    <option value="<?= e($k) ?>" <?= $tipoDoc === $k ? 'selected' : '' ?>><?= e($t) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div data-solo-documento <?= $tipoDoc === 'ninguno' ? 'hidden' : '' ?>>
            <label for="documento" class="etiqueta">Número</label>
            <input id="documento" name="documento" class="input font-mono" value="<?= e($v('documento')) ?>" inputmode="numeric" autocomplete="off">
            <p class="ayuda">Cédula 11 dígitos, RNC 9 dígitos. Se valida el dígito verificador.</p>
        </div>
        <div class="sm:col-span-2" data-solo-rnc <?= $tipoDoc === 'rnc' ? '' : 'hidden' ?>>
            <label for="razon_social" class="etiqueta">Razón social</label>
            <input id="razon_social" name="razon_social" class="input" value="<?= e($v('razon_social')) ?>" placeholder="Como aparece en el RNC">
        </div>
    </section>

    <section class="grid gap-4 border-t border-linea pt-6 sm:grid-cols-2">
        <h2 class="sm:col-span-2 text-[13px] font-semibold uppercase tracking-wider text-texto-suave">Contacto</h2>
        <div>
            <label for="telefono" class="etiqueta">Teléfono</label>
            <input id="telefono" name="telefono" class="input" inputmode="tel" value="<?= e($v('telefono')) ?>" placeholder="809 555 1234">
        </div>
        <div>
            <label for="whatsapp" class="etiqueta">WhatsApp</label>
            <input id="whatsapp" name="whatsapp" class="input" inputmode="tel" value="<?= e($v('whatsapp')) ?>" placeholder="Si es distinto al teléfono">
        </div>
        <div>
            <label for="email" class="etiqueta">Correo</label>
            <input id="email" name="email" type="email" class="input" value="<?= e($v('email')) ?>">
        </div>
        <div>
            <label for="fecha_nacimiento" class="etiqueta">Fecha de nacimiento</label>
            <input id="fecha_nacimiento" name="fecha_nacimiento" type="date" class="input" value="<?= e($v('fecha_nacimiento')) ?>">
        </div>
        <div class="sm:col-span-2">
            <label for="direccion" class="etiqueta">Dirección</label>
            <input id="direccion" name="direccion" class="input" value="<?= e($v('direccion')) ?>">
        </div>
    </section>

    <section class="grid gap-4 border-t border-linea pt-6 sm:grid-cols-2">
        <h2 class="sm:col-span-2 text-[13px] font-semibold uppercase tracking-wider text-texto-suave">Cómo llegó</h2>
        <div>
            <label for="fuente" class="etiqueta">Fuente</label>
            <select id="fuente" name="fuente" class="input" data-fuente>
                <?php foreach (S::FUENTES as $k => $t): ?>
                    <option value="<?= e($k) ?>" <?= $fuente === $k ? 'selected' : '' ?>><?= e($t) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="sede_id" class="etiqueta">Sede</label>
            <select id="sede_id" name="sede_id" class="input">
                <option value="">Sin sede</option>
                <?php foreach ($sedes as $s): ?>
                    <option value="<?= (int) $s['id'] ?>" <?= $v('sede_id') === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="sm:col-span-2" data-solo-referido <?= $fuente === 'referido' ? '' : 'hidden' ?>>
            <?= \App\Core\View::parcial('parciales/buscador_cliente', ['nombre' => 'referido_por_id', 'idCampo' => 'referido', 'etiqueta' => 'Referido por', 'actual' => $referido]) ?>
        </div>
        <div class="sm:col-span-2">
            <label for="notas" class="etiqueta">Notas internas</label>
            <textarea id="notas" name="notas" rows="3" class="input" placeholder="Preferencias, alergias a materiales, ocasión especial…"><?= e($v('notas')) ?></textarea>
        </div>
    </section>

    <?php if ($aviso && !$aviso['bloquea']): ?>
        <label class="flex items-start gap-3 rounded-xl bg-amber-50 p-3 text-[15px] text-amber-900">
            <input type="checkbox" name="confirmar_telefono" value="1" class="check mt-0.5">
            <span>Confirmo que es una persona distinta a <?= e($aviso['nombre']) ?>.</span>
        </label>
    <?php endif; ?>

    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $c ? 'Guardar cambios' : 'Crear cliente' ?></button>
        <a href="<?= e(url($c ? '/clientes/' . $c['id'] : '/clientes')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
