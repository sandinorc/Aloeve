<?php
use App\Modulos\Clientes\ClientesServicio as S;
[$segTexto, $segChip] = S::SEGMENTOS[$segmento];
$wa = S::enlaceWhatsapp($c['whatsapp'] ?: $c['telefono'], 'Hola ' . explode(' ', $c['nombre'])[0] . ', te saludamos de Aloeve Art Studio.');
$acciones = '';
if (puede('clientes.editar')) {
    $acciones .= '<a href="' . e(url('/clientes/' . $c['id'] . '/editar')) . '" class="btn-secundario">' . icono('lapiz', 'h-4 w-4') . ' Editar</a>';
}
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $c['nombre'],
    'descripcion' => $c['razon_social'] ? $c['razon_social'] . ' · RNC ' . $c['documento'] : '',
    'volver' => ['texto' => 'Clientes', 'ruta' => '/clientes'],
    'acciones' => $acciones,
]) ?>

<div class="mb-6 flex flex-wrap items-center gap-2">
    <span class="<?= $segChip ?>"><?= e($segTexto) ?></span>
    <?php if ((int) $c['activo'] !== 1): ?><span class="chip-gris">Inactivo</span><?php endif; ?>
    <span class="chip-gris"><?= e(explode(' (', S::FUENTES[$c['fuente']])[0]) ?></span>
    <?php if ($c['sede']): ?><span class="chip-gris"><?= e($c['sede']) ?></span><?php endif; ?>
</div>

<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
    <div class="space-y-6 min-w-0">
        <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Visitas</p><p class="mt-1 font-display text-2xl tabular-nums"><?= $actividad['visitas'] ?></p></div>
            <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Última visita</p><p class="mt-1 text-lg font-medium tabular-nums"><?= e(fecha($actividad['ultima'])) ?></p></div>
            <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Compras</p><p class="mt-1 font-display text-2xl tabular-nums"><?= $actividad['compras'] ?></p></div>
            <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave">Total comprado</p><p class="mt-1 text-lg font-medium tabular-nums"><?= e(dinero($actividad['total'])) ?></p></div>
        </div>

        <section class="tarjeta">
            <h2 class="border-b border-linea px-5 py-4 font-semibold">Historial</h2>
            <div class="grid gap-px bg-linea sm:grid-cols-2">
                <div class="bg-white p-5">
                    <p class="font-medium">Reservas y sesiones</p>
                    <?php if (!$reservas): ?><p class="mt-1 text-[14px] text-texto-suave">Sin reservas todavía.</p><?php else: ?>
                    <ul class="mt-2 space-y-1.5 text-[14px]">
                        <?php foreach ($reservas as $r): ?>
                            <li class="flex justify-between gap-3"><a class="min-w-0 truncate text-primario-700 hover:underline" href="<?= e(url('/agenda/sesiones/' . $r['sesion_id'])) ?>"><?= e($r['servicio']) ?></a>
                                <span class="shrink-0 text-texto-suave"><?= e(fecha($r['fecha'])) ?><?= $r['estado'] === 'cancelada' ? ' · cancelada' : ($r['asistio'] === null ? '' : ((int) $r['asistio'] === 1 ? ' · asistió' : ' · no asistió')) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="bg-white p-5">
                    <p class="font-medium">Compras y comprobantes</p>
                    <?php if (!$compras): ?><p class="mt-1 text-[14px] text-texto-suave">Sin compras en la caja todavía.</p><?php else: ?>
                    <ul class="mt-2 space-y-1.5 text-[14px]">
                        <?php foreach ($compras as $v): ?>
                            <li class="flex justify-between gap-3"><a class="min-w-0 truncate text-primario-700 hover:underline" href="<?= e(url('/ventas/' . $v['id'])) ?>"><?= e($v['numero']) ?> <span class="font-mono text-texto-suave"><?= e($v['ncf'] ?? '') ?></span></a>
                                <span class="shrink-0 tabular-nums <?= $v['estado'] === 'anulada' ? 'text-texto-suave line-through' : '' ?>"><?= e(dinero($v['total'])) ?></span></li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if ($c['notas']): ?>
        <section class="tarjeta tarjeta-cuerpo">
            <h2 class="font-semibold">Notas internas</h2>
            <p class="mt-2 whitespace-pre-line text-[15px]"><?= e($c['notas']) ?></p>
        </section>
        <?php endif; ?>

        <section class="tarjeta">
            <h2 class="border-b border-linea px-5 py-4 font-semibold">Cambios registrados</h2>
            <?php if (!$historial): ?>
                <p class="px-5 py-4 text-texto-suave">Sin cambios registrados.</p>
            <?php else: ?>
                <ul class="divide-y divide-linea">
                    <?php foreach ($historial as $h): ?>
                        <li class="flex flex-wrap justify-between gap-2 px-5 py-3 text-[14px]">
                            <span><?= e($h['descripcion']) ?></span>
                            <span class="text-texto-suave"><?= e(($h['usuario'] ?? 'Sistema') . ' · ' . fecha($h['fecha'], true)) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>

    <aside class="space-y-4">
        <section class="tarjeta tarjeta-cuerpo space-y-3 text-[15px]">
            <h2 class="font-semibold">Contacto</h2>
            <?php if ($c['telefono']): ?>
                <p class="flex items-center gap-2"><?= icono('punto', 'h-4 w-4 text-texto-suave') ?> <a class="enlace" href="tel:+1<?= e($c['telefono']) ?>"><?= e(S::formatearTelefono($c['telefono'])) ?></a></p>
            <?php endif; ?>
            <?php if ($c['email']): ?>
                <p class="flex items-center gap-2 break-all"><?= icono('correo', 'h-4 w-4 shrink-0 text-texto-suave') ?> <?= e($c['email']) ?></p>
            <?php endif; ?>
            <?php if ($c['documento']): ?>
                <p class="flex items-center gap-2"><?= icono('archivo', 'h-4 w-4 text-texto-suave') ?> <span class="font-mono"><?= e(S::DOCUMENTOS[$c['tipo_documento']] . ' ' . $c['documento']) ?></span></p>
            <?php endif; ?>
            <?php if ($c['direccion']): ?>
                <p class="flex items-start gap-2"><?= icono('pin', 'mt-0.5 h-4 w-4 shrink-0 text-texto-suave') ?> <?= e($c['direccion']) ?></p>
            <?php endif; ?>
            <?php if ($c['fecha_nacimiento']): ?>
                <p class="flex items-center gap-2"><?= icono('agenda', 'h-4 w-4 text-texto-suave') ?> Cumpleaños: <?= e(date('d/m', strtotime($c['fecha_nacimiento']))) ?></p>
            <?php endif; ?>
            <?php if (!$c['telefono'] && !$c['email']): ?>
                <p class="text-texto-suave">Sin datos de contacto.</p>
            <?php endif; ?>
            <?php if ($wa): ?>
                <a href="<?= e($wa) ?>" target="_blank" rel="noopener" class="btn w-full bg-[#1f8f4e] text-white hover:bg-[#187a42]"><?= icono('enlace', 'h-4 w-4') ?> Escribir por WhatsApp</a>
            <?php endif; ?>
        </section>

        <section class="tarjeta tarjeta-cuerpo text-[15px]">
            <h2 class="font-semibold">Referidos</h2>
            <?php if ($referido): ?>
                <p class="mt-2">Lo refirió <a class="enlace" href="<?= e(url('/clientes/' . $referido['id'])) ?>"><?= e($referido['nombre']) ?></a>.</p>
            <?php endif; ?>
            <?php if ($referidos): ?>
                <p class="mt-2 text-texto-suave">Ha referido a <?= count($referidos) ?>:</p>
                <ul class="mt-1 space-y-1">
                    <?php foreach ($referidos as $r): ?>
                        <li><a class="enlace" href="<?= e(url('/clientes/' . $r['id'])) ?>"><?= e($r['nombre']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            <?php elseif (!$referido): ?>
                <p class="mt-2 text-texto-suave">Sin referidos.</p>
            <?php endif; ?>
        </section>

        <?php if (puede('clientes.editar')): ?>
        <section class="tarjeta tarjeta-cuerpo space-y-3">
            <h2 class="font-semibold">Duplicados</h2>
            <p class="text-[14px] text-texto-suave">Si esta persona está registrada dos veces, elige el otro registro. Su historial pasa a este y el duplicado queda inactivo.</p>
            <form method="post" action="<?= e(url('/clientes/' . $c['id'] . '/fusionar')) ?>" class="space-y-3" data-confirmar="¿Unir el cliente elegido dentro de <?= e($c['nombre']) ?>? No se puede deshacer.">
                <?= csrf_campo() ?>
                <?= \App\Core\View::parcial('parciales/buscador_cliente', ['nombre' => 'origen_id', 'idCampo' => 'duplicado', 'etiqueta' => 'Registro duplicado', 'actual' => null]) ?>
                <button class="btn-secundario w-full">Unir en este cliente</button>
            </form>
        </section>
        <section class="tarjeta tarjeta-cuerpo">
            <form method="post" action="<?= e(url('/clientes/' . $c['id'] . '/estado')) ?>" data-confirmar="<?= (int) $c['activo'] === 1 ? '¿Desactivar este cliente? Su historial se conserva.' : '¿Reactivar este cliente?' ?>">
                <?= csrf_campo() ?>
                <button class="<?= (int) $c['activo'] === 1 ? 'btn-peligro' : 'btn-secundario' ?> w-full"><?= (int) $c['activo'] === 1 ? 'Desactivar cliente' : 'Reactivar cliente' ?></button>
            </form>
        </section>
        <?php endif; ?>
    </aside>
</div>
