<?php
use App\Modulos\Clientes\ClientesServicio as S;
$descripciones = [
    'sin_visitas' => 'Registrados que todavía no han asistido a una sesión.',
    'nuevo' => '1 visita.',
    'recurrente' => '2 a 4 visitas.',
    'fiel' => '5 visitas o más.',
    'inactivo' => 'Sin visitas en los últimos 90 días.',
    'corporativo' => 'Empresas con RNC.',
];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Segmentos e inactivos',
    'descripcion' => 'El segmento se calcula solo con las asistencias registradas en la agenda.',
    'volver' => ['texto' => 'Clientes', 'ruta' => '/clientes'],
]) ?>
<div class="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
    <?php foreach (S::SEGMENTOS as $k => [$t, $chip]): ?>
        <div class="tarjeta p-4">
            <div class="flex items-center justify-between"><span class="<?= $chip ?>"><?= e($t) ?></span><span class="font-display text-2xl tabular-nums"><?= (int) $conteo[$k] ?></span></div>
            <p class="mt-2 text-[14px] text-texto-suave"><?= e($descripciones[$k]) ?></p>
        </div>
    <?php endforeach; ?>
</div>
<div class="mb-6 tarjeta p-5">
    <h2 class="font-semibold">Retención mensual</h2>
    <?php if (!$retencion): ?>
        <p class="mt-1 text-texto-suave">Sin datos: nadie asistió el mes pasado.</p>
    <?php else: ?>
        <p class="mt-1"><span class="font-display text-3xl tabular-nums"><?= round($retencion['volvieron'] / $retencion['base'] * 100) ?>%</span>
        <span class="text-texto-suave">· <?= (int) $retencion['volvieron'] ?> de <?= (int) $retencion['base'] ?> clientes que vinieron el mes pasado volvieron este mes.</span></p>
    <?php endif; ?>
</div>
<section class="tarjeta overflow-hidden">
    <h2 class="border-b border-linea px-5 py-4 font-semibold">Inactivos para reactivar (<?= count($inactivos) ?>)</h2>
    <?php if (!$inactivos): ?>
        <p class="px-5 py-8 text-center text-texto-suave">No hay clientes inactivos.</p>
    <?php else: ?>
    <ul class="divide-y divide-linea">
        <?php foreach ($inactivos as $c): $wa = S::enlaceWhatsapp($c['whatsapp'] ?: $c['telefono'], 'Hola ' . explode(' ', $c['nombre'])[0] . ', te extrañamos en Aloeve Art Studio. ¿Te apuntas a la próxima sesión?'); ?>
            <li class="flex flex-wrap items-center gap-3 px-5 py-3">
                <a href="<?= e(url('/clientes/' . $c['id'])) ?>" class="min-w-0 flex-1"><span class="block font-medium"><?= e($c['nombre']) ?></span>
                    <span class="text-[14px] text-texto-suave"><?= (int) $c['visitas'] ?> visitas · última hace <?= (int) $c['dias'] ?> días</span></a>
                <?php if ($wa): ?><a href="<?= e($wa) ?>" target="_blank" rel="noopener" class="btn-secundario btn-sm"><?= icono('enlace', 'h-4 w-4') ?> WhatsApp</a><?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</section>
