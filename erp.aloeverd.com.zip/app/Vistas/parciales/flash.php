<?php
$mensajes = \App\Core\Flash::tomar();
$estilos = [
    'ok' => ['border-emerald-200 bg-emerald-50 text-emerald-800', 'check'],
    'error' => ['border-red-200 bg-red-50 text-red-800', 'alerta'],
    'aviso' => ['border-amber-200 bg-amber-50 text-amber-900', 'info'],
];
?>
<?php if ($mensajes): ?>
<div class="mb-6 space-y-2" role="status" aria-live="polite">
    <?php foreach ($mensajes as $m): [$clase, $ico] = $estilos[$m['tipo']] ?? $estilos['aviso']; ?>
        <div class="flex items-start gap-3 rounded-xl border px-4 py-3 text-[15px] <?= $clase ?>">
            <?= icono($ico, 'mt-0.5 h-5 w-5 shrink-0') ?>
            <span><?= e($m['texto']) ?></span>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>
