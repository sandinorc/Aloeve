<?php
/** @var int $pagina @var int $paginas @var int $total */
if ($paginas <= 1) { return; }
$q = $_GET;
$enlace = static function (int $p) use ($q): string { $q['pagina'] = $p; return '?' . http_build_query($q); };
?>
<nav class="flex items-center justify-between gap-3 border-t border-linea px-4 py-3 text-[15px]" aria-label="Paginación">
    <span class="text-texto-suave">Página <?= $pagina ?> de <?= $paginas ?> · <?= $total ?> en total</span>
    <span class="flex gap-2">
        <?php if ($pagina > 1): ?><a class="btn-secundario btn-sm" href="<?= e($enlace($pagina - 1)) ?>">Anterior</a><?php endif; ?>
        <?php if ($pagina < $paginas): ?><a class="btn-secundario btn-sm" href="<?= e($enlace($pagina + 1)) ?>">Siguiente</a><?php endif; ?>
    </span>
</nav>
