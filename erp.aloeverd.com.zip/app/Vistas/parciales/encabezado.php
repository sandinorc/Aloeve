<?php
/**
 * Encabezado de página.
 * @var string $titulo
 * @var string $descripcion
 * @var string $acciones HTML ya escapado
 * @var array|null $volver ['texto' => ..., 'ruta' => ...]
 */
?>
<div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
    <div class="min-w-0">
        <?php if (!empty($volver)): ?>
            <a href="<?= e(url($volver['ruta'])) ?>" class="mb-2 inline-flex items-center gap-1.5 text-[15px] text-texto-suave hover:text-texto">
                <?= icono('izquierda', 'h-4 w-4') ?> <?= e($volver['texto']) ?>
            </a>
        <?php endif; ?>
        <h1 class="titulo-pagina"><?= e($titulo) ?></h1>
        <?php if (!empty($descripcion)): ?>
            <p class="mt-1 max-w-2xl text-texto-suave"><?= e($descripcion) ?></p>
        <?php endif; ?>
    </div>
    <?php if (!empty($acciones)): ?>
        <div class="flex shrink-0 flex-wrap gap-2"><?= $acciones ?></div>
    <?php endif; ?>
</div>
