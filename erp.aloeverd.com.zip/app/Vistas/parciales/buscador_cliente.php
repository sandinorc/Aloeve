<?php
/**
 * Selector de cliente con búsqueda.
 * @var string $nombre nombre del campo oculto con el id
 * @var string $idCampo id del input visible
 * @var ?array $actual ['id'=>, 'nombre'=>]
 * @var string $etiqueta
 */
$actual = $actual ?? null;
?>
<div class="relative" data-buscador-cliente="<?= e(url('/clientes/buscar')) ?>">
    <label for="<?= e($idCampo) ?>" class="etiqueta"><?= e($etiqueta) ?></label>
    <input type="hidden" name="<?= e($nombre) ?>" value="<?= e($actual['id'] ?? '') ?>" data-valor>
    <div class="relative">
        <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
        <input id="<?= e($idCampo) ?>" type="text" class="input pl-10" autocomplete="off" placeholder="Nombre, teléfono, correo o cédula"
               value="<?= e($actual['nombre'] ?? '') ?>" data-texto role="combobox" aria-expanded="false" aria-controls="<?= e($idCampo) ?>-lista">
    </div>
    <ul id="<?= e($idCampo) ?>-lista" class="absolute z-30 mt-1 max-h-72 w-full overflow-y-auto rounded-xl border border-linea bg-white py-1 shadow-modal" role="listbox" hidden data-lista></ul>
</div>
