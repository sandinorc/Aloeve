<?php
$nombresAccion = [
    'entrar' => 'Entró', 'salir' => 'Salió', 'crear' => 'Creó', 'editar' => 'Editó', 'instalar' => 'Instaló',
    'actualizar' => 'Actualizó', 'cambiar_clave' => 'Cambió contraseña', 'restablecer_clave' => 'Restableció contraseña',
    'cargar' => 'Cargó', 'probar' => 'Probó conexión', 'configurar' => 'Configuró',
];
$csv = url('/actividad/exportar') . ($_GET ? '?' . http_build_query($_GET) : '');
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Actividad',
    'descripcion' => 'Registro de todo lo que se hace en el sistema: quién, qué, cuándo y qué cambió. Nadie puede borrarlo desde la app.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' Exportar CSV</a>',
]) ?>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_160px_160px_auto]">
    <select name="usuario" class="input" aria-label="Usuario">
        <option value="">Todos los usuarios</option>
        <?php foreach ($usuarios as $u): ?>
            <option value="<?= (int) $u['id'] ?>" <?= get('usuario') === (string) $u['id'] ? 'selected' : '' ?>><?= e($u['nombre']) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="modulo" class="input" aria-label="Módulo">
        <option value="">Todos los módulos</option>
        <?php foreach ($modulos as $m): ?>
            <option value="<?= e($m) ?>" <?= get('modulo') === $m ? 'selected' : '' ?>><?= e(ucfirst($m)) ?></option>
        <?php endforeach; ?>
    </select>
    <select name="accion" class="input" aria-label="Acción">
        <option value="">Todas las acciones</option>
        <?php foreach ($acciones as $a): ?>
            <option value="<?= e($a) ?>" <?= get('accion') === $a ? 'selected' : '' ?>><?= e($nombresAccion[$a] ?? $a) ?></option>
        <?php endforeach; ?>
    </select>
    <input type="date" name="desde" class="input" value="<?= e(get('desde')) ?>" aria-label="Desde">
    <input type="date" name="hasta" class="input" value="<?= e(get('hasta')) ?>" aria-label="Hasta">
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <?php if (!$filas): ?>
        <p class="px-5 py-10 text-center text-texto-suave">No hay registros con esos filtros.</p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Fecha y hora</th><th>Usuario</th><th>Acción</th><th>Módulo</th><th>Descripción</th></tr></thead>
            <tbody>
            <?php foreach ($filas as $f): $antes = $f['antes'] ? json_decode($f['antes'], true) : null; $despues = $f['despues'] ? json_decode($f['despues'], true) : null; ?>
                <tr>
                    <td data-principal class="whitespace-nowrap tabular-nums"><?= e(fecha($f['fecha'], true)) ?></td>
                    <td data-etiqueta="Usuario"><?= e($f['usuario'] ?? 'Sistema') ?></td>
                    <td data-etiqueta="Acción"><span class="chip-morado"><?= e($nombresAccion[$f['accion']] ?? $f['accion']) ?></span></td>
                    <td data-etiqueta="Módulo"><?= e(ucfirst($f['modulo'])) ?></td>
                    <td data-etiqueta="Descripción" class="md:max-w-md">
                        <span class="block"><?= e($f['descripcion']) ?></span>
                        <?php if ($antes || $despues): ?>
                            <details class="mt-1 text-left text-[13px]">
                                <summary class="cursor-pointer text-primario-700">Ver cambios</summary>
                                <dl class="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1">
                                    <?php foreach (array_unique([...array_keys((array) $antes), ...array_keys((array) $despues)]) as $campo): ?>
                                        <dt class="font-mono text-texto-suave"><?= e($campo) ?></dt>
                                        <dd class="break-words">
                                            <span class="text-red-700 line-through"><?= e(is_array($antes[$campo] ?? null) ? implode(', ', $antes[$campo]) : ($antes[$campo] ?? '')) ?></span>
                                            <span class="text-emerald-700"><?= e(is_array($despues[$campo] ?? null) ? implode(', ', $despues[$campo]) : ($despues[$campo] ?? '')) ?></span>
                                        </dd>
                                    <?php endforeach; ?>
                                </dl>
                            </details>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
