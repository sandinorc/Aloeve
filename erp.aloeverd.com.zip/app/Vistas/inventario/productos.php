<?php
use App\Modulos\Inventario\InventarioServicio as I;
$acciones = puede('inventario.editar') ? '<a href="' . e(url('/inventario/productos/nuevo')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nuevo producto</a>' : '';
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Inventario',
    'descripcion' => 'Lo que se vende en caja. El precio se guarda sin ITBIS y el ERP calcula el final.',
    'acciones' => $acciones,
]) ?>
<?= \App\Core\View::parcial('inventario/_pestanas') ?>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-[1fr_200px_auto]">
    <label class="relative">
        <span class="sr-only">Buscar</span>
        <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
        <input name="q" value="<?= e(get('q')) ?>" class="input pl-10" placeholder="Nombre o código">
    </label>
    <select name="categoria" class="input" aria-label="Categoría">
        <option value="">Todas las categorías</option>
        <?php foreach ($categorias as $c): ?><option <?= get('categoria') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
    </select>
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <?php if (!$filas): ?>
        <div class="px-5 py-12 text-center">
            <div class="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('etiqueta') ?></div>
            <p class="text-texto-suave">Todavía no hay productos de venta. Crea los que se cobran en caja: café, vino, kits, lienzos para llevar.</p>
        </div>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Producto</th><th>Categoría</th><th class="text-right">Precio</th><th class="text-right">Precio final</th><th class="text-right">Disponible</th><th class="text-right">Acciones</th></tr></thead>
            <tbody>
            <?php foreach ($filas as $p):
                $final = (float) $p['precio'] * ((int) $p['lleva_itbis'] === 1 ? 1 + $itbis / 100 : 1);
                $bajo = $p['control_stock'] === 'propio' && (float) $p['stock_minimo'] > 0 && (float) $p['stock'] <= (float) $p['stock_minimo'];
            ?>
                <tr>
                    <td data-principal>
                        <span class="block font-medium"><?= e($p['nombre']) ?></span>
                        <span class="block font-mono text-[13px] font-normal text-texto-suave"><?= e($p['sku']) ?></span>
                    </td>
                    <td data-etiqueta="Categoría"><?= e($p['categoria']) ?></td>
                    <td data-etiqueta="Precio" class="text-right tabular-nums"><?= e(dinero($p['precio'])) ?><?= (int) $p['lleva_itbis'] === 1 ? ' <span class="text-[12px] text-texto-suave">+ITBIS</span>' : '' ?></td>
                    <td data-etiqueta="Precio final" class="text-right font-medium tabular-nums"><?= e(dinero($final)) ?></td>
                    <td data-etiqueta="Disponible" class="text-right tabular-nums">
                        <?php if ($p['control_stock'] === 'ninguno'): ?><span class="text-texto-suave">Sin control</span>
                        <?php elseif ($p['control_stock'] === 'material'): ?>
                            <span title="Se descuenta de <?= e($p['material']) ?>"><?= e(I::fmt((float) $p['material_stock'] / max(0.001, (float) $p['factor_material']))) ?></span>
                            <span class="block text-[12px] text-texto-suave">de <?= e($p['material']) ?></span>
                        <?php else: ?>
                            <span class="<?= $bajo ? 'font-semibold text-amber-700' : '' ?>"><?= e(I::fmt($p['stock'])) ?></span><?php if ($bajo): ?> <span class="chip-ambar">Bajo</span><?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td data-etiqueta="" class="whitespace-nowrap text-right">
                        <?php if (puede('inventario.editar')): ?>
                            <?php if ($p['control_stock'] === 'propio'): ?><a href="<?= e(url('/inventario/movimiento/producto/' . $p['id'])) ?>" class="btn-secundario btn-sm">Movimiento</a><?php endif; ?>
                            <a href="<?= e(url('/inventario/productos/' . $p['id'])) ?>" class="btn-secundario btn-sm" aria-label="Editar <?= e($p['nombre']) ?>"><?= icono('lapiz', 'h-4 w-4') ?></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
