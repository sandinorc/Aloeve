<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Inventario',
    'descripcion' => 'Proveedores de materiales. Su RNC se usa en el reporte 606 de compras.',
]) ?>
<?= \App\Core\View::parcial('inventario/_pestanas') ?>
<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
    <div class="space-y-3">
        <?php if (!$filas): ?>
            <div class="tarjeta px-5 py-10 text-center text-texto-suave">Todavía no hay proveedores.</div>
        <?php endif; ?>
        <?php foreach ($filas as $p): ?>
            <details class="tarjeta group">
                <summary class="flex cursor-pointer list-none items-center justify-between gap-3 p-4">
                    <span class="min-w-0">
                        <span class="block font-medium <?= (int) $p['activo'] === 1 ? '' : 'text-texto-suave line-through' ?>"><?= e($p['nombre']) ?></span>
                        <span class="block text-[14px] text-texto-suave"><?= e(implode(' · ', array_filter([$p['rnc'] ? 'RNC ' . $p['rnc'] : null, $p['contacto'], $p['telefono']]))) ?: 'Sin datos de contacto' ?></span>
                    </span>
                    <span class="flex shrink-0 items-center gap-2"><span class="chip-gris"><?= (int) $p['materiales'] ?> materiales</span><?= icono('abajo', 'h-4 w-4 transition-transform group-open:rotate-180') ?></span>
                </summary>
                <?php if (puede('inventario.editar')): ?>
                <form method="post" action="<?= e(url('/inventario/proveedores/' . $p['id'])) ?>" class="grid gap-3 border-t border-linea p-4 sm:grid-cols-2">
                    <?= csrf_campo() ?>
                    <div><label class="etiqueta" for="pn<?= (int) $p['id'] ?>">Nombre</label><input id="pn<?= (int) $p['id'] ?>" name="nombre" class="input" value="<?= e($p['nombre']) ?>" required></div>
                    <div><label class="etiqueta" for="pr<?= (int) $p['id'] ?>">RNC</label><input id="pr<?= (int) $p['id'] ?>" name="rnc" class="input font-mono" value="<?= e($p['rnc']) ?>"></div>
                    <div><label class="etiqueta" for="pc<?= (int) $p['id'] ?>">Contacto</label><input id="pc<?= (int) $p['id'] ?>" name="contacto" class="input" value="<?= e($p['contacto']) ?>"></div>
                    <div><label class="etiqueta" for="pt<?= (int) $p['id'] ?>">Teléfono</label><input id="pt<?= (int) $p['id'] ?>" name="telefono" class="input" value="<?= e($p['telefono']) ?>"></div>
                    <div class="sm:col-span-2"><label class="etiqueta" for="pe<?= (int) $p['id'] ?>">Correo</label><input id="pe<?= (int) $p['id'] ?>" name="email" type="email" class="input" value="<?= e($p['email']) ?>"></div>
                    <div class="sm:col-span-2"><label class="etiqueta" for="po<?= (int) $p['id'] ?>">Notas</label><input id="po<?= (int) $p['id'] ?>" name="notas" class="input" value="<?= e($p['notas']) ?>"></div>
                    <label class="flex items-center gap-3"><input type="checkbox" name="activo" value="1" class="check" <?= (int) $p['activo'] === 1 ? 'checked' : '' ?>> Activo</label>
                    <div class="sm:text-right"><button class="btn-secundario btn-sm">Guardar</button></div>
                </form>
                <?php endif; ?>
            </details>
        <?php endforeach; ?>
    </div>
    <?php if (puede('inventario.editar')): ?>
    <form method="post" action="<?= e(url('/inventario/proveedores')) ?>" class="tarjeta tarjeta-cuerpo h-fit space-y-4">
        <?= csrf_campo() ?>
        <h2 class="font-semibold">Agregar proveedor</h2>
        <div><label for="n_nombre" class="etiqueta">Nombre</label><input id="n_nombre" name="nombre" class="input" required placeholder="Ej. LINESCO"></div>
        <div><label for="n_rnc" class="etiqueta">RNC</label><input id="n_rnc" name="rnc" class="input font-mono" inputmode="numeric"></div>
        <div><label for="n_contacto" class="etiqueta">Contacto</label><input id="n_contacto" name="contacto" class="input"></div>
        <div><label for="n_tel" class="etiqueta">Teléfono</label><input id="n_tel" name="telefono" class="input" inputmode="tel"></div>
        <div><label for="n_email" class="etiqueta">Correo</label><input id="n_email" name="email" type="email" class="input"></div>
        <button class="btn-primario w-full"><?= icono('mas', 'h-5 w-5') ?> Agregar</button>
    </form>
    <?php endif; ?>
</div>
