<?php
use App\Modulos\Inventario\InventarioServicio as I;
$v = static fn(string $c, $d = '') => viejo($c, isset($p[$c]) ? (in_array($c, ['stock_minimo', 'factor_material'], true) ? I::fmt($p[$c]) : $p[$c]) : $d);
$control = $v('control_stock', 'propio');
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $p ? $p['nombre'] : 'Nuevo producto',
    'descripcion' => $p ? 'Código ' . $p['sku'] : 'Algo que se cobra en caja.',
    'volver' => ['texto' => 'Productos de venta', 'ruta' => '/inventario/productos'],
]) ?>
<form method="post" action="<?= e(url($p ? '/inventario/productos/' . $p['id'] : '/inventario/productos')) ?>" class="tarjeta tarjeta-cuerpo max-w-3xl space-y-6" data-form-producto data-itbis="<?= e((string) $itbis) ?>">
    <?= csrf_campo() ?>
    <section class="grid gap-4 sm:grid-cols-2">
        <div class="sm:col-span-2">
            <label for="nombre" class="etiqueta">Nombre <span class="text-red-600">*</span></label>
            <input id="nombre" name="nombre" class="input" value="<?= e($v('nombre')) ?>" required placeholder="Ej. Copa de vino tinto">
        </div>
        <div>
            <label for="sku" class="etiqueta">Código</label>
            <input id="sku" name="sku" class="input font-mono uppercase placeholder:normal-case placeholder:font-sans" value="<?= e($v('sku')) ?>" placeholder="Se genera solo si lo dejas vacío">
        </div>
        <div>
            <label for="categoria" class="etiqueta">Categoría</label>
            <select id="categoria" name="categoria" class="input">
                <?php foreach ($categorias as $c): ?><option <?= $v('categoria', 'Otros') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="sm:col-span-2">
            <label for="descripcion" class="etiqueta">Descripción corta</label>
            <input id="descripcion" name="descripcion" class="input" value="<?= e($v('descripcion')) ?>" maxlength="500">
        </div>
    </section>

    <section class="grid gap-4 border-t border-linea pt-6 sm:grid-cols-2">
        <h2 class="sm:col-span-2 text-[13px] font-semibold uppercase tracking-wider text-texto-suave">Precio</h2>
        <div>
            <label for="precio" class="etiqueta">Precio (RD$) <span class="text-red-600">*</span></label>
            <input id="precio" name="precio" class="input tabular-nums" inputmode="decimal" value="<?= e($v('precio')) ?>" required data-precio>
        </div>
        <div class="space-y-2 pt-1 sm:pt-7">
            <label class="flex items-center gap-3"><input type="checkbox" name="lleva_itbis" value="1" class="check" <?= $v('lleva_itbis', '1') === '1' ? 'checked' : '' ?> data-lleva-itbis> Lleva ITBIS (<?= e(rtrim(rtrim(number_format($itbis, 2), '0'), '.')) ?>%)</label>
            <label class="flex items-center gap-3"><input type="checkbox" name="precio_con_itbis" value="1" class="check" data-con-itbis> El precio que escribí ya incluye ITBIS</label>
        </div>
        <p class="sm:col-span-2 rounded-xl bg-fondo px-3 py-2 text-[14px]" data-precio-final></p>
        <div>
            <label for="costo" class="etiqueta">Costo (opcional)</label>
            <input id="costo" name="costo" class="input tabular-nums" inputmode="decimal" value="<?= e($v('costo')) ?>">
            <p class="ayuda">Para calcular el margen en los reportes.</p>
        </div>
    </section>

    <fieldset class="grid gap-4 border-t border-linea pt-6 sm:grid-cols-2">
        <legend class="sr-only">Control de stock</legend>
        <h2 class="sm:col-span-2 text-[13px] font-semibold uppercase tracking-wider text-texto-suave">Stock</h2>
        <div class="sm:col-span-2 grid gap-2 sm:grid-cols-3">
            <?php foreach (['propio' => ['Stock propio', 'Se cuenta por unidades (botellas, kits).'], 'material' => ['Descuenta un material', 'Ej. un lienzo para llevar descuenta del material lienzo.'], 'ninguno' => ['Sin control', 'Servicios o cosas que no se cuentan.']] as $k => [$t, $d]): ?>
                <label class="flex cursor-pointer items-start gap-3 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50">
                    <input type="radio" name="control_stock" value="<?= e($k) ?>" class="mt-0.5 h-5 w-5 text-primario" <?= $control === $k ? 'checked' : '' ?> data-control>
                    <span><span class="block font-medium"><?= e($t) ?></span><span class="block text-[13px] text-texto-suave"><?= e($d) ?></span></span>
                </label>
            <?php endforeach; ?>
        </div>
        <?php if (!$p): ?>
        <div data-solo-control="propio" <?= $control === 'propio' ? '' : 'hidden' ?>>
            <label for="stock_inicial" class="etiqueta">Stock inicial</label>
            <input id="stock_inicial" name="stock_inicial" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('stock_inicial', '0')) ?>">
        </div>
        <?php endif; ?>
        <div data-solo-control="propio" <?= $control === 'propio' ? '' : 'hidden' ?>>
            <label for="stock_minimo" class="etiqueta">Stock mínimo</label>
            <input id="stock_minimo" name="stock_minimo" class="input tabular-nums" inputmode="decimal" value="<?= e($v('stock_minimo', '0')) ?>">
        </div>
        <div data-solo-control="material" <?= $control === 'material' ? '' : 'hidden' ?>>
            <label for="material_id" class="etiqueta">Material</label>
            <select id="material_id" name="material_id" class="input">
                <option value="">Elige un material</option>
                <?php foreach ($materiales as $m): ?><option value="<?= (int) $m['id'] ?>" <?= $v('material_id') === (string) $m['id'] ? 'selected' : '' ?>><?= e($m['nombre'] . ' (' . I::fmt($m['stock']) . ' ' . $m['unidad'] . ')') ?></option><?php endforeach; ?>
            </select>
        </div>
        <div data-solo-control="material" <?= $control === 'material' ? '' : 'hidden' ?>>
            <label for="factor_material" class="etiqueta">Cantidad de material por unidad vendida</label>
            <input id="factor_material" name="factor_material" class="input tabular-nums" inputmode="decimal" value="<?= e($v('factor_material', '1')) ?>">
            <p class="ayuda">Ej. 1 lienzo, o 0.25 litros.</p>
        </div>
        <?php if ($p): ?><p class="sm:col-span-2 text-[14px] text-texto-suave">Stock actual: <strong><?= e(I::fmt($p['stock'])) ?></strong>. Para cambiarlo usa Movimiento en la lista de productos.</p><?php endif; ?>
    </fieldset>

    <?php if ($p): ?><label class="flex items-center gap-3"><input type="checkbox" name="activo" value="1" class="check" <?= $v('activo', '1') === '1' ? 'checked' : '' ?>> Activo (se ve en la caja)</label><?php endif; ?>

    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $p ? 'Guardar' : 'Crear producto' ?></button>
        <a href="<?= e(url('/inventario/productos')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
