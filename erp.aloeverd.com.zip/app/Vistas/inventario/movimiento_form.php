<?php use App\Modulos\Inventario\InventarioServicio as I; $tipo = viejo('tipo', 'entrada'); ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $item['nombre'],
    'descripcion' => 'Stock actual: ' . I::fmt($item['stock']) . ' ' . $item['unidad'] . ' · código ' . $item['codigo'],
    'volver' => ['texto' => 'Inventario', 'ruta' => $volver],
]) ?>
<form method="post" class="tarjeta tarjeta-cuerpo max-w-2xl space-y-5" data-form-movimiento data-stock="<?= e((string) (float) $item['stock']) ?>" data-unidad="<?= e($item['unidad']) ?>">
    <?= csrf_campo() ?>
    <fieldset>
        <legend class="etiqueta">¿Qué pasó?</legend>
        <div class="grid gap-2 sm:grid-cols-3">
            <?php foreach (['entrada' => ['Entró', 'Compra o donación'], 'salida' => ['Salió', 'Se dañó, se regaló, se usó fuera de sesión'], 'ajuste' => ['Conté', 'El conteo físico no coincide']] as $k => [$t, $d]): ?>
                <label class="flex cursor-pointer items-start gap-3 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50">
                    <input type="radio" name="tipo" value="<?= e($k) ?>" class="mt-0.5 h-5 w-5 text-primario" <?= $tipo === $k ? 'checked' : '' ?> data-tipo-mov>
                    <span><span class="block font-medium"><?= e($t) ?></span><span class="block text-[13px] text-texto-suave"><?= e($d) ?></span></span>
                </label>
            <?php endforeach; ?>
        </div>
    </fieldset>
    <div>
        <label for="cantidad" class="etiqueta" data-etiqueta-cantidad>Cantidad (<?= e($item['unidad']) ?>)</label>
        <input id="cantidad" name="cantidad" class="input max-w-xs tabular-nums text-lg" inputmode="decimal" value="<?= e(viejo('cantidad')) ?>" required autofocus>
        <p class="mt-2 rounded-xl bg-fondo px-3 py-2 text-[14px]" data-resultado-mov></p>
    </div>
    <div class="grid gap-4 sm:grid-cols-2" data-solo-mov="entrada">
        <div>
            <label for="costo_unitario" class="etiqueta">Costo por unidad (RD$)</label>
            <input id="costo_unitario" name="costo_unitario" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('costo_unitario', $item['costo_unitario'] ?? '')) ?>">
        </div>
        <?php if ($tipoItem === 'material'): ?>
        <div>
            <label for="proveedor_id" class="etiqueta">Proveedor</label>
            <select id="proveedor_id" name="proveedor_id" class="input">
                <option value="">Sin proveedor</option>
                <?php foreach ($proveedores as $p): ?><option value="<?= (int) $p['id'] ?>" <?= (string) ($item['proveedor_id'] ?? '') === (string) $p['id'] ? 'selected' : '' ?>><?= e($p['nombre']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div>
            <label for="referencia" class="etiqueta">Factura o referencia</label>
            <input id="referencia" name="referencia" class="input" value="<?= e(viejo('referencia')) ?>">
        </div>
    </div>
    <div>
        <label for="motivo" class="etiqueta">Motivo <span class="text-texto-suave font-normal" data-motivo-opcional>(opcional)</span></label>
        <input id="motivo" name="motivo" class="input" value="<?= e(viejo('motivo')) ?>" maxlength="255">
    </div>
    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Registrar</button>
        <a href="<?= e(url($volver)) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
