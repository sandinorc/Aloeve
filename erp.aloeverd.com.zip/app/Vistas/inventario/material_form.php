<?php
use App\Modulos\Inventario\InventarioServicio as I;
$v = static fn(string $c, $d = '') => viejo($c, isset($m[$c]) ? (in_array($c, ['stock_minimo'], true) ? I::fmt($m[$c]) : $m[$c]) : $d);
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => $m ? $m['nombre'] : 'Nuevo material',
    'descripcion' => $m ? 'Código ' . $m['codigo'] . ' · stock actual ' . I::fmt($m['stock']) . ' ' . $m['unidad'] : 'Los materiales son de uso interno: pinturas, lienzos, pinceles. Lo que se vende va en Productos de venta.',
    'volver' => ['texto' => 'Inventario', 'ruta' => '/inventario'],
    'acciones' => $m && puede('inventario.editar') ? '<a href="' . e(url('/inventario/movimiento/material/' . $m['id'])) . '" class="btn-secundario">Registrar movimiento</a>' : '',
]) ?>
<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
<form method="post" action="<?= e(url($m ? '/inventario/materiales/' . $m['id'] : '/inventario/materiales')) ?>" class="tarjeta tarjeta-cuerpo space-y-5">
    <?= csrf_campo() ?>
    <div class="grid gap-4 sm:grid-cols-2">
        <div class="sm:col-span-2">
            <label for="nombre" class="etiqueta">Nombre <span class="text-red-600">*</span></label>
            <input id="nombre" name="nombre" class="input" value="<?= e($v('nombre')) ?>" required placeholder="Ej. Acrílico Blick · Blanco">
        </div>
        <div>
            <label for="codigo" class="etiqueta">Código</label>
            <input id="codigo" name="codigo" class="input font-mono uppercase placeholder:normal-case placeholder:font-sans" value="<?= e($v('codigo')) ?>" placeholder="Se genera solo si lo dejas vacío">
        </div>
        <div>
            <label for="categoria" class="etiqueta">Categoría</label>
            <select id="categoria" name="categoria" class="input">
                <?php foreach ($categorias as $c): ?><option <?= $v('categoria', 'Otros') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="unidad" class="etiqueta">Unidad de medida</label>
            <select id="unidad" name="unidad" class="input">
                <?php foreach ($unidades as $u): ?><option <?= $v('unidad', 'Unidad') === $u ? 'selected' : '' ?>><?= e($u) ?></option><?php endforeach; ?>
            </select>
        </div>
        <?php if (!$m): ?>
        <div>
            <label for="stock_inicial" class="etiqueta">Stock inicial</label>
            <input id="stock_inicial" name="stock_inicial" class="input tabular-nums" inputmode="decimal" value="<?= e(viejo('stock_inicial', '0')) ?>">
            <p class="ayuda">Acepta decimales, por ejemplo 14.18 litros.</p>
        </div>
        <?php endif; ?>
        <div>
            <label for="stock_minimo" class="etiqueta">Stock mínimo</label>
            <input id="stock_minimo" name="stock_minimo" class="input tabular-nums" inputmode="decimal" value="<?= e($v('stock_minimo', '0')) ?>">
            <p class="ayuda">Al llegar aquí, el ERP avisa.</p>
        </div>
        <div>
            <label for="costo_unitario" class="etiqueta">Costo por unidad (RD$)</label>
            <input id="costo_unitario" name="costo_unitario" class="input tabular-nums" inputmode="decimal" value="<?= e($v('costo_unitario', '0')) ?>">
        </div>
        <div>
            <label for="proveedor_id" class="etiqueta">Proveedor</label>
            <select id="proveedor_id" name="proveedor_id" class="input">
                <option value="">Sin proveedor</option>
                <?php foreach ($proveedores as $p): ?><option value="<?= (int) $p['id'] ?>" <?= $v('proveedor_id') === (string) $p['id'] ? 'selected' : '' ?>><?= e($p['nombre']) ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="sm:col-span-2">
            <label for="descripcion" class="etiqueta">Notas</label>
            <textarea id="descripcion" name="descripcion" rows="2" class="input" placeholder="Rendimiento, para qué sesiones se usa…"><?= e($v('descripcion')) ?></textarea>
        </div>
        <?php if ($m): ?>
        <label class="flex items-center gap-3"><input type="checkbox" name="activo" value="1" class="check" <?= $v('activo', '1') === '1' ? 'checked' : '' ?>> Activo</label>
        <?php endif; ?>
    </div>
    <?php if ($m): ?><p class="text-[14px] text-texto-suave">El stock no se edita aquí: usa <strong>Registrar movimiento</strong> (entrada, salida o ajuste por conteo).</p><?php endif; ?>
    <div class="flex flex-wrap gap-3">
        <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> <?= $m ? 'Guardar' : 'Crear material' ?></button>
        <a href="<?= e(url('/inventario')) ?>" class="btn-secundario">Cancelar</a>
    </div>
</form>
<?php if ($m): ?>
<aside class="space-y-4">
    <?php if ($productosLigados): ?>
    <section class="tarjeta tarjeta-cuerpo text-[15px]">
        <h2 class="font-semibold">Se vende como</h2>
        <ul class="mt-2 space-y-1"><?php foreach ($productosLigados as $p): ?><li><a class="enlace" href="<?= e(url('/inventario/productos/' . $p['id'])) ?>"><?= e($p['nombre']) ?></a></li><?php endforeach; ?></ul>
    </section>
    <?php endif; ?>
    <section class="tarjeta">
        <h2 class="border-b border-linea px-5 py-4 font-semibold">Últimos movimientos</h2>
        <?php if (!$movimientos): ?><p class="px-5 py-4 text-texto-suave">Sin movimientos.</p><?php else: ?>
        <ul class="divide-y divide-linea text-[14px]">
            <?php foreach ($movimientos as $mv): ?>
                <li class="px-5 py-3">
                    <div class="flex justify-between gap-2">
                        <span class="font-medium"><?= e(I::TIPOS[$mv['tipo']]) ?></span>
                        <span class="tabular-nums <?= (float) $mv['cantidad'] < 0 ? 'text-red-700' : 'text-emerald-700' ?>"><?= (float) $mv['cantidad'] > 0 ? '+' : '' ?><?= e(I::fmt($mv['cantidad'])) ?></span>
                    </div>
                    <div class="flex justify-between gap-2 text-texto-suave">
                        <span><?= e(fecha($mv['fecha'], true)) ?> · <?= e($mv['usuario'] ?? 'Sistema') ?></span>
                        <span class="tabular-nums">queda <?= e(I::fmt($mv['stock_resultante'])) ?></span>
                    </div>
                    <?php if ($mv['motivo']): ?><p class="text-texto-suave"><?= e($mv['motivo']) ?></p><?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </section>
</aside>
<?php endif; ?>
</div>
