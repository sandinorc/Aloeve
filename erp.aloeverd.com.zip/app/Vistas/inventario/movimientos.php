<?php use App\Modulos\Inventario\InventarioServicio as I; $csv = url('/inventario/movimientos/exportar') . ($_GET ? '?' . http_build_query($_GET) : ''); ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Inventario',
    'descripcion' => 'Cada entrada, salida, ajuste, venta y consumo, con el stock antes y después.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>',
]) ?>
<?= \App\Core\View::parcial('inventario/_pestanas') ?>
<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[1fr_170px_190px_150px_150px_auto]">
    <input name="q" value="<?= e(get('q')) ?>" class="input" placeholder="Artículo o código" aria-label="Buscar">
    <select name="articulo" class="input" aria-label="Artículo">
        <option value="">Materiales y productos</option>
        <option value="material" <?= get('articulo') === 'material' ? 'selected' : '' ?>>Materiales</option>
        <option value="producto" <?= get('articulo') === 'producto' ? 'selected' : '' ?>>Productos</option>
    </select>
    <select name="tipo" class="input" aria-label="Tipo">
        <option value="">Todos los tipos</option>
        <?php foreach (I::TIPOS as $k => $t): ?><option value="<?= e($k) ?>" <?= get('tipo') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
    </select>
    <input type="date" name="desde" value="<?= e(get('desde')) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e(get('hasta')) ?>" class="input" aria-label="Hasta">
    <button class="btn-secundario">Filtrar</button>
</form>
<div class="tarjeta overflow-hidden">
    <?php if (!$filas): ?>
        <p class="px-5 py-10 text-center text-texto-suave">No hay movimientos con esos filtros.</p>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Fecha</th><th>Artículo</th><th>Tipo</th><th class="text-right">Cantidad</th><th class="text-right">Queda</th><th>Detalle</th></tr></thead>
            <tbody>
            <?php foreach ($filas as $f): ?>
                <tr>
                    <td data-principal class="whitespace-nowrap tabular-nums"><?= e(fecha($f['fecha'], true)) ?></td>
                    <td data-etiqueta="Artículo"><?= e($f['articulo']) ?> <span class="font-mono text-[12px] text-texto-suave"><?= e($f['codigo']) ?></span></td>
                    <td data-etiqueta="Tipo"><span class="chip-morado"><?= e(I::TIPOS[$f['tipo']]) ?></span></td>
                    <td data-etiqueta="Cantidad" class="text-right tabular-nums <?= (float) $f['cantidad'] < 0 ? 'text-red-700' : 'text-emerald-700' ?>"><?= (float) $f['cantidad'] > 0 ? '+' : '' ?><?= e(I::fmt($f['cantidad'])) ?></td>
                    <td data-etiqueta="Queda" class="text-right tabular-nums"><?= e(I::fmt($f['stock_resultante']) . ' ' . $f['unidad']) ?></td>
                    <td data-etiqueta="Detalle" class="text-[14px] text-texto-suave">
                        <?= e(implode(' · ', array_filter([$f['motivo'], $f['proveedor'], $f['referencia'] ? 'Ref. ' . $f['referencia'] : null, $f['usuario']]))) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
