<?php
use App\Modulos\Inventario\InventarioServicio as I;
$acciones = puede('inventario.editar') ? '<a href="' . e(url('/inventario/materiales/nuevo')) . '" class="btn-primario">' . icono('mas', 'h-5 w-5') . ' Nuevo material</a>' : '';
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Inventario',
    'descripcion' => 'Materiales de uso interno y productos para la venta. Cada cambio de stock queda como movimiento.',
    'acciones' => $acciones,
]) ?>
<?= \App\Core\View::parcial('inventario/_pestanas') ?>

<div class="mb-6 grid grid-cols-3 gap-3 sm:gap-4">
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave sm:text-[15px]">Materiales activos</p><p class="mt-1 font-display text-2xl tabular-nums sm:text-3xl"><?= number_format($activos) ?></p></div>
    <a href="<?= e(url('/inventario?bajo=1')) ?>" class="tarjeta p-4 hover:border-amber-300"><p class="text-[13px] text-texto-suave sm:text-[15px]">Bajo el mínimo</p><p class="mt-1 font-display text-2xl tabular-nums sm:text-3xl <?= $bajos ? 'text-amber-700' : '' ?>"><?= number_format($bajos) ?></p></a>
    <div class="tarjeta p-4"><p class="text-[13px] text-texto-suave sm:text-[15px]">Valor al costo</p><p class="mt-1 text-lg font-semibold tabular-nums sm:text-2xl"><?= e(dinero($valor)) ?></p></div>
</div>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-[1fr_200px_auto_auto]">
    <label class="relative">
        <span class="sr-only">Buscar</span>
        <span class="pointer-events-none absolute inset-y-0 left-3 grid place-items-center text-texto-suave"><?= icono('buscar', 'h-5 w-5') ?></span>
        <input name="q" value="<?= e(get('q')) ?>" class="input pl-10" placeholder="Nombre o código">
    </label>
    <select name="categoria" class="input" aria-label="Categoría">
        <option value="">Todas las categorías</option>
        <?php foreach ($categorias as $c): ?><option <?= get('categoria') === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
    </select>
    <label class="flex min-h-[44px] items-center gap-2 rounded-xl border border-linea bg-white px-3 text-[15px]">
        <input type="checkbox" name="bajo" value="1" class="check" <?= get('bajo') === '1' ? 'checked' : '' ?>> Solo bajo mínimo
    </label>
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <?php if (!$filas): ?>
        <div class="px-5 py-12 text-center">
            <div class="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('inventario') ?></div>
            <p class="text-texto-suave"><?= get('q') !== '' || get('categoria') !== '' || get('bajo') !== '' ? 'Ningún material coincide.' : 'Todavía no hay materiales. Los del CRM anterior se traen en la migración (Fase 3), o puedes crearlos ahora.' ?></p>
        </div>
    <?php else: ?>
    <div class="overflow-x-auto">
        <table class="tabla tabla-resp">
            <thead><tr><th>Material</th><th>Categoría</th><th class="text-right">Stock</th><th class="text-right">Mínimo</th><th class="text-right">Costo</th><th class="text-right">Acciones</th></tr></thead>
            <tbody>
            <?php foreach ($filas as $m): $bajo = (float) $m['stock_minimo'] > 0 && (float) $m['stock'] <= (float) $m['stock_minimo']; ?>
                <tr>
                    <td data-principal>
                        <span class="block font-medium"><?= e($m['nombre']) ?></span>
                        <span class="block font-mono text-[13px] font-normal text-texto-suave"><?= e($m['codigo']) ?></span>
                    </td>
                    <td data-etiqueta="Categoría"><?= e($m['categoria']) ?></td>
                    <td data-etiqueta="Stock" class="text-right tabular-nums">
                        <span class="<?= $bajo ? 'font-semibold text-amber-700' : '' ?>"><?= e(I::fmt($m['stock'])) ?></span> <span class="text-texto-suave"><?= e($m['unidad']) ?></span>
                        <?php if ($bajo): ?><span class="chip-ambar ml-1">Bajo</span><?php endif; ?>
                    </td>
                    <td data-etiqueta="Mínimo" class="text-right tabular-nums text-texto-suave"><?= e(I::fmt($m['stock_minimo'])) ?></td>
                    <td data-etiqueta="Costo" class="text-right tabular-nums"><?= e(dinero($m['costo_unitario'])) ?></td>
                    <td data-etiqueta="" class="whitespace-nowrap text-right">
                        <?php if (puede('inventario.editar')): ?>
                            <a href="<?= e(url('/inventario/movimiento/material/' . $m['id'])) ?>" class="btn-secundario btn-sm">Movimiento</a>
                            <a href="<?= e(url('/inventario/materiales/' . $m['id'])) ?>" class="btn-secundario btn-sm" aria-label="Editar <?= e($m['nombre']) ?>"><?= icono('lapiz', 'h-4 w-4') ?></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
