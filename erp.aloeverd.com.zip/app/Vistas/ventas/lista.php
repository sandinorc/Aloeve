<?php
use App\Modulos\Ecf\EcfServicio;
use App\Modulos\Ventas\VentasServicio as V;
/** @var array $ventas @var string $desde @var string $hasta @var array $sumas @var int $total @var int $pagina @var int $paginas */
$csv = url('/ventas') . '?' . http_build_query(array_merge($_GET, ['formato' => 'csv']));
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Historial de ventas',
    'descripcion' => puede('finanzas.ver') ? 'Todas las ventas de la caja con su comprobante fiscal.' : 'Tus ventas en la caja.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>'
        . (puede('pos.cobrar') ? '<a href="' . e(url('/pos')) . '" class="btn-primario">' . icono('venta', 'h-5 w-5') . ' Ir a la caja</a>' : ''),
]) ?>
<div class="mb-4 grid gap-3 sm:grid-cols-3">
    <div class="tarjeta p-4"><p class="text-sm text-texto-suave">Vendido</p><p class="mt-1 text-2xl font-semibold tabular-nums"><?= e(dinero($sumas['total'])) ?></p></div>
    <div class="tarjeta p-4"><p class="text-sm text-texto-suave">Ventas</p><p class="mt-1 text-2xl font-semibold tabular-nums"><?= (int) $sumas['cantidad'] ?><?= (int) $sumas['anuladas'] ? ' <span class="text-base font-normal text-texto-suave">· ' . (int) $sumas['anuladas'] . ' anuladas</span>' : '' ?></p></div>
    <div class="tarjeta p-4"><p class="text-sm text-texto-suave">ITBIS cobrado</p><p class="mt-1 text-2xl font-semibold tabular-nums"><?= e(dinero($sumas['itbis'])) ?></p></div>
</div>
<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[150px_150px_1fr_180px_auto]">
    <input type="date" name="desde" value="<?= e($desde) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e($hasta) ?>" class="input" aria-label="Hasta">
    <input type="search" name="q" value="<?= e(get('q')) ?>" class="input" placeholder="Número, cliente o NCF" aria-label="Buscar">
    <select name="estado" class="input" aria-label="Estado">
        <option value="">Todas</option>
        <option value="completada" <?= get('estado') === 'completada' ? 'selected' : '' ?>>Completadas</option>
        <option value="anulada" <?= get('estado') === 'anulada' ? 'selected' : '' ?>>Anuladas</option>
    </select>
    <button class="btn-secundario">Filtrar</button>
</form>
<div class="tarjeta overflow-hidden">
    <?php if (!$ventas): ?><p class="px-5 py-10 text-center text-texto-suave">No hay ventas en ese rango.</p><?php else: ?>
    <div class="overflow-x-auto"><table class="tabla tabla-resp">
        <thead><tr><th>Venta</th><th>Fecha</th><th>Cliente</th><th>Comprobante</th><th>Pago</th><th class="text-right">Total</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($ventas as $v): ?>
            <tr class="<?= $v['estado'] === 'anulada' ? 'opacity-60' : '' ?>">
                <td data-principal><a class="font-medium text-primario-700 hover:underline" href="<?= e(url('/ventas/' . $v['id'])) ?>"><?= e($v['numero']) ?></a>
                    <?= $v['estado'] === 'anulada' ? ' <span class="chip-rojo">Anulada</span>' : '' ?></td>
                <td data-etiqueta="Fecha" class="whitespace-nowrap tabular-nums"><?= e(fecha($v['fecha'], true)) ?></td>
                <td data-etiqueta="Cliente"><?= e($v['cliente'] ?? 'Consumidor final') ?></td>
                <td data-etiqueta="Comprobante"><span class="font-mono text-[14px]"><?= e($v['ncf'] ?? '—') ?></span>
                    <?php if ($v['ecf_estado']): [$t, $cl] = EcfServicio::ESTADOS[$v['ecf_estado']]; ?> <span class="<?= e($cl) ?>"><?= e($t) ?></span><?php endif; ?></td>
                <td data-etiqueta="Pago"><?= e(implode(', ', array_map(static fn($m) => V::METODOS[$m] ?? $m, array_filter(explode(',', (string) $v['metodos']))))) ?></td>
                <td data-etiqueta="Total" class="text-right font-medium tabular-nums"><?= e(dinero($v['total'])) ?></td>
                <td data-etiqueta="" class="text-right"><a class="btn-secundario btn-sm" href="<?= e(url('/ventas/' . $v['id'] . '/recibo')) ?>" target="_blank" rel="noopener" aria-label="Recibo de <?= e($v['numero']) ?>"><?= icono('imprimir', 'h-4 w-4') ?> Recibo</a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?= \App\Core\View::parcial('parciales/paginacion', compact('pagina', 'paginas', 'total')) ?>
    <?php endif; ?>
</div>
