<?php
use App\Core\Ncf;
use App\Modulos\Ventas\VentasServicio as V;
/**
 * Recibo de 80 mm (representación impresa). Página independiente, sin el menú.
 * @var array $v @var ?array $c @var ?array $origen @var array $items @var array $pagos @var array $negocio @var ?string $qr @var ?string $urlQr
 */
$n = static fn(string $k) => trim((string) ($negocio[$k] ?? ''));
$nombre = $n('negocio.nombre_comercial') ?: 'Aloeve Art Studio';
$esEcf = $c && $c['clase'] === 'electronico';
$titulo = $c ? Ncf::nombre($c['tipo']) : 'Recibo de venta';
$fmt = static fn($m) => number_format((float) $m, 2, '.', ',');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(($c['ncf'] ?? $v['numero']) . ' · ' . $nombre) ?></title>
<link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
<script src="<?= e(asset('js/app.js')) ?>" defer></script>
<style>
  @page { size: 80mm auto; margin: 0; }
  body { background: #f5f4f8; color: #000; }
  .ticket { width: 80mm; margin: 16px auto; background: #fff; padding: 5mm 4mm 8mm; font-size: 12px; line-height: 1.35; box-shadow: 0 2px 10px rgba(0,0,0,.08); }
  .ticket h1 { font-size: 16px; font-weight: 700; text-align: center; }
  .c { text-align: center; } .r { text-align: right; } .b { font-weight: 700; }
  .sep { border: 0; border-top: 1px dashed #000; margin: 6px 0; }
  .fila { display: flex; justify-content: space-between; gap: 8px; }
  .fila span:last-child { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
  .items { width: 100%; border-collapse: collapse; }
  .items td { padding: 1px 0; vertical-align: top; font-variant-numeric: tabular-nums; }
  .total { font-size: 15px; font-weight: 700; }
  .qr svg { width: 34mm; height: 34mm; margin: 4px auto 0; display: block; }
  .marca { border: 2px solid #000; padding: 3px; text-align: center; font-weight: 700; margin: 6px 0; }
  .acciones { width: 80mm; margin: 0 auto 24px; display: flex; gap: 8px; }
  @media print {
    body { background: #fff; }
    .ticket { margin: 0; box-shadow: none; width: 100%; }
    .acciones { display: none; }
  }
</style>
</head>
<body<?= get('imprimir') === '1' ? ' data-auto-imprimir' : '' ?>>
<div class="acciones">
    <button type="button" class="btn-primario flex-1" data-imprimir><?= icono('imprimir', 'h-5 w-5') ?> Imprimir</button>
    <a class="btn-secundario" href="<?= e(url('/ventas/' . $v['id'])) ?>">Ver venta</a>
</div>
<main class="ticket">
    <h1><?= e($nombre) ?></h1>
    <?php if ($n('negocio.razon_social') && $n('negocio.razon_social') !== $nombre): ?><p class="c"><?= e($n('negocio.razon_social')) ?></p><?php endif; ?>
    <?php if ($n('negocio.rnc')): ?><p class="c">RNC: <?= e($n('negocio.rnc')) ?></p><?php endif; ?>
    <?php if ($n('negocio.direccion')): ?><p class="c"><?= e($n('negocio.direccion')) ?></p><?php endif; ?>
    <?php if ($n('negocio.telefono')): ?><p class="c">Tel. <?= e($n('negocio.telefono')) ?></p><?php endif; ?>
    <hr class="sep">

    <p class="c b"><?= e(mb_strtoupper($titulo)) ?></p>
    <?php if ($c): ?>
        <div class="fila"><span><?= $esEcf ? 'e-NCF' : 'NCF' ?>:</span><span class="b"><?= e($c['ncf']) ?></span></div>
        <?php if (!$esEcf && $c['vence_secuencia']): ?><div class="fila"><span>Válido hasta:</span><span><?= e(fecha($c['vence_secuencia'])) ?></span></div><?php endif; ?>
        <?php if ($origen): ?><div class="fila"><span>NCF modificado:</span><span><?= e($origen['ncf']) ?></span></div><?php endif; ?>
    <?php endif; ?>
    <div class="fila"><span>Fecha:</span><span><?= e(fecha($c['fecha'] ?? $v['fecha'], true)) ?></span></div>
    <div class="fila"><span>Venta:</span><span><?= e($v['numero']) ?></span></div>
    <div class="fila"><span>Cajero:</span><span><?= e($v['cajero'] ?? '—') ?></span></div>
    <?php if ($c && $c['rnc_cedula']): ?>
        <hr class="sep">
        <div class="fila"><span>RNC/Céd. cliente:</span><span><?= e($c['rnc_cedula']) ?></span></div>
        <p><?= e($c['razon_social']) ?></p>
    <?php elseif ($v['cliente']): ?>
        <div class="fila"><span>Cliente:</span><span><?= e($v['cliente']) ?></span></div>
    <?php endif; ?>

    <?php if ($v['estado'] === 'anulada' && (!$c || !$c['comprobante_origen_id'])): ?><p class="marca">VENTA ANULADA</p><?php endif; ?>
    <?php if ($c && $c['ecf_simulado']): ?><p class="marca">SIMULACIÓN · SIN VALIDEZ FISCAL</p><?php endif; ?>

    <hr class="sep">
    <table class="items">
        <?php foreach ($items as $it): ?>
            <tr><td colspan="2"><?= e($it['descripcion']) ?><?= (float) $it['tasa_itbis'] === 0.0 ? ' (E)' : '' ?></td></tr>
            <tr>
                <td><?= e(\App\Modulos\Inventario\InventarioServicio::fmt($it['cantidad'])) ?> x <?= e($fmt($it['precio_unitario'])) ?><?= (float) $it['descuento'] > 0 ? ' − ' . e($fmt($it['descuento'])) : '' ?></td>
                <td class="r"><?= e($fmt((float) $it['precio_unitario'] * (float) $it['cantidad'] - (float) $it['descuento'])) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <hr class="sep">
    <div class="fila"><span>Subtotal</span><span><?= e($fmt((float) $v['subtotal'] + (float) $v['descuento'])) ?></span></div>
    <?php if ((float) $v['descuento'] > 0): ?><div class="fila"><span>Descuento</span><span>−<?= e($fmt($v['descuento'])) ?></span></div><?php endif; ?>
    <div class="fila"><span>ITBIS</span><span><?= e($fmt($v['itbis'])) ?></span></div>
    <div class="fila total"><span><?= $c && $c['comprobante_origen_id'] ? 'TOTAL CRÉDITO' : 'TOTAL' ?> RD$</span><span><?= e($fmt($c['total'] ?? $v['total'])) ?></span></div>
    <?php if (!$c || !$c['comprobante_origen_id']): ?>
        <hr class="sep">
        <?php foreach ($pagos as $p): ?><div class="fila"><span><?= e(V::METODOS[$p['metodo']] ?? $p['metodo']) ?></span><span><?= e($fmt($p['monto'])) ?></span></div><?php endforeach; ?>
        <?php if ((float) $v['cambio'] > 0): ?><div class="fila"><span>Recibido en efectivo</span><span><?= e($fmt(array_sum(array_map(static fn($p) => $p['metodo'] === 'efectivo' ? (float) $p['monto'] : 0, $pagos)) + (float) $v['cambio'])) ?></span></div><div class="fila b"><span>Cambio</span><span><?= e($fmt($v['cambio'])) ?></span></div><?php endif; ?>
    <?php endif; ?>

    <?php if ($esEcf): ?>
        <hr class="sep">
        <?php if ($c['codigo_seguridad']): ?>
            <div class="fila"><span>Código de seguridad:</span><span class="b"><?= e($c['codigo_seguridad']) ?></span></div>
            <?php if ($c['fecha_firma']): ?><div class="fila"><span>Fecha de firma:</span><span><?= e(date('d-m-Y H:i:s', strtotime($c['fecha_firma']))) ?></span></div><?php endif; ?>
            <?php if ($qr): ?><div class="qr" role="img" aria-label="Código QR para consultar el comprobante en la DGII"><?= $qr ?></div><?php endif; ?>
        <?php else: ?>
            <p class="c">Comprobante electrónico pendiente de firma. Reimprima cuando esté aceptado.</p>
        <?php endif; ?>
    <?php endif; ?>

    <hr class="sep">
    <p class="c"><?= e($n('negocio.pie_recibo') ?: '¡Gracias por crear con nosotros!') ?></p>
    <?php if ($n('negocio.correo')): ?><p class="c"><?= e($n('negocio.correo')) ?></p><?php endif; ?>
</main>
</body>
</html>
