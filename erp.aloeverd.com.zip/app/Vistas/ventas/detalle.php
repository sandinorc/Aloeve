<?php
use App\Core\Ncf;
use App\Modulos\Ecf\EcfServicio;
use App\Modulos\Ventas\VentasServicio as V;
/** @var array $v @var array $items @var array $pagos @var array $comprobantes */
$anulada = $v['estado'] === 'anulada';
$acciones = '<a href="' . e(url('/ventas/' . $v['id'] . '/recibo')) . '" target="_blank" rel="noopener" class="btn-secundario">' . icono('imprimir', 'h-4 w-4') . ' Recibo</a>';
if (!$anulada && puede('comprobantes.anular')) {
    $acciones .= '<button type="button" class="btn-peligro" data-dialogo-abrir="dlg-anular">' . icono('anular', 'h-4 w-4') . ' Anular venta</button>';
}
$conectores = ['simulador' => 'Simulador', 'dgii' => 'DGII directo', 'proveedor' => 'Proveedor'];
$ambientes = ['testecf' => 'Prueba', 'certecf' => 'Certificación', 'ecf' => 'Producción'];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Venta ' . $v['numero'],
    'descripcion' => fecha($v['fecha'], true) . ' · ' . ($v['cajero'] ?? '—') . ($v['sede'] ? ' · ' . $v['sede'] : ''),
    'volver' => ['texto' => 'Historial de ventas', 'ruta' => '/ventas'],
    'acciones' => $acciones,
]) ?>

<?php if ($anulada): ?>
    <div class="mb-5 flex gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-red-800">
        <?= icono('anular', 'h-5 w-5 shrink-0') ?>
        <p><strong>Venta anulada</strong> el <?= e(fecha($v['anulada_en'], true)) ?> por <?= e($v['anulador'] ?? '—') ?>. Motivo: <?= e($v['motivo_anulacion']) ?></p>
    </div>
<?php endif; ?>

<div class="grid gap-6 lg:grid-cols-[1fr_360px]">
    <div class="space-y-6">
        <div class="tarjeta overflow-hidden">
            <h2 class="border-b border-linea px-5 py-3 font-semibold">Artículos</h2>
            <div class="overflow-x-auto"><table class="tabla tabla-resp">
                <thead><tr><th>Descripción</th><th class="text-right">Cant.</th><th class="text-right">Precio</th><th class="text-right">Desc.</th><th class="text-right">ITBIS</th><th class="text-right">Total</th></tr></thead>
                <tbody>
                <?php foreach ($items as $it): ?>
                    <tr>
                        <td data-principal><?= e($it['descripcion']) ?><?= (float) $it['tasa_itbis'] === 0.0 ? ' <span class="chip-gris">Exento</span>' : '' ?></td>
                        <td data-etiqueta="Cantidad" class="whitespace-nowrap text-right tabular-nums"><?= e(\App\Modulos\Inventario\InventarioServicio::fmt($it['cantidad'])) ?></td>
                        <td data-etiqueta="Precio" class="whitespace-nowrap text-right tabular-nums"><?= e(dinero($it['precio_unitario'])) ?></td>
                        <td data-etiqueta="Descuento" class="whitespace-nowrap text-right tabular-nums"><?= (float) $it['descuento'] > 0 ? e(dinero($it['descuento'])) : '—' ?></td>
                        <td data-etiqueta="ITBIS" class="whitespace-nowrap text-right tabular-nums"><?= e(dinero($it['itbis'])) ?></td>
                        <td data-etiqueta="Total" class="whitespace-nowrap text-right font-medium tabular-nums"><?= e(dinero($it['total'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
            <dl class="space-y-1.5 border-t border-linea px-5 py-4 text-[15px] sm:ml-auto sm:max-w-xs">
                <div class="flex justify-between"><dt class="text-texto-suave">Subtotal</dt><dd class="tabular-nums"><?= e(dinero((float) $v['subtotal'] + (float) $v['descuento'])) ?></dd></div>
                <?php if ((float) $v['descuento'] > 0): ?><div class="flex justify-between"><dt class="text-texto-suave">Descuento</dt><dd class="tabular-nums text-red-700">− <?= e(dinero($v['descuento'])) ?></dd></div><?php endif; ?>
                <div class="flex justify-between"><dt class="text-texto-suave">ITBIS</dt><dd class="tabular-nums"><?= e(dinero($v['itbis'])) ?></dd></div>
                <div class="flex justify-between text-lg font-semibold"><dt>Total</dt><dd class="tabular-nums"><?= e(dinero($v['total'])) ?></dd></div>
            </dl>
        </div>

        <?php foreach ($comprobantes as $c):
            $estado = $c['ecf_estado'] ? EcfServicio::ESTADOS[$c['ecf_estado']] : null; ?>
            <div class="tarjeta overflow-hidden">
                <div class="flex flex-wrap items-center justify-between gap-3 border-b border-linea px-5 py-3">
                    <div>
                        <h2 class="font-semibold"><?= e(Ncf::nombre($c['tipo'])) ?></h2>
                        <p class="font-mono text-[15px]"><?= e($c['ncf']) ?></p>
                    </div>
                    <div class="flex flex-wrap items-center gap-2">
                        <?= $c['estado'] === 'anulado' ? '<span class="chip-rojo">Anulado</span>' : '' ?>
                        <?php if ($estado): ?><span class="<?= e($estado[1]) ?>"><?= e($estado[0]) ?></span><?php endif; ?>
                        <?= $c['ecf_simulado'] ? '<span class="chip-ambar">Simulado</span>' : '' ?>
                        <?php if ($c['comprobante_origen_id'] || $anulada): ?>
                            <a class="btn-secundario btn-sm" target="_blank" rel="noopener" href="<?= e(url('/ventas/' . $v['id'] . '/recibo') . '?comprobante=' . $c['id']) ?>"><?= icono('imprimir', 'h-4 w-4') ?> Imprimir</a>
                        <?php endif; ?>
                        <?php if ($c['clase'] === 'electronico' && !in_array($c['ecf_estado'], ['aceptado', 'aceptado_condicional'], true) && (puede('comprobantes.emitir') || puede('fiscal.editar'))): ?>
                            <form method="post" action="<?= e(url('/comprobantes/' . $c['id'] . '/reenviar')) ?>"><?= csrf_campo() ?>
                                <button class="btn-secundario btn-sm"><?= icono('refrescar', 'h-4 w-4') ?> <?= $c['ecf_estado'] === 'en_proceso' ? 'Consultar' : 'Reenviar' ?></button></form>
                        <?php endif; ?>
                    </div>
                </div>
                <dl class="grid gap-x-6 gap-y-2 px-5 py-4 text-[15px] sm:grid-cols-2">
                    <div><dt class="text-[13px] text-texto-suave">Cliente</dt><dd><?= e($c['razon_social'] ?? 'Consumidor final') ?><?= $c['rnc_cedula'] ? ' · ' . e($c['rnc_cedula']) : '' ?></dd></div>
                    <div><dt class="text-[13px] text-texto-suave">Monto</dt><dd class="tabular-nums"><?= e(dinero($c['total'])) ?> <span class="text-texto-suave">(ITBIS <?= e(dinero($c['itbis'])) ?>)</span></dd></div>
                    <?php if ($c['vence_secuencia']): ?><div><dt class="text-[13px] text-texto-suave">Secuencia válida hasta</dt><dd><?= e(fecha($c['vence_secuencia'])) ?></dd></div><?php endif; ?>
                    <?php if ($c['codigo_seguridad']): ?><div><dt class="text-[13px] text-texto-suave">Código de seguridad</dt><dd class="font-mono"><?= e($c['codigo_seguridad']) ?></dd></div><?php endif; ?>
                    <?php if ($c['track_id']): ?><div class="sm:col-span-2"><dt class="text-[13px] text-texto-suave">TrackId</dt><dd class="break-all font-mono text-[14px]"><?= e($c['track_id']) ?></dd></div><?php endif; ?>
                    <?php if ($c['motivo_anulacion']): ?><div class="sm:col-span-2"><dt class="text-[13px] text-texto-suave">Motivo</dt><dd><?= e($c['motivo_anulacion']) ?></dd></div><?php endif; ?>
                </dl>
                <?php if ($c['envios']): ?>
                    <details class="border-t border-linea px-5 py-3">
                        <summary class="cursor-pointer text-[15px] font-medium text-primario-700">Historial de envíos a la DGII (<?= count($c['envios']) ?>)</summary>
                        <ul class="mt-3 space-y-3">
                            <?php foreach ($c['envios'] as $en):
                                $mensajes = json_decode((string) $en['mensajes'], true) ?: []; ?>
                                <li class="rounded-xl border border-linea p-3 text-[14px]">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <span class="<?= e(EcfServicio::ESTADOS[$en['estado']][1]) ?>"><?= e(EcfServicio::ESTADOS[$en['estado']][0]) ?></span>
                                        <span class="text-texto-suave"><?= e($conectores[$en['conector']] ?? $en['conector']) ?> · <?= e($ambientes[$en['ambiente']] ?? $en['ambiente']) ?> · <?= e(strtoupper($en['documento'])) ?> · <?= e(fecha($en['enviado_en'] ?? $en['creado_en'], true)) ?> · <?= (int) $en['intentos'] ?> intento(s)</span>
                                        <?php if ($en['xml_firmado'] && puede('fiscal.ver')): ?>
                                            <a class="ml-auto text-primario-700 hover:underline" href="<?= e(url('/comprobantes/envios/' . $en['id'] . '/xml')) ?>">Descargar XML</a>
                                        <?php endif; ?>
                                    </div>
                                    <?php foreach ($mensajes as $m): ?><p class="mt-1 text-texto-suave"><?= isset($m['codigo']) && $m['codigo'] !== null ? '[' . e((string) $m['codigo']) . '] ' : '' ?><?= e((string) ($m['valor'] ?? '')) ?></p><?php endforeach; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </details>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <aside class="space-y-6">
        <div class="tarjeta tarjeta-cuerpo">
            <h2 class="mb-3 font-semibold">Cliente</h2>
            <?php if ($v['cliente_id']): ?>
                <a class="font-medium text-primario-700 hover:underline" href="<?= e(url('/clientes/' . $v['cliente_id'])) ?>"><?= e($v['cliente']) ?></a>
                <?php if ($v['cliente_documento']): ?><p class="text-texto-suave"><?= e($v['cliente_documento']) ?></p><?php endif; ?>
            <?php else: ?><p class="text-texto-suave">Consumidor final</p><?php endif; ?>
        </div>
        <div class="tarjeta tarjeta-cuerpo">
            <h2 class="mb-3 font-semibold">Pagos</h2>
            <ul class="space-y-1.5 text-[15px]">
                <?php foreach ($pagos as $p): ?>
                    <li class="flex justify-between gap-3"><span><?= e(V::METODOS[$p['metodo']] ?? $p['metodo']) ?><?= $p['referencia'] ? ' <span class="text-texto-suave">· ' . e($p['referencia']) . '</span>' : '' ?></span><span class="tabular-nums"><?= e(dinero($p['monto'])) ?></span></li>
                <?php endforeach; ?>
                <?php if ((float) $v['cambio'] > 0): ?><li class="flex justify-between gap-3 text-texto-suave"><span>Cambio entregado</span><span class="tabular-nums"><?= e(dinero($v['cambio'])) ?></span></li><?php endif; ?>
            </ul>
            <?php if ($v['notas']): ?><p class="mt-3 border-t border-linea pt-3 text-texto-suave"><?= e($v['notas']) ?></p><?php endif; ?>
        </div>
    </aside>
</div>

<?php if (!$anulada && puede('comprobantes.anular')):
    $esEcf = (bool) array_filter($comprobantes, static fn($c) => $c['clase'] === 'electronico'); ?>
<dialog id="dlg-anular" class="dialogo" aria-labelledby="t-anular">
    <form method="post" action="<?= e(url('/ventas/' . $v['id'] . '/anular')) ?>" class="space-y-4">
        <?= csrf_campo() ?>
        <div class="flex items-start justify-between gap-4"><h2 id="t-anular" class="text-xl font-semibold">Anular venta <?= e($v['numero']) ?></h2><button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button></div>
        <ul class="list-disc space-y-1 pl-5 text-[15px] text-texto-suave">
            <li>Los artículos vuelven al inventario.</li>
            <li>Los ingresos de esta venta quedan anulados en Finanzas.</li>
            <?php if ($esEcf): ?>
                <li>Un e-CF no se puede borrar: se emitirá una <strong class="text-texto">nota de crédito electrónica (E34)</strong> por el total.</li>
            <?php else: ?>
                <li>El comprobante <?= e($comprobantes[0]['ncf'] ?? '') ?> queda anulado (aparecerá en el reporte 608).</li>
            <?php endif; ?>
        </ul>
        <div><label class="etiqueta" for="a_motivo">Motivo</label><input id="a_motivo" name="motivo" class="input" required minlength="4" maxlength="255" placeholder="Ej. Cliente devolvió el producto"></div>
        <div class="grid grid-cols-[1fr_2fr] gap-3"><button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button><button class="btn-peligro">Anular venta</button></div>
    </form>
</dialog>
<?php endif; ?>
