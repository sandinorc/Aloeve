<?php
use App\Core\Ncf;
use App\Modulos\Ecf\EcfServicio;
/** @var array $filas @var string $desde @var string $hasta @var int $pendientes @var int $problemas @var string $urlCron */
$csv = url('/comprobantes') . '?' . http_build_query(array_merge($_GET, ['formato' => 'csv']));
$puedeCola = puede('comprobantes.emitir') || puede('fiscal.editar');
$suma = array_sum(array_map(static fn($f) => $f['estado'] === 'emitido' ? ((str_ends_with($f['tipo'], '34') || $f['tipo'] === 'B04') ? -1 : 1) * (float) $f['total'] : 0, $filas));
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Comprobantes emitidos',
    'descripcion' => 'Cada NCF o e-NCF usado en la caja, con su estado ante la DGII.',
    'acciones' => '<a href="' . e($csv) . '" class="btn-secundario">' . icono('descargar', 'h-4 w-4') . ' CSV</a>'
        . ($puedeCola && $pendientes ? '<form method="post" action="' . e(url('/comprobantes/cola')) . '">' . csrf_campo() . '<button class="btn-primario">' . icono('refrescar', 'h-4 w-4') . ' Procesar pendientes (' . $pendientes . ')</button></form>' : ''),
]) ?>

<?php if ($problemas): ?>
    <div class="mb-4 flex gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-red-800">
        <?= icono('alerta', 'h-5 w-5 shrink-0') ?>
        <p><strong><?= $problemas ?></strong> comprobante(s) electrónicos rechazados o con error. <a class="font-medium underline" href="<?= e(url('/comprobantes') . '?ecf=rechazado&desde=2020-01-01') ?>">Ver rechazados</a> · <a class="font-medium underline" href="<?= e(url('/comprobantes') . '?ecf=error&desde=2020-01-01') ?>">Ver con error</a></p>
    </div>
<?php endif; ?>

<form method="get" class="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-[150px_150px_1fr_200px_200px_auto]">
    <input type="date" name="desde" value="<?= e($desde) ?>" class="input" aria-label="Desde">
    <input type="date" name="hasta" value="<?= e($hasta) ?>" class="input" aria-label="Hasta">
    <input type="search" name="q" value="<?= e(get('q')) ?>" class="input" placeholder="NCF, RNC o razón social" aria-label="Buscar">
    <select name="tipo" class="input" aria-label="Tipo"><option value="">Todos los tipos</option>
        <?php foreach (Ncf::TIPOS as $k => $t): if (!$t['basico']) continue; ?><option value="<?= e($k) ?>" <?= get('tipo') === $k ? 'selected' : '' ?>><?= e($k . ' · ' . $t['nombre']) ?></option><?php endforeach; ?></select>
    <select name="ecf" class="input" aria-label="Estado DGII"><option value="">Cualquier estado DGII</option>
        <?php foreach (EcfServicio::ESTADOS as $k => [$t]): ?><option value="<?= e($k) ?>" <?= get('ecf') === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
    <button class="btn-secundario">Filtrar</button>
</form>

<div class="tarjeta overflow-hidden">
    <div class="flex justify-between border-b border-linea px-5 py-3 text-[15px]"><span class="text-texto-suave"><?= count($filas) ?> comprobantes<?= count($filas) >= 500 ? ' (mostrando los 500 más recientes)' : '' ?></span><strong class="tabular-nums" title="Facturas menos notas de crédito"><?= e(dinero($suma)) ?></strong></div>
    <?php if (!$filas): ?><p class="px-5 py-10 text-center text-texto-suave">No hay comprobantes en ese rango.</p><?php else: ?>
    <div class="overflow-x-auto"><table class="tabla tabla-resp">
        <thead><tr><th>NCF</th><th>Fecha</th><th>Cliente</th><th>Estado</th><th class="text-right">Total</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($filas as $f): ?>
            <tr class="<?= $f['estado'] === 'anulado' ? 'opacity-60' : '' ?>">
                <td data-principal><span class="font-mono"><?= e($f['ncf']) ?></span> <span class="chip-gris"><?= e($f['tipo']) ?></span>
                    <?php if ($f['ncf_origen']): ?><span class="block text-[13px] font-normal text-texto-suave">Modifica <?= e($f['ncf_origen']) ?></span><?php endif; ?></td>
                <td data-etiqueta="Fecha" class="whitespace-nowrap tabular-nums"><?= e(fecha($f['fecha'], true)) ?></td>
                <td data-etiqueta="Cliente"><?= e($f['razon_social'] ?? 'Consumidor final') ?><?= $f['rnc_cedula'] ? ' <span class="text-[13px] text-texto-suave">· ' . e($f['rnc_cedula']) . '</span>' : '' ?></td>
                <td data-etiqueta="Estado">
                    <?= $f['estado'] === 'anulado' ? '<span class="chip-rojo">Anulado</span>' : '' ?>
                    <?php if ($f['ecf_estado']): [$t, $cl] = EcfServicio::ESTADOS[$f['ecf_estado']]; ?><span class="<?= e($cl) ?>"><?= e($t) ?></span><?php elseif ($f['estado'] === 'emitido'): ?><span class="chip-verde">Emitido</span><?php endif; ?>
                    <?= $f['ecf_simulado'] ? '<span class="chip-ambar">Simulado</span>' : '' ?>
                </td>
                <td data-etiqueta="Total" class="text-right font-medium tabular-nums"><?= e(dinero($f['total'])) ?></td>
                <td data-etiqueta="" class="text-right whitespace-nowrap">
                    <?php if ($f['venta_id']): ?><a class="btn-secundario btn-sm" href="<?= e(url('/ventas/' . $f['venta_id'])) ?>"><?= e($f['venta']) ?></a><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php endif; ?>
</div>

<?php if (puede('fiscal.editar')): ?>
<details class="tarjeta mt-6 px-5 py-4">
    <summary class="cursor-pointer font-medium">Envío automático a la DGII (tarea programada)</summary>
    <div class="mt-3 space-y-3 text-[15px] text-texto-suave">
        <p>Si la DGII no responde al momento de cobrar, el comprobante queda <em>pendiente</em> y se reintenta solo. Para eso, crea en Hostinger un <strong>Cron Job</strong> cada 5 minutos con este comando:</p>
        <div class="flex gap-2">
            <code id="cmd-cron" class="block min-w-0 flex-1 overflow-x-auto whitespace-nowrap rounded-xl border border-linea bg-fondo px-3 py-3 text-[13px] text-texto"><?= e('curl -s "' . $urlCron . '" > /dev/null') ?></code>
            <button type="button" class="btn-secundario" data-copiar="cmd-cron"><?= icono('copiar', 'h-4 w-4') ?> Copiar</button>
        </div>
        <p class="text-[13px]">Esta dirección contiene una clave privada: no la compartas.</p>
    </div>
</details>
<?php endif; ?>
