<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Sedes',
    'descripcion' => 'Cada sesión, venta y usuario puede asociarse a una sede.',
    'volver' => ['texto' => 'Configuración', 'ruta' => '/configuracion'],
]) ?>
<div class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
    <div class="space-y-4">
        <?php foreach ($sedes as $s): ?>
            <form method="post" action="<?= e(url('/configuracion/sedes/' . $s['id'])) ?>" class="tarjeta tarjeta-cuerpo grid gap-4 sm:grid-cols-2">
                <?= csrf_campo() ?>
                <div>
                    <label class="etiqueta" for="n<?= (int) $s['id'] ?>">Nombre</label>
                    <input id="n<?= (int) $s['id'] ?>" name="nombre" class="input" value="<?= e($s['nombre']) ?>" required>
                </div>
                <div>
                    <label class="etiqueta" for="t<?= (int) $s['id'] ?>">Teléfono</label>
                    <input id="t<?= (int) $s['id'] ?>" name="telefono" class="input" value="<?= e($s['telefono']) ?>">
                </div>
                <div class="sm:col-span-2">
                    <label class="etiqueta" for="d<?= (int) $s['id'] ?>">Dirección</label>
                    <input id="d<?= (int) $s['id'] ?>" name="direccion" class="input" value="<?= e($s['direccion']) ?>">
                </div>
                <label class="flex items-center gap-3">
                    <input type="checkbox" name="activa" value="1" class="check" <?= (int) $s['activa'] === 1 ? 'checked' : '' ?>> Activa
                </label>
                <div class="sm:text-right"><button class="btn-secundario btn-sm">Guardar</button></div>
            </form>
        <?php endforeach; ?>
    </div>
    <form method="post" action="<?= e(url('/configuracion/sedes')) ?>" class="tarjeta tarjeta-cuerpo h-fit space-y-4">
        <?= csrf_campo() ?>
        <h2 class="font-semibold">Agregar sede</h2>
        <div>
            <label for="nueva_nombre" class="etiqueta">Nombre</label>
            <input id="nueva_nombre" name="nombre" class="input" placeholder="Ej. Punta Cana" required>
        </div>
        <div>
            <label for="nueva_direccion" class="etiqueta">Dirección</label>
            <input id="nueva_direccion" name="direccion" class="input">
        </div>
        <div>
            <label for="nueva_telefono" class="etiqueta">Teléfono</label>
            <input id="nueva_telefono" name="telefono" class="input">
        </div>
        <button class="btn-primario w-full"><?= icono('mas', 'h-5 w-5') ?> Agregar</button>
    </form>
</div>
