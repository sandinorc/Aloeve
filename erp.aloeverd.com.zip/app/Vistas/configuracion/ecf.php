<?php
use App\Modulos\Configuracion\EcfControlador as Ecf;

$servicios = require APP . '/ecf_servicios.php';
$estadoChip = [
    'sin_verificar' => ['chip-gris', 'Sin verificar'],
    'conectado' => ['chip-verde', 'Conectado'],
    'error' => ['chip-rojo', 'Error'],
];
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Facturación electrónica (e-CF)',
    'descripcion' => 'Conexión del ERP con la DGII para emitir e-CF. Cada ambiente guarda sus propias credenciales.',
    'volver' => ['texto' => 'Comprobantes fiscales', 'ruta' => '/configuracion/comprobantes'],
]) ?>

<div class="space-y-6">
    <!-- Estado general -->
    <form method="post" action="<?= e(url('/configuracion/ecf/modo')) ?>" class="tarjeta">
        <?= csrf_campo() ?>
        <div class="flex flex-wrap items-start justify-between gap-4 border-b border-linea p-5 sm:p-6">
            <div>
                <h2 class="flex items-center gap-2 text-lg font-semibold"><span class="text-primario"><?= icono('rayo', 'h-5 w-5') ?></span> Estado</h2>
                <p class="mt-1 text-texto-suave">
                    <?php if ($activo): ?>
                        Encendida con <?= e(Ecf::CONECTORES[$conectorActual]) ?> en <?= e(Ecf::AMBIENTES[$ambienteActual]['nombre']) ?>.
                    <?php else: ?>
                        Apagada. Las ventas usan NCF de papel (B01, B02, B04).
                    <?php endif; ?>
                </p>
            </div>
            <label class="flex min-h-[44px] cursor-pointer items-center gap-3 rounded-xl border border-linea px-4 has-[:checked]:border-emerald-300 has-[:checked]:bg-emerald-50">
                <input type="checkbox" name="activo" value="1" class="check" <?= $activo ? 'checked' : '' ?> <?= $editable ? '' : 'disabled' ?>>
                <span class="font-medium">Usar facturación electrónica</span>
            </label>
        </div>
        <div class="grid gap-6 p-5 sm:p-6 lg:grid-cols-2">
            <fieldset>
                <legend class="etiqueta">Conector</legend>
                <div class="space-y-2">
                    <?php foreach (Ecf::CONECTORES as $clave => $nombre): ?>
                        <label class="flex cursor-pointer items-start gap-3 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50">
                            <input type="radio" name="conector" value="<?= e($clave) ?>" class="mt-0.5 h-5 w-5 text-primario" <?= $conectorActual === $clave ? 'checked' : '' ?> <?= $editable ? '' : 'disabled' ?>>
                            <span>
                                <span class="block font-medium"><?= e($nombre) ?></span>
                                <span class="block text-[14px] text-texto-suave"><?= e([
                                    'simulador' => 'Genera y firma el XML pero no lo envía. Para probar la caja sin riesgo.',
                                    'dgii' => 'El ERP habla directo con la DGII usando el certificado digital de Aloeve.',
                                    'proveedor' => 'Para usar un proveedor de servicios electrónicos más adelante.',
                                ][$clave]) ?></span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </fieldset>
            <fieldset>
                <legend class="etiqueta">Ambiente</legend>
                <div class="space-y-2">
                    <?php foreach (Ecf::AMBIENTES as $clave => $a): ?>
                        <label class="flex cursor-pointer items-start gap-3 rounded-xl border border-linea p-3 has-[:checked]:border-primario has-[:checked]:bg-primario-50">
                            <input type="radio" name="ambiente" value="<?= e($clave) ?>" class="mt-0.5 h-5 w-5 text-primario" <?= $ambienteActual === $clave ? 'checked' : '' ?> <?= $editable ? '' : 'disabled' ?>>
                            <span>
                                <span class="block font-medium"><?= e($a['nombre']) ?> <span class="font-mono text-[13px] text-texto-suave"><?= e($a['dgii']) ?></span></span>
                                <span class="block text-[14px] text-texto-suave"><?= e($a['texto']) ?></span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <label class="mt-3 flex items-start gap-3 rounded-xl bg-amber-50 p-3 text-[14px] text-amber-900">
                    <input type="checkbox" name="confirmo_produccion" value="1" class="check mt-0.5" <?= $editable ? '' : 'disabled' ?>>
                    <span>Solo para Producción: confirmo que Aloeve completó la certificación con la DGII.</span>
                </label>
            </fieldset>
        </div>
        <?php if ($editable): ?>
            <div class="flex flex-wrap items-center gap-3 border-t border-linea p-5 sm:px-6">
                <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Guardar estado</button>
                <?php if (!in_array('E32', $secuenciasE, true)): ?>
                    <span class="text-[14px] text-texto-suave">Para encenderla necesitas una secuencia E32 activa en <a class="enlace" href="<?= e(url('/configuracion/comprobantes')) ?>">Comprobantes fiscales</a>.</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </form>

    <!-- Credenciales -->
    <section>
        <div class="mb-3 flex flex-wrap items-end justify-between gap-3">
            <div>
                <h2 class="text-xl font-semibold">Credenciales por ambiente</h2>
                <p class="text-texto-suave">Cada ambiente conserva su propio certificado o sus propias claves.</p>
            </div>
            <nav class="inline-flex rounded-xl border border-linea bg-white p-1" aria-label="Conector">
                <?php foreach (['dgii' => 'DGII directo', 'proveedor' => 'Proveedor'] as $c => $t): ?>
                    <a href="<?= e(url('/configuracion/ecf?conector=' . $c)) ?>" class="rounded-lg px-3 py-2 text-[14px] font-medium <?= $conector === $c ? 'bg-primario text-white' : 'text-texto-suave hover:text-texto' ?>"><?= e($t) ?></a>
                <?php endforeach; ?>
            </nav>
        </div>

        <?php if ($conector === 'simulador'): ?>
            <div class="tarjeta tarjeta-cuerpo text-texto-suave">
                El Simulador no necesita credenciales. Elige <a class="enlace" href="<?= e(url('/configuracion/ecf?conector=dgii')) ?>">DGII directo</a> para cargar el certificado digital.
            </div>
        <?php else: ?>
            <?php if ($conector === 'dgii' && $rnc === ''): ?>
                <div class="mb-4 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-[15px] text-amber-900">
                    <?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?>
                    <span>Falta el RNC del negocio. Complétalo en <a class="font-medium underline" href="<?= e(url('/configuracion/negocio')) ?>">Datos del negocio</a>; va en cada e-CF.</span>
                </div>
            <?php endif; ?>
            <div class="grid gap-4 lg:grid-cols-3">
                <?php foreach (Ecf::AMBIENTES as $amb => $a):
                    $c = $conexiones[$amb] ?? null;
                    [$chip, $chipTexto] = $estadoChip[$c['estado'] ?? 'sin_verificar'];
                    $esProd = $amb === 'ecf';
                ?>
                <article class="tarjeta flex flex-col p-5 <?= $esProd ? 'border-amber-300 ring-1 ring-amber-200' : '' ?>">
                    <div class="flex items-start justify-between gap-3">
                        <div>
                            <h3 class="text-lg font-semibold"><?= e($a['nombre']) ?></h3>
                            <p class="font-mono text-[13px] text-texto-suave"><?= e($a['dgii']) ?></p>
                        </div>
                        <span class="<?= $chip ?>" data-estado-chip><?= e($chipTexto) ?></span>
                    </div>
                    <p class="mt-3 break-all rounded-lg bg-fondo px-3 py-2 font-mono text-[12px] text-texto-suave">
                        <?= e($conector === 'dgii' ? str_replace('{ambiente}', $amb, dirname($servicios['recepcion'], 3)) : 'https://… (URL del proveedor)') ?>
                    </p>
                    <?php if ($esProd): ?>
                        <p class="mt-3 border-l-4 border-amber-400 bg-amber-50 px-3 py-2 text-[14px] text-amber-900">Producción emite documentos reales. Actívalo solo después de completar la certificación.</p>
                    <?php endif; ?>
                    <?php if ($c && $c['verificado_en']): ?>
                        <p class="mt-3 text-[13px] text-texto-suave">Última prueba: <?= e(fecha($c['verificado_en'], true)) ?></p>
                    <?php endif; ?>
                    <?php if ($c && $c['estado'] === 'error' && $c['mensaje']): ?>
                        <p class="mt-2 rounded-lg bg-red-50 px-3 py-2 text-[13px] text-red-800"><?= e($c['mensaje']) ?></p>
                    <?php endif; ?>

                    <form method="post" action="<?= e(url('/configuracion/ecf/' . $amb . '/credenciales')) ?>" enctype="multipart/form-data" class="mt-4 flex flex-1 flex-col gap-4">
                        <?= csrf_campo() ?>
                        <input type="hidden" name="conector" value="<?= e($conector) ?>">
                        <?php if ($conector === 'dgii'): ?>
                            <?php if ($c && $c['certificado_ruta']): ?>
                                <div class="rounded-xl border border-linea p-3 text-[14px]">
                                    <p class="font-medium"><?= icono('llave', 'mr-1 inline h-4 w-4 text-primario') ?> <?= e($c['certificado_titular']) ?></p>
                                    <p class="text-texto-suave">Vence el <?= e(fecha($c['certificado_vence'])) ?></p>
                                </div>
                            <?php endif; ?>
                            <div>
                                <label class="etiqueta" for="cert-<?= e($amb) ?>"><?= $c && $c['certificado_ruta'] ? 'Reemplazar certificado' : 'Certificado digital (.p12)' ?></label>
                                <input id="cert-<?= e($amb) ?>" name="certificado" type="file" accept=".p12,.pfx" class="block w-full text-[14px] file:mr-3 file:rounded-lg file:border-0 file:bg-primario-50 file:px-3 file:py-2 file:font-medium file:text-primario-700" <?= $editable ? '' : 'disabled' ?>>
                            </div>
                            <div>
                                <label class="etiqueta" for="clave-<?= e($amb) ?>">Contraseña del certificado</label>
                                <input id="clave-<?= e($amb) ?>" name="certificado_clave" type="password" class="input" autocomplete="off"
                                       placeholder="<?= $c && $c['certificado_clave_cifrada'] ? 'Guardada; deja vacío para conservarla' : 'Contraseña del .p12' ?>" <?= $editable ? '' : 'disabled' ?>>
                            </div>
                        <?php else: ?>
                            <div>
                                <label class="etiqueta" for="correo-<?= e($amb) ?>">Correo</label>
                                <input id="correo-<?= e($amb) ?>" name="correo" type="email" class="input" value="<?= e($c['correo'] ?? '') ?>" <?= $editable ? '' : 'disabled' ?>>
                            </div>
                            <div>
                                <label class="etiqueta" for="pc-<?= e($amb) ?>">Contraseña</label>
                                <input id="pc-<?= e($amb) ?>" name="clave" type="password" class="input" autocomplete="off"
                                       placeholder="<?= !empty($c['clave_cifrada']) ? 'Guardada; deja vacío para conservarla' : 'Contraseña del ambiente' ?>" <?= $editable ? '' : 'disabled' ?>>
                            </div>
                            <div>
                                <label class="etiqueta" for="ak-<?= e($amb) ?>">API Key</label>
                                <input id="ak-<?= e($amb) ?>" name="api_key" type="password" class="input" autocomplete="off"
                                       placeholder="<?= !empty($c['api_key_final']) ? 'Guardada; termina en ' . e($c['api_key_final']) : 'API Key del ambiente' ?>" <?= $editable ? '' : 'disabled' ?>>
                            </div>
                        <?php endif; ?>
                        <?php if ($editable): ?>
                            <div class="mt-auto space-y-2 pt-2">
                                <button class="btn w-full bg-menu text-white hover:bg-menu-claro">Guardar credenciales</button>
                                <?php if ($c): ?>
                                    <button type="button" class="btn-secundario w-full" data-probar="<?= e(url('/configuracion/ecf/' . $amb . '/probar')) ?>" data-conector="<?= e($conector) ?>">
                                        <?= icono('enchufe', 'h-4 w-4') ?> Probar conexión
                                    </button>
                                <?php endif; ?>
                                <p class="min-h-[1.25rem] text-[13px]" data-probar-resultado aria-live="polite"></p>
                            </div>
                        <?php endif; ?>
                    </form>
                </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <details class="tarjeta group p-5">
        <summary class="flex cursor-pointer list-none items-center gap-2 font-medium">
            <?= icono('derecha', 'h-4 w-4 transition-transform group-open:rotate-90') ?> ¿Cómo llego a Producción?
        </summary>
        <ol class="mt-3 list-decimal space-y-2 pl-6 text-[15px] text-texto-suave">
            <li>Obtén el certificado digital para procedimiento tributario (persona física autorizada por Aloeve) con una entidad certificadora autorizada por INDOTEL.</li>
            <li>Solicita en la Oficina Virtual de la DGII ser emisor electrónico y registra este software.</li>
            <li>Sube el certificado en <strong>Prueba</strong> y presiona Probar conexión hasta que diga Conectado.</li>
            <li>Haz el set de pruebas en <strong>Certificación</strong> (CerteCF) con el mismo certificado.</li>
            <li>Cuando la DGII apruebe, carga las secuencias E31, E32 y E34 de producción, elige <strong>Producción</strong> y enciende la facturación electrónica.</li>
        </ol>
    </details>
</div>
