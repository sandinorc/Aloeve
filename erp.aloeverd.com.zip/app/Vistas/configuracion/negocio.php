<?php $v = static fn(string $c, string $d = '') => viejo(str_replace('.', '_', $c), $ajustes[$c] ?? $d); ?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Datos del negocio',
    'descripcion' => 'Estos datos salen en cada recibo y comprobante fiscal.',
    'volver' => ['texto' => 'Configuración', 'ruta' => '/configuracion'],
]) ?>
<form method="post" class="tarjeta tarjeta-cuerpo max-w-3xl space-y-5">
    <?= csrf_campo() ?>
    <div class="grid gap-4 sm:grid-cols-2">
        <div>
            <label for="negocio_razon_social" class="etiqueta">Razón social</label>
            <input id="negocio_razon_social" name="negocio_razon_social" class="input" value="<?= e($v('negocio.razon_social')) ?>" placeholder="Como aparece en el RNC">
        </div>
        <div>
            <label for="negocio_nombre_comercial" class="etiqueta">Nombre comercial</label>
            <input id="negocio_nombre_comercial" name="negocio_nombre_comercial" class="input" value="<?= e($v('negocio.nombre_comercial')) ?>" required>
        </div>
        <div>
            <label for="negocio_rnc" class="etiqueta">RNC</label>
            <input id="negocio_rnc" name="negocio_rnc" class="input font-mono" inputmode="numeric" value="<?= e($v('negocio.rnc')) ?>" placeholder="9 dígitos">
            <p class="ayuda">Se valida el dígito verificador.</p>
        </div>
        <div>
            <label for="fiscal_itbis" class="etiqueta">Tasa de ITBIS (%)</label>
            <input id="fiscal_itbis" name="fiscal_itbis" type="number" step="0.01" min="0" max="30" class="input" value="<?= e($v('fiscal.itbis', '18')) ?>">
        </div>
        <div class="sm:col-span-2">
            <label for="negocio_direccion" class="etiqueta">Dirección fiscal</label>
            <input id="negocio_direccion" name="negocio_direccion" class="input" value="<?= e($v('negocio.direccion')) ?>">
        </div>
        <div>
            <label for="negocio_telefono" class="etiqueta">Teléfono</label>
            <input id="negocio_telefono" name="negocio_telefono" class="input" inputmode="tel" value="<?= e($v('negocio.telefono')) ?>">
        </div>
        <div>
            <label for="negocio_correo" class="etiqueta">Correo</label>
            <input id="negocio_correo" name="negocio_correo" type="email" class="input" value="<?= e($v('negocio.correo')) ?>">
        </div>
        <div class="sm:col-span-2">
            <label for="negocio_pie_recibo" class="etiqueta">Texto al pie del recibo</label>
            <input id="negocio_pie_recibo" name="negocio_pie_recibo" class="input" value="<?= e($v('negocio.pie_recibo')) ?>" maxlength="160">
        </div>
    </div>
    <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Guardar</button>
</form>
