<?php
$tarjetas = [];
if (puede('configuracion.editar')) {
    $tarjetas[] = ['/configuracion/negocio', 'edificio', 'Datos del negocio', 'Razón social, RNC, dirección y tasa de ITBIS que salen en los comprobantes.',
        ($ajustes['negocio.rnc'] ?? '') !== '' ? ['chip-verde', 'Completo'] : ['chip-ambar', 'Falta RNC']];
    $tarjetas[] = ['/configuracion/sedes', 'pin', 'Sedes', 'Plaza La Nube, Punta Cana y las que se agreguen.', ['chip-morado', $sedes . ' activa' . ($sedes === 1 ? '' : 's')]];
}
if (puede('fiscal.ver')) {
    $tarjetas[] = ['/configuracion/comprobantes', 'archivo', 'Comprobantes fiscales', 'Secuencias de NCF y e-NCF autorizadas por la DGII.',
        $secuencias > 0 ? ['chip-verde', $secuencias . ' activa' . ($secuencias === 1 ? '' : 's')] : ['chip-ambar', 'Sin secuencias']];
    $tarjetas[] = ['/configuracion/ecf', 'rayo', 'Facturación electrónica (e-CF)', 'Conexión con la DGII: certificado digital y ambientes de prueba, certificación y producción.',
        ($ajustes['ecf.activo'] ?? '0') === '1' ? ['chip-verde', 'Encendida'] : ['chip-gris', 'Apagada']];
}
if (in_array('*', \App\Core\Auth::permisos(), true)) {
    $tarjetas[] = ['/setup/actualizar', 'refrescar', 'Actualizar el sistema', 'Aplica los cambios de base de datos después de subir una fase nueva.', ['chip-gris', VERSION_ERP]];
}
?>
<?= \App\Core\View::parcial('parciales/encabezado', ['titulo' => 'Configuración', 'descripcion' => 'Datos del negocio, sedes y facturación.']) ?>
<div class="grid gap-4 md:grid-cols-2">
    <?php foreach ($tarjetas as [$ruta, $ico, $nombre, $texto, [$chip, $chipTexto]]): ?>
        <a href="<?= e(url($ruta)) ?>" class="tarjeta flex gap-4 p-5 transition hover:border-primario-300">
            <span class="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primario-50 text-primario-700"><?= icono($ico) ?></span>
            <span class="min-w-0 flex-1">
                <span class="flex flex-wrap items-center justify-between gap-2">
                    <span class="font-semibold"><?= e($nombre) ?></span>
                    <span class="<?= $chip ?>"><?= e($chipTexto) ?></span>
                </span>
                <span class="mt-1 block text-[15px] text-texto-suave"><?= e($texto) ?></span>
            </span>
        </a>
    <?php endforeach; ?>
</div>
