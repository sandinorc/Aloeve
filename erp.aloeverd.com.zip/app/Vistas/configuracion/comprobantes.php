<?php
use App\Core\Ncf;

$conectores = ['simulador' => 'Simulador (no emite ante la DGII)', 'dgii' => 'DGII directo', 'proveedor' => 'Proveedor autorizado'];
$ambientes = ['testecf' => 'Prueba (TesteCF)', 'certecf' => 'Certificación (CerteCF)', 'ecf' => 'Producción (eCF)'];
$barra = ['verde' => 'bg-emerald-500', 'ambar' => 'bg-amber-500', 'rojo' => 'bg-red-500'];
$botonCargar = $editable
    ? '<button type="button" class="btn-primario" data-dialogo-abrir="dlg-cargar">' . icono('mas', 'h-5 w-5') . ' Cargar secuencia</button>'
    : '';
$digitos = [];
foreach (Ncf::TIPOS as $t => $_) { $digitos[$t] = Ncf::digitos($t); }
?>
<?= \App\Core\View::parcial('parciales/encabezado', [
    'titulo' => 'Comprobantes fiscales',
    'descripcion' => 'Las secuencias de NCF y e-NCF autorizadas por la DGII.',
    'volver' => ['texto' => 'Configuración', 'ruta' => '/configuracion'],
    'acciones' => $botonCargar,
]) ?>

<div class="mx-auto max-w-4xl space-y-4">

    <!-- Facturación electrónica -->
    <section class="tarjeta p-5">
        <h2 class="flex items-center gap-2 text-lg font-semibold">
            <span class="text-primario"><?= icono('rayo', 'h-5 w-5') ?></span> Facturación electrónica (e-CF)
        </h2>
        <?php if ($ecf['activo']): ?>
            <p class="mt-1">Encendida. Las ventas nuevas usan e-NCF (E31, E32, E34) y se envían a la DGII.</p>
        <?php else: ?>
            <p class="mt-1">Apagada. Aloeve factura con sus comprobantes de papel (NCF), como siempre.</p>
        <?php endif; ?>
        <p class="mt-1 text-[14px] text-texto-suave">
            Por: <?= e($conectores[$ecf['conector']] ?? $ecf['conector']) ?> · Ambiente: <?= e($ambientes[$ecf['ambiente']] ?? $ecf['ambiente']) ?> ·
            <a href="<?= e(url('/configuracion/ecf')) ?>" class="enlace">cambiar</a>
        </p>
    </section>

    <?php foreach ($alertas as $a): ?>
        <div class="flex items-start gap-3 rounded-xl border px-4 py-3 text-[15px] <?= $a['nivel'] === 'rojo' ? 'border-red-200 bg-red-50 text-red-800' : 'border-amber-200 bg-amber-50 text-amber-900' ?>">
            <?= icono('alerta', 'mt-0.5 h-5 w-5 shrink-0') ?><span><?= e($a['texto']) ?></span>
        </div>
    <?php endforeach; ?>

    <!-- Secuencias activas -->
    <?php if (!$activas): ?>
        <section class="tarjeta px-5 py-10 text-center">
            <div class="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full bg-primario-50 text-primario-700"><?= icono('archivo') ?></div>
            <h2 class="text-lg font-semibold">Todavía no hay secuencias</h2>
            <p class="mx-auto mt-1 max-w-md text-texto-suave">Carga como mínimo una secuencia B02 (consumo) y una B01 (crédito fiscal) con el rango que te autorizó la DGII.</p>
            <?php if ($editable): ?>
                <button type="button" class="btn-primario mt-5" data-dialogo-abrir="dlg-cargar"><?= icono('mas', 'h-5 w-5') ?> Cargar secuencia</button>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php foreach ($activas as $s): ?>
        <section class="tarjeta p-5">
            <div class="flex items-start justify-between gap-4">
                <div class="min-w-0">
                    <h3 class="flex flex-wrap items-center gap-2 text-lg font-semibold">
                        <?= e($s['nombre']) ?>
                        <span class="rounded-md bg-slate-100 px-1.5 py-0.5 font-mono text-[12px] font-medium text-slate-600"><?= e($s['tipo']) ?></span>
                        <?php if ($s['clase'] === 'electronico'): ?><span class="chip-morado">e-CF</span><?php endif; ?>
                    </h3>
                    <p class="mt-0.5 break-words text-[14px] text-texto-suave">
                        Del <span class="font-mono"><?= e($s['primero']) ?></span> al <span class="font-mono"><?= e($s['ultimo']) ?></span>
                        <?php if ($s['vence_en']): ?> · <span class="<?= $s['vencida'] || ($s['dias'] !== null && $s['dias'] < 30) ? 'font-medium text-red-700' : '' ?>"><?= $s['vencida'] ? 'venció' : 'vence' ?> el <?= e(fecha($s['vence_en'])) ?></span><?php endif; ?>
                    </p>
                </div>
                <div class="shrink-0 text-right">
                    <div class="font-display text-[34px] leading-none tabular-nums <?= $s['disponibles'] === 0 ? 'text-red-700' : '' ?>"><?= number_format($s['disponibles']) ?></div>
                    <div class="mt-1 text-[11px] font-semibold uppercase tracking-wider text-texto-suave">Disponibles</div>
                </div>
            </div>
            <div class="barra mt-4" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?= (int) round($s['pct']) ?>" aria-label="Uso de la secuencia">
                <span class="<?= $barra[$s['nivel']] ?>" style="width: <?= max(0, min(100, round($s['pct'], 1))) ?>%"></span>
            </div>
            <div class="mt-3 flex flex-wrap items-center justify-between gap-2 text-[14px] text-texto-suave">
                <span>
                    Usados <?= number_format($s['usados']) ?> de <?= number_format($s['total']) ?> ·
                    <?php if ($s['siguiente']): ?>el próximo será <strong class="font-mono font-semibold text-texto"><?= e($s['siguiente']) ?></strong>
                    <?php else: ?><strong class="text-red-700">agotada</strong><?php endif; ?>
                </span>
                <?php if ($editable): ?>
                    <button type="button" class="enlace" data-dialogo-abrir="dlg-editar-<?= (int) $s['id'] ?>">Editar</button>
                <?php endif; ?>
            </div>
        </section>

        <?php if ($editable): ?>
        <dialog id="dlg-editar-<?= (int) $s['id'] ?>" class="dialogo" aria-labelledby="t-editar-<?= (int) $s['id'] ?>">
            <form method="post" action="<?= e(url('/configuracion/comprobantes/secuencias/' . $s['id'])) ?>" class="space-y-4" data-secuencia-form>
                <?= csrf_campo() ?>
                <div class="flex items-start justify-between gap-4">
                    <h2 id="t-editar-<?= (int) $s['id'] ?>" class="text-xl font-semibold">Editar <?= e($s['tipo']) ?></h2>
                    <button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button>
                </div>
                <input type="hidden" name="tipo" value="<?= e($s['tipo']) ?>">
                <input type="hidden" name="desde" value="<?= (int) $s['desde'] ?>">
                <p class="text-[14px] text-texto-suave">Empieza en <span class="font-mono"><?= e($s['primero']) ?></span>. Ya se usaron <?= number_format($s['usados']) ?>; el rango no puede quedar por debajo de eso.</p>
                <div>
                    <label class="etiqueta" for="cant-<?= (int) $s['id'] ?>">Cantidad total autorizada</label>
                    <div class="flex items-center gap-3">
                        <input id="cant-<?= (int) $s['id'] ?>" name="cantidad" type="number" min="<?= max(1, $s['usados']) ?>" class="input w-36 text-center" value="<?= (int) $s['total'] ?>" required>
                        <span class="text-texto-suave">comprobantes</span>
                    </div>
                </div>
                <div>
                    <label class="etiqueta" for="vence-<?= (int) $s['id'] ?>">Vence el</label>
                    <input id="vence-<?= (int) $s['id'] ?>" name="vence_en" type="date" class="input" value="<?= e($s['vence_en']) ?>" required>
                </div>
                <label class="flex items-center gap-3">
                    <input type="checkbox" name="activa" value="1" class="check" checked> Secuencia activa
                </label>
                <p class="rounded-xl bg-fondo px-3 py-2 text-[14px]" data-vista-previa></p>
                <div class="grid grid-cols-[1fr_2fr] gap-3 pt-2">
                    <button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button>
                    <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Guardar</button>
                </div>
            </form>
        </dialog>
        <?php endif; ?>
    <?php endforeach; ?>

    <!-- Ayuda -->
    <details class="tarjeta group p-5">
        <summary class="flex cursor-pointer list-none items-center gap-2 font-medium">
            <?= icono('derecha', 'h-4 w-4 transition-transform group-open:rotate-90') ?> ¿De dónde saco estos números?
        </summary>
        <div class="mt-3 space-y-2 text-[15px] text-texto-suave">
            <p>Los rangos los autoriza la DGII. Se piden en la <strong>Oficina Virtual</strong> (dgii.gov.do) en <em>Solicitud de Autorización de Emisión de Comprobantes Fiscales</em>.</p>
            <p>La respuesta indica el tipo (por ejemplo B02), el número inicial, el final y la fecha de vencimiento. Esos son los datos que se cargan aquí.</p>
            <p>Para facturación electrónica, los e-NCF (E31, E32, E34) se solicitan igual en la Oficina Virtual una vez que la DGII autoriza a Aloeve como emisor electrónico.</p>
            <p>Pedirle una secuencia nueva a la DGII toma unos días: avisa con margen. El ERP avisa cuando una secuencia pasa del 80% o le faltan menos de 60 días para vencer.</p>
        </div>
    </details>

    <?php if ($editable): ?>
    <details class="tarjeta group p-5">
        <summary class="flex cursor-pointer list-none items-center gap-2 font-medium">
            <?= icono('derecha', 'h-4 w-4 transition-transform group-open:rotate-90') ?> Tipos de comprobante adicionales
        </summary>
        <form method="post" action="<?= e(url('/configuracion/comprobantes/tipos')) ?>" class="mt-3 space-y-3">
            <?= csrf_campo() ?>
            <p class="text-[15px] text-texto-suave">B01, B02, B04, E31, E32 y E34 están siempre disponibles. Activa otros solo si Aloeve los necesita.</p>
            <div class="grid gap-1 sm:grid-cols-2">
                <?php foreach (Ncf::TIPOS as $t => $info): if ($info['basico']) { continue; } ?>
                    <label class="flex min-h-[40px] items-center gap-3">
                        <input type="checkbox" name="tipos[]" value="<?= e($t) ?>" class="check" <?= in_array($t, $extra, true) ? 'checked' : '' ?>>
                        <span><span class="font-mono text-[14px]"><?= e($t) ?></span> · <?= e($info['nombre']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <button class="btn-secundario btn-sm">Guardar tipos</button>
        </form>
    </details>
    <?php endif; ?>

    <?php if ($historial): ?>
    <details class="tarjeta group p-5">
        <summary class="flex cursor-pointer list-none items-center gap-2 font-medium">
            <?= icono('derecha', 'h-4 w-4 transition-transform group-open:rotate-90') ?> Secuencias inactivas (<?= count($historial) ?>)
        </summary>
        <ul class="mt-3 divide-y divide-linea text-[15px]">
            <?php foreach ($historial as $h): ?>
                <li class="flex flex-wrap justify-between gap-2 py-2">
                    <span><span class="font-mono"><?= e($h['primero']) ?></span> → <span class="font-mono"><?= e($h['ultimo']) ?></span></span>
                    <span class="text-texto-suave">Usados <?= number_format($h['usados']) ?> de <?= number_format($h['total']) ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </details>
    <?php endif; ?>
</div>

<?php if ($editable): ?>
<dialog id="dlg-cargar" class="dialogo" aria-labelledby="t-cargar">
    <form method="post" action="<?= e(url('/configuracion/comprobantes/secuencias')) ?>" class="space-y-4" data-secuencia-form
          data-digitos='<?= e(json_encode($digitos)) ?>' data-sugeridos='<?= e(json_encode($sugeridos)) ?>'>
        <?= csrf_campo() ?>
        <div class="flex items-start justify-between gap-4">
            <h2 id="t-cargar" class="text-xl font-semibold">Cargar secuencia</h2>
            <button type="button" class="grid h-9 w-9 place-items-center rounded-lg text-texto-suave hover:bg-fondo" data-dialogo-cerrar aria-label="Cerrar"><?= icono('cerrar') ?></button>
        </div>
        <div>
            <label for="sec-tipo" class="etiqueta">Tipo de comprobante <span class="text-red-600">*</span></label>
            <select id="sec-tipo" name="tipo" class="input" required data-tipo>
                <?php foreach ($tipos as $t): ?>
                    <option value="<?= e($t) ?>"><?= e(Ncf::nombre($t)) ?> (<?= e($t) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
            <div>
                <label for="sec-desde" class="etiqueta">Empieza en el número</label>
                <input id="sec-desde" name="desde" type="number" min="1" class="input text-center" value="<?= (int) ($sugeridos[$tipos[0]] ?? 1) ?>" required data-desde>
            </div>
            <div>
                <label for="sec-cantidad" class="etiqueta">Cantidad</label>
                <div class="flex items-center gap-2">
                    <input id="sec-cantidad" name="cantidad" type="number" min="1" class="input text-center" value="50" required data-cantidad>
                </div>
            </div>
        </div>
        <div>
            <label for="sec-vence" class="etiqueta">Vence el <span class="text-red-600">*</span></label>
            <input id="sec-vence" name="vence_en" type="date" class="input" min="<?= e(date('Y-m-d')) ?>" required>
        </div>
        <p class="rounded-xl bg-fondo px-3 py-2 text-[14px]" data-vista-previa></p>
        <p class="text-[13px] text-texto-suave">Pedirle una secuencia nueva a la DGII toma unos días: avisa con margen.</p>
        <div class="grid grid-cols-[1fr_2fr] gap-3 border-t border-linea pt-4">
            <button type="button" class="btn-secundario" data-dialogo-cerrar>Cancelar</button>
            <button class="btn-primario"><?= icono('check', 'h-5 w-5') ?> Guardar</button>
        </div>
    </form>
</dialog>
<?php endif; ?>
