<?php
declare(strict_types=1);

namespace App\Modulos\Agenda;

use App\Core\Auth;
use App\Core\DB;
use App\Modulos\Inventario\InventarioServicio;
use RuntimeException;

final class AgendaServicio
{
    public const LINEAS = [
        'privados' => 'Privados',
        'corporativo' => 'Corporativo',
        'experiencias' => 'Experiencias',
        'formacion' => 'Formación',
        'turismo' => 'Turismo',
    ];

    public const ESTADOS = [
        'programada' => ['Programada', 'chip-gris'],
        'confirmada' => ['Confirmada', 'chip-morado'],
        'realizada' => ['Realizada', 'chip-ambar'],
        'cerrada' => ['Cerrada', 'chip-verde'],
        'cancelada' => ['Cancelada', 'chip-rojo'],
    ];

    public const ESTADOS_RESERVA = [
        'pendiente' => ['Pendiente', 'chip-ambar'],
        'confirmada' => ['Confirmada', 'chip-verde'],
        'cancelada' => ['Cancelada', 'chip-rojo'],
        'no_show' => ['No vino', 'chip-gris'],
    ];

    public const METODOS = [
        'efectivo' => 'Efectivo',
        'tarjeta' => 'Tarjeta',
        'transferencia' => 'Transferencia',
        'enlace' => 'Enlace de pago',
        'otro' => 'Otro',
    ];

    /** Restricción de sesiones según el rol: agenda completa, solo hoy, o solo las del facilitador. */
    public static function alcance(string $alias = 's'): array
    {
        if (Auth::puede('agenda.ver')) {
            return ['1 = 1', []];
        }
        if (Auth::puede('agenda.propias')) {
            $fid = (int) DB::valor('SELECT id FROM facilitadores WHERE usuario_id = ?', [Auth::id()]);
            return ["$alias.facilitador_id = ?", [$fid ?: -1]];
        }
        if (Auth::puede('agenda.dia')) {
            return ["$alias.fecha = ?", [date('Y-m-d')]];
        }
        return ['1 = 0', []];
    }

    public static function puedeVer(array $sesion): bool
    {
        [$cond, $params] = self::alcance('s');
        return (bool) DB::valor("SELECT 1 FROM sesiones s WHERE s.id = ? AND $cond", [$sesion['id'], ...$params]);
    }

    /** Puede marcar asistencia y cobrar: editores, caja del día, o el facilitador de la sesión. */
    public static function puedeOperar(array $sesion): bool
    {
        return Auth::puede('agenda.editar') || (self::puedeVer($sesion) && (Auth::puede('agenda.dia') || Auth::puede('agenda.propias')));
    }

    public static function minutos(string $hora): int
    {
        [$h, $m] = array_map('intval', explode(':', $hora) + [0, 0]);
        return $h * 60 + $m;
    }

    /** Sesiones del mismo facilitador que se cruzan en horario. */
    public static function choques(?int $facilitadorId, string $fecha, string $inicio, string $fin, int $excluir = 0): array
    {
        if (!$facilitadorId) {
            return [];
        }
        return DB::todos(
            "SELECT s.id, s.hora_inicio, s.hora_fin, sv.nombre AS servicio FROM sesiones s JOIN servicios sv ON sv.id = s.servicio_id
              WHERE s.facilitador_id = ? AND s.fecha = ? AND s.id <> ? AND s.estado <> 'cancelada'
                AND s.hora_inicio < ? AND s.hora_fin > ?",
            [$facilitadorId, $fecha, $excluir, $fin, $inicio]
        );
    }

    /** Cupos ocupados (personas en reservas no canceladas). */
    public static function ocupados(int $sesionId, int $excluirReserva = 0): int
    {
        return (int) DB::valor(
            "SELECT COALESCE(SUM(personas),0) FROM reservas WHERE sesion_id = ? AND estado IN ('pendiente','confirmada') AND id <> ?",
            [$sesionId, $excluirReserva]
        );
    }

    /** Sesiones pasadas que nadie cerró. */
    public static function porCerrar(): array
    {
        [$cond, $params] = self::alcance('s');
        return DB::todos(
            "SELECT s.*, sv.nombre AS servicio, f.nombre AS facilitador FROM sesiones s
               JOIN servicios sv ON sv.id = s.servicio_id LEFT JOIN facilitadores f ON f.id = s.facilitador_id
              WHERE s.estado IN ('programada','confirmada','realizada') AND (s.fecha < CURDATE() OR (s.fecha = CURDATE() AND s.hora_fin < CURTIME()))
                AND $cond
              ORDER BY s.fecha, s.hora_inicio LIMIT 50",
            $params
        );
    }

    /**
     * Registra un pago de una reserva: actualiza lo pagado y crea el ingreso.
     * Debe ir dentro de DB::tx().
     */
    public static function registrarPago(array $reserva, float $monto, string $metodo, ?string $referencia = null): int
    {
        if ($monto <= 0) {
            throw new RuntimeException('El monto debe ser mayor que cero.');
        }
        if (!isset(self::METODOS[$metodo])) {
            throw new RuntimeException('Elige el método de pago.');
        }
        $s = DB::uno(
            'SELECT s.*, sv.nombre AS servicio, sv.linea_negocio FROM sesiones s JOIN servicios sv ON sv.id = s.servicio_id WHERE s.id = ?',
            [$reserva['sesion_id']]
        );
        $cliente = (string) DB::valor('SELECT nombre FROM clientes WHERE id = ?', [$reserva['cliente_id']]);
        DB::q('UPDATE reservas SET pagado = pagado + ? WHERE id = ?', [$monto, $reserva['id']]);
        return DB::insertar('ingresos', [
            'fecha' => date('Y-m-d'),
            'concepto' => $s['servicio'] . ' ' . date('d/m', strtotime($s['fecha'])) . ' · ' . $cliente,
            'linea_negocio' => $s['linea_negocio'],
            'monto' => round($monto, 2),
            'metodo' => $metodo,
            'origen_tipo' => 'reserva',
            'origen_id' => $reserva['id'],
            'cliente_id' => $reserva['cliente_id'],
            'sede_id' => $s['sede_id'],
            'referencia' => $referencia,
            'usuario_id' => Auth::id(),
        ]);
    }

    /** Estado de pago legible de una reserva. */
    public static function estadoPago(array $r): array
    {
        if ((int) $r['cortesia'] === 1) {
            return ['Cortesía', 'chip-morado'];
        }
        $monto = (float) $r['monto'];
        $pagado = (float) $r['pagado'];
        return match (true) {
            $monto <= 0 && $pagado <= 0 => ['Sin costo', 'chip-gris'],
            $pagado >= $monto - 0.009 => ['Pagado', 'chip-verde'],
            $pagado > 0 => ['Abono ' . dinero($pagado), 'chip-ambar'],
            default => ['Pendiente', 'chip-rojo'],
        };
    }

    /**
     * Cierra una sesión: asistencia, consumo de materiales e inventario.
     * @param array<int, bool> $asistencia reserva_id => asistió
     * @param array<int, float> $materiales material_id => cantidad usada
     */
    public static function cerrar(array $sesion, array $asistencia, array $materiales, string $notas): void
    {
        DB::tx(function () use ($sesion, $asistencia, $materiales, $notas) {
            foreach (DB::todos("SELECT id FROM reservas WHERE sesion_id = ? AND estado IN ('pendiente','confirmada','no_show')", [$sesion['id']]) as $r) {
                $vino = !empty($asistencia[$r['id']]);
                DB::actualizar('reservas', [
                    'asistio' => $vino ? 1 : 0,
                    'estado' => $vino ? 'confirmada' : 'no_show',
                ], 'id = ?', [$r['id']]);
            }
            foreach ($materiales as $materialId => $cantidad) {
                if ($cantidad <= 0) {
                    continue;
                }
                $mov = InventarioServicio::mover('material', (int) $materialId, 'consumo_sesion', -$cantidad, [
                    'sesion_id' => $sesion['id'],
                    'motivo' => 'Sesión del ' . date('d/m/Y', strtotime($sesion['fecha'])),
                ], true);
                DB::insertar('sesion_materiales', [
                    'sesion_id' => $sesion['id'],
                    'material_id' => (int) $materialId,
                    'cantidad' => $cantidad,
                    'movimiento_id' => $mov['id'],
                ]);
            }
            DB::actualizar('sesiones', [
                'estado' => 'cerrada',
                'notas_cierre' => $notas ?: null,
                'cerrada_por' => Auth::id(),
                'cerrada_en' => date('Y-m-d H:i:s'),
            ], 'id = ?', [$sesion['id']]);
        });
    }
}
