<?php
declare(strict_types=1);

namespace App\Modulos\Agenda;

use App\Core\Actividad;
use App\Core\App;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\View;
use App\Modulos\Agenda\AgendaServicio as A;
use App\Modulos\Clientes\ClientesServicio;
use App\Modulos\Inventario\InventarioServicio as I;
use Throwable;

final class AgendaControlador
{
    private const SQL_SESION = "SELECT s.*, sv.nombre AS servicio, sv.color, sv.linea_negocio, f.nombre AS facilitador, sd.nombre AS sede,
            (SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.estado IN ('pendiente','confirmada')) AS ocupados,
            (SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.asistio = 1) AS asistentes
        FROM sesiones s
        JOIN servicios sv ON sv.id = s.servicio_id
        LEFT JOIN facilitadores f ON f.id = s.facilitador_id
        LEFT JOIN sedes sd ON sd.id = s.sede_id";

    private function sesion(int $id): array
    {
        $s = DB::uno(self::SQL_SESION . ' WHERE s.id = ?', [$id]);
        if (!$s || !A::puedeVer($s)) {
            App::error(404);
        }
        return $s;
    }

    private function fechaValida(string $f): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $f);
        return $d !== false && $d->format('Y-m-d') === $f;
    }

    /* ======================= Calendario ======================= */

    public function calendario(): never
    {
        $base = get('semana');
        $ref = $this->fechaValida($base) ? strtotime($base) : time();
        $lunes = strtotime('monday this week', $ref);
        $dias = [];
        for ($i = 0; $i < 7; $i++) {
            $dias[] = date('Y-m-d', strtotime("+$i day", $lunes));
        }
        [$cond, $params] = A::alcance('s');
        $donde = ["s.fecha BETWEEN ? AND ?", $cond];
        $params = [$dias[0], $dias[6], ...$params];
        if (($fac = (int) get('facilitador')) > 0) {
            $donde[] = 's.facilitador_id = ?';
            $params[] = $fac;
        }
        if (($sede = (int) get('sede')) > 0) {
            $donde[] = 's.sede_id = ?';
            $params[] = $sede;
        }
        $sesiones = DB::todos(self::SQL_SESION . ' WHERE ' . implode(' AND ', $donde) . " ORDER BY s.fecha, s.hora_inicio", $params);
        $porDia = array_fill_keys($dias, []);
        foreach ($sesiones as $s) {
            $porDia[$s['fecha']][] = $s;
        }
        View::mostrar('agenda/calendario', [
            'titulo' => 'Agenda',
            'migas' => ['Agenda' => null],
            'dias' => $dias,
            'porDia' => $porDia,
            'lunes' => $lunes,
            'facilitadores' => DB::todos('SELECT id, nombre FROM facilitadores WHERE activo = 1 ORDER BY nombre'),
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
            'porCerrar' => A::porCerrar(),
            'experiencias' => (int) DB::valor('SELECT COUNT(*) FROM servicios WHERE activo = 1'),
        ]);
    }

    /* ======================= Lista de sesiones ======================= */

    private function filtrosLista(): array
    {
        [$cond, $params] = A::alcance('s');
        $donde = [$cond];
        if (isset(A::ESTADOS[$e = get('estado')])) {
            $donde[] = 's.estado = ?';
            $params[] = $e;
        }
        if (get('estado') === 'por_cerrar') {
            $donde[] = "s.estado IN ('programada','confirmada','realizada') AND (s.fecha < CURDATE() OR (s.fecha = CURDATE() AND s.hora_fin < CURTIME()))";
        }
        if ($this->fechaValida($d = get('desde'))) {
            $donde[] = 's.fecha >= ?';
            $params[] = $d;
        }
        if ($this->fechaValida($h = get('hasta'))) {
            $donde[] = 's.fecha <= ?';
            $params[] = $h;
        }
        if (($f = (int) get('facilitador')) > 0) {
            $donde[] = 's.facilitador_id = ?';
            $params[] = $f;
        }
        if (($sv = (int) get('experiencia')) > 0) {
            $donde[] = 's.servicio_id = ?';
            $params[] = $sv;
        }
        return [implode(' AND ', $donde), $params];
    }

    public function lista(): never
    {
        [$where, $params] = $this->filtrosLista();
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) FROM sesiones s WHERE $where", $params);
        $orden = get('estado') === 'por_cerrar' ? 's.fecha ASC, s.hora_inicio ASC' : 's.fecha DESC, s.hora_inicio DESC';
        $filas = DB::todos(self::SQL_SESION . " WHERE $where ORDER BY $orden LIMIT 30 OFFSET " . (($pagina - 1) * 30), $params);
        View::mostrar('agenda/sesiones', [
            'titulo' => 'Sesiones',
            'migas' => ['Agenda' => '/agenda', 'Sesiones' => null],
            'filas' => $filas,
            'facilitadores' => DB::todos('SELECT id, nombre FROM facilitadores ORDER BY nombre'),
            'experiencias' => DB::todos('SELECT id, nombre FROM servicios ORDER BY nombre'),
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / 30)),
        ]);
    }

    /* ======================= Crear y editar ======================= */

    private function vistaForm(?array $s): never
    {
        $servicios = DB::todos('SELECT id, nombre, duracion_min, capacidad, precio, lleva_itbis, linea_negocio FROM servicios WHERE activo = 1 OR id = ? ORDER BY nombre', [$s['servicio_id'] ?? 0]);
        if (!$servicios) {
            Flash::aviso('Primero crea al menos una experiencia (por ejemplo, Paint & Wine) para poder programar sesiones.');
            redirigir('/agenda/experiencias/nueva');
        }
        View::mostrar('agenda/sesion_form', [
            'titulo' => $s ? 'Editar sesión' : 'Nueva sesión',
            'migas' => ['Agenda' => '/agenda', $s ? 'Editar sesión' : 'Nueva sesión' => null],
            's' => $s,
            'servicios' => $servicios,
            'facilitadores' => DB::todos('SELECT id, nombre FROM facilitadores WHERE activo = 1 OR id = ? ORDER BY nombre', [$s['facilitador_id'] ?? 0]),
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
            'choque' => $this->tomar('_choque'),
        ]);
    }

    private function tomar(string $clave): mixed
    {
        $v = $_SESSION[$clave] ?? null;
        unset($_SESSION[$clave]);
        return $v;
    }

    public function nueva(): never
    {
        $this->vistaForm(null);
    }

    public function editar(string $id): never
    {
        $s = $this->sesion((int) $id);
        if (in_array($s['estado'], ['cerrada', 'cancelada'], true)) {
            Flash::error('Una sesión ' . A::ESTADOS[$s['estado']][0] . ' no se puede editar.');
            redirigir("/agenda/sesiones/$id");
        }
        $this->vistaForm($s);
    }

    private function datos(?int $id): array
    {
        $volver = $id ? "/agenda/sesiones/$id/editar" : '/agenda/sesiones/nueva';
        $servicio = DB::uno('SELECT * FROM servicios WHERE id = ?', [(int) post('servicio_id')]);
        $d = [
            'servicio_id' => $servicio ? (int) $servicio['id'] : 0,
            'facilitador_id' => (int) post('facilitador_id') ?: null,
            'sede_id' => (int) post('sede_id') ?: null,
            'fecha' => post('fecha'),
            'hora_inicio' => post('hora_inicio'),
            'hora_fin' => post('hora_fin'),
            'capacidad' => (int) post('capacidad'),
            'precio_persona' => I::numero(post('precio_persona', '0') ?: '0'),
            'notas' => post('notas') ?: null,
        ];
        $hora = '/^([01]\d|2[0-3]):[0-5]\d$/';
        $error = match (true) {
            !$servicio => 'Elige la experiencia.',
            !$this->fechaValida($d['fecha']) => 'Elige la fecha.',
            !preg_match($hora, $d['hora_inicio']) || !preg_match($hora, $d['hora_fin']) => 'Escribe la hora de inicio y de fin.',
            A::minutos($d['hora_fin']) <= A::minutos($d['hora_inicio']) => 'La hora de fin debe ser después de la de inicio.',
            $d['capacidad'] < 1 => 'La capacidad debe ser 1 o más.',
            is_nan($d['precio_persona']) || $d['precio_persona'] < 0 => 'Escribe un precio válido.',
            $id === null && $d['fecha'] < date('Y-m-d') && post('confirmar_pasada') !== '1' => 'La fecha ya pasó. Si estás registrando una sesión que ya ocurrió, marca la casilla para confirmarlo.',
            default => null,
        };
        if (!$error && $id) {
            $ocupados = A::ocupados($id);
            if ($d['capacidad'] < $ocupados) {
                $error = "Ya hay $ocupados personas reservadas; la capacidad no puede ser menor.";
            }
        }
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        $choques = A::choques($d['facilitador_id'], $d['fecha'], $d['hora_inicio'], $d['hora_fin'], $id ?? 0);
        if ($choques && post('confirmar_choque') !== '1') {
            Flash::recordarFormulario();
            $_SESSION['_choque'] = array_map(static fn($c) => $c['servicio'] . ' de ' . substr($c['hora_inicio'], 0, 5) . ' a ' . substr($c['hora_fin'], 0, 5), $choques);
            redirigir($volver);
        }
        return $d;
    }

    public function crear(): never
    {
        $d = $this->datos(null);
        $d['creado_por'] = Auth::id();
        $d['estado'] = $d['fecha'] < date('Y-m-d') ? 'realizada' : 'programada';
        $id = DB::insertar('sesiones', $d);
        $nombre = (string) DB::valor('SELECT nombre FROM servicios WHERE id = ?', [$d['servicio_id']]);
        Actividad::registrar('agenda', 'crear', 'sesiones', $id, "Programó $nombre el " . fecha($d['fecha']) . ' a las ' . $d['hora_inicio'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Sesión programada. Agrega los participantes.');
        redirigir("/agenda/sesiones/$id");
    }

    public function guardar(string $id): never
    {
        $antes = $this->sesion((int) $id);
        if (in_array($antes['estado'], ['cerrada', 'cancelada'], true)) {
            redirigir("/agenda/sesiones/$id");
        }
        $d = $this->datos((int) $id);
        DB::actualizar('sesiones', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('agenda', 'editar', 'sesiones', (int) $antes['id'], 'Editó la sesión ' . $antes['servicio'] . ' del ' . fecha($antes['fecha']), $a, $dd);
        }
        Flash::limpiarFormulario();
        Flash::ok('Sesión actualizada.');
        redirigir("/agenda/sesiones/$id");
    }

    public function estado(string $id): never
    {
        $s = $this->sesion((int) $id);
        $accion = post('accion');
        if ($accion === 'confirmar' && $s['estado'] === 'programada') {
            DB::actualizar('sesiones', ['estado' => 'confirmada'], 'id = ?', [$s['id']]);
            Actividad::registrar('agenda', 'confirmar', 'sesiones', (int) $s['id'], 'Confirmó la sesión ' . $s['servicio'] . ' del ' . fecha($s['fecha']));
            Flash::ok('Sesión confirmada.');
        } elseif ($accion === 'cancelar' && !in_array($s['estado'], ['cerrada', 'cancelada'], true)) {
            $motivo = post('motivo');
            if ($motivo === '') {
                Flash::error('Escribe el motivo de la cancelación.');
                redirigir("/agenda/sesiones/$id");
            }
            $pagado = (float) DB::valor("SELECT COALESCE(SUM(pagado),0) FROM reservas WHERE sesion_id = ? AND estado IN ('pendiente','confirmada')", [$s['id']]);
            DB::tx(function () use ($s, $motivo) {
                DB::actualizar('sesiones', ['estado' => 'cancelada', 'motivo_cancelacion' => $motivo], 'id = ?', [$s['id']]);
                DB::q("UPDATE reservas SET estado = 'cancelada' WHERE sesion_id = ? AND estado IN ('pendiente','confirmada')", [$s['id']]);
            });
            Actividad::registrar('agenda', 'cancelar', 'sesiones', (int) $s['id'], 'Canceló la sesión ' . $s['servicio'] . ' del ' . fecha($s['fecha']) . ": $motivo");
            Flash::ok('Sesión cancelada.');
            if ($pagado > 0) {
                Flash::aviso('Había ' . dinero($pagado) . ' cobrados en reservas. Si devuelves dinero, regístralo como gasto o anula el ingreso en Finanzas.');
            }
        }
        redirigir("/agenda/sesiones/$id");
    }

    /* ======================= Detalle y reservas ======================= */

    public function ver(string $id): never
    {
        $s = $this->sesion((int) $id);
        $reservas = DB::todos(
            "SELECT r.*, c.nombre AS cliente, c.telefono, c.email FROM reservas r JOIN clientes c ON c.id = r.cliente_id
              WHERE r.sesion_id = ? ORDER BY FIELD(r.estado,'confirmada','pendiente','no_show','cancelada'), c.nombre",
            [$s['id']]
        );
        View::mostrar('agenda/sesion', [
            'titulo' => $s['servicio'],
            'migas' => ['Agenda' => '/agenda?semana=' . $s['fecha'], $s['servicio'] . ' · ' . fecha($s['fecha']) => null],
            's' => $s,
            'reservas' => $reservas,
            'consumo' => DB::todos('SELECT sm.cantidad, m.nombre, m.unidad FROM sesion_materiales sm JOIN materiales m ON m.id = sm.material_id WHERE sm.sesion_id = ?', [$s['id']]),
            'puedeOperar' => A::puedeOperar($s),
            'puedeEditar' => Auth::puede('agenda.editar'),
            'aviso' => $this->tomar('_cupo'),
        ]);
    }

    public function agregarReserva(string $id): never
    {
        $s = $this->sesion((int) $id);
        if (!A::puedeOperar($s) || in_array($s['estado'], ['cerrada', 'cancelada'], true)) {
            Flash::error('No se pueden agregar participantes a esta sesión.');
            redirigir("/agenda/sesiones/$id");
        }
        $personas = max(1, (int) post('personas', '1'));
        $clienteId = (int) post('cliente_id');
        $nuevoNombre = post('nuevo_nombre');
        if (!$clienteId && $nuevoNombre === '') {
            Flash::error('Busca un cliente o escribe el nombre de uno nuevo.');
            redirigir("/agenda/sesiones/$id");
        }
        $libres = (int) $s['capacidad'] - A::ocupados((int) $s['id']);
        if ($personas > $libres && post('confirmar_cupo') !== '1') {
            Flash::recordarFormulario();
            $_SESSION['_cupo'] = "Quedan $libres cupo" . ($libres === 1 ? '' : 's') . " y quieres agregar $personas. Marca la casilla para pasar de la capacidad.";
            redirigir("/agenda/sesiones/$id#agregar");
        }
        $cortesia = post('cortesia') === '1';
        $monto = $cortesia ? 0.0 : I::numero(post('monto', '') !== '' ? post('monto') : (string) ((float) $s['precio_persona'] * $personas));
        $pago = I::numero(post('pago', '0') ?: '0');
        if (is_nan($monto) || $monto < 0 || is_nan($pago) || $pago < 0) {
            Flash::error('Revisa el monto y el pago.');
            redirigir("/agenda/sesiones/$id");
        }
        try {
            DB::tx(function () use ($s, $clienteId, $nuevoNombre, $personas, $monto, $cortesia, $pago) {
                if (!$clienteId) {
                    $tel = ClientesServicio::normalizarTelefono(post('nuevo_telefono'));
                    $dup = $tel ? DB::uno('SELECT id FROM clientes WHERE (telefono = ? OR whatsapp = ?) AND activo = 1 AND nombre = ? LIMIT 1', [$tel, $tel, $nuevoNombre]) : null;
                    $clienteId = $dup ? (int) $dup['id'] : DB::insertar('clientes', [
                        'nombre' => $nuevoNombre, 'telefono' => $tel, 'fuente' => 'plaza', 'sede_id' => $s['sede_id'], 'creado_por' => Auth::id(),
                    ]);
                }
                $rid = DB::insertar('reservas', [
                    'sesion_id' => $s['id'],
                    'cliente_id' => $clienteId,
                    'personas' => $personas,
                    'estado' => 'confirmada',
                    'monto' => round($monto, 2),
                    'cortesia' => $cortesia ? 1 : 0,
                    'origen' => 'manual',
                    'notas' => post('notas') ?: null,
                    'creado_por' => Auth::id(),
                ]);
                if ($pago > 0) {
                    A::registrarPago(DB::uno('SELECT * FROM reservas WHERE id = ?', [$rid]), $pago, post('metodo', 'efectivo'), post('referencia') ?: null);
                }
                $cliente = (string) DB::valor('SELECT nombre FROM clientes WHERE id = ?', [$clienteId]);
                Actividad::registrar('agenda', 'reservar', 'reservas', $rid, "Agregó a $cliente ($personas) a " . $s['servicio'] . ' del ' . fecha($s['fecha']) . ($pago > 0 ? ' con pago de ' . dinero($pago) : ''));
            });
        } catch (Throwable $e) {
            Flash::error($e->getMessage());
            redirigir("/agenda/sesiones/$id");
        }
        Flash::limpiarFormulario();
        Flash::ok('Participante agregado.');
        redirigir("/agenda/sesiones/$id");
    }

    private function reserva(int $id): array
    {
        $r = DB::uno('SELECT r.*, c.nombre AS cliente FROM reservas r JOIN clientes c ON c.id = r.cliente_id WHERE r.id = ?', [$id]);
        if (!$r) {
            App::error(404);
        }
        $s = $this->sesion((int) $r['sesion_id']);
        if (!A::puedeOperar($s)) {
            App::error(403);
        }
        return [$r, $s];
    }

    public function asistencia(string $id): never
    {
        [$r, $s] = $this->reserva((int) $id);
        if ($r['estado'] === 'cancelada' || $s['estado'] === 'cancelada') {
            json(['ok' => false, 'mensaje' => 'La reserva está cancelada.'], 422);
        }
        $vino = post('asistio') === '1';
        DB::actualizar('reservas', ['asistio' => $vino ? 1 : 0, 'estado' => $vino ? 'confirmada' : $r['estado']], 'id = ?', [$r['id']]);
        Actividad::registrar('agenda', 'asistencia', 'reservas', (int) $r['id'], ($vino ? 'Marcó llegada de ' : 'Quitó la llegada de ') . $r['cliente'] . ' en ' . $s['servicio']);
        if (es_ajax()) {
            $n = (int) DB::valor('SELECT COALESCE(SUM(personas),0) FROM reservas WHERE sesion_id = ? AND asistio = 1', [$s['id']]);
            json(['ok' => true, 'asistentes' => $n]);
        }
        redirigir('/agenda/sesiones/' . $s['id']);
    }

    public function pago(string $id): never
    {
        [$r, $s] = $this->reserva((int) $id);
        $monto = I::numero(post('monto'));
        try {
            if (is_nan($monto)) {
                throw new \RuntimeException('Escribe el monto.');
            }
            DB::tx(fn() => A::registrarPago($r, $monto, post('metodo'), post('referencia') ?: null));
        } catch (Throwable $e) {
            Flash::error($e->getMessage());
            redirigir('/agenda/sesiones/' . $s['id']);
        }
        Actividad::registrar('agenda', 'cobrar', 'reservas', (int) $r['id'], 'Cobró ' . dinero($monto) . ' a ' . $r['cliente'] . ' (' . A::METODOS[post('metodo')] . ')');
        Flash::ok('Pago de ' . dinero($monto) . ' registrado. Quedó en Finanzas → Ingresos.');
        redirigir('/agenda/sesiones/' . $s['id']);
    }

    public function cancelarReserva(string $id): never
    {
        [$r, $s] = $this->reserva((int) $id);
        DB::actualizar('reservas', ['estado' => 'cancelada', 'asistio' => null], 'id = ?', [$r['id']]);
        Actividad::registrar('agenda', 'cancelar', 'reservas', (int) $r['id'], 'Canceló la reserva de ' . $r['cliente'] . ' en ' . $s['servicio']);
        Flash::ok('Reserva cancelada. El cupo quedó libre.');
        if ((float) $r['pagado'] > 0) {
            Flash::aviso('Esta reserva tenía ' . dinero($r['pagado']) . ' pagados. Si devuelves el dinero, anula el ingreso en Finanzas.');
        }
        redirigir('/agenda/sesiones/' . $s['id']);
    }

    /* ======================= Cierre ======================= */

    public function formularioCierre(string $id): never
    {
        $s = $this->sesion((int) $id);
        if (!A::puedeOperar($s) || in_array($s['estado'], ['cerrada', 'cancelada'], true)) {
            Flash::error('Esta sesión no se puede cerrar.');
            redirigir("/agenda/sesiones/$id");
        }
        $reservas = DB::todos(
            "SELECT r.*, c.nombre AS cliente FROM reservas r JOIN clientes c ON c.id = r.cliente_id
              WHERE r.sesion_id = ? AND r.estado <> 'cancelada' ORDER BY c.nombre",
            [$s['id']]
        );
        $asistentes = 0;
        foreach ($reservas as $r) {
            $asistentes += (int) $r['asistio'] === 1 || $r['asistio'] === null ? (int) $r['personas'] : 0;
        }
        $receta = DB::todos(
            'SELECT m.id, m.nombre, m.unidad, m.stock, sm.cantidad_por_persona FROM servicio_materiales sm JOIN materiales m ON m.id = sm.material_id
              WHERE sm.servicio_id = ? ORDER BY m.nombre',
            [$s['servicio_id']]
        );
        View::mostrar('agenda/cierre', [
            'titulo' => 'Cerrar sesión',
            'migas' => ['Agenda' => '/agenda', $s['servicio'] => '/agenda/sesiones/' . $s['id'], 'Cerrar' => null],
            's' => $s,
            'reservas' => $reservas,
            'receta' => $receta,
            'asistentesSugeridos' => $asistentes,
            'materiales' => DB::todos('SELECT id, nombre, unidad, stock FROM materiales WHERE activo = 1 ORDER BY nombre'),
        ]);
    }

    public function cerrar(string $id): never
    {
        $s = $this->sesion((int) $id);
        if (!A::puedeOperar($s) || in_array($s['estado'], ['cerrada', 'cancelada'], true)) {
            redirigir("/agenda/sesiones/$id");
        }
        if ($s['fecha'] > date('Y-m-d')) {
            Flash::error('No se puede cerrar una sesión que todavía no ocurre.');
            redirigir("/agenda/sesiones/$id");
        }
        $asistencia = array_map(static fn($v) => $v === '1', (array) ($_POST['asistio'] ?? []));
        $materiales = [];
        $ids = (array) ($_POST['material_id'] ?? []);
        $cants = (array) ($_POST['material_cantidad'] ?? []);
        foreach ($ids as $i => $mid) {
            $c = I::numero((string) ($cants[$i] ?? ''));
            if ((int) $mid > 0 && !is_nan($c) && $c > 0) {
                $materiales[(int) $mid] = ($materiales[(int) $mid] ?? 0) + $c;
            }
        }
        try {
            A::cerrar($s, $asistencia, $materiales, post('notas_cierre'));
        } catch (Throwable $e) {
            Flash::error('No se pudo cerrar: ' . $e->getMessage());
            redirigir("/agenda/sesiones/$id/cerrar");
        }
        $vinieron = (int) DB::valor('SELECT COALESCE(SUM(personas),0) FROM reservas WHERE sesion_id = ? AND asistio = 1', [$s['id']]);
        Actividad::registrar('agenda', 'cerrar', 'sesiones', (int) $s['id'],
            'Cerró ' . $s['servicio'] . ' del ' . fecha($s['fecha']) . ": $vinieron asistentes, " . count($materiales) . ' materiales descontados');
        $negativos = DB::todos('SELECT nombre FROM materiales WHERE id IN (' . (implode(',', array_map('intval', array_keys($materiales))) ?: '0') . ') AND stock < 0');
        Flash::ok("Sesión cerrada con $vinieron asistentes.");
        if ($negativos) {
            Flash::aviso('El inventario quedó en negativo para: ' . implode(', ', array_column($negativos, 'nombre')) . '. Registra la entrada o un ajuste por conteo.');
        }
        redirigir("/agenda/sesiones/$id");
    }

    /* ======================= Reportes ======================= */

    private function rango(): array
    {
        $desde = $this->fechaValida(get('desde')) ? get('desde') : date('Y-m-01');
        $hasta = $this->fechaValida(get('hasta')) ? get('hasta') : date('Y-m-t');
        return [$desde, $hasta];
    }

    public static function datosReporte(string $desde, string $hasta): array
    {
        [$cond, $params] = A::alcance('s');
        $filas = DB::todos(
            "SELECT s.id, s.fecha, s.hora_inicio, s.capacidad, s.estado, sv.nombre AS servicio, sv.linea_negocio, f.nombre AS facilitador,
                    (SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.estado IN ('pendiente','confirmada','no_show')) AS reservados,
                    (SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.asistio = 1) AS asistentes,
                    (SELECT COALESCE(SUM(i.monto),0) FROM ingresos i JOIN reservas r ON i.origen_tipo = 'reserva' AND i.origen_id = r.id
                      WHERE r.sesion_id = s.id AND i.anulado = 0) AS ingresos
               FROM sesiones s JOIN servicios sv ON sv.id = s.servicio_id LEFT JOIN facilitadores f ON f.id = s.facilitador_id
              WHERE s.fecha BETWEEN ? AND ? AND s.estado <> 'cancelada' AND $cond
              ORDER BY s.fecha, s.hora_inicio",
            [$desde, $hasta, ...$params]
        );
        $porServicio = [];
        $porFacilitador = [];
        $sumar = static function (array &$grupo, string $clave, array $f): void {
            $grupo[$clave] ??= ['sesiones' => 0, 'capacidad' => 0, 'asistentes' => 0, 'ingresos' => 0.0];
            $grupo[$clave]['sesiones']++;
            $grupo[$clave]['ingresos'] += (float) $f['ingresos'];
            if ($f['estado'] === 'cerrada') {
                $grupo[$clave]['capacidad'] += (int) $f['capacidad'];
                $grupo[$clave]['asistentes'] += (int) $f['asistentes'];
            }
        };
        foreach ($filas as $f) {
            $sumar($porServicio, $f['servicio'], $f);
            $sumar($porFacilitador, $f['facilitador'] ?? 'Sin asignar', $f);
        }
        return [$filas, $porServicio, $porFacilitador];
    }

    public function reportes(): never
    {
        [$desde, $hasta] = $this->rango();
        [$filas, $porServicio, $porFacilitador] = self::datosReporte($desde, $hasta);
        if (get('formato') === 'csv') {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="ocupacion-' . $desde . '-a-' . $hasta . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Fecha', 'Hora', 'Experiencia', 'Facilitador', 'Estado', 'Capacidad', 'Reservados', 'Asistentes', 'Ocupación %', 'Ingresos']);
            foreach ($filas as $f) {
                fputcsv($out, [$f['fecha'], substr($f['hora_inicio'], 0, 5), $f['servicio'], $f['facilitador'], $f['estado'], $f['capacidad'], $f['reservados'], $f['asistentes'],
                    $f['estado'] === 'cerrada' ? round($f['asistentes'] / max(1, $f['capacidad']) * 100, 1) : '', $f['ingresos']]);
            }
            fclose($out);
            exit;
        }
        View::mostrar('agenda/reportes', [
            'titulo' => 'Reportes de agenda',
            'migas' => ['Agenda' => '/agenda', 'Reportes' => null],
            'desde' => $desde,
            'hasta' => $hasta,
            'filas' => $filas,
            'porServicio' => $porServicio,
            'porFacilitador' => $porFacilitador,
        ]);
    }
}
