<?php
declare(strict_types=1);

namespace App\Modulos\Agenda;

use App\Core\Actividad;
use App\Core\App;
use App\Core\DB;
use App\Core\Flash;
use App\Core\View;
use App\Modulos\Agenda\AgendaServicio as A;
use App\Modulos\Inventario\InventarioServicio as I;

/** Experiencias (servicios) que se programan en la agenda: Paint & Wine, Café & Paint, corporativos… */
final class ServiciosControlador
{
    public function lista(): never
    {
        View::mostrar('agenda/experiencias', [
            'titulo' => 'Experiencias',
            'migas' => ['Agenda' => '/agenda', 'Experiencias' => null],
            'filas' => DB::todos(
                "SELECT sv.*, (SELECT COUNT(*) FROM servicio_materiales sm WHERE sm.servicio_id = sv.id) AS materiales,
                        (SELECT COUNT(*) FROM sesiones s WHERE s.servicio_id = sv.id AND s.fecha >= CURDATE() AND s.estado <> 'cancelada') AS proximas
                   FROM servicios sv ORDER BY sv.activo DESC, sv.nombre"
            ),
        ]);
    }

    private function vista(?array $s): never
    {
        View::mostrar('agenda/experiencia_form', [
            'titulo' => $s ? $s['nombre'] : 'Nueva experiencia',
            'migas' => ['Agenda' => '/agenda', 'Experiencias' => '/agenda/experiencias', $s ? $s['nombre'] : 'Nueva' => null],
            's' => $s,
            'receta' => $s ? DB::todos(
                'SELECT sm.*, m.nombre, m.unidad FROM servicio_materiales sm JOIN materiales m ON m.id = sm.material_id WHERE sm.servicio_id = ? ORDER BY m.nombre',
                [$s['id']]
            ) : [],
            'materiales' => DB::todos('SELECT id, nombre, unidad FROM materiales WHERE activo = 1 ORDER BY nombre'),
        ]);
    }

    public function nuevo(): never
    {
        $this->vista(null);
    }

    public function editar(string $id): never
    {
        $this->vista(DB::uno('SELECT * FROM servicios WHERE id = ?', [(int) $id]) ?? App::error(404));
    }

    private function datos(?int $id): array
    {
        $volver = $id ? "/agenda/experiencias/$id" : '/agenda/experiencias/nueva';
        $linea = post('linea_negocio');
        $d = [
            'nombre' => post('nombre'),
            'linea_negocio' => isset(A::LINEAS[$linea]) ? $linea : 'experiencias',
            'descripcion' => post('descripcion') ?: null,
            'duracion_min' => (int) post('duracion_min', '120'),
            'precio' => I::numero(post('precio', '0') ?: '0'),
            'lleva_itbis' => post('lleva_itbis') === '1' ? 1 : 0,
            'capacidad' => (int) post('capacidad', '12'),
            'edad_min' => post('edad_min') === '' ? null : (int) post('edad_min'),
            'edad_max' => post('edad_max') === '' ? null : (int) post('edad_max'),
            'color' => preg_match('/^#[0-9a-fA-F]{6}$/', post('color')) ? strtolower(post('color')) : '#6a47dc',
        ];
        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre de la experiencia.',
            $d['duracion_min'] < 15 || $d['duracion_min'] > 720 => 'La duración debe estar entre 15 minutos y 12 horas.',
            is_nan($d['precio']) || $d['precio'] < 0 => 'Escribe un precio válido.',
            $d['capacidad'] < 1 || $d['capacidad'] > 500 => 'La capacidad debe estar entre 1 y 500.',
            $d['edad_min'] !== null && $d['edad_max'] !== null && $d['edad_min'] > $d['edad_max'] => 'La edad mínima no puede ser mayor que la máxima.',
            (bool) DB::valor('SELECT id FROM servicios WHERE nombre = ? AND id <> ?', [$d['nombre'], $id ?? 0]) => 'Ya existe una experiencia con ese nombre.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        return $d;
    }

    /** Guarda la receta de materiales por persona. */
    private function guardarReceta(int $servicioId): void
    {
        DB::q('DELETE FROM servicio_materiales WHERE servicio_id = ?', [$servicioId]);
        $ids = (array) ($_POST['receta_material'] ?? []);
        $cants = (array) ($_POST['receta_cantidad'] ?? []);
        foreach ($ids as $i => $mid) {
            $mid = (int) $mid;
            $c = I::numero((string) ($cants[$i] ?? ''));
            if ($mid > 0 && !is_nan($c) && $c > 0) {
                DB::q(
                    'INSERT INTO servicio_materiales (servicio_id, material_id, cantidad_por_persona) VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE cantidad_por_persona = VALUES(cantidad_por_persona)',
                    [$servicioId, $mid, $c]
                );
            }
        }
    }

    public function crear(): never
    {
        $d = $this->datos(null);
        $id = DB::tx(function () use ($d) {
            $id = DB::insertar('servicios', $d);
            $this->guardarReceta($id);
            return $id;
        });
        Actividad::registrar('agenda', 'crear', 'servicios', $id, 'Creó la experiencia ' . $d['nombre'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Experiencia creada.');
        redirigir('/agenda/experiencias');
    }

    public function guardar(string $id): never
    {
        $antes = DB::uno('SELECT * FROM servicios WHERE id = ?', [(int) $id]) ?? App::error(404);
        $d = $this->datos((int) $id);
        $d['activo'] = post('activo') === '1' ? 1 : 0;
        DB::tx(function () use ($d, $antes) {
            DB::actualizar('servicios', $d, 'id = ?', [$antes['id']]);
            $this->guardarReceta((int) $antes['id']);
        });
        [$a, $dd] = Actividad::diferencias($antes, $d);
        Actividad::registrar('agenda', 'editar', 'servicios', (int) $antes['id'], 'Editó la experiencia ' . $d['nombre'], $a ?: null, $dd ?: null);
        Flash::limpiarFormulario();
        Flash::ok('Experiencia guardada.');
        redirigir('/agenda/experiencias');
    }
}
