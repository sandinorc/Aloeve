<?php
declare(strict_types=1);

namespace App\Modulos\Agenda;

use App\Core\Actividad;
use App\Core\App;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Validar;
use App\Core\View;
use App\Modulos\Clientes\ClientesServicio;

final class FacilitadoresControlador
{
    public function lista(): never
    {
        View::mostrar('agenda/facilitadores', [
            'titulo' => 'Facilitadores',
            'migas' => ['Agenda' => '/agenda', 'Facilitadores' => null],
            'filas' => DB::todos(
                "SELECT f.*, u.email AS usuario_email,
                        (SELECT COUNT(*) FROM sesiones s WHERE s.facilitador_id = f.id AND s.fecha >= CURDATE() AND s.estado <> 'cancelada') AS proximas,
                        (SELECT COUNT(*) FROM sesiones s WHERE s.facilitador_id = f.id AND s.estado = 'cerrada' AND s.fecha >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) AS ultimas30
                   FROM facilitadores f LEFT JOIN usuarios u ON u.id = f.usuario_id
                  ORDER BY f.activo DESC, f.nombre"
            ),
        ]);
    }

    private function vista(?array $f): never
    {
        View::mostrar('agenda/facilitador_form', [
            'titulo' => $f ? $f['nombre'] : 'Nuevo facilitador',
            'migas' => ['Agenda' => '/agenda', 'Facilitadores' => '/facilitadores', $f ? $f['nombre'] : 'Nuevo' => null],
            'f' => $f,
            'usuarios' => DB::todos(
                "SELECT u.id, u.nombre, u.email FROM usuarios u JOIN roles r ON r.id = u.rol_id
                  WHERE u.activo = 1 AND (r.clave = 'facilitador' OR u.id = ?)
                    AND u.id NOT IN (SELECT usuario_id FROM facilitadores WHERE usuario_id IS NOT NULL AND id <> ?)
                  ORDER BY u.nombre",
                [$f['usuario_id'] ?? 0, $f['id'] ?? 0]
            ),
        ]);
    }

    public function nuevo(): never
    {
        $this->vista(null);
    }

    public function editar(string $id): never
    {
        $this->vista(DB::uno('SELECT * FROM facilitadores WHERE id = ?', [(int) $id]) ?? App::error(404));
    }

    private function datos(?int $id): array
    {
        $volver = $id ? "/facilitadores/$id" : '/facilitadores/nuevo';
        $d = [
            'nombre' => post('nombre'),
            'email' => mb_strtolower(post('email')) ?: null,
            'telefono' => ClientesServicio::normalizarTelefono(post('telefono')),
            'especialidad' => post('especialidad') ?: null,
            'anos_experiencia' => post('anos_experiencia') === '' ? null : (int) post('anos_experiencia'),
            'bio' => post('bio') ?: null,
            'color' => preg_match('/^#[0-9a-fA-F]{6}$/', post('color')) ? strtolower(post('color')) : '#6a47dc',
            'usuario_id' => (int) post('usuario_id') ?: null,
        ];
        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre.',
            $d['email'] !== null && !Validar::email($d['email']) => 'El correo no es válido.',
            $d['anos_experiencia'] !== null && ($d['anos_experiencia'] < 0 || $d['anos_experiencia'] > 80) => 'Los años de experiencia no son válidos.',
            $d['email'] !== null && (bool) DB::valor('SELECT id FROM facilitadores WHERE email = ? AND id <> ?', [$d['email'], $id ?? 0]) => 'Ya existe un facilitador con ese correo.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        return $d;
    }

    public function crear(): never
    {
        $d = $this->datos(null);
        $id = DB::insertar('facilitadores', $d);
        Actividad::registrar('agenda', 'crear', 'facilitadores', $id, 'Creó el facilitador ' . $d['nombre'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Facilitador agregado.');
        redirigir('/facilitadores');
    }

    public function guardar(string $id): never
    {
        $antes = DB::uno('SELECT * FROM facilitadores WHERE id = ?', [(int) $id]) ?? App::error(404);
        $d = $this->datos((int) $id);
        $d['activo'] = post('activo') === '1' ? 1 : 0;
        if ($d['activo'] === 0 && (int) DB::valor("SELECT COUNT(*) FROM sesiones WHERE facilitador_id = ? AND fecha >= CURDATE() AND estado <> 'cancelada'", [$antes['id']]) > 0) {
            Flash::aviso('Ojo: este facilitador tiene sesiones futuras. Reasígnalas en la agenda.');
        }
        DB::actualizar('facilitadores', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('agenda', 'editar', 'facilitadores', (int) $antes['id'], 'Editó el facilitador ' . $d['nombre'], $a, $dd);
        }
        Flash::limpiarFormulario();
        Flash::ok('Facilitador guardado.');
        redirigir('/facilitadores');
    }
}
