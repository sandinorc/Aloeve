<?php
declare(strict_types=1);

namespace App\Modulos\Panorama;

use App\Core\DB;

/** Indicadores del Panorama (PRD §8.1). Todo sale de la base de datos; nada se inventa. */
final class PanoramaServicio
{
    public static function kpis(string $desde, string $hasta, ?int $sede): array
    {
        $fs = $sede ? ' AND sede_id = ' . (int) $sede : '';
        $ss = $sede ? ' AND s.sede_id = ' . (int) $sede : '';

        $ing = DB::uno("SELECT COUNT(*) AS n, COALESCE(SUM(monto),0) AS total FROM ingresos WHERE anulado = 0 AND fecha BETWEEN ? AND ? $fs", [$desde, $hasta]);
        $gas = (float) DB::valor("SELECT COALESCE(SUM(monto),0) FROM gastos WHERE anulado = 0 AND fecha BETWEEN ? AND ? $fs", [$desde, $hasta]);
        $ingresos = (float) $ing['total'];

        $occ = DB::uno(
            "SELECT COUNT(*) AS n, COALESCE(SUM(s.capacidad),0) AS cap,
                    COALESCE(SUM((SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.asistio = 1)),0) AS asis
               FROM sesiones s WHERE s.estado = 'cerrada' AND s.fecha BETWEEN ? AND ? $ss",
            [$desde, $hasta]
        );

        $rec = DB::uno(
            "SELECT COUNT(*) AS con_visita, COALESCE(SUM(v >= 2),0) AS recurrentes FROM (
                SELECT r.cliente_id, COUNT(*) AS v FROM reservas r JOIN sesiones s ON s.id = r.sesion_id
                 WHERE r.asistio = 1 AND s.fecha BETWEEN DATE_SUB(?, INTERVAL 12 MONTH) AND ? $ss
                 GROUP BY r.cliente_id) t",
            [$hasta, $hasta]
        );

        $periodo = substr($hasta, 0, 7);
        $mismoMes = substr($desde, 0, 7) === $periodo;
        $meta = $mismoMes ? DB::valor('SELECT meta_ingresos FROM metas WHERE periodo = ?', [$periodo]) : null;

        $web = (int) DB::valor(
            "SELECT COALESCE(SUM(r.personas),0) FROM reservas r JOIN sesiones s ON s.id = r.sesion_id
              WHERE r.origen = 'amelia' AND DATE(r.creado_en) BETWEEN ? AND ? $ss",
            [$desde, $hasta]
        );

        $k = [];
        $k[] = [
            'nombre' => 'Ingresos del periodo',
            'valor' => (int) $ing['n'] > 0 ? dinero($ingresos) : null,
            'estado' => (int) $ing['n'] > 0 ? 'ok' : 'sin_datos',
            'detalle' => (int) $ing['n'] > 0 ? $ing['n'] . ' movimientos' : null,
            'formula' => 'Suma de ingresos no anulados en el rango: cobros de reservas, ingresos manuales y ventas de caja.',
        ];
        $k[] = [
            'nombre' => 'Margen neto',
            'valor' => $ingresos > 0 ? number_format(($ingresos - $gas) / $ingresos * 100, 1) . '%' : null,
            'estado' => $ingresos > 0 ? (($ingresos - $gas) < 0 ? 'malo' : 'ok') : 'sin_datos',
            'detalle' => $ingresos > 0 ? 'Gastos ' . dinero($gas) : null,
            'formula' => '(Ingresos − Gastos) ÷ Ingresos del rango.',
        ];
        $k[] = [
            'nombre' => 'Ocupación promedio',
            'valor' => (int) $occ['cap'] > 0 ? number_format((int) $occ['asis'] / (int) $occ['cap'] * 100, 0) . '%' : null,
            'estado' => (int) $occ['cap'] > 0 ? ((int) $occ['asis'] / (int) $occ['cap'] < 0.5 ? 'malo' : 'ok') : 'sin_datos',
            'detalle' => (int) $occ['n'] > 0 ? $occ['asis'] . ' asistentes en ' . $occ['n'] . ((int) $occ['n'] === 1 ? ' sesión cerrada' : ' sesiones cerradas') : null,
            'formula' => 'Asistentes ÷ capacidad, solo de sesiones cerradas en el rango.',
        ];
        $k[] = [
            'nombre' => 'Clientes recurrentes',
            'valor' => (int) $rec['con_visita'] > 0 ? number_format((int) $rec['recurrentes'] / (int) $rec['con_visita'] * 100, 0) . '%' : null,
            'estado' => (int) $rec['con_visita'] > 0 ? 'ok' : 'sin_datos',
            'detalle' => (int) $rec['con_visita'] > 0 ? $rec['recurrentes'] . ' de ' . $rec['con_visita'] . ' clientes' : null,
            'formula' => 'Clientes con 2 o más asistencias en los 12 meses anteriores ÷ clientes con al menos una.',
        ];
        $k[] = [
            'nombre' => 'Cumplimiento de meta',
            'valor' => $meta ? number_format($ingresos / (float) $meta * 100, 0) . '%' : null,
            'estado' => $meta ? 'ok' : 'sin_meta',
            'detalle' => $meta ? 'Meta ' . dinero($meta) : ($mismoMes ? null : 'Elige un rango dentro de un mismo mes'),
            'formula' => 'Ingresos ÷ meta de ingresos del mes (Finanzas → Reportes y metas).',
            'barra' => $meta ? min(100, $ingresos / (float) $meta * 100) : null,
        ];
        $k[] = [
            'nombre' => 'Reservas web',
            'valor' => $web > 0 ? (string) $web : null,
            'estado' => $web > 0 ? 'ok' : 'parcial',
            'detalle' => $web > 0 ? 'personas reservadas desde aloeverd.com' : null,
            'formula' => 'Personas reservadas desde Amelia en el rango. Llegan cuando se active la conexión con aloeverd.com (Fase 3).',
        ];
        return $k;
    }

    public static function proximas(): array
    {
        [$cond, $params] = \App\Modulos\Agenda\AgendaServicio::alcance('s');
        return DB::todos(
            "SELECT s.id, s.fecha, s.hora_inicio, s.capacidad, s.estado, sv.nombre AS servicio, sv.color, f.nombre AS facilitador,
                    (SELECT COALESCE(SUM(r.personas),0) FROM reservas r WHERE r.sesion_id = s.id AND r.estado IN ('pendiente','confirmada')) AS ocupados
               FROM sesiones s JOIN servicios sv ON sv.id = s.servicio_id LEFT JOIN facilitadores f ON f.id = s.facilitador_id
              WHERE s.fecha BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 DAY) AND s.estado IN ('programada','confirmada') AND $cond
              ORDER BY s.fecha, s.hora_inicio LIMIT 10",
            $params
        );
    }
}
