<?php
declare(strict_types=1);

namespace App\Modulos\Panorama;

use App\Core\Ajustes;
use App\Core\DB;
use App\Core\View;
use App\Modulos\Configuracion\ComprobantesControlador;

final class PanoramaControlador
{
    public function inicio(): never
    {
        if (!puede('panorama.ver')) {
            View::mostrar('panorama/bienvenida', ['titulo' => 'Inicio', 'migas' => ['Inicio' => null]]);
        }

        $desde = get('desde') ?: date('Y-m-01');
        $hasta = get('hasta') ?: date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) { $desde = date('Y-m-01'); }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) { $hasta = date('Y-m-d'); }

        if ($hasta < $desde) { [$desde, $hasta] = [$hasta, $desde]; }
        $sede = (int) get('sede') ?: null;
        $kpis = PanoramaServicio::kpis($desde, $hasta, $sede);

        $pasos = [
            [
                'Completa los datos fiscales del negocio',
                'Razón social y RNC salen en cada comprobante.',
                '/configuracion/negocio',
                Ajustes::get('negocio.razon_social') !== '' && Ajustes::get('negocio.rnc') !== '',
                'configuracion.editar',
            ],
            [
                'Carga tus secuencias de comprobantes',
                'Como mínimo B01 y B02 con el rango que autorizó la DGII.',
                '/configuracion/comprobantes',
                (int) DB::valor('SELECT COUNT(*) FROM secuencias_ncf WHERE activa = 1') > 0,
                'fiscal.editar',
            ],
            [
                'Crea tus experiencias y facilitadores',
                'Paint & Wine, Café & Paint… con precio, duración y materiales por persona.',
                '/agenda/experiencias',
                (int) DB::valor('SELECT COUNT(*) FROM servicios') > 0 && (int) DB::valor('SELECT COUNT(*) FROM facilitadores') > 0,
                'agenda.editar',
            ],
            [
                'Crea los usuarios de tu equipo',
                'Cada persona con su rol: Fundadora, Gerente, Caja o Facilitador.',
                '/usuarios/nuevo',
                (int) DB::valor('SELECT COUNT(*) FROM usuarios') > 1,
                'usuarios.editar',
            ],
            [
                'Prueba la conexión de facturación electrónica',
                'En ambiente de Prueba (TesteCF) con tu certificado digital.',
                '/configuracion/ecf',
                (int) DB::valor("SELECT COUNT(*) FROM ecf_conexiones WHERE estado = 'conectado'") > 0,
                'fiscal.editar',
            ],
        ];
        $pasos = array_values(array_filter($pasos, static fn($p) => puede($p[4])));

        $alertas = puede('fiscal.ver') ? ComprobantesControlador::alertas() : [];
        if (puede('inventario.ver') || puede('inventario.editar')) {
            $bajos = \App\Modulos\Inventario\InventarioServicio::bajoMinimo();
            if ($bajos) {
                $nombres = array_slice(array_column($bajos, 'nombre'), 0, 3);
                $alertas[] = [
                    'nivel' => 'ambar',
                    'texto' => count($bajos) . ' artículo' . (count($bajos) === 1 ? '' : 's') . ' en o bajo el mínimo: ' . implode(', ', $nombres) . (count($bajos) > 3 ? '…' : '') . '.',
                    'enlace' => '/inventario?bajo=1',
                ];
            }
        }

        View::mostrar('panorama/inicio', [
            'titulo' => 'Panorama',
            'migas' => ['Panorama' => null],
            'desde' => $desde,
            'hasta' => $hasta,
            'kpis' => $kpis,
            'pasos' => $pasos,
            'alertas' => $alertas,
            'proximas' => PanoramaServicio::proximas(),
            'porCerrar' => \App\Modulos\Agenda\AgendaServicio::porCerrar(),
            'serie' => puede('finanzas.ver') ? \App\Modulos\Finanzas\FinanzasServicio::serie(date('Y-m'), 6) : [],
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
        ]);
    }
}
