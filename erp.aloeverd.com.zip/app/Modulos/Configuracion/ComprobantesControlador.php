<?php
declare(strict_types=1);

namespace App\Modulos\Configuracion;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\App;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Ncf;
use App\Core\View;

/** Configuración → Comprobantes fiscales: secuencias NCF (papel) y e-NCF (electrónicos). */
final class ComprobantesControlador
{
    /** Tipos que se pueden cargar: los básicos más los extra activados. */
    public static function tiposHabilitados(): array
    {
        $extra = array_filter(explode(',', (string) Ajustes::get('fiscal.tipos_extra', '')));
        $tipos = Ncf::ORDEN_MODAL;
        foreach (array_keys(Ncf::TIPOS) as $t) {
            if (in_array($t, $extra, true) && !in_array($t, $tipos, true)) {
                $tipos[] = $t;
            }
        }
        return $tipos;
    }

    /** Calcula uso, disponibles y estado de una secuencia. */
    public static function resumen(array $s): array
    {
        $total = (int) $s['hasta'] - (int) $s['desde'] + 1;
        $usados = (int) $s['proximo'] - (int) $s['desde'];
        $disponibles = max(0, (int) $s['hasta'] - (int) $s['proximo'] + 1);
        $pct = $total > 0 ? $usados / $total * 100 : 100;
        $dias = $s['vence_en'] ? (int) floor((strtotime($s['vence_en'] . ' 23:59:59') - time()) / 86400) : null;
        $vencida = $dias !== null && $dias < 0;

        $nivel = 'verde';
        if ($pct >= 80 || ($dias !== null && $dias < 60)) {
            $nivel = 'ambar';
        }
        if ($pct >= 95 || $disponibles === 0 || $vencida || ($dias !== null && $dias < 30)) {
            $nivel = 'rojo';
        }

        return [
            ...$s,
            'nombre' => Ncf::nombre($s['tipo']),
            'total' => $total,
            'usados' => $usados,
            'disponibles' => $disponibles,
            'pct' => $pct,
            'dias' => $dias,
            'vencida' => $vencida,
            'nivel' => $nivel,
            'primero' => Ncf::formatear($s['tipo'], (int) $s['desde']),
            'ultimo' => Ncf::formatear($s['tipo'], (int) $s['hasta']),
            'siguiente' => $disponibles > 0 ? Ncf::formatear($s['tipo'], (int) $s['proximo']) : null,
        ];
    }

    /** Avisos para el Panorama y esta pantalla. */
    public static function alertas(): array
    {
        $alertas = [];
        foreach (DB::todos('SELECT * FROM secuencias_ncf WHERE activa = 1') as $s) {
            $r = self::resumen($s);
            $etq = $r['tipo'] . ' (' . $r['nombre'] . ')';
            if ($r['disponibles'] === 0) {
                $alertas[] = ['nivel' => 'rojo', 'texto' => "La secuencia $etq se agotó. Carga una nueva para seguir facturando con este tipo."];
            } elseif ($r['vencida']) {
                $alertas[] = ['nivel' => 'rojo', 'texto' => "La secuencia $etq venció el " . fecha($r['vence_en']) . '.'];
            } elseif ($r['dias'] !== null && $r['dias'] < 30) {
                $alertas[] = ['nivel' => 'rojo', 'texto' => "La secuencia $etq vence en {$r['dias']} días (" . fecha($r['vence_en']) . ').'];
            } elseif ($r['pct'] >= 95) {
                $alertas[] = ['nivel' => 'rojo', 'texto' => "La secuencia $etq va por el " . floor($r['pct']) . "%: quedan {$r['disponibles']}."];
            } elseif ($r['pct'] >= 80) {
                $alertas[] = ['nivel' => 'ambar', 'texto' => "La secuencia $etq va por el " . floor($r['pct']) . "%: quedan {$r['disponibles']}. Pide la próxima a la DGII con margen."];
            }
        }
        return $alertas;
    }

    public function inicio(): never
    {
        $filas = DB::todos(
            "SELECT * FROM secuencias_ncf
              ORDER BY activa DESC, FIELD(clase, 'papel', 'electronico'), tipo, desde"
        );
        $activas = [];
        $historial = [];
        foreach ($filas as $f) {
            $r = self::resumen($f);
            if ((int) $f['activa'] === 1) {
                $activas[] = $r;
            } else {
                $historial[] = $r;
            }
        }

        // Sugerencia de número inicial por tipo: después de la última secuencia cargada
        $sugeridos = [];
        foreach (Ncf::TIPOS as $t => $_) {
            $sugeridos[$t] = (int) (DB::valor('SELECT MAX(hasta) FROM secuencias_ncf WHERE tipo = ?', [$t]) ?? 0) + 1;
        }

        View::mostrar('configuracion/comprobantes', [
            'titulo' => 'Comprobantes fiscales',
            'migas' => ['Configuración' => '/configuracion', 'Comprobantes fiscales' => null],
            'activas' => $activas,
            'historial' => $historial,
            'tipos' => self::tiposHabilitados(),
            'extra' => array_filter(explode(',', (string) Ajustes::get('fiscal.tipos_extra', ''))),
            'sugeridos' => $sugeridos,
            'ecf' => [
                'activo' => Ajustes::get('ecf.activo') === '1',
                'conector' => Ajustes::get('ecf.conector', 'simulador'),
                'ambiente' => Ajustes::get('ecf.ambiente', 'testecf'),
            ],
            'alertas' => self::alertas(),
            'editable' => Auth::puede('fiscal.editar'),
        ]);
    }

    private function rangoCruzado(string $tipo, int $desde, int $hasta, int $excluir = 0): ?array
    {
        return DB::uno(
            'SELECT * FROM secuencias_ncf WHERE tipo = ? AND id <> ? AND desde <= ? AND hasta >= ? LIMIT 1',
            [$tipo, $excluir, $hasta, $desde]
        );
    }

    private function fechaValida(string $f): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $f);
        return $d !== false && $d->format('Y-m-d') === $f;
    }

    public function cargar(): never
    {
        $tipo = post('tipo');
        $desde = (int) post('desde', '1');
        $cantidad = (int) post('cantidad');
        $vence = post('vence_en');

        $error = match (true) {
            !in_array($tipo, self::tiposHabilitados(), true) => 'Elige un tipo de comprobante válido.',
            $desde < 1 => 'El número inicial debe ser 1 o mayor.',
            $cantidad < 1 => 'La cantidad debe ser 1 o mayor.',
            $desde + $cantidad - 1 > Ncf::maximo($tipo) => 'El rango pasa del máximo que permite el formato de ' . $tipo . '.',
            !$this->fechaValida($vence) => 'Escribe la fecha de vencimiento que indica la autorización de la DGII.',
            $vence < date('Y-m-d') => 'La fecha de vencimiento ya pasó.',
            default => null,
        };
        $hasta = $desde + $cantidad - 1;
        if (!$error && ($cruce = $this->rangoCruzado($tipo, $desde, $hasta))) {
            $error = 'Ese rango se cruza con la secuencia ya cargada del '
                . Ncf::formatear($tipo, (int) $cruce['desde']) . ' al ' . Ncf::formatear($tipo, (int) $cruce['hasta']) . '.';
        }
        if ($error) {
            Flash::error($error);
            redirigir('/configuracion/comprobantes');
        }

        $datos = [
            'clase' => Ncf::TIPOS[$tipo]['clase'],
            'tipo' => $tipo,
            'desde' => $desde,
            'hasta' => $hasta,
            'proximo' => $desde,
            'vence_en' => $vence,
            'activa' => 1,
            'creado_por' => Auth::id(),
        ];
        $id = DB::insertar('secuencias_ncf', $datos);
        Actividad::registrar('fiscal', 'cargar', 'secuencias_ncf', $id,
            'Cargó la secuencia ' . Ncf::formatear($tipo, $desde) . ' al ' . Ncf::formatear($tipo, $hasta), null, $datos);
        Flash::ok("Secuencia $tipo cargada: $cantidad comprobantes disponibles.");
        redirigir('/configuracion/comprobantes');
    }

    public function editar(string $id): never
    {
        $s = DB::uno('SELECT * FROM secuencias_ncf WHERE id = ?', [(int) $id]);
        if (!$s) {
            App::error(404);
        }
        $cantidad = (int) post('cantidad');
        $hasta = (int) $s['desde'] + $cantidad - 1;
        $vence = post('vence_en');
        $activa = post('activa') === '1' ? 1 : 0;
        $minimo = (int) $s['proximo'] - 1; // último número ya usado

        $error = match (true) {
            $cantidad < 1 => 'La cantidad debe ser 1 o mayor.',
            $hasta < $minimo => 'No se puede reducir el rango por debajo de ' . Ncf::formatear($s['tipo'], max(1, $minimo)) . ', que ya se usó.',
            $hasta > Ncf::maximo($s['tipo']) => 'El rango pasa del máximo permitido.',
            !$this->fechaValida($vence) => 'Escribe una fecha de vencimiento válida.',
            default => null,
        };
        if (!$error && ($cruce = $this->rangoCruzado($s['tipo'], (int) $s['desde'], $hasta, (int) $s['id']))) {
            $error = 'El nuevo rango se cruza con otra secuencia ' . $s['tipo'] . ' ya cargada.';
        }
        if ($error) {
            Flash::error($error);
            redirigir('/configuracion/comprobantes');
        }

        $nuevos = ['hasta' => $hasta, 'vence_en' => $vence, 'activa' => $activa];
        DB::actualizar('secuencias_ncf', $nuevos, 'id = ?', [$s['id']]);
        [$a, $d] = Actividad::diferencias($s, $nuevos);
        if ($d) {
            Actividad::registrar('fiscal', 'editar', 'secuencias_ncf', (int) $s['id'], 'Editó la secuencia ' . $s['tipo'], $a, $d);
        }
        Flash::ok('Secuencia ' . $s['tipo'] . ' actualizada.');
        redirigir('/configuracion/comprobantes');
    }

    public function tipos(): never
    {
        $basicos = Ncf::ORDEN_MODAL;
        $elegidos = array_values(array_filter(
            (array) ($_POST['tipos'] ?? []),
            static fn($t) => is_string($t) && Ncf::existe($t) && !in_array($t, $basicos, true)
        ));
        $antes = (string) Ajustes::get('fiscal.tipos_extra', '');
        Ajustes::set('fiscal.tipos_extra', implode(',', $elegidos));
        Actividad::registrar('fiscal', 'configurar', 'configuracion', null, 'Cambió los tipos de comprobante adicionales',
            ['tipos_extra' => $antes], ['tipos_extra' => implode(',', $elegidos)]);
        Flash::ok('Tipos de comprobante actualizados.');
        redirigir('/configuracion/comprobantes');
    }
}
