<?php
declare(strict_types=1);

namespace App\Modulos\Configuracion;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\Auth;
use App\Core\Crypto;
use App\Core\DB;
use App\Core\Flash;
use App\Core\View;
use App\Modulos\Ecf\DgiiCliente;
use App\Modulos\Ecf\Firmador;
use Throwable;

/** Configuración → Facturación electrónica (conexión con la DGII). */
final class EcfControlador
{
    public const AMBIENTES = [
        'testecf' => ['nombre' => 'Prueba', 'dgii' => 'TesteCF', 'texto' => 'Pruebas libres, sin valor fiscal.'],
        'certecf' => ['nombre' => 'Certificación', 'dgii' => 'CerteCF', 'texto' => 'Set de pruebas que exige la DGII para certificar el software.'],
        'ecf' => ['nombre' => 'Producción', 'dgii' => 'eCF', 'texto' => 'Comprobantes reales con valor fiscal.'],
    ];

    public const CONECTORES = [
        'simulador' => 'Simulador (no emite ante la DGII)',
        'dgii' => 'DGII directo (certificado digital)',
        'proveedor' => 'Proveedor autorizado (API)',
    ];

    private const MAX_CERT_BYTES = 200 * 1024;

    private function conexion(string $ambiente, string $conector): ?array
    {
        return DB::uno('SELECT * FROM ecf_conexiones WHERE ambiente = ? AND conector = ?', [$ambiente, $conector]);
    }

    private function asegurar(string $ambiente, string $conector): array
    {
        $c = $this->conexion($ambiente, $conector);
        if (!$c) {
            DB::insertar('ecf_conexiones', ['ambiente' => $ambiente, 'conector' => $conector]);
            $c = $this->conexion($ambiente, $conector);
        }
        return $c;
    }

    public function inicio(): never
    {
        $conector = get('conector') ?: Ajustes::get('ecf.conector', 'simulador');
        if (!isset(self::CONECTORES[$conector])) {
            $conector = 'simulador';
        }
        $conexiones = [];
        if ($conector !== 'simulador') {
            foreach (array_keys(self::AMBIENTES) as $a) {
                $conexiones[$a] = $this->conexion($a, $conector);
            }
        }
        View::mostrar('configuracion/ecf', [
            'titulo' => 'Facturación electrónica',
            'migas' => ['Configuración' => '/configuracion', 'Facturación electrónica' => null],
            'activo' => Ajustes::get('ecf.activo') === '1',
            'conectorActual' => Ajustes::get('ecf.conector', 'simulador'),
            'ambienteActual' => Ajustes::get('ecf.ambiente', 'testecf'),
            'conector' => $conector,
            'conexiones' => $conexiones,
            'rnc' => (string) Ajustes::get('negocio.rnc', ''),
            'secuenciasE' => array_column(DB::todos(
                "SELECT DISTINCT tipo FROM secuencias_ncf WHERE clase = 'electronico' AND activa = 1 AND proximo <= hasta"
            ), 'tipo'),
            'editable' => Auth::puede('fiscal.editar'),
        ]);
    }

    public function modo(): never
    {
        $activo = post('activo') === '1';
        $conector = post('conector');
        $ambiente = post('ambiente');
        if (!isset(self::CONECTORES[$conector]) || !isset(self::AMBIENTES[$ambiente])) {
            Flash::error('Elige un conector y un ambiente válidos.');
            redirigir('/configuracion/ecf');
        }

        $error = null;
        if ($ambiente === 'ecf' && post('confirmo_produccion') !== '1') {
            $error = 'Para usar Producción confirma que Aloeve ya completó la certificación con la DGII.';
        } elseif ($ambiente === 'ecf' && $conector === 'simulador') {
            $error = 'El Simulador no se puede usar en Producción.';
        } elseif ($activo && $conector !== 'simulador') {
            $c = $this->conexion($ambiente, $conector);
            if (!$c || $c['estado'] !== 'conectado') {
                $error = 'Antes de encender la facturación electrónica, prueba la conexión del ambiente ' . self::AMBIENTES[$ambiente]['nombre'] . ' y verifica que diga "Conectado".';
            }
        }
        if (!$error && $activo) {
            $tiene = (int) DB::valor("SELECT COUNT(*) FROM secuencias_ncf WHERE tipo IN ('E31','E32') AND activa = 1 AND proximo <= hasta");
            if ($tiene === 0) {
                $error = 'Carga al menos una secuencia E32 (y E31 si vendes a empresas) en Comprobantes fiscales antes de encender la facturación electrónica.';
            }
        }
        if ($error) {
            Flash::error($error);
            redirigir('/configuracion/ecf?conector=' . rawurlencode($conector));
        }

        $antes = ['activo' => Ajustes::get('ecf.activo'), 'conector' => Ajustes::get('ecf.conector'), 'ambiente' => Ajustes::get('ecf.ambiente')];
        Ajustes::set('ecf.activo', $activo ? '1' : '0');
        Ajustes::set('ecf.conector', $conector);
        Ajustes::set('ecf.ambiente', $ambiente);
        $despues = ['activo' => $activo ? '1' : '0', 'conector' => $conector, 'ambiente' => $ambiente];
        [$a, $d] = Actividad::diferencias($antes, $despues);
        if ($d) {
            Actividad::registrar('fiscal', 'configurar', 'configuracion', null, 'Cambió la configuración de facturación electrónica', $a, $d);
        }
        Flash::ok($activo
            ? 'Facturación electrónica encendida en ' . self::AMBIENTES[$ambiente]['nombre'] . '.'
            : 'Configuración guardada. La facturación electrónica está apagada; se sigue usando NCF de papel.');
        redirigir('/configuracion/ecf?conector=' . rawurlencode($conector));
    }

    public function credenciales(string $ambiente): never
    {
        $conector = post('conector');
        if (!isset(self::AMBIENTES[$ambiente]) || !in_array($conector, ['dgii', 'proveedor'], true)) {
            Flash::error('Datos inválidos.');
            redirigir('/configuracion/ecf');
        }
        $volver = '/configuracion/ecf?conector=' . $conector;
        $c = $this->asegurar($ambiente, $conector);
        $cambios = [];

        if ($conector === 'dgii') {
            $clave = (string) ($_POST['certificado_clave'] ?? '');
            $archivo = $_FILES['certificado'] ?? null;
            $hayArchivo = $archivo && ($archivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

            if (!$hayArchivo && $clave === '') {
                Flash::error('Sube el certificado .p12 y escribe su contraseña.');
                redirigir($volver);
            }
            if ($hayArchivo) {
                if ($archivo['error'] !== UPLOAD_ERR_OK || $archivo['size'] > self::MAX_CERT_BYTES) {
                    Flash::error('No se pudo subir el certificado. Debe ser un archivo .p12 o .pfx de menos de 200 KB.');
                    redirigir($volver);
                }
                $ext = strtolower(pathinfo((string) $archivo['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['p12', 'pfx'], true)) {
                    Flash::error('El certificado debe tener extensión .p12 o .pfx.');
                    redirigir($volver);
                }
                $p12 = (string) file_get_contents($archivo['tmp_name']);
            } else {
                $p12 = $this->leerCertificado($c);
                if ($p12 === null) {
                    Flash::error('Sube el archivo del certificado.');
                    redirigir($volver);
                }
            }
            if ($clave === '') {
                $clave = (string) Crypto::descifrar($c['certificado_clave_cifrada']);
            }

            try {
                $info = (new Firmador($p12, $clave))->info();
            } catch (Throwable $e) {
                Flash::error($e->getMessage());
                redirigir($volver);
            }

            if ($hayArchivo) {
                $dir = STORAGE . '/certificados';
                if (!is_dir($dir)) {
                    mkdir($dir, 0750, true);
                }
                $nombre = $ambiente . '-' . bin2hex(random_bytes(8)) . '.p12.enc';
                file_put_contents($dir . '/' . $nombre, Crypto::cifrar(base64_encode($p12)), LOCK_EX);
                @chmod($dir . '/' . $nombre, 0640);
                if ($c['certificado_ruta'] && is_file($dir . '/' . $c['certificado_ruta'])) {
                    @unlink($dir . '/' . $c['certificado_ruta']);
                }
                $cambios['certificado_ruta'] = $nombre;
            }
            $cambios += [
                'certificado_clave_cifrada' => Crypto::cifrar($clave),
                'certificado_titular' => mb_substr($info['titular'] . ($info['documento'] ? ' · ' . $info['documento'] : ''), 0, 255),
                'certificado_vence' => $info['vence'],
                'estado' => 'sin_verificar',
                'mensaje' => $info['vigente'] ? null : 'El certificado no está vigente.',
                'token_cache' => null,
                'token_vence' => null,
            ];
            $descripcion = 'Guardó el certificado digital de ' . self::AMBIENTES[$ambiente]['nombre'] . ' (' . $info['titular'] . ', vence ' . fecha($info['vence']) . ')';
        } else {
            $correo = post('correo');
            $clave = (string) ($_POST['clave'] ?? '');
            $apiKey = trim((string) ($_POST['api_key'] ?? ''));
            $cambios['correo'] = $correo ?: null;
            if ($clave !== '') {
                $cambios['clave_cifrada'] = Crypto::cifrar($clave);
            }
            if ($apiKey !== '') {
                $cambios['api_key_cifrada'] = Crypto::cifrar($apiKey);
                $cambios['api_key_final'] = substr($apiKey, -4);
            }
            $cambios['estado'] = 'sin_verificar';
            $descripcion = 'Guardó las credenciales del proveedor para ' . self::AMBIENTES[$ambiente]['nombre'];
        }

        DB::actualizar('ecf_conexiones', $cambios, 'id = ?', [$c['id']]);
        Actividad::registrar('fiscal', 'configurar', 'ecf_conexiones', (int) $c['id'], $descripcion);
        Flash::ok('Credenciales guardadas. Ahora prueba la conexión.');
        redirigir($volver);
    }

    private function leerCertificado(array $c): ?string
    {
        if (!$c['certificado_ruta']) {
            return null;
        }
        $ruta = STORAGE . '/certificados/' . basename((string) $c['certificado_ruta']);
        if (!is_file($ruta)) {
            return null;
        }
        $b64 = Crypto::descifrar((string) file_get_contents($ruta));
        $bin = $b64 !== null ? base64_decode($b64, true) : false;
        return $bin === false ? null : $bin;
    }

    /** Probar conexión (respuesta JSON para el botón). */
    public function probar(string $ambiente): never
    {
        $conector = post('conector');
        if (!isset(self::AMBIENTES[$ambiente]) || !in_array($conector, ['dgii', 'proveedor'], true)) {
            json(['ok' => false, 'mensaje' => 'Datos inválidos.'], 422);
        }
        $c = $this->conexion($ambiente, $conector);
        if (!$c) {
            json(['ok' => false, 'mensaje' => 'Primero guarda las credenciales.'], 422);
        }

        if ($conector === 'proveedor') {
            json([
                'ok' => false,
                'mensaje' => 'La conexión con un proveedor se programa cuando Aloeve elija uno y tengamos su documentación. Por ahora usa "DGII directo".',
            ], 200);
        }

        try {
            $p12 = $this->leerCertificado($c);
            if ($p12 === null) {
                throw new \RuntimeException('Falta el certificado. Súbelo y guarda.');
            }
            $firmador = new Firmador($p12, (string) Crypto::descifrar($c['certificado_clave_cifrada']));
            $firmador->info();
            $auth = (new DgiiCliente($ambiente))->autenticar($firmador);

            DB::actualizar('ecf_conexiones', [
                'estado' => 'conectado',
                'mensaje' => null,
                'verificado_en' => date('Y-m-d H:i:s'),
                'token_cache' => Crypto::cifrar($auth['token']),
                'token_vence' => $auth['expira'],
            ], 'id = ?', [$c['id']]);
            Actividad::registrar('fiscal', 'probar', 'ecf_conexiones', (int) $c['id'],
                'Probó la conexión con la DGII en ' . self::AMBIENTES[$ambiente]['nombre'] . ': conectado');
            json([
                'ok' => true,
                'mensaje' => 'Conectado con la DGII (' . self::AMBIENTES[$ambiente]['dgii'] . '). El token vence a las ' . date('H:i', strtotime($auth['expira'])) . '.',
                'estado' => 'Conectado el ' . date('d/m/Y H:i'),
            ]);
        } catch (Throwable $e) {
            $mensaje = mb_substr($e->getMessage(), 0, 480);
            DB::actualizar('ecf_conexiones', [
                'estado' => 'error',
                'mensaje' => $mensaje,
                'verificado_en' => date('Y-m-d H:i:s'),
            ], 'id = ?', [$c['id']]);
            Actividad::registrar('fiscal', 'probar', 'ecf_conexiones', (int) $c['id'],
                'Probó la conexión con la DGII en ' . self::AMBIENTES[$ambiente]['nombre'] . ': error');
            registrar_error('e-CF probar ' . $ambiente . ': ' . $e->getMessage());
            json(['ok' => false, 'mensaje' => $mensaje, 'estado' => 'Error']);
        }
    }
}
