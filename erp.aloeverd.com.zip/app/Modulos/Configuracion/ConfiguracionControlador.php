<?php
declare(strict_types=1);

namespace App\Modulos\Configuracion;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\App;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Validar;
use App\Core\View;

final class ConfiguracionControlador
{
    private const CAMPOS_NEGOCIO = [
        'negocio.razon_social', 'negocio.nombre_comercial', 'negocio.rnc', 'negocio.direccion',
        'negocio.telefono', 'negocio.correo', 'negocio.pie_recibo', 'fiscal.itbis',
    ];

    public function inicio(): never
    {
        View::mostrar('configuracion/inicio', [
            'titulo' => 'Configuración',
            'migas' => ['Configuración' => null],
            'ajustes' => Ajustes::todos(),
            'sedes' => (int) DB::valor('SELECT COUNT(*) FROM sedes WHERE activa = 1'),
            'secuencias' => (int) DB::valor('SELECT COUNT(*) FROM secuencias_ncf WHERE activa = 1'),
        ]);
    }

    public function negocio(): never
    {
        View::mostrar('configuracion/negocio', [
            'titulo' => 'Datos del negocio',
            'migas' => ['Configuración' => '/configuracion', 'Datos del negocio' => null],
            'ajustes' => Ajustes::todos(),
        ]);
    }

    public function guardarNegocio(): never
    {
        $nuevos = [];
        foreach (self::CAMPOS_NEGOCIO as $c) {
            $nuevos[$c] = post(str_replace('.', '_', $c));
        }
        $nuevos['negocio.rnc'] = Validar::soloDigitos($nuevos['negocio.rnc']);

        $error = match (true) {
            $nuevos['negocio.nombre_comercial'] === '' => 'Escribe el nombre comercial.',
            $nuevos['negocio.rnc'] !== '' && !Validar::rncOCedula($nuevos['negocio.rnc'])
                => 'El RNC no es válido. Debe tener 9 dígitos (o 11 si es cédula) y su dígito verificador correcto.',
            $nuevos['negocio.correo'] !== '' && !Validar::email($nuevos['negocio.correo']) => 'El correo no es válido.',
            !is_numeric($nuevos['fiscal.itbis']) || (float) $nuevos['fiscal.itbis'] < 0 || (float) $nuevos['fiscal.itbis'] > 30
                => 'La tasa de ITBIS debe ser un número entre 0 y 30.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir('/configuracion/negocio');
        }

        $antes = array_intersect_key(Ajustes::todos(), $nuevos);
        DB::tx(function () use ($nuevos) {
            foreach ($nuevos as $c => $v) {
                Ajustes::set($c, $v);
            }
        });
        [$a, $d] = Actividad::diferencias($antes, $nuevos);
        if ($d) {
            Actividad::registrar('configuracion', 'editar', 'configuracion', null, 'Editó los datos del negocio', $a, $d);
        }
        Flash::ok('Datos del negocio guardados.');
        redirigir('/configuracion/negocio');
    }

    public function sedes(): never
    {
        View::mostrar('configuracion/sedes', [
            'titulo' => 'Sedes',
            'migas' => ['Configuración' => '/configuracion', 'Sedes' => null],
            'sedes' => DB::todos('SELECT * FROM sedes ORDER BY activa DESC, nombre'),
        ]);
    }

    private function datosSede(string $volver, int $id = 0): array
    {
        $d = [
            'nombre' => post('nombre'),
            'direccion' => post('direccion') ?: null,
            'telefono' => post('telefono') ?: null,
        ];
        if ($d['nombre'] === '') {
            Flash::error('Escribe el nombre de la sede.');
            redirigir($volver);
        }
        if (DB::valor('SELECT id FROM sedes WHERE nombre = ? AND id <> ?', [$d['nombre'], $id])) {
            Flash::error('Ya existe una sede con ese nombre.');
            redirigir($volver);
        }
        return $d;
    }

    public function crearSede(): never
    {
        $d = $this->datosSede('/configuracion/sedes');
        $id = DB::insertar('sedes', $d);
        Actividad::registrar('configuracion', 'crear', 'sedes', $id, 'Creó la sede ' . $d['nombre'], null, $d);
        Flash::ok('Sede creada.');
        redirigir('/configuracion/sedes');
    }

    public function guardarSede(string $id): never
    {
        $antes = DB::uno('SELECT * FROM sedes WHERE id = ?', [(int) $id]);
        if (!$antes) {
            App::error(404);
        }
        $d = $this->datosSede('/configuracion/sedes', (int) $id);
        $d['activa'] = post('activa') === '1' ? 1 : 0;
        if ($d['activa'] === 0 && (int) DB::valor('SELECT COUNT(*) FROM sedes WHERE activa = 1 AND id <> ?', [(int) $id]) === 0) {
            Flash::error('Debe quedar al menos una sede activa.');
            redirigir('/configuracion/sedes');
        }
        DB::actualizar('sedes', $d, 'id = ?', [(int) $id]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('configuracion', 'editar', 'sedes', (int) $id, 'Editó la sede ' . $d['nombre'], $a, $dd);
        }
        Flash::ok('Sede guardada.');
        redirigir('/configuracion/sedes');
    }
}
