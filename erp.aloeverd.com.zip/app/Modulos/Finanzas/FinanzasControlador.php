<?php
declare(strict_types=1);

namespace App\Modulos\Finanzas;

use App\Core\Actividad;
use App\Core\App;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Ncf;
use App\Core\View;
use App\Modulos\Agenda\AgendaServicio;
use App\Modulos\Finanzas\FinanzasServicio as F;
use App\Modulos\Inventario\InventarioServicio as I;

final class FinanzasControlador
{
    private function periodo(): string
    {
        $p = get('mes');
        return F::periodoValido($p) ? $p : date('Y-m');
    }

    private function fechaValida(string $f): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $f);
        return $d !== false && $d->format('Y-m-d') === $f;
    }

    /* ======================= Resumen ======================= */

    public function resumen(): never
    {
        $p = $this->periodo();
        [$desde, $hasta] = F::rangoPeriodo($p);
        $anterior = date('Y-m', strtotime("$p-01 -1 month"));
        [$ad, $ah] = F::rangoPeriodo($anterior);
        View::mostrar('finanzas/resumen', [
            'titulo' => 'Finanzas',
            'migas' => ['Finanzas' => null],
            'p' => $p,
            't' => F::totales($desde, $hasta),
            'ant' => F::totales($ad, $ah),
            'porLinea' => F::porLinea($desde, $hasta),
            'porCategoria' => F::porCategoria($desde, $hasta),
            'saldoCaja' => F::saldoCaja(),
            'meta' => F::meta($p),
            'ultimos' => DB::todos(
                "(SELECT 'ingreso' AS clase, id, fecha, concepto AS texto, monto, creado_en FROM ingresos WHERE anulado = 0 AND fecha BETWEEN ? AND ?)
                 UNION ALL
                 (SELECT 'gasto', id, fecha, descripcion, monto, creado_en FROM gastos WHERE anulado = 0 AND fecha BETWEEN ? AND ?)
                 ORDER BY fecha DESC, creado_en DESC LIMIT 8",
                [$desde, $hasta, $desde, $hasta]
            ),
        ]);
    }

    /* ======================= Ingresos ======================= */

    private function filtrosIngresos(): array
    {
        $donde = ['1 = 1'];
        $params = [];
        $desde = $this->fechaValida(get('desde')) ? get('desde') : date('Y-m-01');
        $hasta = $this->fechaValida(get('hasta')) ? get('hasta') : date('Y-m-t');
        $donde[] = 'i.fecha BETWEEN ? AND ?';
        array_push($params, $desde, $hasta);
        if (isset(F::LINEAS[$l = get('linea')])) {
            $donde[] = 'i.linea_negocio = ?';
            $params[] = $l;
        }
        if (isset(AgendaServicio::METODOS[$m = get('metodo')])) {
            $donde[] = 'i.metodo = ?';
            $params[] = $m;
        }
        if (get('anulados') !== '1') {
            $donde[] = 'i.anulado = 0';
        }
        return [implode(' AND ', $donde), $params, $desde, $hasta];
    }

    public function ingresos(): never
    {
        [$where, $params, $desde, $hasta] = $this->filtrosIngresos();
        $filas = DB::todos(
            "SELECT i.*, c.nombre AS cliente, u.nombre AS usuario FROM ingresos i
               LEFT JOIN clientes c ON c.id = i.cliente_id LEFT JOIN usuarios u ON u.id = i.usuario_id
              WHERE $where ORDER BY i.fecha DESC, i.id DESC LIMIT 500",
            $params
        );
        if (get('formato') === 'csv') {
            $this->csv('ingresos', ['Fecha', 'Concepto', 'Línea', 'Método', 'Monto', 'Origen', 'Cliente', 'Referencia', 'Anulado', 'Usuario'],
                array_map(static fn($f) => [$f['fecha'], $f['concepto'], F::LINEAS[$f['linea_negocio']], $f['metodo'], $f['monto'], $f['origen_tipo'], $f['cliente'], $f['referencia'], $f['anulado'] ? 'Sí' : '', $f['usuario']], $filas));
        }
        View::mostrar('finanzas/ingresos', [
            'titulo' => 'Ingresos',
            'migas' => ['Finanzas' => '/finanzas', 'Ingresos' => null],
            'filas' => $filas,
            'desde' => $desde,
            'hasta' => $hasta,
            'total' => array_sum(array_map(static fn($f) => $f['anulado'] ? 0 : (float) $f['monto'], $filas)),
        ]);
    }

    public function crearIngreso(): never
    {
        $d = [
            'fecha' => post('fecha'),
            'concepto' => post('concepto'),
            'linea_negocio' => isset(F::LINEAS[post('linea_negocio')]) ? post('linea_negocio') : 'otros',
            'monto' => I::numero(post('monto')),
            'metodo' => isset(AgendaServicio::METODOS[post('metodo')]) ? post('metodo') : 'efectivo',
            'referencia' => post('referencia') ?: null,
            'origen_tipo' => 'manual',
            'usuario_id' => Auth::id(),
        ];
        $error = match (true) {
            !$this->fechaValida($d['fecha']) => 'Elige la fecha.',
            $d['concepto'] === '' => 'Escribe el concepto.',
            is_nan($d['monto']) || $d['monto'] <= 0 => 'Escribe un monto mayor que cero.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir('/finanzas/ingresos');
        }
        $id = DB::insertar('ingresos', $d);
        Actividad::registrar('finanzas', 'crear', 'ingresos', $id, 'Registró ingreso de ' . dinero($d['monto']) . ': ' . $d['concepto'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Ingreso registrado.');
        redirigir('/finanzas/ingresos');
    }

    public function anularIngreso(string $id): never
    {
        $i = DB::uno('SELECT * FROM ingresos WHERE id = ?', [(int) $id]) ?? App::error(404);
        $motivo = post('motivo');
        if ($i['anulado'] || $motivo === '') {
            Flash::error('Escribe el motivo para anular.');
            redirigir('/finanzas/ingresos');
        }
        if ($i['origen_tipo'] === 'venta') {
            Flash::error('Los ingresos de ventas se anulan anulando la venta en la caja.');
            redirigir('/finanzas/ingresos');
        }
        DB::tx(function () use ($i, $motivo) {
            DB::actualizar('ingresos', ['anulado' => 1, 'motivo_anulacion' => $motivo], 'id = ?', [$i['id']]);
            if ($i['origen_tipo'] === 'reserva' && $i['origen_id']) {
                DB::q('UPDATE reservas SET pagado = GREATEST(0, pagado - ?) WHERE id = ?', [$i['monto'], $i['origen_id']]);
            }
        });
        Actividad::registrar('finanzas', 'anular', 'ingresos', (int) $i['id'], 'Anuló el ingreso de ' . dinero($i['monto']) . " ({$i['concepto']}): $motivo");
        Flash::ok('Ingreso anulado.' . ($i['origen_tipo'] === 'reserva' ? ' La reserva vuelve a quedar con saldo pendiente.' : ''));
        redirigir('/finanzas/ingresos');
    }

    /* ======================= Gastos ======================= */

    public function gastos(): never
    {
        $desde = $this->fechaValida(get('desde')) ? get('desde') : date('Y-m-01');
        $hasta = $this->fechaValida(get('hasta')) ? get('hasta') : date('Y-m-t');
        $donde = ['g.fecha BETWEEN ? AND ?'];
        $params = [$desde, $hasta];
        if (in_array($t = get('tipo'), ['fijo', 'variable'], true)) {
            $donde[] = 'g.tipo = ?';
            $params[] = $t;
        }
        if (($c = get('categoria')) !== '') {
            $donde[] = 'g.categoria = ?';
            $params[] = $c;
        }
        if (get('anulados') !== '1') {
            $donde[] = 'g.anulado = 0';
        }
        $filas = DB::todos(
            'SELECT g.*, p.nombre AS proveedor, p.rnc AS proveedor_rnc, u.nombre AS usuario FROM gastos g
               LEFT JOIN proveedores p ON p.id = g.proveedor_id LEFT JOIN usuarios u ON u.id = g.usuario_id
              WHERE ' . implode(' AND ', $donde) . ' ORDER BY g.fecha DESC, g.id DESC LIMIT 500',
            $params
        );
        if (get('formato') === 'csv') {
            $this->csv('gastos', ['Fecha', 'Tipo', 'Categoría', 'Descripción', 'Proveedor', 'RNC proveedor', 'NCF', 'Monto', 'ITBIS', 'Método', 'Anulado', 'Usuario'],
                array_map(static fn($f) => [$f['fecha'], $f['tipo'], $f['categoria'], $f['descripcion'], $f['proveedor'], $f['proveedor_rnc'], $f['ncf_proveedor'], $f['monto'], $f['itbis'], $f['metodo'], $f['anulado'] ? 'Sí' : '', $f['usuario']], $filas));
        }
        View::mostrar('finanzas/gastos', [
            'titulo' => 'Gastos',
            'migas' => ['Finanzas' => '/finanzas', 'Gastos' => null],
            'filas' => $filas,
            'desde' => $desde,
            'hasta' => $hasta,
            'categorias' => F::categoriasGasto(),
            'proveedores' => DB::todos('SELECT id, nombre FROM proveedores WHERE activo = 1 ORDER BY nombre'),
            'total' => array_sum(array_map(static fn($f) => $f['anulado'] ? 0 : (float) $f['monto'], $filas)),
        ]);
    }

    public function crearGasto(): never
    {
        $ncf = mb_strtoupper(str_replace([' ', '-'], '', post('ncf_proveedor')));
        $d = [
            'fecha' => post('fecha'),
            'tipo' => post('tipo') === 'fijo' ? 'fijo' : 'variable',
            'categoria' => in_array(post('categoria'), F::categoriasGasto(), true) ? post('categoria') : '',
            'descripcion' => post('descripcion'),
            'proveedor_id' => (int) post('proveedor_id') ?: null,
            'monto' => I::numero(post('monto')),
            'itbis' => I::numero(post('itbis', '0') ?: '0'),
            'ncf_proveedor' => $ncf ?: null,
            'metodo' => isset(F::METODOS_GASTO[post('metodo')]) ? post('metodo') : 'transferencia',
            'usuario_id' => Auth::id(),
        ];
        $error = match (true) {
            !$this->fechaValida($d['fecha']) => 'Elige la fecha.',
            $d['descripcion'] === '' => 'Escribe en qué se gastó.',
            $d['categoria'] === '' => 'Elige la categoría del gasto.',
            is_nan($d['monto']) || $d['monto'] <= 0 => 'Escribe un monto mayor que cero.',
            is_nan($d['itbis']) || $d['itbis'] < 0 || $d['itbis'] > $d['monto'] => 'El ITBIS no puede ser mayor que el monto.',
            $d['ncf_proveedor'] !== null && !Ncf::valido($d['ncf_proveedor']) => 'El NCF del proveedor no tiene un formato válido (11 caracteres B o 13 caracteres E).',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir('/finanzas/gastos');
        }
        $id = DB::insertar('gastos', $d);
        Actividad::registrar('finanzas', 'crear', 'gastos', $id, 'Registró gasto de ' . dinero($d['monto']) . ': ' . $d['descripcion'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Gasto registrado.');
        redirigir('/finanzas/gastos');
    }

    public function anularGasto(string $id): never
    {
        $g = DB::uno('SELECT * FROM gastos WHERE id = ?', [(int) $id]) ?? App::error(404);
        $motivo = post('motivo');
        if ($g['anulado'] || $motivo === '') {
            Flash::error('Escribe el motivo para anular.');
            redirigir('/finanzas/gastos');
        }
        DB::actualizar('gastos', ['anulado' => 1, 'motivo_anulacion' => $motivo], 'id = ?', [$g['id']]);
        Actividad::registrar('finanzas', 'anular', 'gastos', (int) $g['id'], 'Anuló el gasto de ' . dinero($g['monto']) . " ({$g['descripcion']}): $motivo");
        Flash::ok('Gasto anulado.');
        redirigir('/finanzas/gastos');
    }

    /* ======================= Reserva de caja ======================= */

    public function caja(): never
    {
        View::mostrar('finanzas/caja', [
            'titulo' => 'Reserva de caja',
            'migas' => ['Finanzas' => '/finanzas', 'Reserva de caja' => null],
            'saldo' => F::saldoCaja(),
            'filas' => DB::todos('SELECT rc.*, u.nombre AS usuario FROM reserva_caja rc LEFT JOIN usuarios u ON u.id = rc.usuario_id ORDER BY rc.fecha DESC, rc.id DESC LIMIT 200'),
        ]);
    }

    public function movimientoCaja(): never
    {
        $d = [
            'fecha' => post('fecha'),
            'tipo' => post('tipo') === 'salida' ? 'salida' : 'entrada',
            'monto' => I::numero(post('monto')),
            'nota' => post('nota'),
            'usuario_id' => Auth::id(),
        ];
        $error = match (true) {
            !$this->fechaValida($d['fecha']) => 'Elige la fecha.',
            is_nan($d['monto']) || $d['monto'] <= 0 => 'Escribe un monto mayor que cero.',
            $d['nota'] === '' => 'Escribe una nota.',
            $d['tipo'] === 'salida' && $d['monto'] > F::saldoCaja() => 'La reserva no tiene saldo suficiente.',
            default => null,
        };
        if ($error) {
            Flash::error($error);
            redirigir('/finanzas/caja');
        }
        $id = DB::insertar('reserva_caja', $d);
        Actividad::registrar('finanzas', $d['tipo'], 'reserva_caja', $id, ucfirst($d['tipo']) . ' de reserva de caja por ' . dinero($d['monto']) . ': ' . $d['nota']);
        Flash::ok('Movimiento registrado. Saldo: ' . dinero(F::saldoCaja()) . '.');
        redirigir('/finanzas/caja');
    }

    /* ======================= Reportes y metas ======================= */

    public function reportes(): never
    {
        $p = $this->periodo();
        [$desde, $hasta] = F::rangoPeriodo($p);
        $anioAnterior = date('Y-m', strtotime("$p-01 -1 year"));
        [$yd, $yh] = F::rangoPeriodo($anioAnterior);
        View::mostrar('finanzas/reportes', [
            'titulo' => 'Reportes financieros',
            'migas' => ['Finanzas' => '/finanzas', 'Reportes y metas' => null],
            'p' => $p,
            't' => F::totales($desde, $hasta),
            'tAnio' => F::totales($yd, $yh),
            'serie' => F::serie($p, 6),
            'porLinea' => F::porLinea($desde, $hasta),
            'porCategoria' => F::porCategoria($desde, $hasta),
            'meta' => F::meta($p),
        ]);
    }

    public function guardarMeta(): never
    {
        $p = post('periodo');
        if (!F::periodoValido($p)) {
            Flash::error('Periodo inválido.');
            redirigir('/finanzas/reportes');
        }
        $num = static function (string $v, float $max) {
            if ($v === '') {
                return null;
            }
            $n = I::numero($v);
            return is_nan($n) || $n < 0 || $n > $max ? false : $n;
        };
        $d = [
            'meta_ingresos' => $num(post('meta_ingresos'), 1e10),
            'meta_ocupacion' => $num(post('meta_ocupacion'), 100),
            'meta_recurrentes' => $num(post('meta_recurrentes'), 100),
        ];
        if (in_array(false, $d, true)) {
            Flash::error('Revisa las metas: los porcentajes van de 0 a 100.');
            redirigir('/finanzas/reportes?mes=' . $p);
        }
        $antes = F::meta($p);
        DB::q(
            'INSERT INTO metas (periodo, meta_ingresos, meta_ocupacion, meta_recurrentes) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE meta_ingresos = VALUES(meta_ingresos), meta_ocupacion = VALUES(meta_ocupacion), meta_recurrentes = VALUES(meta_recurrentes)',
            [$p, $d['meta_ingresos'], $d['meta_ocupacion'], $d['meta_recurrentes']]
        );
        Actividad::registrar('finanzas', 'configurar', 'metas', null, 'Guardó las metas de ' . F::nombrePeriodo($p), $antes, $d);
        Flash::ok('Metas de ' . F::nombrePeriodo($p) . ' guardadas.');
        redirigir('/finanzas/reportes?mes=' . $p);
    }

    private function csv(string $nombre, array $cabecera, array $filas): never
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nombre . '-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, $cabecera);
        foreach ($filas as $f) {
            fputcsv($out, array_map(static fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $f));
        }
        fclose($out);
        exit;
    }
}
