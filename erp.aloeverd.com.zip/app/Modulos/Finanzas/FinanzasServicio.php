<?php
declare(strict_types=1);

namespace App\Modulos\Finanzas;

use App\Core\Ajustes;
use App\Core\DB;

final class FinanzasServicio
{
    public const LINEAS = [
        'privados' => 'Privados',
        'corporativo' => 'Corporativo',
        'experiencias' => 'Experiencias',
        'formacion' => 'Formación',
        'turismo' => 'Turismo',
        'tienda' => 'Tienda (POS)',
        'otros' => 'Otros',
    ];

    public const METODOS_GASTO = [
        'transferencia' => 'Transferencia',
        'efectivo' => 'Efectivo',
        'tarjeta' => 'Tarjeta',
        'cheque' => 'Cheque',
        'otro' => 'Otro',
    ];

    public const MESES = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    public const MESES_CORTOS = ['', 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

    public static function categoriasGasto(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) Ajustes::get('finanzas.categorias_gasto', 'Otros')))));
    }

    public static function periodoValido(string $p): bool
    {
        return (bool) preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $p);
    }

    public static function nombrePeriodo(string $p): string
    {
        [$a, $m] = explode('-', $p);
        return self::MESES[(int) $m] . ' ' . $a;
    }

    /** Totales de un rango de fechas. */
    public static function totales(string $desde, string $hasta): array
    {
        $ing = (float) DB::valor('SELECT COALESCE(SUM(monto),0) FROM ingresos WHERE anulado = 0 AND fecha BETWEEN ? AND ?', [$desde, $hasta]);
        $g = DB::uno(
            "SELECT COALESCE(SUM(CASE WHEN tipo = 'fijo' THEN monto END),0) AS fijos,
                    COALESCE(SUM(CASE WHEN tipo = 'variable' THEN monto END),0) AS variables
               FROM gastos WHERE anulado = 0 AND fecha BETWEEN ? AND ?",
            [$desde, $hasta]
        );
        $fijos = (float) $g['fijos'];
        $variables = (float) $g['variables'];
        $gastos = $fijos + $variables;
        $contribucion = $ing > 0 ? ($ing - $variables) / $ing : null; // margen de contribución
        return [
            'ingresos' => $ing,
            'fijos' => $fijos,
            'variables' => $variables,
            'gastos' => $gastos,
            'neto' => $ing - $gastos,
            'margen' => $ing > 0 ? ($ing - $gastos) / $ing * 100 : null,
            'equilibrio' => $contribucion !== null && $contribucion > 0 ? $fijos / $contribucion : null,
        ];
    }

    public static function rangoPeriodo(string $p): array
    {
        $ini = $p . '-01';
        return [$ini, date('Y-m-t', strtotime($ini))];
    }

    /** Ingresos y gastos de los últimos N meses hasta $p (incluido). */
    public static function serie(string $p, int $meses = 6): array
    {
        $serie = [];
        for ($i = $meses - 1; $i >= 0; $i--) {
            $per = date('Y-m', strtotime("$p-01 -$i month"));
            [$d, $h] = self::rangoPeriodo($per);
            $t = self::totales($d, $h);
            $serie[] = ['periodo' => $per, 'etiqueta' => self::MESES_CORTOS[(int) substr($per, 5)] . ' ' . substr($per, 2, 2), 'ingresos' => $t['ingresos'], 'gastos' => $t['gastos']];
        }
        return $serie;
    }

    public static function porLinea(string $desde, string $hasta): array
    {
        return DB::todos(
            'SELECT linea_negocio, SUM(monto) AS total, COUNT(*) AS n FROM ingresos WHERE anulado = 0 AND fecha BETWEEN ? AND ?
              GROUP BY linea_negocio ORDER BY total DESC',
            [$desde, $hasta]
        );
    }

    public static function porCategoria(string $desde, string $hasta): array
    {
        return DB::todos(
            'SELECT categoria, tipo, SUM(monto) AS total FROM gastos WHERE anulado = 0 AND fecha BETWEEN ? AND ?
              GROUP BY categoria, tipo ORDER BY total DESC',
            [$desde, $hasta]
        );
    }

    public static function saldoCaja(): float
    {
        return (float) DB::valor("SELECT COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN monto ELSE -monto END),0) FROM reserva_caja");
    }

    public static function meta(string $p): ?array
    {
        return DB::uno('SELECT * FROM metas WHERE periodo = ?', [$p]);
    }
}
