<?php
declare(strict_types=1);

namespace App\Modulos\Inventario;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\App;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Validar;
use App\Core\View;
use App\Modulos\Inventario\InventarioServicio as I;
use Throwable;

final class InventarioControlador
{
    private const POR_PAGINA = 30;

    private function proveedores(): array
    {
        return DB::todos('SELECT id, nombre FROM proveedores WHERE activo = 1 ORDER BY nombre');
    }

    private function itbis(): float
    {
        return (float) Ajustes::get('fiscal.itbis', '18');
    }

    /* ======================= Materiales ======================= */

    public function materiales(): never
    {
        $donde = ['m.activo = ?'];
        $params = [get('estado') === 'inactivos' ? 0 : 1];
        if (($q = get('q')) !== '') {
            $donde[] = '(m.nombre LIKE ? OR m.codigo LIKE ?)';
            array_push($params, "%$q%", "%$q%");
        }
        if (($cat = get('categoria')) !== '') {
            $donde[] = 'm.categoria = ?';
            $params[] = $cat;
        }
        if (get('bajo') === '1') {
            $donde[] = 'm.stock_minimo > 0 AND m.stock <= m.stock_minimo';
        }
        $where = implode(' AND ', $donde);
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) FROM materiales m WHERE $where", $params);
        $filas = DB::todos(
            "SELECT m.*, p.nombre AS proveedor FROM materiales m LEFT JOIN proveedores p ON p.id = m.proveedor_id
              WHERE $where ORDER BY m.nombre LIMIT " . self::POR_PAGINA . ' OFFSET ' . (($pagina - 1) * self::POR_PAGINA),
            $params
        );
        View::mostrar('inventario/materiales', [
            'titulo' => 'Materiales',
            'migas' => ['Inventario' => '/inventario', 'Materiales' => null],
            'filas' => $filas,
            'categorias' => I::categorias(),
            'valor' => (float) DB::valor('SELECT COALESCE(SUM(stock * costo_unitario),0) FROM materiales WHERE activo = 1'),
            'bajos' => (int) DB::valor('SELECT COUNT(*) FROM materiales WHERE activo = 1 AND stock_minimo > 0 AND stock <= stock_minimo'),
            'activos' => (int) DB::valor('SELECT COUNT(*) FROM materiales WHERE activo = 1'),
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function nuevoMaterial(): never
    {
        View::mostrar('inventario/material_form', [
            'titulo' => 'Nuevo material',
            'migas' => ['Inventario' => '/inventario', 'Nuevo material' => null],
            'm' => null,
            'categorias' => I::categorias(),
            'unidades' => I::unidades(),
            'proveedores' => $this->proveedores(),
        ]);
    }

    public function editarMaterial(string $id): never
    {
        $m = DB::uno('SELECT * FROM materiales WHERE id = ?', [(int) $id]) ?? App::error(404);
        View::mostrar('inventario/material_form', [
            'titulo' => 'Editar material',
            'migas' => ['Inventario' => '/inventario', $m['nombre'] => null],
            'm' => $m,
            'categorias' => I::categorias(),
            'unidades' => I::unidades(),
            'proveedores' => $this->proveedores(),
            'movimientos' => DB::todos(
                "SELECT mv.*, u.nombre AS usuario FROM movimientos_inventario mv LEFT JOIN usuarios u ON u.id = mv.usuario_id
                  WHERE mv.tipo_item = 'material' AND mv.item_id = ? ORDER BY mv.fecha DESC, mv.id DESC LIMIT 15",
                [$m['id']]
            ),
            'productosLigados' => DB::todos('SELECT id, nombre FROM productos WHERE material_id = ? AND activo = 1', [$m['id']]),
        ]);
    }

    private function codigoAuto(string $tabla, string $columna, string $prefijo): string
    {
        $prefijo = strtoupper(substr(preg_replace('/[^A-Za-z]/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $prefijo)) ?: 'ART', 0, 4));
        $n = (int) DB::valor("SELECT COUNT(*) FROM `$tabla` WHERE `$columna` LIKE ?", [$prefijo . '-%']) + 1;
        do {
            $codigo = sprintf('%s-%03d', $prefijo, $n++);
        } while (DB::valor("SELECT id FROM `$tabla` WHERE `$columna` = ?", [$codigo]));
        return $codigo;
    }

    private function datosMaterial(?int $id): array
    {
        $volver = $id ? "/inventario/materiales/$id" : '/inventario/materiales/nuevo';
        $d = [
            'codigo' => mb_strtoupper(post('codigo')),
            'nombre' => post('nombre'),
            'categoria' => post('categoria') ?: 'Otros',
            'unidad' => post('unidad') ?: 'Unidad',
            'stock_minimo' => I::numero(post('stock_minimo', '0') ?: '0'),
            'costo_unitario' => I::numero(post('costo_unitario', '0') ?: '0'),
            'proveedor_id' => (int) post('proveedor_id') ?: null,
            'descripcion' => post('descripcion') ?: null,
        ];
        if ($d['codigo'] === '') {
            $d['codigo'] = $this->codigoAuto('materiales', 'codigo', $d['categoria']);
        }
        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre del material.',
            !preg_match('/^[A-Z0-9\-_.]{2,40}$/', $d['codigo']) => 'El código solo puede tener letras, números y guiones.',
            is_nan($d['stock_minimo']) || $d['stock_minimo'] < 0 => 'El stock mínimo debe ser un número igual o mayor a cero.',
            is_nan($d['costo_unitario']) || $d['costo_unitario'] < 0 => 'El costo debe ser un número igual o mayor a cero.',
            (bool) DB::valor('SELECT id FROM materiales WHERE codigo = ? AND id <> ?', [$d['codigo'], $id ?? 0]) => 'Ya existe un material con ese código.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        return $d;
    }

    public function crearMaterial(): never
    {
        $d = $this->datosMaterial(null);
        $inicial = I::numero(post('stock_inicial', '0') ?: '0');
        if (is_nan($inicial) || $inicial < 0) {
            Flash::recordarFormulario();
            Flash::error('El stock inicial debe ser un número igual o mayor a cero.');
            redirigir('/inventario/materiales/nuevo');
        }
        $id = DB::tx(function () use ($d, $inicial) {
            $id = DB::insertar('materiales', [...$d, 'stock' => 0]);
            if ($inicial > 0) {
                I::mover('material', $id, 'inicial', $inicial, ['costo_unitario' => $d['costo_unitario'] ?: null, 'motivo' => 'Stock inicial al crear']);
            }
            return $id;
        });
        Actividad::registrar('inventario', 'crear', 'materiales', $id, 'Creó el material ' . $d['nombre'] . ' con ' . I::fmt($inicial) . ' ' . $d['unidad'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Material creado.');
        redirigir('/inventario');
    }

    public function guardarMaterial(string $id): never
    {
        $antes = DB::uno('SELECT * FROM materiales WHERE id = ?', [(int) $id]) ?? App::error(404);
        $d = $this->datosMaterial((int) $id);
        $d['activo'] = post('activo') === '1' ? 1 : 0;
        DB::actualizar('materiales', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('inventario', 'editar', 'materiales', (int) $antes['id'], 'Editó el material ' . $d['nombre'], $a, $dd);
        }
        Flash::limpiarFormulario();
        Flash::ok('Material guardado.');
        redirigir('/inventario');
    }

    /* ======================= Productos ======================= */

    public function productos(): never
    {
        $donde = ['p.activo = ?'];
        $params = [get('estado') === 'inactivos' ? 0 : 1];
        if (($q = get('q')) !== '') {
            $donde[] = '(p.nombre LIKE ? OR p.sku LIKE ?)';
            array_push($params, "%$q%", "%$q%");
        }
        if (($cat = get('categoria')) !== '') {
            $donde[] = 'p.categoria = ?';
            $params[] = $cat;
        }
        $where = implode(' AND ', $donde);
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) FROM productos p WHERE $where", $params);
        $filas = DB::todos(
            "SELECT p.*, m.nombre AS material, m.stock AS material_stock, m.unidad AS material_unidad
               FROM productos p LEFT JOIN materiales m ON m.id = p.material_id
              WHERE $where ORDER BY p.categoria, p.nombre LIMIT " . self::POR_PAGINA . ' OFFSET ' . (($pagina - 1) * self::POR_PAGINA),
            $params
        );
        View::mostrar('inventario/productos', [
            'titulo' => 'Productos de venta',
            'migas' => ['Inventario' => '/inventario', 'Productos de venta' => null],
            'filas' => $filas,
            'categorias' => I::categorias(),
            'itbis' => $this->itbis(),
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    private function vistaProducto(?array $p): never
    {
        View::mostrar('inventario/producto_form', [
            'titulo' => $p ? 'Editar producto' : 'Nuevo producto',
            'migas' => ['Inventario' => '/inventario', 'Productos' => '/inventario/productos', $p ? $p['nombre'] : 'Nuevo' => null],
            'p' => $p,
            'categorias' => I::categorias(),
            'materiales' => DB::todos('SELECT id, codigo, nombre, unidad, stock FROM materiales WHERE activo = 1 ORDER BY nombre'),
            'itbis' => $this->itbis(),
        ]);
    }

    public function nuevoProducto(): never
    {
        $this->vistaProducto(null);
    }

    public function editarProducto(string $id): never
    {
        $this->vistaProducto(DB::uno('SELECT * FROM productos WHERE id = ?', [(int) $id]) ?? App::error(404));
    }

    private function datosProducto(?int $id): array
    {
        $volver = $id ? "/inventario/productos/$id" : '/inventario/productos/nuevo';
        $control = post('control_stock', 'propio');
        $control = in_array($control, ['ninguno', 'propio', 'material'], true) ? $control : 'propio';
        $precioTexto = post('precio');
        $precio = I::numero($precioTexto);
        // El precio puede escribirse con ITBIS incluido; se guarda sin ITBIS
        if (!is_nan($precio) && post('precio_con_itbis') === '1' && post('lleva_itbis') === '1') {
            $precio = round($precio / (1 + $this->itbis() / 100), 2);
        }
        $d = [
            'sku' => mb_strtoupper(post('sku')),
            'nombre' => post('nombre'),
            'categoria' => post('categoria') ?: 'Otros',
            'descripcion' => post('descripcion') ?: null,
            'precio' => is_nan($precio) ? NAN : round($precio, 2),
            'lleva_itbis' => post('lleva_itbis') === '1' ? 1 : 0,
            'costo' => post('costo') === '' ? null : I::numero(post('costo')),
            'control_stock' => $control,
            'material_id' => $control === 'material' ? ((int) post('material_id') ?: null) : null,
            'factor_material' => $control === 'material' ? I::numero(post('factor_material', '1') ?: '1') : null,
            'stock_minimo' => $control === 'propio' ? I::numero(post('stock_minimo', '0') ?: '0') : 0,
        ];
        if ($d['sku'] === '') {
            $d['sku'] = $this->codigoAuto('productos', 'sku', $d['categoria']);
        }
        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre del producto.',
            !preg_match('/^[A-Z0-9\-_.]{2,40}$/', $d['sku']) => 'El código solo puede tener letras, números y guiones.',
            is_nan($d['precio']) || $d['precio'] < 0 => 'Escribe un precio válido.',
            $d['costo'] !== null && (is_nan($d['costo']) || $d['costo'] < 0) => 'El costo debe ser un número válido.',
            $control === 'material' && !$d['material_id'] => 'Elige el material del que se descuenta.',
            $control === 'material' && (is_nan($d['factor_material']) || $d['factor_material'] <= 0) => 'Indica cuánto material consume cada unidad vendida.',
            $control === 'propio' && (is_nan($d['stock_minimo']) || $d['stock_minimo'] < 0) => 'El stock mínimo debe ser un número válido.',
            (bool) DB::valor('SELECT id FROM productos WHERE sku = ? AND id <> ?', [$d['sku'], $id ?? 0]) => 'Ya existe un producto con ese código.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        return $d;
    }

    public function crearProducto(): never
    {
        $d = $this->datosProducto(null);
        $inicial = $d['control_stock'] === 'propio' ? I::numero(post('stock_inicial', '0') ?: '0') : 0.0;
        if (is_nan($inicial) || $inicial < 0) {
            Flash::recordarFormulario();
            Flash::error('El stock inicial debe ser un número igual o mayor a cero.');
            redirigir('/inventario/productos/nuevo');
        }
        $id = DB::tx(function () use ($d, $inicial) {
            $id = DB::insertar('productos', [...$d, 'stock' => 0]);
            if ($inicial > 0) {
                I::mover('producto', $id, 'inicial', $inicial, ['costo_unitario' => $d['costo'], 'motivo' => 'Stock inicial al crear']);
            }
            return $id;
        });
        Actividad::registrar('inventario', 'crear', 'productos', $id, 'Creó el producto ' . $d['nombre'] . ' a ' . dinero($d['precio']), null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Producto creado.');
        redirigir('/inventario/productos');
    }

    public function guardarProducto(string $id): never
    {
        $antes = DB::uno('SELECT * FROM productos WHERE id = ?', [(int) $id]) ?? App::error(404);
        $d = $this->datosProducto((int) $id);
        $d['activo'] = post('activo') === '1' ? 1 : 0;
        if ($antes['control_stock'] === 'propio' && $d['control_stock'] !== 'propio' && (float) $antes['stock'] != 0.0) {
            Flash::error('Este producto todavía tiene ' . I::fmt($antes['stock']) . ' unidades en stock propio. Ajusta el stock a cero antes de cambiar cómo se controla.');
            redirigir("/inventario/productos/$id");
        }
        DB::actualizar('productos', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('inventario', 'editar', 'productos', (int) $antes['id'], 'Editó el producto ' . $d['nombre'], $a, $dd);
        }
        Flash::limpiarFormulario();
        Flash::ok('Producto guardado.');
        redirigir('/inventario/productos');
    }

    /* ======================= Movimientos ======================= */

    private function item(string $tipoItem, int $id): array
    {
        $item = match ($tipoItem) {
            'material' => DB::uno('SELECT id, codigo, nombre, unidad, stock, costo_unitario, proveedor_id FROM materiales WHERE id = ?', [$id]),
            'producto' => DB::uno("SELECT id, sku AS codigo, nombre, 'Unidad' AS unidad, stock, costo AS costo_unitario, NULL AS proveedor_id, control_stock FROM productos WHERE id = ?", [$id]),
            default => null,
        };
        if (!$item || ($tipoItem === 'producto' && $item['control_stock'] !== 'propio')) {
            App::error(404);
        }
        return $item;
    }

    public function formularioMovimiento(string $tipoItem, string $id): never
    {
        $item = $this->item($tipoItem, (int) $id);
        View::mostrar('inventario/movimiento_form', [
            'titulo' => 'Movimiento de inventario',
            'migas' => ['Inventario' => '/inventario', $item['nombre'] => null],
            'tipoItem' => $tipoItem,
            'item' => $item,
            'proveedores' => $this->proveedores(),
            'volver' => $tipoItem === 'material' ? '/inventario' : '/inventario/productos',
        ]);
    }

    public function registrarMovimiento(string $tipoItem, string $id): never
    {
        $item = $this->item($tipoItem, (int) $id);
        $volver = "/inventario/movimiento/$tipoItem/{$item['id']}";
        $tipo = post('tipo');
        $cantidad = I::numero(post('cantidad'));
        $motivo = post('motivo');
        $extra = [
            'motivo' => $motivo ?: null,
            'referencia' => post('referencia') ?: null,
            'proveedor_id' => (int) post('proveedor_id') ?: null,
            'costo_unitario' => post('costo_unitario') !== '' && !is_nan(I::numero(post('costo_unitario'))) ? I::numero(post('costo_unitario')) : null,
        ];
        $error = match (true) {
            !in_array($tipo, ['entrada', 'salida', 'ajuste'], true) => 'Elige el tipo de movimiento.',
            is_nan($cantidad) || $cantidad < 0 || ($tipo !== 'ajuste' && $cantidad == 0.0) => 'Escribe una cantidad válida.',
            in_array($tipo, ['salida', 'ajuste'], true) && $motivo === '' => 'Escribe el motivo; queda en el registro.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }
        $delta = match ($tipo) {
            'entrada' => $cantidad,
            'salida' => -$cantidad,
            'ajuste' => round($cantidad - (float) $item['stock'], 3), // en ajuste se escribe el conteo real
        };
        if ($tipo === 'ajuste' && $delta == 0.0) {
            Flash::aviso('El conteo coincide con el sistema; no hubo cambios.');
            redirigir($tipoItem === 'material' ? '/inventario' : '/inventario/productos');
        }
        try {
            $r = DB::tx(fn() => I::mover($tipoItem, (int) $item['id'], $tipo, $delta, $extra));
        } catch (Throwable $e) {
            Flash::recordarFormulario();
            Flash::error($e->getMessage());
            redirigir($volver);
        }
        Actividad::registrar('inventario', $tipo, $tipoItem === 'material' ? 'materiales' : 'productos', (int) $item['id'],
            I::TIPOS[$tipo] . ' de ' . $item['nombre'] . ': ' . I::fmt($r['anterior']) . ' → ' . I::fmt($r['nuevo']) . ' ' . $item['unidad'] . ($motivo ? " ($motivo)" : ''),
            ['stock' => $r['anterior']], ['stock' => $r['nuevo']]);
        Flash::limpiarFormulario();
        Flash::ok('Movimiento registrado. Stock de ' . $item['nombre'] . ': ' . I::fmt($r['nuevo']) . ' ' . $item['unidad'] . '.');
        redirigir($tipoItem === 'material' ? '/inventario' : '/inventario/productos');
    }

    private function filtrosMovimientos(): array
    {
        $donde = ['1 = 1'];
        $params = [];
        if (in_array($t = get('tipo'), array_keys(I::TIPOS), true)) {
            $donde[] = 'mv.tipo = ?';
            $params[] = $t;
        }
        if (in_array($ti = get('articulo'), ['material', 'producto'], true)) {
            $donde[] = 'mv.tipo_item = ?';
            $params[] = $ti;
        }
        if (($q = get('q')) !== '') {
            $donde[] = '(COALESCE(m.nombre, p.nombre) LIKE ? OR COALESCE(m.codigo, p.sku) LIKE ?)';
            array_push($params, "%$q%", "%$q%");
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $d = get('desde'))) {
            $donde[] = 'mv.fecha >= ?';
            $params[] = "$d 00:00:00";
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $h = get('hasta'))) {
            $donde[] = 'mv.fecha <= ?';
            $params[] = "$h 23:59:59";
        }
        return [implode(' AND ', $donde), $params];
    }

    private const SQL_MOV = "FROM movimientos_inventario mv
        LEFT JOIN materiales m ON mv.tipo_item = 'material' AND m.id = mv.item_id
        LEFT JOIN productos p ON mv.tipo_item = 'producto' AND p.id = mv.item_id
        LEFT JOIN usuarios u ON u.id = mv.usuario_id
        LEFT JOIN proveedores pr ON pr.id = mv.proveedor_id";

    public function movimientos(): never
    {
        [$where, $params] = $this->filtrosMovimientos();
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor('SELECT COUNT(*) ' . self::SQL_MOV . " WHERE $where", $params);
        $filas = DB::todos(
            "SELECT mv.*, COALESCE(m.nombre, p.nombre) AS articulo, COALESCE(m.codigo, p.sku) AS codigo,
                    COALESCE(m.unidad, 'Unidad') AS unidad, u.nombre AS usuario, pr.nombre AS proveedor "
            . self::SQL_MOV . " WHERE $where ORDER BY mv.fecha DESC, mv.id DESC LIMIT " . self::POR_PAGINA . ' OFFSET ' . (($pagina - 1) * self::POR_PAGINA),
            $params
        );
        View::mostrar('inventario/movimientos', [
            'titulo' => 'Movimientos de inventario',
            'migas' => ['Inventario' => '/inventario', 'Movimientos' => null],
            'filas' => $filas,
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function exportarMovimientos(): never
    {
        [$where, $params] = $this->filtrosMovimientos();
        $st = DB::q(
            "SELECT mv.fecha, mv.tipo_item, COALESCE(m.codigo, p.sku), COALESCE(m.nombre, p.nombre), mv.tipo, mv.cantidad,
                    mv.stock_anterior, mv.stock_resultante, mv.costo_unitario, pr.nombre, mv.referencia, mv.motivo, u.nombre "
            . self::SQL_MOV . " WHERE $where ORDER BY mv.fecha DESC LIMIT 50000",
            $params
        );
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="movimientos-inventario-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Fecha', 'Artículo', 'Código', 'Nombre', 'Tipo', 'Cantidad', 'Stock anterior', 'Stock resultante', 'Costo unitario', 'Proveedor', 'Referencia', 'Motivo', 'Usuario']);
        while ($f = $st->fetch(\PDO::FETCH_NUM)) {
            $f = array_map(static fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $f);
            fputcsv($out, $f);
        }
        fclose($out);
        exit;
    }

    /* ======================= Proveedores ======================= */

    public function proveedoresLista(): never
    {
        View::mostrar('inventario/proveedores', [
            'titulo' => 'Proveedores',
            'migas' => ['Inventario' => '/inventario', 'Proveedores' => null],
            'filas' => DB::todos(
                'SELECT p.*, (SELECT COUNT(*) FROM materiales m WHERE m.proveedor_id = p.id AND m.activo = 1) AS materiales
                   FROM proveedores p ORDER BY p.activo DESC, p.nombre'
            ),
        ]);
    }

    private function datosProveedor(int $id = 0): array
    {
        $d = [
            'nombre' => post('nombre'),
            'rnc' => Validar::soloDigitos(post('rnc')) ?: null,
            'contacto' => post('contacto') ?: null,
            'telefono' => Validar::soloDigitos(post('telefono')) ?: null,
            'email' => mb_strtolower(post('email')) ?: null,
            'notas' => post('notas') ?: null,
        ];
        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre del proveedor.',
            $d['rnc'] !== null && !Validar::rncOCedula($d['rnc']) => 'El RNC del proveedor no es válido.',
            $d['email'] !== null && !Validar::email($d['email']) => 'El correo no es válido.',
            (bool) DB::valor('SELECT id FROM proveedores WHERE nombre = ? AND id <> ?', [$d['nombre'], $id]) => 'Ya existe un proveedor con ese nombre.',
            default => null,
        };
        if ($error) {
            Flash::error($error);
            redirigir('/inventario/proveedores');
        }
        return $d;
    }

    public function crearProveedor(): never
    {
        $d = $this->datosProveedor();
        $id = DB::insertar('proveedores', $d);
        Actividad::registrar('inventario', 'crear', 'proveedores', $id, 'Creó el proveedor ' . $d['nombre'], null, $d);
        Flash::ok('Proveedor agregado.');
        redirigir('/inventario/proveedores');
    }

    public function guardarProveedor(string $id): never
    {
        $antes = DB::uno('SELECT * FROM proveedores WHERE id = ?', [(int) $id]) ?? App::error(404);
        $d = $this->datosProveedor((int) $id);
        $d['activo'] = post('activo') === '1' ? 1 : 0;
        DB::actualizar('proveedores', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('inventario', 'editar', 'proveedores', (int) $antes['id'], 'Editó el proveedor ' . $d['nombre'], $a, $dd);
        }
        Flash::ok('Proveedor guardado.');
        redirigir('/inventario/proveedores');
    }
}
