<?php
declare(strict_types=1);

namespace App\Modulos\Inventario;

use App\Core\Ajustes;
use App\Core\Auth;
use App\Core\DB;
use RuntimeException;

/**
 * Toda variación de stock pasa por aquí: guarda el movimiento con el stock anterior y el resultante.
 * Lo usan el inventario, el POS (ventas y anulaciones) y la agenda (consumo de sesiones).
 */
final class InventarioServicio
{
    public const TIPOS = [
        'inicial' => 'Stock inicial',
        'entrada' => 'Entrada (compra)',
        'salida' => 'Salida',
        'ajuste' => 'Ajuste por conteo',
        'consumo_sesion' => 'Consumo en sesión',
        'venta' => 'Venta',
        'anulacion_venta' => 'Venta anulada',
    ];

    public static function categorias(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) Ajustes::get('inventario.categorias', 'Otros')))));
    }

    public static function unidades(): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) Ajustes::get('inventario.unidades', 'Unidad')))));
    }

    public static function numero(string $v): float
    {
        $v = str_replace([' ', ','], ['', '.'], trim($v));
        return is_numeric($v) ? (float) $v : NAN;
    }

    /**
     * Registra un movimiento y actualiza el stock. Debe ir dentro de DB::tx().
     * @param float $cantidad positiva suma, negativa resta
     * @param array $extra costo_unitario, proveedor_id, referencia, motivo, sesion_id, venta_id
     */
    public static function mover(string $tipoItem, int $itemId, string $tipo, float $cantidad, array $extra = [], bool $permitirNegativo = false): array
    {
        if (!isset(self::TIPOS[$tipo])) {
            throw new RuntimeException('Tipo de movimiento desconocido.');
        }
        $tabla = match ($tipoItem) {
            'material' => 'materiales',
            'producto' => 'productos',
            default => throw new RuntimeException('Artículo desconocido.'),
        };
        $item = DB::uno("SELECT id, nombre, stock FROM `$tabla` WHERE id = ? FOR UPDATE", [$itemId]);
        if (!$item) {
            throw new RuntimeException('El artículo no existe.');
        }
        $anterior = round((float) $item['stock'], 3);
        $nuevo = round($anterior + $cantidad, 3);
        if ($nuevo < 0 && !$permitirNegativo) {
            throw new RuntimeException(sprintf(
                'No hay suficiente "%s": hay %s y se necesitan %s.',
                $item['nombre'], self::fmt($anterior), self::fmt(abs($cantidad))
            ));
        }
        DB::actualizar($tabla, ['stock' => $nuevo], 'id = ?', [$itemId]);
        if ($tipoItem === 'material' && $tipo === 'entrada' && !empty($extra['costo_unitario'])) {
            DB::actualizar('materiales', ['costo_unitario' => $extra['costo_unitario']], 'id = ?', [$itemId]);
        }
        $id = DB::insertar('movimientos_inventario', [
            'tipo_item' => $tipoItem,
            'item_id' => $itemId,
            'tipo' => $tipo,
            'cantidad' => round($cantidad, 3),
            'stock_anterior' => $anterior,
            'stock_resultante' => $nuevo,
            'costo_unitario' => $extra['costo_unitario'] ?? null,
            'proveedor_id' => $extra['proveedor_id'] ?? null,
            'referencia' => $extra['referencia'] ?? null,
            'motivo' => $extra['motivo'] ?? null,
            'sesion_id' => $extra['sesion_id'] ?? null,
            'venta_id' => $extra['venta_id'] ?? null,
            'usuario_id' => Auth::id(),
            'fecha' => date('Y-m-d H:i:s'),
        ]);
        return ['id' => $id, 'anterior' => $anterior, 'nuevo' => $nuevo, 'nombre' => $item['nombre']];
    }

    /** Descuenta (o devuelve) el stock de un producto vendido, sea propio o de su material. Para el POS. */
    public static function moverProducto(array $producto, float $unidades, string $tipo, array $extra = []): void
    {
        $signo = $tipo === 'anulacion_venta' ? 1 : -1;
        if ($producto['control_stock'] === 'propio') {
            self::mover('producto', (int) $producto['id'], $tipo, $signo * $unidades, $extra);
        } elseif ($producto['control_stock'] === 'material' && $producto['material_id']) {
            self::mover('material', (int) $producto['material_id'], $tipo, $signo * $unidades * (float) $producto['factor_material'], $extra);
        }
    }

    public static function fmt(float|string|null $n): string
    {
        $n = (float) $n;
        return rtrim(rtrim(number_format($n, 3, '.', ','), '0'), '.');
    }

    /** Materiales y productos en o por debajo del mínimo. */
    public static function bajoMinimo(): array
    {
        return DB::todos(
            "SELECT 'material' AS tipo_item, id, codigo, nombre, stock, stock_minimo, unidad FROM materiales
              WHERE activo = 1 AND stock_minimo > 0 AND stock <= stock_minimo
             UNION ALL
             SELECT 'producto', id, sku, nombre, stock, stock_minimo, 'Unidad' FROM productos
              WHERE activo = 1 AND control_stock = 'propio' AND stock_minimo > 0 AND stock <= stock_minimo
             ORDER BY nombre"
        );
    }
}
