<?php
declare(strict_types=1);

namespace App\Modulos\Roles;

use App\Core\Actividad;
use App\Core\App;
use App\Core\DB;
use App\Core\Flash;
use App\Core\View;

final class RolesControlador
{
    public function lista(): never
    {
        $roles = DB::todos(
            'SELECT r.*,
                    (SELECT COUNT(*) FROM rol_permisos p WHERE p.rol_id = r.id) AS permisos,
                    (SELECT COUNT(*) FROM usuarios u WHERE u.rol_id = r.id AND u.activo = 1) AS usuarios
               FROM roles r ORDER BY r.id'
        );
        View::mostrar('roles/lista', [
            'titulo' => 'Roles y permisos',
            'migas' => ['Administración' => null, 'Roles y permisos' => null],
            'roles' => $roles,
            'totalPermisos' => count(RolesServicio::clavesValidas()),
        ]);
    }

    private function buscar(int $id): array
    {
        $r = DB::uno('SELECT * FROM roles WHERE id = ?', [$id]);
        if (!$r) {
            App::error(404);
        }
        return $r;
    }

    public function editar(string $id): never
    {
        $rol = $this->buscar((int) $id);
        View::mostrar('roles/editar', [
            'titulo' => $rol['nombre'],
            'migas' => ['Roles y permisos' => '/roles', $rol['nombre'] => null],
            'rol' => $rol,
            'catalogo' => RolesServicio::definicion()['catalogo'],
            'activos' => array_column(DB::todos('SELECT permiso FROM rol_permisos WHERE rol_id = ?', [$rol['id']]), 'permiso'),
            'editable' => puede('roles.editar') && $rol['clave'] !== 'admin',
        ]);
    }

    public function guardar(string $id): never
    {
        $rol = $this->buscar((int) $id);
        if ($rol['clave'] === 'admin') {
            Flash::error('El Administrador siempre tiene acceso completo.');
            redirigir('/roles');
        }
        $validos = RolesServicio::clavesValidas();
        $nuevos = array_values(array_intersect((array) ($_POST['permisos'] ?? []), $validos));
        $antes = array_column(DB::todos('SELECT permiso FROM rol_permisos WHERE rol_id = ?', [$rol['id']]), 'permiso');

        DB::tx(function () use ($rol, $nuevos) {
            DB::q('DELETE FROM rol_permisos WHERE rol_id = ?', [$rol['id']]);
            foreach ($nuevos as $p) {
                DB::insertar('rol_permisos', ['rol_id' => $rol['id'], 'permiso' => $p]);
            }
        });

        $agregados = array_values(array_diff($nuevos, $antes));
        $quitados = array_values(array_diff($antes, $nuevos));
        if ($agregados || $quitados) {
            Actividad::registrar('roles', 'editar', 'roles', (int) $rol['id'], 'Cambió los permisos del rol ' . $rol['nombre'],
                ['quitados' => $quitados], ['agregados' => $agregados]);
        }
        Flash::ok('Permisos de ' . $rol['nombre'] . ' guardados.');
        redirigir('/roles');
    }
}
