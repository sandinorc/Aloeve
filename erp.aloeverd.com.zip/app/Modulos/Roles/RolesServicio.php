<?php
declare(strict_types=1);

namespace App\Modulos\Roles;

use App\Core\DB;

final class RolesServicio
{
    public static function definicion(): array
    {
        return require APP . '/permisos.php';
    }

    /** Lista plana de claves de permiso válidas. */
    public static function clavesValidas(): array
    {
        $claves = [];
        foreach (self::definicion()['catalogo'] as $permisos) {
            $claves = [...$claves, ...array_keys($permisos)];
        }
        return $claves;
    }

    /** Crea los roles que falten con sus permisos por defecto. No toca los roles existentes. */
    public static function sincronizar(): void
    {
        foreach (self::definicion()['roles'] as $clave => $rol) {
            $existe = DB::valor('SELECT id FROM roles WHERE clave = ?', [$clave]);
            if ($existe) {
                continue;
            }
            $id = DB::insertar('roles', [
                'clave' => $clave,
                'nombre' => $rol['nombre'],
                'descripcion' => $rol['descripcion'],
            ]);
            $permisos = $rol['permisos'] === '*' ? [] : $rol['permisos'];
            foreach ($permisos as $p) {
                DB::insertar('rol_permisos', ['rol_id' => $id, 'permiso' => $p]);
            }
        }
    }
}
