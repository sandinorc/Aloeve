<?php
declare(strict_types=1);

namespace App\Modulos\Setup;

use App\Core\Actividad;
use App\Core\App;
use App\Core\Auth;
use App\Core\Config;
use App\Core\Crypto;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Migrador;
use App\Core\Validar;
use App\Core\View;
use App\Modulos\Roles\RolesServicio;
use Throwable;

/**
 * Instalador desde el navegador (el hosting no tiene SSH).
 * Protegido por la clave de config/setup.key y bloqueado al terminar.
 */
final class SetupControlador
{
    private const ARCHIVO_CLAVE = '/config/setup.key';

    private function claveEsperada(): ?string
    {
        $f = RAIZ . self::ARCHIVO_CLAVE;
        return is_file($f) ? trim((string) file_get_contents($f)) : null;
    }

    private function autorizado(): bool
    {
        $esperada = $this->claveEsperada();
        if ($esperada === null || $esperada === '') {
            return false;
        }
        $dada = get('clave') ?: post('clave_setup');
        if ($dada !== '' && hash_equals($esperada, $dada)) {
            $_SESSION['setup_ok'] = hash('sha256', $esperada);
        }
        return hash_equals(hash('sha256', $esperada), (string) ($_SESSION['setup_ok'] ?? ''));
    }

    private function vista(string $vista, array $datos = []): never
    {
        View::mostrar('setup/' . $vista, [...$datos, 'titulo' => 'Instalación', 'ancho' => 'max-w-2xl'], 'layout_simple');
    }

    public function inicio(): never
    {
        if (App::instalado()) {
            $this->vista('completado');
        }
        if ($this->claveEsperada() === null) {
            $this->vista('sin_clave');
        }
        if (!$this->autorizado()) {
            if (get('clave') !== '') {
                Flash::error('Clave de instalación inválida.');
            }
            $this->vista('clave');
        }
        if (!Config::existe()) {
            $this->vista('base_datos', ['requisitos' => self::requisitos()]);
        }
        $this->vista('admin');
    }

    public static function requisitos(): array
    {
        $escribible = static fn(string $d) => is_dir(RAIZ . $d) && is_writable(RAIZ . $d);
        return [
            ['PHP 8.1 o superior (tienes ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '8.1.0', '>='), true],
            ['Extensión pdo_mysql', extension_loaded('pdo_mysql'), true],
            ['Extensión openssl', extension_loaded('openssl'), true],
            ['Extensión mbstring', extension_loaded('mbstring'), true],
            ['Extensión dom (XML para e-CF)', extension_loaded('dom'), true],
            ['Extensión curl (conexión con la DGII)', extension_loaded('curl'), true],
            ['Extensión fileinfo', extension_loaded('fileinfo'), true],
            ['Extensión intl', extension_loaded('intl'), false],
            ['Librerías incluidas (carpeta vendor)', is_file(RAIZ . '/vendor/autoload.php'), true],
            ['Se puede escribir en config/', $escribible('/config'), false],
            ['Se puede escribir en storage/', $escribible('/storage'), true],
            ['Se puede escribir en storage/certificados/', $escribible('/storage/certificados'), true],
        ];
    }

    public function baseDatos(): never
    {
        if (App::instalado() || !$this->autorizado()) {
            redirigir('/setup');
        }
        if (Config::existe()) {
            redirigir('/setup');
        }
        $db = [
            'host' => post('db_host', 'localhost') ?: 'localhost',
            'puerto' => (int) (post('db_puerto', '3306') ?: 3306),
            'nombre' => post('db_nombre'),
            'usuario' => post('db_usuario'),
            'clave' => (string) ($_POST['db_clave'] ?? ''),
        ];
        Flash::recordarFormulario();
        if ($db['nombre'] === '' || $db['usuario'] === '') {
            Flash::error('Escribe el nombre de la base de datos y el usuario.');
            redirigir('/setup');
        }
        try {
            $pdo = DB::conectar($db);
            $version = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
        } catch (Throwable $e) {
            registrar_error('Setup: conexión fallida: ' . $e->getMessage());
            Flash::error('No se pudo conectar a la base de datos. Revisa nombre, usuario y contraseña (cópialos desde hPanel → Databases).');
            redirigir('/setup');
        }

        $urlBase = rtrim(post('app_url') ?: Config::urlDetectada(), '/');
        $config = [
            'app' => [
                'url' => $urlBase,
                'llave' => Crypto::generarLlave(),
            ],
            'db' => $db,
        ];

        if (!Config::escribir($config)) {
            // Sin permiso de escritura: mostrar el contenido para crearlo a mano
            $this->vista('config_manual', ['contenido' => Config::contenidoPara($config)]);
        }

        try {
            DB::usar($pdo);
            Migrador::aplicar();
            RolesServicio::sincronizar();
        } catch (Throwable $e) {
            registrar_error('Setup: migración fallida: ' . $e->getMessage());
            @unlink(Config::archivo());
            Flash::error('Se conectó a la base de datos (' . $version . ') pero no se pudieron crear las tablas: ' . $e->getMessage());
            redirigir('/setup');
        }
        Flash::limpiarFormulario();
        Flash::ok('Base de datos lista. Ahora crea tu usuario Administrador.');
        redirigir('/setup');
    }

    public function admin(): never
    {
        if (App::instalado() || !$this->autorizado() || !Config::existe()) {
            redirigir('/setup');
        }
        // Si config.php se creó a mano, puede faltar aplicar las migraciones
        if (Migrador::pendientes()) {
            Migrador::aplicar();
            RolesServicio::sincronizar();
        }

        $nombre = post('nombre');
        $email = mb_strtolower(post('email'));
        $clave = (string) ($_POST['clave'] ?? '');
        $clave2 = (string) ($_POST['clave2'] ?? '');
        $negocio = post('negocio') ?: 'Aloeve Art Studio';
        Flash::recordarFormulario();

        $error = match (true) {
            $nombre === '' => 'Escribe tu nombre.',
            !Validar::email($email) => 'Escribe un correo válido.',
            $clave !== $clave2 => 'Las contraseñas no coinciden.',
            default => Auth::validarClave($clave),
        };
        if ($error) {
            Flash::error($error);
            redirigir('/setup');
        }

        $rolAdmin = (int) DB::valor("SELECT id FROM roles WHERE clave = 'admin'");
        DB::tx(function () use ($nombre, $email, $clave, $rolAdmin, $negocio) {
            $existe = DB::valor('SELECT id FROM usuarios WHERE email = ?', [$email]);
            if ($existe) {
                DB::actualizar('usuarios', [
                    'nombre' => $nombre,
                    'password_hash' => password_hash($clave, PASSWORD_DEFAULT),
                    'rol_id' => $rolAdmin,
                    'activo' => 1,
                ], 'id = ?', [$existe]);
                $id = (int) $existe;
            } else {
                $id = DB::insertar('usuarios', [
                    'nombre' => $nombre,
                    'email' => $email,
                    'password_hash' => password_hash($clave, PASSWORD_DEFAULT),
                    'rol_id' => $rolAdmin,
                    'sede_id' => DB::valor('SELECT id FROM sedes ORDER BY id LIMIT 1'),
                ]);
            }
            DB::q("UPDATE configuracion SET valor = ? WHERE clave = 'negocio.nombre_comercial'", [$negocio]);
            $_SESSION['uid'] = $id;
            Actividad::registrar('sistema', 'instalar', 'usuarios', $id, 'Instaló el ERP y creó el usuario Administrador');
        });

        // Bloquear el instalador
        file_put_contents(STORAGE . '/instalado.lock', date('c') . PHP_EOL);
        @unlink(RAIZ . self::ARCHIVO_CLAVE);
        unset($_SESSION['setup_ok']);

        // Entrar directamente
        session_regenerate_id(true);
        $_SESSION['inicio'] = time();
        $_SESSION['ultimo_uso'] = time();
        Flash::limpiarFormulario();
        Flash::ok('Instalación completada. Empieza por la lista de primeros pasos.');
        redirigir('/');
    }

    /** Actualizaciones de base de datos después de subir una fase nueva. */
    public function actualizar(): never
    {
        if (!in_array('*', Auth::permisos(), true)) {
            App::error(403);
        }
        View::mostrar('setup/actualizar', [
            'titulo' => 'Actualizar el sistema',
            'migas' => ['Actualizar el sistema' => null],
            'pendientes' => array_map(static fn($f) => basename($f, '.sql'), Migrador::pendientes()),
            'aplicadas' => Migrador::aplicadas(),
        ]);
    }

    public function aplicar(): never
    {
        if (!in_array('*', Auth::permisos(), true)) {
            App::error(403);
        }
        try {
            $hechas = Migrador::aplicar();
            RolesServicio::sincronizar();
            Actividad::registrar('sistema', 'actualizar', null, null, 'Aplicó actualizaciones: ' . (implode(', ', $hechas) ?: 'ninguna'));
            Flash::ok($hechas ? 'Actualización aplicada: ' . implode(', ', $hechas) . '.' : 'No había cambios pendientes.');
        } catch (Throwable $e) {
            registrar_error('Actualizar: ' . $e->getMessage());
            Flash::error('No se pudo aplicar la actualización: ' . $e->getMessage());
        }
        redirigir('/setup/actualizar');
    }
}
