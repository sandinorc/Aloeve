<?php
declare(strict_types=1);

namespace App\Modulos\Auth;

use App\Core\Actividad;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\View;

final class AuthControlador
{
    public function formulario(): never
    {
        if (Auth::usuario()) {
            redirigir('/');
        }
        View::mostrar('auth/login', ['titulo' => 'Iniciar sesión'], 'layout_simple');
    }

    public function entrar(): never
    {
        $email = post('email');
        $error = Auth::intentar($email, (string) ($_POST['clave'] ?? ''));
        if ($error !== null) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir('/login');
        }
        $destino = $_SESSION['volver_a'] ?? '/';
        unset($_SESSION['volver_a']);
        redirigir(is_string($destino) && str_starts_with($destino, '/') && !str_starts_with($destino, '//') ? $destino : '/');
    }

    public function salir(): never
    {
        Actividad::registrar('sesion', 'salir', 'usuarios', Auth::id(), 'Cerró sesión');
        Auth::cerrar();
        Flash::ok('Cerraste sesión.');
        redirigir('/login');
    }

    public function formularioClave(): never
    {
        $u = Auth::usuario();
        View::mostrar('auth/clave', [
            'titulo' => 'Cambiar contraseña',
            'migas' => ['Mi contraseña' => null],
            'obligatorio' => (int) $u['debe_cambiar_clave'] === 1,
        ]);
    }

    public function cambiarClave(): never
    {
        $u = Auth::usuario();
        $actual = (string) ($_POST['actual'] ?? '');
        $nueva = (string) ($_POST['nueva'] ?? '');
        $nueva2 = (string) ($_POST['nueva2'] ?? '');
        $hash = (string) DB::valor('SELECT password_hash FROM usuarios WHERE id = ?', [$u['id']]);

        $error = match (true) {
            !password_verify($actual, $hash) => 'La contraseña actual no es correcta.',
            $nueva !== $nueva2 => 'Las contraseñas nuevas no coinciden.',
            $nueva === $actual => 'La contraseña nueva debe ser distinta a la actual.',
            default => Auth::validarClave($nueva),
        };
        if ($error) {
            Flash::error($error);
            redirigir('/perfil/clave');
        }
        DB::actualizar('usuarios', [
            'password_hash' => password_hash($nueva, PASSWORD_DEFAULT),
            'debe_cambiar_clave' => 0,
        ], 'id = ?', [$u['id']]);
        session_regenerate_id(true);
        Actividad::registrar('usuarios', 'cambiar_clave', 'usuarios', (int) $u['id'], 'Cambió su contraseña');
        Flash::ok('Contraseña actualizada.');
        redirigir('/');
    }
}
