<?php
declare(strict_types=1);

namespace App\Modulos\Ecf;

use RuntimeException;

/**
 * Arma el XML de un e-CF respetando el orden exacto de elementos del formato de la DGII.
 * El orden sale de esquemas/*.json, derivados de las plantillas del paquete MIT
 * platinum-place/laravel-dgii (que sigue el "Formato Comprobante Fiscal Electrónico v1.0").
 * Solo se escriben los elementos que vienen en los datos.
 */
final class XmlEcf
{
    private static array $esquemas = [];

    private static function esquema(string $nombre): array
    {
        if (!isset(self::$esquemas[$nombre])) {
            $f = __DIR__ . '/esquemas/' . $nombre . '.json';
            if (!is_file($f)) {
                throw new RuntimeException("Esquema e-CF no disponible: $nombre");
            }
            self::$esquemas[$nombre] = json_decode((string) file_get_contents($f), true, 512, JSON_THROW_ON_ERROR);
        }
        return self::$esquemas[$nombre];
    }

    /** @param string $esquema 31, 32, 34 o rfce */
    public static function construir(string $esquema, array $datos): string
    {
        [$raiz, $hijos] = self::esquema($esquema);
        return '<?xml version="1.0" encoding="utf-8"?>' . "\n<$raiz>" . self::nodos($hijos, $datos) . "</$raiz>";
    }

    private static function nodos(array $hijos, array $datos): string
    {
        $xml = '';
        foreach ($hijos as [$nombre, $subHijos]) {
            if (!array_key_exists($nombre, $datos) || $datos[$nombre] === null || $datos[$nombre] === '') {
                continue;
            }
            $valor = $datos[$nombre];
            if ($subHijos) {
                $lista = is_array($valor) && array_is_list($valor) ? $valor : [$valor];
                foreach ($lista as $elemento) {
                    $xml .= "<$nombre>" . self::nodos($subHijos, (array) $elemento) . "</$nombre>";
                }
            } else {
                $xml .= "<$nombre>" . htmlspecialchars(self::texto($valor), ENT_XML1 | ENT_QUOTES, 'UTF-8') . "</$nombre>";
            }
        }
        return $xml;
    }

    private static function texto(mixed $v): string
    {
        if (is_float($v)) {
            return number_format($v, 2, '.', '');
        }
        return trim((string) $v);
    }

    public static function monto(float|string $v): string
    {
        return number_format(round((float) $v, 2), 2, '.', '');
    }

    public static function fecha(string $fechaHora): string
    {
        return date('d-m-Y', strtotime($fechaHora));
    }

    public static function fechaHora(string $fechaHora): string
    {
        return date('d-m-Y H:i:s', strtotime($fechaHora));
    }
}
