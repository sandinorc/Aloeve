<?php
declare(strict_types=1);

namespace App\Modulos\Ecf;

use RuntimeException;

/**
 * Cliente HTTP de los servicios web e-CF de la DGII, sin framework (cURL).
 * Flujo de autenticación: semilla → firmar → validar semilla → token (válido ~1 hora).
 */
final class DgiiCliente
{
    public const AMBIENTES = ['testecf', 'certecf', 'ecf'];
    private array $servicios;

    public function __construct(private string $ambiente)
    {
        if (!in_array($ambiente, self::AMBIENTES, true)) {
            throw new RuntimeException('Ambiente desconocido: ' . $ambiente);
        }
        $this->servicios = require APP . '/ecf_servicios.php';
    }

    public function url(string $servicio): string
    {
        if (!isset($this->servicios[$servicio])) {
            throw new RuntimeException('Servicio DGII no configurado: ' . $servicio);
        }
        return str_replace('{ambiente}', $this->ambiente, $this->servicios[$servicio]);
    }

    /** Paso 1: pedir la semilla (XML). */
    public function semilla(): string
    {
        [$codigo, $cuerpo] = $this->pedir('GET', $this->url('semilla'));
        if ($codigo !== 200 || !str_contains($cuerpo, '<')) {
            throw new RuntimeException("La DGII no devolvió la semilla (HTTP $codigo).");
        }
        return $cuerpo;
    }

    /** Paso 3: enviar la semilla firmada y recibir el token. */
    public function validarSemilla(string $semillaFirmada): array
    {
        [$codigo, $cuerpo] = $this->pedir('POST', $this->url('validar_semilla'), null, ['xml' => ['semilla.xml', $semillaFirmada]]);
        $json = json_decode($cuerpo, true);
        if ($codigo !== 200 || !is_array($json) || empty($json['token'])) {
            $msg = match (true) {
                is_array($json) => $json['mensaje'] ?? $json['message'] ?? json_encode($json, JSON_UNESCAPED_UNICODE),
                is_string($json) => $json,
                default => mb_substr(trim(strip_tags($cuerpo)), 0, 200),
            };
            throw new RuntimeException("La DGII rechazó la semilla firmada (HTTP $codigo): $msg");
        }
        return $json;
    }

    /** Autenticación completa. Devuelve ['token' => ..., 'expira' => 'Y-m-d H:i:s']. */
    public function autenticar(Firmador $firmador): array
    {
        $semilla = $this->semilla();
        $firmada = $firmador->firmar($semilla);
        $r = $this->validarSemilla($firmada);
        $expira = isset($r['expira']) ? strtotime((string) $r['expira']) : false;
        return [
            'token' => (string) $r['token'],
            'expira' => date('Y-m-d H:i:s', $expira ?: time() + 3300),
        ];
    }

    /** Enviar un e-CF firmado (Fase 2). */
    public function enviarEcf(string $token, string $xmlFirmado, string $nombreArchivo, bool $resumenConsumo = false): array
    {
        $url = $this->url($resumenConsumo ? 'recepcion_fc' : 'recepcion');
        [$codigo, $cuerpo] = $this->pedir('POST', $url, $token, ['xml' => [$nombreArchivo, $xmlFirmado]]);
        return ['http' => $codigo, 'respuesta' => json_decode($cuerpo, true) ?? $cuerpo];
    }

    /** Consultar el resultado de un envío por TrackId (Fase 2). */
    public function consultarTrackId(string $token, string $trackId): array
    {
        [$codigo, $cuerpo] = $this->pedir('GET', $this->url('consulta_resultado') . '?trackid=' . rawurlencode($trackId), $token);
        return ['http' => $codigo, 'respuesta' => json_decode($cuerpo, true) ?? $cuerpo];
    }

    /**
     * @param array<string, array{0:string,1:string}>|null $archivos campo => [nombre, contenido]
     * @return array{0:int,1:string}
     */
    private function pedir(string $metodo, string $url, ?string $token = null, ?array $archivos = null): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('El servidor no tiene la extensión curl.');
        }
        $ch = curl_init($url);
        $cabeceras = ['Accept: application/json, application/xml, */*'];
        if ($token) {
            $cabeceras[] = 'Authorization: Bearer ' . $token;
        }
        $opciones = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'AloeveERP/' . VERSION_ERP,
            CURLOPT_HTTPHEADER => $cabeceras,
        ];
        if ($metodo === 'POST') {
            $opciones[CURLOPT_POST] = true;
            $campos = [];
            foreach ((array) $archivos as $campo => [$nombre, $contenido]) {
                $campos[$campo] = new \CURLStringFile($contenido, $nombre, 'text/xml');
            }
            $opciones[CURLOPT_POSTFIELDS] = $campos;
        }
        curl_setopt_array($ch, $opciones);
        $cuerpo = curl_exec($ch);
        $codigo = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($cuerpo === false) {
            throw new RuntimeException('No hubo respuesta de la DGII: ' . $error);
        }
        return [$codigo, (string) $cuerpo];
    }
}
