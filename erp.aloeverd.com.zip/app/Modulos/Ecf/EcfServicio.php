<?php
declare(strict_types=1);

namespace App\Modulos\Ecf;

use App\Core\Ajustes;
use App\Core\Crypto;
use App\Core\DB;
use RuntimeException;
use Throwable;

/**
 * Emisión de comprobantes fiscales electrónicos (PRD §8.7.5).
 * Arma el XML, lo firma, lo envía a la DGII y guarda la respuesta.
 * Nunca bloquea una venta: si la DGII no responde, el envío queda pendiente y la cola lo reintenta.
 */
final class EcfServicio
{
    public const ESTADOS = [
        'pendiente' => ['Pendiente de envío', 'chip-ambar'],
        'en_proceso' => ['En proceso en la DGII', 'chip-ambar'],
        'aceptado' => ['Aceptado', 'chip-verde'],
        'aceptado_condicional' => ['Aceptado condicional', 'chip-verde'],
        'rechazado' => ['Rechazado', 'chip-rojo'],
        'error' => ['Error', 'chip-rojo'],
    ];

    private const MAX_INTENTOS = 20;

    public static function activo(): bool
    {
        return Ajustes::get('ecf.activo') === '1';
    }

    public static function limiteRfce(): float
    {
        return (float) ((require APP . '/ecf_servicios.php')['limite_rfce'] ?? 250000);
    }

    /* ======================= Datos del XML ======================= */

    private static function formaPago(string $metodo): int
    {
        return match ($metodo) {
            'efectivo' => 1,
            'transferencia' => 2,
            'tarjeta', 'enlace' => 3,
            default => 8,
        };
    }

    /** Datos del comprobante, la venta y sus líneas, listos para el XML. */
    public static function datos(array $c, string $fechaFirma): array
    {
        $tipo = substr($c['tipo'], 1);
        $venta = $c['venta_id'] ? DB::uno('SELECT * FROM ventas WHERE id = ?', [$c['venta_id']]) : null;
        $ventaItems = $c['venta_id'] ? DB::todos('SELECT * FROM venta_items WHERE venta_id = ? ORDER BY id', [$c['venta_id']]) : [];
        $pagos = $c['venta_id'] ? DB::todos('SELECT metodo, SUM(monto) AS monto FROM venta_pagos WHERE venta_id = ? GROUP BY metodo', [$c['venta_id']]) : [];
        $origen = $c['comprobante_origen_id'] ? DB::uno('SELECT * FROM comprobantes WHERE id = ?', [$c['comprobante_origen_id']]) : null;

        $gravado = 0.0;
        $exento = 0.0;
        $itbis = 0.0;
        $items = [];
        foreach ($ventaItems as $i => $it) {
            $base = (float) $it['total'] - (float) $it['itbis'];
            $grava = (float) $it['tasa_itbis'] > 0;
            $grava ? $gravado += $base : $exento += $base;
            $itbis += (float) $it['itbis'];
            $linea = [
                'NumeroLinea' => $i + 1,
                'IndicadorFacturacion' => $grava ? 1 : 4,
                'NombreItem' => mb_substr($it['descripcion'], 0, 80),
                'IndicadorBienoServicio' => (int) $it['es_servicio'] === 1 ? 2 : 1,
                'CantidadItem' => XmlEcf::monto($it['cantidad']),
                'PrecioUnitarioItem' => XmlEcf::monto($it['precio_unitario']),
                'MontoItem' => XmlEcf::monto($base),
            ];
            if ((float) $it['descuento'] > 0) {
                $linea['DescuentoMonto'] = XmlEcf::monto($it['descuento']);
                $bruto = (float) $it['precio_unitario'] * (float) $it['cantidad'];
                $linea['TablaSubDescuento'] = ['SubDescuento' => [[
                    'TipoSubDescuento' => '%',
                    'SubDescuentoPorcentaje' => XmlEcf::monto($bruto > 0 ? (float) $it['descuento'] / $bruto * 100 : 0),
                    'MontoSubDescuento' => XmlEcf::monto($it['descuento']),
                ]]];
            }
            $items[] = $linea;
        }

        $emisor = [
            'RNCEmisor' => (string) Ajustes::get('negocio.rnc'),
            'RazonSocialEmisor' => (string) (Ajustes::get('negocio.razon_social') ?: Ajustes::get('negocio.nombre_comercial')),
            'NombreComercial' => Ajustes::get('negocio.nombre_comercial') ?: null,
            'DireccionEmisor' => Ajustes::get('negocio.direccion') ?: null,
            'CorreoEmisor' => Ajustes::get('negocio.correo') ?: null,
            'NumeroFacturaInterna' => $venta['numero'] ?? null,
            'FechaEmision' => XmlEcf::fecha($c['fecha']),
        ];
        $comprador = $c['rnc_cedula'] ? array_filter([
            'RNCComprador' => $c['rnc_cedula'],
            'RazonSocialComprador' => $c['razon_social'] ? mb_substr($c['razon_social'], 0, 150) : null,
        ]) : null;

        $totales = array_filter([
            'MontoGravadoTotal' => $gravado > 0 ? XmlEcf::monto($gravado) : null,
            'MontoGravadoI1' => $gravado > 0 ? XmlEcf::monto($gravado) : null,
            'MontoExento' => $exento > 0 ? XmlEcf::monto($exento) : null,
            'ITBIS1' => $gravado > 0 ? '18' : null,
            'TotalITBIS' => $gravado > 0 ? XmlEcf::monto($itbis) : null,
            'TotalITBIS1' => $gravado > 0 ? XmlEcf::monto($itbis) : null,
            'MontoTotal' => XmlEcf::monto($c['total']),
        ]);

        $idDoc = [
            'TipoeCF' => $tipo,
            'eNCF' => $c['ncf'],
            'FechaVencimientoSecuencia' => $tipo === '31' && $c['vence_secuencia'] ? XmlEcf::fecha($c['vence_secuencia']) : null,
            'IndicadorMontoGravado' => 0,
            'TipoIngresos' => '01',
            'TipoPago' => 1,
            'TablaFormasPago' => $pagos ? ['FormaDePago' => array_map(static fn($p) => [
                'FormaPago' => self::formaPago($p['metodo']),
                'MontoPago' => XmlEcf::monto($p['monto']),
            ], $pagos)] : null,
        ];
        if ($tipo === '34' && $origen) {
            $dias = (int) floor((strtotime($c['fecha']) - strtotime($origen['fecha'])) / 86400);
            $idDoc['IndicadorNotaCredito'] = $dias > 30 ? 1 : 0;
        }

        $datos = [
            'Encabezado' => [
                'Version' => '1.0',
                'IdDoc' => $idDoc,
                'Emisor' => $emisor,
                'Comprador' => $comprador,
                'Totales' => $totales,
            ],
            'DetallesItems' => ['Item' => $items],
            'FechaHoraFirma' => XmlEcf::fechaHora($fechaFirma),
        ];
        if ($tipo === '34' && $origen) {
            $datos['InformacionReferencia'] = [
                'NCFModificado' => $origen['ncf'],
                'FechaNCFModificado' => XmlEcf::fecha($origen['fecha']),
                'CodigoModificacion' => 1,
                'RazonModificacion' => mb_substr((string) ($c['motivo_anulacion'] ?? 'Anulación de la venta'), 0, 90),
            ];
        }
        return $datos;
    }

    /** Resumen de factura de consumo (RFCE) para E32 de menos de RD$250,000. */
    public static function datosRfce(array $datosEcf, string $codigoSeguridad): array
    {
        $enc = $datosEcf['Encabezado'];
        return [
            'Encabezado' => [
                'Version' => '1.0',
                'IdDoc' => [
                    'TipoeCF' => $enc['IdDoc']['TipoeCF'],
                    'eNCF' => $enc['IdDoc']['eNCF'],
                    'TipoIngresos' => $enc['IdDoc']['TipoIngresos'],
                    'TipoPago' => $enc['IdDoc']['TipoPago'],
                    'TablaFormasPago' => $enc['IdDoc']['TablaFormasPago'] ?? null,
                ],
                'Emisor' => [
                    'RNCEmisor' => $enc['Emisor']['RNCEmisor'],
                    'RazonSocialEmisor' => $enc['Emisor']['RazonSocialEmisor'],
                    'FechaEmision' => $enc['Emisor']['FechaEmision'],
                ],
                'Comprador' => $enc['Comprador'] ?? null,
                'Totales' => array_intersect_key($enc['Totales'], array_flip([
                    'MontoGravadoTotal', 'MontoGravadoI1', 'MontoExento', 'TotalITBIS', 'TotalITBIS1', 'MontoTotal',
                ])),
                'CodigoSeguridadeCF' => $codigoSeguridad,
            ],
        ];
    }

    /* ======================= Conexión ======================= */

    private static function conexion(string $ambiente): array
    {
        $c = DB::uno("SELECT * FROM ecf_conexiones WHERE ambiente = ? AND conector = 'dgii'", [$ambiente]);
        if (!$c || !$c['certificado_ruta']) {
            throw new RuntimeException('No hay certificado digital cargado para el ambiente ' . $ambiente . '.');
        }
        return $c;
    }

    public static function firmador(array $conexion): Firmador
    {
        $ruta = STORAGE . '/certificados/' . basename((string) $conexion['certificado_ruta']);
        if (!is_file($ruta)) {
            throw new RuntimeException('Falta el archivo del certificado. Súbelo de nuevo en Facturación electrónica.');
        }
        $p12 = base64_decode((string) Crypto::descifrar((string) file_get_contents($ruta)), true);
        return new Firmador((string) $p12, (string) Crypto::descifrar($conexion['certificado_clave_cifrada']));
    }

    private static function token(string $ambiente, array $conexion, Firmador $firmador): string
    {
        if ($conexion['token_cache'] && $conexion['token_vence'] && strtotime($conexion['token_vence']) > time() + 120) {
            return (string) Crypto::descifrar($conexion['token_cache']);
        }
        $auth = (new DgiiCliente($ambiente))->autenticar($firmador);
        DB::actualizar('ecf_conexiones', [
            'token_cache' => Crypto::cifrar($auth['token']),
            'token_vence' => $auth['expira'],
            'estado' => 'conectado',
            'verificado_en' => date('Y-m-d H:i:s'),
        ], 'id = ?', [$conexion['id']]);
        return $auth['token'];
    }

    /* ======================= Emisión ======================= */

    /** Emite un comprobante electrónico. No lanza excepciones: deja el estado guardado. */
    public static function emitir(int $comprobanteId): array
    {
        $c = DB::uno('SELECT * FROM comprobantes WHERE id = ?', [$comprobanteId]);
        if (!$c || $c['clase'] !== 'electronico') {
            return ['estado' => null];
        }
        $conector = (string) Ajustes::get('ecf.conector', 'simulador');
        $ambiente = (string) Ajustes::get('ecf.ambiente', 'testecf');
        $fechaFirma = date('Y-m-d H:i:s');
        $envioId = DB::insertar('ecf_envios', [
            'comprobante_id' => $c['id'],
            'ambiente' => $ambiente,
            'conector' => $conector,
            'estado' => 'pendiente',
        ]);
        try {
            $datos = self::datos($c, $fechaFirma);
            $xml = XmlEcf::construir(substr($c['tipo'], 1), $datos);

            if ($conector === 'simulador') {
                $codigo = strtoupper(substr(base_convert(hash('sha256', $xml), 16, 36), 0, 6));
                return self::guardar($c, $envioId, $ambiente, [
                    'xml' => $xml, 'codigo' => str_pad($codigo, 6, '0'), 'fecha_firma' => $fechaFirma,
                    'estado' => 'aceptado', 'track' => 'SIM-' . $c['ncf'], 'simulado' => 1,
                    'mensajes' => [['valor' => 'Simulador: el XML se generó pero no se envió a la DGII.']],
                ]);
            }
            if ($conector !== 'dgii') {
                throw new RuntimeException('El conector de proveedor todavía no está programado. Usa DGII directo o el Simulador.');
            }

            $conexion = self::conexion($ambiente);
            $firmador = self::firmador($conexion);
            $firmado = $firmador->firmar($xml);
            $codigo = Firmador::codigoSeguridad($firmado);
            $cliente = new DgiiCliente($ambiente);
            $token = self::token($ambiente, $conexion, $firmador);
            $archivo = Ajustes::get('negocio.rnc') . $c['ncf'] . '.xml';

            $esResumen = $c['tipo'] === 'E32' && (float) $c['total'] < self::limiteRfce();
            if ($esResumen) {
                $rfce = $firmador->firmar(XmlEcf::construir('rfce', self::datosRfce($datos, $codigo)));
                $r = $cliente->enviarEcf($token, $rfce, $archivo, true);
                DB::actualizar('ecf_envios', ['documento' => 'rfce'], 'id = ?', [$envioId]);
                $resp = is_array($r['respuesta']) ? $r['respuesta'] : [];
                $estado = self::mapear((string) ($resp['estado'] ?? ''), $r['http']);
                return self::guardar($c, $envioId, $ambiente, [
                    'xml' => $firmado, 'codigo' => $codigo, 'fecha_firma' => $fechaFirma, 'estado' => $estado,
                    'track' => $resp['trackId'] ?? null, 'mensajes' => self::mensajes($r),
                ]);
            }

            $r = $cliente->enviarEcf($token, $firmado, $archivo);
            $resp = is_array($r['respuesta']) ? $r['respuesta'] : [];
            $track = $resp['trackId'] ?? null;
            $estado = $track ? 'en_proceso' : 'error';
            $res = self::guardar($c, $envioId, $ambiente, [
                'xml' => $firmado, 'codigo' => $codigo, 'fecha_firma' => $fechaFirma, 'estado' => $estado,
                'track' => $track, 'mensajes' => self::mensajes($r),
            ]);
            if ($track) {
                sleep(2);
                return self::consultar($envioId);
            }
            return $res;
        } catch (Throwable $e) {
            registrar_error('e-CF emitir ' . $c['ncf'] . ': ' . $e->getMessage());
            return self::reintentar($envioId, (int) $c['id'], $e->getMessage());
        }
    }

    private static function guardar(array $c, int $envioId, string $ambiente, array $r): array
    {
        DB::actualizar('ecf_envios', [
            'xml_firmado' => $r['xml'],
            'track_id' => $r['track'] ?? null,
            'estado' => $r['estado'],
            'mensajes' => json_encode($r['mensajes'] ?? [], JSON_UNESCAPED_UNICODE),
            'intentos' => 1,
            'enviado_en' => date('Y-m-d H:i:s'),
            'respondido_en' => in_array($r['estado'], ['pendiente', 'en_proceso'], true) ? null : date('Y-m-d H:i:s'),
            'siguiente_intento' => $r['estado'] === 'en_proceso' ? date('Y-m-d H:i:s', time() + 60) : null,
        ], 'id = ?', [$envioId]);
        DB::actualizar('comprobantes', [
            'ecf_estado' => $r['estado'],
            'ecf_ambiente' => $ambiente,
            'ecf_simulado' => $r['simulado'] ?? 0,
            'codigo_seguridad' => $r['codigo'],
            'fecha_firma' => $r['fecha_firma'],
            'track_id' => $r['track'] ?? null,
        ], 'id = ?', [$c['id']]);
        return ['estado' => $r['estado'], 'mensajes' => $r['mensajes'] ?? []];
    }

    private static function reintentar(int $envioId, int $comprobanteId, string $error): array
    {
        $e = DB::uno('SELECT intentos FROM ecf_envios WHERE id = ?', [$envioId]);
        $intentos = (int) ($e['intentos'] ?? 0) + 1;
        $final = $intentos >= self::MAX_INTENTOS;
        $estado = $final ? 'error' : 'pendiente';
        DB::actualizar('ecf_envios', [
            'estado' => $estado,
            'intentos' => $intentos,
            'mensajes' => json_encode([['valor' => $error]], JSON_UNESCAPED_UNICODE),
            'siguiente_intento' => $final ? null : date('Y-m-d H:i:s', time() + 60 * min(60, 2 ** min($intentos, 6))),
        ], 'id = ?', [$envioId]);
        DB::actualizar('comprobantes', ['ecf_estado' => $estado], 'id = ?', [$comprobanteId]);
        return ['estado' => $estado, 'mensajes' => [['valor' => $error]]];
    }

    /** Consulta el resultado de un envío por TrackId. */
    public static function consultar(int $envioId): array
    {
        $e = DB::uno('SELECT * FROM ecf_envios WHERE id = ?', [$envioId]);
        if (!$e || !$e['track_id'] || $e['conector'] !== 'dgii') {
            return ['estado' => $e['estado'] ?? null];
        }
        try {
            $conexion = self::conexion($e['ambiente']);
            $token = self::token($e['ambiente'], $conexion, self::firmador($conexion));
            $r = (new DgiiCliente($e['ambiente']))->consultarTrackId($token, $e['track_id']);
            $resp = is_array($r['respuesta']) ? $r['respuesta'] : [];
            $estado = self::mapear((string) ($resp['estado'] ?? ''), $r['http']);
            DB::actualizar('ecf_envios', [
                'estado' => $estado,
                'mensajes' => json_encode(self::mensajes($r), JSON_UNESCAPED_UNICODE),
                'respondido_en' => $estado === 'en_proceso' ? null : date('Y-m-d H:i:s'),
                'siguiente_intento' => $estado === 'en_proceso' ? date('Y-m-d H:i:s', time() + 120) : null,
            ], 'id = ?', [$envioId]);
            DB::actualizar('comprobantes', ['ecf_estado' => $estado], 'id = ?', [$e['comprobante_id']]);
            return ['estado' => $estado, 'mensajes' => self::mensajes($r)];
        } catch (Throwable $ex) {
            registrar_error('e-CF consultar ' . $e['track_id'] . ': ' . $ex->getMessage());
            DB::actualizar('ecf_envios', ['siguiente_intento' => date('Y-m-d H:i:s', time() + 300)], 'id = ?', [$envioId]);
            return ['estado' => $e['estado'], 'mensajes' => [['valor' => $ex->getMessage()]]];
        }
    }

    /** Cola: reintenta pendientes y consulta los que están en proceso. */
    public static function procesarCola(int $limite = 20): array
    {
        $hechos = ['reenviados' => 0, 'consultados' => 0];
        $filas = DB::todos(
            "SELECT * FROM ecf_envios WHERE estado IN ('pendiente','en_proceso')
                AND (siguiente_intento IS NULL OR siguiente_intento <= NOW())
                AND id IN (SELECT MAX(id) FROM ecf_envios GROUP BY comprobante_id)
              ORDER BY id LIMIT " . (int) $limite
        );
        foreach ($filas as $e) {
            if ($e['estado'] === 'en_proceso') {
                self::consultar((int) $e['id']);
                $hechos['consultados']++;
            } else {
                DB::actualizar('ecf_envios', ['estado' => 'error', 'mensajes' => json_encode([['valor' => 'Reemplazado por un nuevo intento.']])], 'id = ?', [$e['id']]);
                self::emitir((int) $e['comprobante_id']);
                $hechos['reenviados']++;
            }
        }
        return $hechos;
    }

    private static function mapear(string $estado, int $http): string
    {
        $e = mb_strtolower(trim($estado));
        $e = strtr($e, ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u']);
        return match (true) {
            str_contains($e, 'condicional') => 'aceptado_condicional',
            str_contains($e, 'aceptado') => 'aceptado',
            str_contains($e, 'rechazado') => 'rechazado',
            str_contains($e, 'proceso') => 'en_proceso',
            $http >= 500 || $http === 0 => 'pendiente',
            default => 'error',
        };
    }

    private static function mensajes(array $r): array
    {
        $resp = $r['respuesta'];
        if (is_array($resp)) {
            $m = $resp['mensajes'] ?? ($resp['mensaje'] ?? null);
            if (is_array($m)) {
                return array_map(static fn($x) => is_array($x) ? ['valor' => (string) ($x['valor'] ?? json_encode($x, JSON_UNESCAPED_UNICODE)), 'codigo' => $x['codigo'] ?? null] : ['valor' => (string) $x], $m);
            }
            if ($m) {
                return [['valor' => (string) $m]];
            }
            return [];
        }
        return $resp ? [['valor' => 'HTTP ' . $r['http'] . ': ' . mb_substr(strip_tags((string) $resp), 0, 300)]] : [];
    }

    /* ======================= Representación impresa ======================= */

    /** URL del código QR de consulta en la DGII (timbre). */
    public static function urlQr(array $c): ?string
    {
        if ($c['clase'] !== 'electronico' || !$c['codigo_seguridad'] || !$c['ecf_ambiente']) {
            return null;
        }
        $s = require APP . '/ecf_servicios.php';
        $rnc = (string) Ajustes::get('negocio.rnc');
        $total = XmlEcf::monto($c['total']);
        if ($c['tipo'] === 'E32' && (float) $c['total'] < self::limiteRfce()) {
            return str_replace('{ambiente}', $c['ecf_ambiente'], $s['timbre_fc']) . '?' . http_build_query([
                'RncEmisor' => $rnc, 'ENCF' => $c['ncf'], 'MontoTotal' => $total, 'CodigoSeguridad' => $c['codigo_seguridad'],
            ]);
        }
        return str_replace('{ambiente}', $c['ecf_ambiente'], $s['timbre']) . '?' . http_build_query(array_filter([
            'RncEmisor' => $rnc,
            'RncComprador' => $c['rnc_cedula'],
            'ENCF' => $c['ncf'],
            'FechaEmision' => XmlEcf::fecha($c['fecha']),
            'MontoTotal' => $total,
            'FechaFirma' => $c['fecha_firma'] ? XmlEcf::fechaHora($c['fecha_firma']) : null,
            'CodigoSeguridad' => $c['codigo_seguridad'],
        ]));
    }

    public static function qrSvg(string $texto): string
    {
        $opciones = new \chillerlan\QRCode\QROptions([
            'outputType' => \chillerlan\QRCode\Output\QROutputInterface::MARKUP_SVG,
            'outputBase64' => false,
            'eccLevel' => \chillerlan\QRCode\Common\EccLevel::M,
            'addQuietzone' => true,
            'svgAddXmlHeader' => false,
        ]);
        return (new \chillerlan\QRCode\QRCode($opciones))->render($texto);
    }
}
