<?php
declare(strict_types=1);

namespace App\Modulos\Ecf;

use PlatinumPlace\DgiiXmlSigner\SignManager;
use RuntimeException;
use Throwable;

/**
 * Firma digital de XML para la DGII con el certificado .p12 del emisor.
 * Usa la librería platinum-place/php-dgii-xml-signer (MIT), que aplica la
 * canonicalización que exige el instructivo "Firmado de e-CF" de la DGII.
 */
final class Firmador
{
    public function __construct(private string $p12, private string $clave)
    {
    }

    /** Lee el certificado y devuelve titular, RNC/cédula y vencimiento. */
    public function info(): array
    {
        $certs = [];
        if (!@openssl_pkcs12_read($this->p12, $certs, $this->clave)) {
            $errores = '';
            while ($m = openssl_error_string()) {
                $errores .= $m . ' ';
            }
            if (stripos($errores, 'unsupported') !== false || stripos($errores, 'RC2') !== false) {
                throw new RuntimeException(
                    'El certificado usa un cifrado antiguo (RC2) que el servidor no puede leer. '
                    . 'Pide a tu proveedor del certificado una copia en formato moderno (AES) o conviértelo una vez con el procedimiento de INSTRUCCIONES.md.'
                );
            }
            throw new RuntimeException('No se pudo abrir el certificado. Revisa que la contraseña sea la correcta.');
        }
        $x509 = openssl_x509_parse($certs['cert']);
        if (!$x509) {
            throw new RuntimeException('El archivo no contiene un certificado válido.');
        }
        $sujeto = $x509['subject'] ?? [];
        $titular = $sujeto['CN'] ?? ($sujeto['O'] ?? 'Desconocido');
        $titular = is_array($titular) ? implode(' ', $titular) : $titular;
        $documento = $sujeto['serialNumber'] ?? ($sujeto['SN'] ?? '');
        return [
            'titular' => (string) $titular,
            'documento' => is_array($documento) ? implode(' ', $documento) : (string) $documento,
            'emisor' => (string) ($x509['issuer']['O'] ?? ($x509['issuer']['CN'] ?? '')),
            'vence' => date('Y-m-d', (int) $x509['validTo_time_t']),
            'vigente' => time() >= (int) $x509['validFrom_time_t'] && time() <= (int) $x509['validTo_time_t'],
        ];
    }

    public function firmar(string $xml): string
    {
        try {
            return (new SignManager())->sign($this->p12, $this->clave, $xml);
        } catch (Throwable $e) {
            throw new RuntimeException('No se pudo firmar el XML: ' . $e->getMessage(), 0, $e);
        }
    }

    /** Código de seguridad del e-CF: primeros 6 caracteres del SignatureValue. */
    public static function codigoSeguridad(string $xmlFirmado): string
    {
        if (preg_match('#<(?:\w+:)?SignatureValue[^>]*>\s*([^<\s]{6})#', $xmlFirmado, $m)) {
            return $m[1];
        }
        throw new RuntimeException('El XML firmado no tiene SignatureValue.');
    }
}
