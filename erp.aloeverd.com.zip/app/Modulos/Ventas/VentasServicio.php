<?php
declare(strict_types=1);

namespace App\Modulos\Ventas;

use App\Core\Ajustes;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Ncf;
use App\Modulos\Ecf\EcfServicio;
use App\Modulos\Inventario\InventarioServicio;
use RuntimeException;

/** Cobro en caja: una sola transacción para venta, stock, comprobante e ingresos (PRD §8.6). */
final class VentasServicio
{
    public const METODOS = [
        'efectivo' => 'Efectivo',
        'tarjeta' => 'Tarjeta',
        'transferencia' => 'Transferencia',
        'enlace' => 'Enlace de pago',
        'otro' => 'Otro',
    ];

    /**
     * Calcula líneas y totales desde la base de datos (nunca con precios del navegador).
     * @param array<int, array{producto_id:int, cantidad:float}> $carrito
     */
    public static function calcular(array $carrito, float $descuentoPct): array
    {
        if (!$carrito) {
            throw new RuntimeException('El carrito está vacío.');
        }
        if ($descuentoPct < 0 || $descuentoPct > 100) {
            throw new RuntimeException('El descuento debe estar entre 0 y 100%.');
        }
        $tasa = (float) Ajustes::get('fiscal.itbis', '18');
        $lineas = [];
        $subtotal = $descuento = $itbis = 0.0;
        foreach ($carrito as $item) {
            $cant = round((float) ($item['cantidad'] ?? 0), 3);
            $p = DB::uno('SELECT * FROM productos WHERE id = ? AND activo = 1', [(int) ($item['producto_id'] ?? 0)]);
            if (!$p) {
                throw new RuntimeException('Un producto del carrito ya no está disponible. Recarga la caja.');
            }
            if ($cant <= 0) {
                throw new RuntimeException('Cantidad inválida para ' . $p['nombre'] . '.');
            }
            $bruto = round((float) $p['precio'] * $cant, 2);
            $desc = round($bruto * $descuentoPct / 100, 2);
            $base = $bruto - $desc;
            $t = (int) $p['lleva_itbis'] === 1 ? $tasa : 0.0;
            $imp = round($base * $t / 100, 2);
            $lineas[] = [
                'producto' => $p,
                'producto_id' => (int) $p['id'],
                'descripcion' => $p['nombre'],
                'cantidad' => $cant,
                'precio_unitario' => (float) $p['precio'],
                'descuento' => $desc,
                'tasa_itbis' => $t,
                'itbis' => $imp,
                'total' => round($base + $imp, 2),
                'es_servicio' => $p['control_stock'] === 'ninguno' ? 1 : 0,
            ];
            $subtotal += $base;
            $descuento += $desc;
            $itbis += $imp;
        }
        return [
            'lineas' => $lineas,
            'subtotal' => round($subtotal, 2),
            'descuento' => round($descuento, 2),
            'itbis' => round($itbis, 2),
            'total' => round($subtotal + $itbis, 2),
        ];
    }

    /** Tipo de comprobante según e-CF y si el cliente pide crédito fiscal (PRD §8.7.3). */
    public static function tipoComprobante(bool $creditoFiscal): string
    {
        $e = EcfServicio::activo();
        return $creditoFiscal ? ($e ? 'E31' : 'B01') : ($e ? 'E32' : 'B02');
    }

    private static function siguienteNumero(): string
    {
        $n = (int) DB::valor("SELECT valor FROM configuracion WHERE clave = 'ventas.ultimo_numero' FOR UPDATE") + 1;
        DB::q("UPDATE configuracion SET valor = ? WHERE clave = 'ventas.ultimo_numero'", [(string) $n]);
        return sprintf('V-%06d', $n);
    }

    /**
     * Registra la venta completa. Devuelve [venta_id, comprobante_id].
     * @param array<int, array{metodo:string, monto:float, referencia?:string}> $pagos
     */
    public static function cobrar(array $carrito, ?int $clienteId, bool $creditoFiscal, float $descuentoPct, array $pagos, ?string $notas = null): array
    {
        $calc = self::calcular($carrito, $descuentoPct);
        $total = $calc['total'];

        // Pagos: solo el efectivo puede exceder (genera cambio)
        $sumaOtros = 0.0;
        $efectivo = 0.0;
        $limpios = [];
        foreach ($pagos as $pg) {
            $m = round((float) ($pg['monto'] ?? 0), 2);
            $metodo = (string) ($pg['metodo'] ?? '');
            if ($m <= 0) {
                continue;
            }
            if (!isset(self::METODOS[$metodo])) {
                throw new RuntimeException('Método de pago inválido.');
            }
            $metodo === 'efectivo' ? $efectivo += $m : $sumaOtros += $m;
            $limpios[] = ['metodo' => $metodo, 'monto' => $m, 'referencia' => mb_substr((string) ($pg['referencia'] ?? ''), 0, 80) ?: null];
        }
        if ($sumaOtros - $total > 0.009) {
            throw new RuntimeException('Los pagos con tarjeta o transferencia no pueden pasar del total.');
        }
        if ($efectivo + $sumaOtros + 0.009 < $total) {
            throw new RuntimeException('Falta dinero: el total es ' . dinero($total) . ' y se recibieron ' . dinero($efectivo + $sumaOtros) . '.');
        }
        $cambio = round($efectivo + $sumaOtros - $total, 2);

        $cliente = $clienteId ? DB::uno('SELECT * FROM clientes WHERE id = ? AND activo = 1', [$clienteId]) : null;
        if ($clienteId && !$cliente) {
            throw new RuntimeException('El cliente elegido no existe.');
        }
        if ($creditoFiscal) {
            if (!$cliente || !$cliente['documento'] || !in_array($cliente['tipo_documento'], ['rnc', 'cedula'], true)) {
                throw new RuntimeException('Para factura de crédito fiscal el cliente debe tener RNC o cédula registrados.');
            }
        }

        return DB::tx(function () use ($calc, $cliente, $creditoFiscal, $limpios, $cambio, $notas, $total) {
            $ahora = date('Y-m-d H:i:s');
            $usuario = Auth::usuario();
            $ventaId = DB::insertar('ventas', [
                'numero' => self::siguienteNumero(),
                'fecha' => $ahora,
                'cliente_id' => $cliente['id'] ?? null,
                'usuario_id' => $usuario['id'] ?? null,
                'sede_id' => $usuario['sede_id'] ?? null,
                'subtotal' => $calc['subtotal'],
                'descuento' => $calc['descuento'],
                'itbis' => $calc['itbis'],
                'total' => $total,
                'cambio' => $cambio,
                'notas' => $notas ?: null,
            ]);
            foreach ($calc['lineas'] as $l) {
                DB::insertar('venta_items', array_diff_key($l, ['producto' => 1]) + ['venta_id' => $ventaId]);
                InventarioServicio::moverProducto($l['producto'], $l['cantidad'], 'venta', ['venta_id' => $ventaId, 'motivo' => 'Venta en caja']);
            }

            // Pagos e ingresos (el efectivo entra neto de cambio)
            $porDescontar = $cambio;
            foreach ($limpios as $pg) {
                $neto = $pg['monto'];
                if ($pg['metodo'] === 'efectivo' && $porDescontar > 0) {
                    $quita = min($porDescontar, $neto);
                    $neto -= $quita;
                    $porDescontar -= $quita;
                }
                if ($neto <= 0) {
                    continue;
                }
                DB::insertar('venta_pagos', ['venta_id' => $ventaId, 'metodo' => $pg['metodo'], 'monto' => round($neto, 2), 'referencia' => $pg['referencia']]);
                DB::insertar('ingresos', [
                    'fecha' => date('Y-m-d'),
                    'concepto' => 'Venta en caja ' . DB::valor('SELECT numero FROM ventas WHERE id = ?', [$ventaId]),
                    'linea_negocio' => 'tienda',
                    'monto' => round($neto, 2),
                    'metodo' => $pg['metodo'],
                    'origen_tipo' => 'venta',
                    'origen_id' => $ventaId,
                    'cliente_id' => $cliente['id'] ?? null,
                    'sede_id' => $usuario['sede_id'] ?? null,
                    'referencia' => $pg['referencia'],
                    'usuario_id' => $usuario['id'] ?? null,
                ]);
            }

            // Comprobante fiscal
            $tipo = self::tipoComprobante($creditoFiscal);
            $num = Ncf::siguiente($tipo);
            $sec = DB::uno('SELECT vence_en FROM secuencias_ncf WHERE id = ?', [$num['secuencia_id']]);
            $comprobanteId = DB::insertar('comprobantes', [
                'ncf' => $num['ncf'],
                'clase' => Ncf::TIPOS[$tipo]['clase'],
                'tipo' => $tipo,
                'secuencia_id' => $num['secuencia_id'],
                'vence_secuencia' => $sec['vence_en'] ?? null,
                'venta_id' => $ventaId,
                'cliente_id' => $cliente['id'] ?? null,
                'rnc_cedula' => $cliente && in_array($cliente['tipo_documento'], ['rnc', 'cedula'], true) ? $cliente['documento'] : null,
                'razon_social' => $cliente ? ($cliente['razon_social'] ?: $cliente['nombre']) : null,
                'subtotal' => $calc['subtotal'],
                'itbis' => $calc['itbis'],
                'total' => $total,
                'fecha' => $ahora,
                'ecf_estado' => Ncf::TIPOS[$tipo]['clase'] === 'electronico' ? 'pendiente' : null,
                'usuario_id' => $usuario['id'] ?? null,
            ]);
            return [$ventaId, $comprobanteId];
        });
    }

    /**
     * Anula una venta: devuelve el stock, anula ingresos y el comprobante.
     * Los e-CF no se anulan: se emite una nota de crédito electrónica (E34).
     * Devuelve el id de la nota de crédito si se creó.
     */
    public static function anular(array $venta, string $motivo): ?int
    {
        return DB::tx(function () use ($venta, $motivo) {
            $v = DB::uno('SELECT * FROM ventas WHERE id = ? FOR UPDATE', [$venta['id']]);
            if (!$v || $v['estado'] !== 'completada') {
                throw new RuntimeException('Esta venta ya está anulada.');
            }
            $items = DB::todos('SELECT * FROM venta_items WHERE venta_id = ?', [$v['id']]);
            foreach ($items as $it) {
                $p = $it['producto_id'] ? DB::uno('SELECT * FROM productos WHERE id = ?', [$it['producto_id']]) : null;
                if ($p) {
                    InventarioServicio::moverProducto($p, (float) $it['cantidad'], 'anulacion_venta', ['venta_id' => $v['id'], 'motivo' => 'Anulación: ' . $motivo]);
                }
            }
            DB::q("UPDATE ingresos SET anulado = 1, motivo_anulacion = ? WHERE origen_tipo = 'venta' AND origen_id = ?", ['Venta anulada: ' . $motivo, $v['id']]);
            DB::actualizar('ventas', [
                'estado' => 'anulada', 'motivo_anulacion' => $motivo, 'anulada_por' => Auth::id(), 'anulada_en' => date('Y-m-d H:i:s'),
            ], 'id = ?', [$v['id']]);

            $c = DB::uno("SELECT * FROM comprobantes WHERE venta_id = ? AND comprobante_origen_id IS NULL", [$v['id']]);
            if (!$c) {
                return null;
            }
            if ($c['clase'] === 'papel') {
                DB::actualizar('comprobantes', ['estado' => 'anulado', 'motivo_anulacion' => $motivo], 'id = ?', [$c['id']]);
                return null;
            }
            // e-CF: nota de crédito electrónica por el total
            $num = Ncf::siguiente('E34');
            return DB::insertar('comprobantes', [
                'ncf' => $num['ncf'],
                'clase' => 'electronico',
                'tipo' => 'E34',
                'secuencia_id' => $num['secuencia_id'],
                'venta_id' => $v['id'],
                'comprobante_origen_id' => $c['id'],
                'cliente_id' => $c['cliente_id'],
                'rnc_cedula' => $c['rnc_cedula'],
                'razon_social' => $c['razon_social'],
                'subtotal' => $c['subtotal'],
                'itbis' => $c['itbis'],
                'total' => $c['total'],
                'fecha' => date('Y-m-d H:i:s'),
                'motivo_anulacion' => $motivo,
                'ecf_estado' => 'pendiente',
                'usuario_id' => Auth::id(),
            ]);
        });
    }
}
