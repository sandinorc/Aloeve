<?php
declare(strict_types=1);

namespace App\Modulos\Ventas;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\App;
use App\Core\Config;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Ncf;
use App\Core\View;
use App\Modulos\Ecf\EcfServicio;
use RuntimeException;
use Throwable;

/** Historial de ventas, recibos, anulaciones y comprobantes emitidos. */
final class VentasControlador
{
    private const POR_PAGINA = 30;

    private function fechaValida(string $f): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $f);
        return $d !== false && $d->format('Y-m-d') === $f;
    }

    private function rango(): array
    {
        $desde = get('desde');
        $hasta = get('hasta');
        return [
            $this->fechaValida($desde) ? $desde : date('Y-m-01'),
            $this->fechaValida($hasta) ? $hasta : date('Y-m-d'),
        ];
    }

    private function venta(int $id): array
    {
        $v = DB::uno(
            'SELECT v.*, c.nombre AS cliente, c.documento AS cliente_documento, u.nombre AS cajero, a.nombre AS anulador, s.nombre AS sede
               FROM ventas v
               LEFT JOIN clientes c ON c.id = v.cliente_id
               LEFT JOIN usuarios u ON u.id = v.usuario_id
               LEFT JOIN usuarios a ON a.id = v.anulada_por
               LEFT JOIN sedes s ON s.id = v.sede_id
              WHERE v.id = ?',
            [$id]
        );
        if (!$v) {
            App::error(404);
        }
        // Caja solo ve sus propias ventas si no tiene permiso de finanzas
        if (!puede('finanzas.ver') && (int) $v['usuario_id'] !== (int) usuario()['id']) {
            App::error(403);
        }
        return $v;
    }

    /* ======================= Historial ======================= */

    public function lista(): never
    {
        [$desde, $hasta] = $this->rango();
        $donde = ['v.fecha >= ?', 'v.fecha < ?'];
        $params = [$desde . ' 00:00:00', date('Y-m-d', strtotime($hasta . ' +1 day')) . ' 00:00:00'];
        if (!puede('finanzas.ver')) {
            $donde[] = 'v.usuario_id = ?';
            $params[] = usuario()['id'];
        }
        if (in_array($e = get('estado'), ['completada', 'anulada'], true)) {
            $donde[] = 'v.estado = ?';
            $params[] = $e;
        }
        if (($q = get('q')) !== '') {
            $donde[] = '(v.numero LIKE ? OR c.nombre LIKE ? OR EXISTS (SELECT 1 FROM comprobantes k WHERE k.venta_id = v.id AND k.ncf LIKE ?))';
            array_push($params, "%$q%", "%$q%", "%$q%");
        }
        $where = implode(' AND ', $donde);
        $base = "FROM ventas v LEFT JOIN clientes c ON c.id = v.cliente_id LEFT JOIN usuarios u ON u.id = v.usuario_id WHERE $where";
        $select = "SELECT v.*, c.nombre AS cliente, u.nombre AS cajero,
                   (SELECT ncf FROM comprobantes k WHERE k.venta_id = v.id AND k.comprobante_origen_id IS NULL LIMIT 1) AS ncf,
                   (SELECT ecf_estado FROM comprobantes k WHERE k.venta_id = v.id AND k.comprobante_origen_id IS NULL LIMIT 1) AS ecf_estado,
                   (SELECT GROUP_CONCAT(DISTINCT metodo) FROM venta_pagos p WHERE p.venta_id = v.id) AS metodos ";

        if (get('formato') === 'csv') {
            $filas = DB::todos($select . $base . ' ORDER BY v.fecha', $params);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="ventas-' . $desde . '-a-' . $hasta . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['Número', 'Fecha', 'Cliente', 'Comprobante', 'Subtotal', 'Descuento', 'ITBIS', 'Total', 'Métodos', 'Estado', 'Cajero']);
            foreach ($filas as $f) {
                fputcsv($out, [$f['numero'], $f['fecha'], $f['cliente'] ?? 'Consumidor final', $f['ncf'], $f['subtotal'], $f['descuento'], $f['itbis'], $f['total'], $f['metodos'], $f['estado'], $f['cajero']]);
            }
            exit;
        }

        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) $base", $params);
        $sumas = DB::uno("SELECT COALESCE(SUM(CASE WHEN v.estado = 'completada' THEN v.total END), 0) AS total,
                                 COALESCE(SUM(CASE WHEN v.estado = 'completada' THEN v.itbis END), 0) AS itbis,
                                 SUM(v.estado = 'completada') AS cantidad, SUM(v.estado = 'anulada') AS anuladas $base", $params);
        $offset = ($pagina - 1) * self::POR_PAGINA;
        View::mostrar('ventas/lista', [
            'titulo' => 'Historial de ventas',
            'migas' => ['Ventas' => null, 'Historial' => null],
            'ventas' => DB::todos($select . $base . ' ORDER BY v.fecha DESC, v.id DESC LIMIT ' . self::POR_PAGINA . " OFFSET $offset", $params),
            'desde' => $desde,
            'hasta' => $hasta,
            'sumas' => $sumas,
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function ver(string $id): never
    {
        $v = $this->venta((int) $id);
        $comprobantes = DB::todos('SELECT * FROM comprobantes WHERE venta_id = ? ORDER BY id', [$v['id']]);
        foreach ($comprobantes as &$c) {
            $c['envios'] = DB::todos('SELECT * FROM ecf_envios WHERE comprobante_id = ? ORDER BY id DESC', [$c['id']]);
        }
        unset($c);
        View::mostrar('ventas/detalle', [
            'titulo' => 'Venta ' . $v['numero'],
            'migas' => ['Ventas' => '/ventas', $v['numero'] => null],
            'v' => $v,
            'items' => DB::todos('SELECT * FROM venta_items WHERE venta_id = ? ORDER BY id', [$v['id']]),
            'pagos' => DB::todos('SELECT * FROM venta_pagos WHERE venta_id = ? ORDER BY id', [$v['id']]),
            'comprobantes' => $comprobantes,
        ]);
    }

    /** Recibo de 80 mm, listo para imprimir. */
    public function recibo(string $id): never
    {
        $v = $this->venta((int) $id);
        $cid = (int) get('comprobante', '0');
        $c = $cid
            ? DB::uno('SELECT * FROM comprobantes WHERE id = ? AND venta_id = ?', [$cid, $v['id']])
            : DB::uno('SELECT * FROM comprobantes WHERE venta_id = ? AND comprobante_origen_id IS NULL', [$v['id']]);
        $origen = $c && $c['comprobante_origen_id'] ? DB::uno('SELECT ncf FROM comprobantes WHERE id = ?', [$c['comprobante_origen_id']]) : null;
        $qr = null;
        $urlQr = $c ? EcfServicio::urlQr($c) : null;
        if ($urlQr) {
            try {
                $qr = EcfServicio::qrSvg($urlQr);
            } catch (Throwable $e) {
                registrar_error('QR recibo: ' . $e->getMessage());
            }
        }
        echo View::render('ventas/recibo', [
            'v' => $v,
            'c' => $c,
            'origen' => $origen,
            'items' => DB::todos('SELECT * FROM venta_items WHERE venta_id = ? ORDER BY id', [$v['id']]),
            'pagos' => DB::todos('SELECT * FROM venta_pagos WHERE venta_id = ? ORDER BY id', [$v['id']]),
            'negocio' => Ajustes::todos(),
            'qr' => $qr,
            'urlQr' => $urlQr,
        ], null);
        exit;
    }

    public function anular(string $id): never
    {
        $v = $this->venta((int) $id);
        $motivo = mb_substr(post('motivo'), 0, 255);
        if (mb_strlen($motivo) < 4) {
            Flash::error('Escribe el motivo de la anulación.');
            redirigir('/ventas/' . $v['id']);
        }
        try {
            $notaId = VentasServicio::anular($v, $motivo);
        } catch (RuntimeException $e) {
            Flash::error($e->getMessage());
            redirigir('/ventas/' . $v['id']);
        }
        Actividad::registrar('ventas', 'anular', 'ventas', (int) $v['id'], 'Anuló la venta ' . $v['numero'] . ': ' . $motivo);
        if ($notaId) {
            $r = EcfServicio::emitir($notaId);
            $ncf = DB::valor('SELECT ncf FROM comprobantes WHERE id = ?', [$notaId]);
            $txt = EcfServicio::ESTADOS[$r['estado']][0] ?? (string) $r['estado'];
            Flash::ok('Venta anulada. Se emitió la nota de crédito ' . $ncf . ' (' . mb_strtolower($txt) . ').');
        } else {
            Flash::ok('Venta anulada. El stock y el ingreso se revirtieron.');
        }
        redirigir('/ventas/' . $v['id']);
    }

    /* ======================= Comprobantes emitidos ======================= */

    public function comprobantes(): never
    {
        [$desde, $hasta] = $this->rango();
        $donde = ['k.fecha >= ?', 'k.fecha < ?'];
        $params = [$desde . ' 00:00:00', date('Y-m-d', strtotime($hasta . ' +1 day')) . ' 00:00:00'];
        if (Ncf::existe($t = get('tipo'))) {
            $donde[] = 'k.tipo = ?';
            $params[] = $t;
        }
        if (isset(EcfServicio::ESTADOS[$e = get('ecf')])) {
            $donde[] = 'k.ecf_estado = ?';
            $params[] = $e;
        }
        if (($q = get('q')) !== '') {
            $donde[] = '(k.ncf LIKE ? OR k.razon_social LIKE ? OR k.rnc_cedula LIKE ?)';
            array_push($params, "%$q%", "%$q%", "%$q%");
        }
        $where = implode(' AND ', $donde);
        $filas = DB::todos(
            "SELECT k.*, v.numero AS venta, o.ncf AS ncf_origen FROM comprobantes k
               LEFT JOIN ventas v ON v.id = k.venta_id
               LEFT JOIN comprobantes o ON o.id = k.comprobante_origen_id
              WHERE $where ORDER BY k.fecha DESC, k.id DESC LIMIT 500",
            $params
        );
        if (get('formato') === 'csv') {
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="comprobantes-' . $desde . '-a-' . $hasta . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, ['NCF', 'Tipo', 'Fecha', 'RNC/Cédula', 'Razón social', 'Subtotal', 'ITBIS', 'Total', 'Estado', 'Estado e-CF', 'NCF modificado', 'Venta']);
            foreach ($filas as $f) {
                fputcsv($out, [$f['ncf'], $f['tipo'], $f['fecha'], $f['rnc_cedula'], $f['razon_social'], $f['subtotal'], $f['itbis'], $f['total'], $f['estado'], $f['ecf_estado'], $f['ncf_origen'], $f['venta']]);
            }
            exit;
        }
        View::mostrar('ventas/comprobantes', [
            'titulo' => 'Comprobantes emitidos',
            'migas' => ['Ventas' => null, 'Comprobantes emitidos' => null],
            'filas' => $filas,
            'desde' => $desde,
            'hasta' => $hasta,
            'pendientes' => (int) DB::valor("SELECT COUNT(*) FROM comprobantes WHERE ecf_estado IN ('pendiente','en_proceso')"),
            'problemas' => (int) DB::valor("SELECT COUNT(*) FROM comprobantes WHERE ecf_estado IN ('rechazado','error')"),
            'urlCron' => url('/cron/ecf') . '?clave=' . self::claveCron(),
        ]);
    }

    /** Descarga el XML enviado (firmado) de un envío. */
    public function xml(string $id): never
    {
        $e = DB::uno('SELECT e.*, k.ncf FROM ecf_envios e JOIN comprobantes k ON k.id = e.comprobante_id WHERE e.id = ?', [(int) $id]);
        if (!$e || !$e['xml_firmado']) {
            App::error(404);
        }
        header('Content-Type: application/xml; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . Ajustes::get('negocio.rnc') . $e['ncf'] . '.xml"');
        echo $e['xml_firmado'];
        exit;
    }

    /** Reintenta el envío de un e-CF pendiente, con error o rechazado. */
    public function reenviar(string $id): never
    {
        $c = DB::uno('SELECT * FROM comprobantes WHERE id = ?', [(int) $id]);
        if (!$c || $c['clase'] !== 'electronico') {
            App::error(404);
        }
        $volver = $c['venta_id'] ? '/ventas/' . $c['venta_id'] : '/comprobantes';
        if (in_array($c['ecf_estado'], ['aceptado', 'aceptado_condicional'], true)) {
            Flash::aviso('Ese comprobante ya fue aceptado.');
            redirigir($volver);
        }
        $ultimo = DB::uno('SELECT * FROM ecf_envios WHERE comprobante_id = ? ORDER BY id DESC LIMIT 1', [$c['id']]);
        if ($ultimo && $ultimo['estado'] === 'en_proceso') {
            $r = EcfServicio::consultar((int) $ultimo['id']);
        } else {
            if ($ultimo && $ultimo['estado'] === 'pendiente') {
                DB::actualizar('ecf_envios', ['estado' => 'error', 'mensajes' => json_encode([['valor' => 'Reemplazado por un reenvío manual.']])], 'id = ?', [$ultimo['id']]);
            }
            $r = EcfServicio::emitir((int) $c['id']);
        }
        Actividad::registrar('fiscal', 'reenviar', 'comprobantes', (int) $c['id'], 'Reenvió el e-CF ' . $c['ncf']);
        $txt = EcfServicio::ESTADOS[$r['estado']][0] ?? (string) $r['estado'];
        $msg = $r['mensajes'][0]['valor'] ?? '';
        in_array($r['estado'], ['aceptado', 'aceptado_condicional', 'en_proceso'], true)
            ? Flash::ok($c['ncf'] . ': ' . $txt . '.')
            : Flash::error($c['ncf'] . ': ' . $txt . ($msg ? ' — ' . $msg : ''));
        redirigir($volver);
    }

    public function procesarCola(): never
    {
        $r = EcfServicio::procesarCola();
        Flash::ok(sprintf('Cola procesada: %d reenviados y %d consultados.', $r['reenviados'], $r['consultados']));
        redirigir('/comprobantes');
    }

    /* ======================= Tarea programada ======================= */

    public static function claveCron(): string
    {
        return substr(hash_hmac('sha256', 'cron-ecf', (string) Config::get('app.llave', '')), 0, 32);
    }

    /** GET /cron/ecf?clave=… — para el cron de Hostinger. */
    public function cron(): never
    {
        if (!hash_equals(self::claveCron(), get('clave'))) {
            http_response_code(403);
            exit('Clave inválida');
        }
        $r = EcfServicio::procesarCola();
        header('Content-Type: text/plain; charset=utf-8');
        echo 'OK ' . date('Y-m-d H:i:s') . ' reenviados=' . $r['reenviados'] . ' consultados=' . $r['consultados'] . "\n";
        exit;
    }
}
