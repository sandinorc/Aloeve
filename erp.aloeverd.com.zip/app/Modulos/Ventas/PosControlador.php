<?php
declare(strict_types=1);

namespace App\Modulos\Ventas;

use App\Core\Actividad;
use App\Core\Ajustes;
use App\Core\DB;
use App\Core\Ncf;
use App\Core\View;
use App\Modulos\Ecf\EcfServicio;
use RuntimeException;
use Throwable;

/** Punto de venta (caja). PRD §8.6. */
final class PosControlador
{
    /** Productos activos con su disponibilidad real (stock propio o del material). */
    private function productos(): array
    {
        $filas = DB::todos(
            'SELECT p.id, p.sku, p.nombre, p.categoria, p.precio, p.lleva_itbis, p.control_stock, p.stock,
                    p.factor_material, m.stock AS stock_material, m.nombre AS material
               FROM productos p LEFT JOIN materiales m ON m.id = p.material_id
              WHERE p.activo = 1 ORDER BY p.categoria, p.nombre'
        );
        return array_map(static function ($p) {
            $disp = match ($p['control_stock']) {
                'propio' => (float) $p['stock'],
                'material' => (float) $p['factor_material'] > 0 ? floor((float) $p['stock_material'] / (float) $p['factor_material'] * 1000) / 1000 : 0,
                default => null,
            };
            return [
                'id' => (int) $p['id'],
                'sku' => $p['sku'],
                'nombre' => $p['nombre'],
                'categoria' => $p['categoria'],
                'precio' => (float) $p['precio'],
                'itbis' => (int) $p['lleva_itbis'] === 1,
                'disponible' => $disp,
            ];
        }, $filas);
    }

    public function inicio(): never
    {
        $productos = $this->productos();
        $ecf = EcfServicio::activo();
        $tipoConsumo = VentasServicio::tipoComprobante(false);
        $tipoCredito = VentasServicio::tipoComprobante(true);
        $disponible = static fn(string $t) => (int) DB::valor(
            'SELECT COALESCE(SUM(hasta - proximo + 1), 0) FROM secuencias_ncf
              WHERE tipo = ? AND activa = 1 AND proximo <= hasta AND (vence_en IS NULL OR vence_en >= CURDATE())',
            [$t]
        );
        View::mostrar('pos/inicio', [
            'titulo' => 'Punto de venta',
            'migas' => ['Ventas' => null, 'Punto de venta' => null],
            'productos' => $productos,
            'categorias' => array_values(array_unique(array_column($productos, 'categoria'))),
            'tasaItbis' => (float) Ajustes::get('fiscal.itbis', '18'),
            'ecf' => $ecf,
            'tipoConsumo' => $tipoConsumo,
            'tipoCredito' => $tipoCredito,
            'quedanConsumo' => $disponible($tipoConsumo),
            'quedanCredito' => $disponible($tipoCredito),
            'ultimas' => DB::todos(
                "SELECT v.id, v.numero, v.total, v.fecha, v.estado, c.nombre AS cliente
                   FROM ventas v LEFT JOIN clientes c ON c.id = v.cliente_id
                  WHERE v.usuario_id = ? AND DATE(v.fecha) = CURDATE() ORDER BY v.id DESC LIMIT 5",
                [usuario()['id']]
            ),
        ]);
    }

    /** POST JSON: {carrito:[{producto_id,cantidad}], cliente_id, credito_fiscal, descuento, pagos:[{metodo,monto,referencia}], notas} */
    public function cobrar(): never
    {
        $d = json_decode((string) file_get_contents('php://input'), true);
        if (!is_array($d)) {
            json(['ok' => false, 'error' => 'Solicitud inválida.'], 400);
        }
        $descuento = (float) ($d['descuento'] ?? 0);
        if ($descuento > 0 && !puede('pos.descuento')) {
            json(['ok' => false, 'error' => 'Tu usuario no puede aplicar descuentos.'], 403);
        }
        $carrito = array_values(array_filter((array) ($d['carrito'] ?? []), 'is_array'));
        $pagos = array_values(array_filter((array) ($d['pagos'] ?? []), 'is_array'));
        try {
            [$ventaId, $comprobanteId] = VentasServicio::cobrar(
                $carrito,
                !empty($d['cliente_id']) ? (int) $d['cliente_id'] : null,
                !empty($d['credito_fiscal']),
                $descuento,
                $pagos,
                isset($d['notas']) ? mb_substr(trim((string) $d['notas']), 0, 255) : null
            );
        } catch (RuntimeException $e) {
            json(['ok' => false, 'error' => $e->getMessage()], 422);
        } catch (Throwable $e) {
            registrar_error('POS cobrar: ' . $e->getMessage());
            json(['ok' => false, 'error' => 'No se pudo registrar la venta; no se guardó nada. Intenta de nuevo o avisa a administración.'], 500);
        }

        $v = DB::uno('SELECT * FROM ventas WHERE id = ?', [$ventaId]);
        $c = DB::uno('SELECT * FROM comprobantes WHERE id = ?', [$comprobanteId]);
        Actividad::registrar('ventas', 'crear', 'ventas', $ventaId, 'Venta ' . $v['numero'] . ' por ' . dinero($v['total']) . ' · ' . $c['ncf']);

        $ecf = null;
        if ($c['clase'] === 'electronico') {
            try {
                $ecf = EcfServicio::emitir($comprobanteId);
            } catch (Throwable $e) {
                registrar_error('POS e-CF: ' . $e->getMessage());
                $ecf = ['estado' => 'pendiente'];
            }
        }
        json([
            'ok' => true,
            'venta' => ['id' => $ventaId, 'numero' => $v['numero'], 'total' => (float) $v['total'], 'cambio' => (float) $v['cambio']],
            'comprobante' => ['ncf' => $c['ncf'], 'tipo' => $c['tipo'], 'nombre' => Ncf::nombre($c['tipo'])],
            'ecf' => $ecf ? ['estado' => $ecf['estado'], 'texto' => EcfServicio::ESTADOS[$ecf['estado']][0] ?? $ecf['estado']] : null,
            'recibo' => url('/ventas/' . $ventaId . '/recibo'),
            'detalle' => url('/ventas/' . $ventaId),
        ]);
    }
}
