<?php
declare(strict_types=1);

namespace App\Modulos\Clientes;

use App\Core\DB;
use App\Core\Validar;
use PDOException;

final class ClientesServicio
{
    public const FUENTES = [
        'plaza' => 'Plaza (pasó por el estudio)',
        'digital' => 'Digital (redes, Google)',
        'referido' => 'Referido por otro cliente',
        'amelia' => 'Reserva web (Amelia)',
        'formulario' => 'Formulario web',
        'otro' => 'Otro',
    ];

    public const DOCUMENTOS = [
        'ninguno' => 'Sin documento',
        'cedula' => 'Cédula',
        'rnc' => 'RNC (empresa)',
        'pasaporte' => 'Pasaporte',
    ];

    public const SEGMENTOS = [
        'sin_visitas' => ['Sin visitas', 'chip-gris'],
        'nuevo' => ['Nuevo', 'chip-morado'],
        'recurrente' => ['Recurrente', 'chip-verde'],
        'fiel' => ['Fiel', 'chip-dorado'],
        'inactivo' => ['Inactivo', 'chip-ambar'],
        'corporativo' => ['Corporativo', 'chip-morado'],
    ];

    /** Deja solo dígitos; números locales de 10 dígitos se guardan tal cual (8095551234). */
    public static function normalizarTelefono(string $tel): ?string
    {
        $d = Validar::soloDigitos($tel);
        if ($d === '') {
            return null;
        }
        if (strlen($d) === 11 && str_starts_with($d, '1')) {
            $d = substr($d, 1);
        }
        return $d;
    }

    public static function formatearTelefono(?string $tel): string
    {
        if (!$tel) {
            return '';
        }
        return strlen($tel) === 10 ? sprintf('(%s) %s-%s', substr($tel, 0, 3), substr($tel, 3, 3), substr($tel, 6)) : $tel;
    }

    /** Enlace de WhatsApp (República Dominicana: prefijo 1). */
    public static function enlaceWhatsapp(?string $tel, string $mensaje = ''): ?string
    {
        if (!$tel) {
            return null;
        }
        $num = strlen($tel) === 10 ? '1' . $tel : $tel;
        return 'https://wa.me/' . $num . ($mensaje !== '' ? '?text=' . rawurlencode($mensaje) : '');
    }

    /**
     * Busca posibles duplicados.
     * @return array{bloqueo: ?array, aviso: ?array} bloqueo = mismo correo o documento; aviso = mismo teléfono
     */
    public static function duplicados(?string $email, ?string $documento, ?string $telefono, int $excluir = 0): array
    {
        $bloqueo = null;
        if ($email) {
            $bloqueo = DB::uno('SELECT id, nombre, email FROM clientes WHERE email = ? AND id <> ?', [$email, $excluir]);
            if ($bloqueo) {
                $bloqueo['motivo'] = 'el mismo correo';
            }
        }
        if (!$bloqueo && $documento) {
            $bloqueo = DB::uno('SELECT id, nombre, documento FROM clientes WHERE documento = ? AND id <> ?', [$documento, $excluir]);
            if ($bloqueo) {
                $bloqueo['motivo'] = 'el mismo documento';
            }
        }
        $aviso = null;
        if ($telefono) {
            $aviso = DB::uno(
                'SELECT id, nombre, telefono FROM clientes WHERE (telefono = ? OR whatsapp = ?) AND id <> ? AND activo = 1 LIMIT 1',
                [$telefono, $telefono, $excluir]
            );
        }
        return ['bloqueo' => $bloqueo, 'aviso' => $aviso];
    }

    /**
     * Actividad del cliente. Las fuentes (ventas, reservas) se suman a medida que existen sus módulos.
     * @return array{visitas:int, ultima:?string, compras:int, total:float}
     */
    public static function actividad(int $id): array
    {
        $r = ['visitas' => 0, 'ultima' => null, 'compras' => 0, 'total' => 0.0];
        try {
            $v = DB::uno(
                "SELECT COUNT(*) AS n, MAX(s.fecha) AS ultima FROM reservas r JOIN sesiones s ON s.id = r.sesion_id
                  WHERE r.cliente_id = ? AND r.asistio = 1",
                [$id]
            );
            $r['visitas'] = (int) ($v['n'] ?? 0);
            $r['ultima'] = $v['ultima'] ?? null;
        } catch (PDOException) {
            // El módulo de agenda llega en la Fase 2C
        }
        try {
            $c = DB::uno("SELECT COUNT(*) AS n, COALESCE(SUM(total),0) AS t FROM ventas WHERE cliente_id = ? AND estado = 'completada'", [$id]);
            $r['compras'] = (int) ($c['n'] ?? 0);
            $r['total'] = (float) ($c['t'] ?? 0);
        } catch (PDOException) {
            // Instalación sin la migración 004
        }
        return $r;
    }

    /** Segmento calculado (PRD §8.2). Nunca se escribe a mano. */
    public static function segmento(array $cliente, array $actividad): string
    {
        if (($cliente['tipo_documento'] ?? '') === 'rnc') {
            return 'corporativo';
        }
        $v = $actividad['visitas'];
        if ($v === 0) {
            return 'sin_visitas';
        }
        if ($actividad['ultima'] && strtotime($actividad['ultima']) < strtotime('-90 days')) {
            return 'inactivo';
        }
        return match (true) {
            $v >= 5 => 'fiel',
            $v >= 2 => 'recurrente',
            default => 'nuevo',
        };
    }

    /** Une $origen dentro de $destino: mueve referencias y desactiva el duplicado. */
    public static function fusionar(int $destino, int $origen): void
    {
        DB::tx(function () use ($destino, $origen) {
            DB::q('UPDATE clientes SET referido_por_id = ? WHERE referido_por_id = ?', [$destino, $origen]);
            foreach (['ventas', 'reservas', 'inscripciones', 'comprobantes', 'solicitudes_web'] as $tabla) {
                try {
                    DB::q("UPDATE `$tabla` SET cliente_id = ? WHERE cliente_id = ?", [$destino, $origen]);
                } catch (PDOException) {
                    // Tabla aún no creada en esta fase
                }
            }
            $o = DB::uno('SELECT * FROM clientes WHERE id = ?', [$origen]);
            $d = DB::uno('SELECT * FROM clientes WHERE id = ?', [$destino]);
            // Completar datos vacíos del destino con los del duplicado
            $completar = [];
            foreach (['email', 'documento', 'telefono', 'whatsapp', 'direccion', 'fecha_nacimiento', 'razon_social'] as $c) {
                if (empty($d[$c]) && !empty($o[$c])) {
                    $completar[$c] = $o[$c];
                }
            }
            DB::actualizar('clientes', [
                'activo' => 0,
                'fusionado_en_id' => $destino,
                'email' => null,
                'documento' => null,
                'amelia_customer_id' => null,
                'notas' => trim(($o['notas'] ?? '') . "\nFusionado en el cliente #$destino el " . date('d/m/Y')),
            ], 'id = ?', [$origen]);
            if ($completar) {
                DB::actualizar('clientes', $completar, 'id = ?', [$destino]);
            }
        });
    }
}
