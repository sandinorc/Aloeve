<?php
declare(strict_types=1);

namespace App\Modulos\Clientes;

use App\Core\Actividad;
use App\Core\App;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Validar;
use App\Core\View;
use App\Modulos\Clientes\ClientesServicio as S;

final class ClientesControlador
{
    private const POR_PAGINA = 25;

    private function filtros(): array
    {
        $donde = ['c.fusionado_en_id IS NULL'];
        $params = [];
        $q = get('q');
        if ($q !== '') {
            $digitos = Validar::soloDigitos($q);
            $partes = ['c.nombre LIKE ?', 'c.email LIKE ?', 'c.razon_social LIKE ?'];
            $params = ["%$q%", "%$q%", "%$q%"];
            if (strlen($digitos) >= 3) {
                $partes[] = 'c.telefono LIKE ?';
                $partes[] = 'c.whatsapp LIKE ?';
                $partes[] = 'c.documento LIKE ?';
                array_push($params, "%$digitos%", "%$digitos%", "%$digitos%");
            }
            $donde[] = '(' . implode(' OR ', $partes) . ')';
        }
        if (isset(S::FUENTES[$f = get('fuente')])) {
            $donde[] = 'c.fuente = ?';
            $params[] = $f;
        }
        $estado = get('estado', 'activos');
        if ($estado === 'activos') {
            $donde[] = 'c.activo = 1';
        } elseif ($estado === 'inactivos') {
            $donde[] = 'c.activo = 0';
        }
        if (get('tipo') === 'empresas') {
            $donde[] = "c.tipo_documento = 'rnc'";
        }
        return [implode(' AND ', $donde), $params];
    }

    public function lista(): never
    {
        [$where, $params] = $this->filtros();
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) FROM clientes c WHERE $where", $params);
        $offset = ($pagina - 1) * self::POR_PAGINA;
        $clientes = DB::todos(
            "SELECT c.*, s.nombre AS sede FROM clientes c LEFT JOIN sedes s ON s.id = c.sede_id
              WHERE $where ORDER BY c.activo DESC, c.nombre ASC LIMIT " . self::POR_PAGINA . " OFFSET $offset",
            $params
        );
        foreach ($clientes as &$c) {
            $c['actividad'] = S::actividad((int) $c['id']);
            $c['segmento'] = S::segmento($c, $c['actividad']);
        }
        unset($c);

        View::mostrar('clientes/lista', [
            'titulo' => 'Clientes',
            'migas' => ['Clientes' => null],
            'clientes' => $clientes,
            'total' => $total,
            'totalActivos' => (int) DB::valor('SELECT COUNT(*) FROM clientes WHERE activo = 1'),
            'nuevosMes' => (int) DB::valor('SELECT COUNT(*) FROM clientes WHERE activo = 1 AND creado_en >= ?', [date('Y-m-01')]),
            'empresas' => (int) DB::valor("SELECT COUNT(*) FROM clientes WHERE activo = 1 AND tipo_documento = 'rnc'"),
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function exportar(): never
    {
        [$where, $params] = $this->filtros();
        $st = DB::q(
            "SELECT c.nombre, c.tipo_documento, c.documento, c.razon_social, c.email, c.telefono, c.whatsapp, c.direccion,
                    c.fecha_nacimiento, c.fuente, c.origen, c.activo, c.creado_en
               FROM clientes c WHERE $where ORDER BY c.nombre LIMIT 20000",
            $params
        );
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="clientes-' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Nombre', 'Tipo documento', 'Documento', 'Razón social', 'Correo', 'Teléfono', 'WhatsApp', 'Dirección', 'Nacimiento', 'Fuente', 'Origen', 'Activo', 'Creado']);
        while ($f = $st->fetch()) {
            $f = array_map(static fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $f);
            fputcsv($out, array_values($f));
        }
        fclose($out);
        Actividad::registrar('clientes', 'exportar', 'clientes', null, 'Exportó la lista de clientes');
        exit;
    }

    /** Búsqueda rápida para selectores (JSON). */
    public function buscar(): never
    {
        $q = get('q');
        if (mb_strlen($q) < 2) {
            json(['ok' => true, 'resultados' => []]);
        }
        $d = Validar::soloDigitos($q);
        $sql = 'SELECT id, nombre, email, telefono, documento, tipo_documento, razon_social FROM clientes
                 WHERE activo = 1 AND (nombre LIKE ? OR email LIKE ?' . (strlen($d) >= 3 ? ' OR telefono LIKE ? OR documento LIKE ?' : '') . ')
                 ORDER BY nombre LIMIT 10';
        $params = ["%$q%", "%$q%"];
        if (strlen($d) >= 3) {
            array_push($params, "%$d%", "%$d%");
        }
        $filas = array_map(static fn($c) => [
            'id' => (int) $c['id'],
            'nombre' => $c['nombre'],
            'detalle' => trim(implode(' · ', array_filter([$c['documento'], S::formatearTelefono($c['telefono']), $c['email']]))),
            'documento' => $c['documento'],
            'tipo_documento' => $c['tipo_documento'],
            'razon_social' => $c['razon_social'],
        ], DB::todos($sql, $params));
        json(['ok' => true, 'resultados' => $filas]);
    }

    private function tomarAviso(): ?array
    {
        $a = $_SESSION['_aviso_duplicado'] ?? null;
        unset($_SESSION['_aviso_duplicado']);
        return $a;
    }

    private function sedes(): array
    {
        return DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre');
    }

    public function nuevo(): never
    {
        View::mostrar('clientes/formulario', [
            'titulo' => 'Nuevo cliente',
            'migas' => ['Clientes' => '/clientes', 'Nuevo' => null],
            'cliente' => null,
            'referido' => null,
            'sedes' => $this->sedes(),
            'aviso' => $this->tomarAviso(),
        ]);
    }

    /** Lee y valida el formulario. Si hay error, vuelve al formulario. */
    private function datos(?int $id): array
    {
        $volver = $id ? "/clientes/$id/editar" : '/clientes/nuevo';
        $tipoDoc = post('tipo_documento', 'ninguno');
        $tipoDoc = isset(S::DOCUMENTOS[$tipoDoc]) ? $tipoDoc : 'ninguno';
        $documento = $tipoDoc === 'pasaporte' ? mb_strtoupper(preg_replace('/\s+/', '', post('documento')) ?? '') : Validar::soloDigitos(post('documento'));
        $fuente = post('fuente', 'plaza');
        $d = [
            'nombre' => post('nombre'),
            'tipo_documento' => $tipoDoc,
            'documento' => $tipoDoc === 'ninguno' || $documento === '' ? null : $documento,
            'razon_social' => $tipoDoc === 'rnc' ? (post('razon_social') ?: null) : null,
            'email' => mb_strtolower(post('email')) ?: null,
            'telefono' => S::normalizarTelefono(post('telefono')),
            'whatsapp' => S::normalizarTelefono(post('whatsapp')),
            'direccion' => post('direccion') ?: null,
            'fecha_nacimiento' => preg_match('/^\d{4}-\d{2}-\d{2}$/', post('fecha_nacimiento')) ? post('fecha_nacimiento') : null,
            'fuente' => isset(S::FUENTES[$fuente]) ? $fuente : 'otro',
            'referido_por_id' => (int) post('referido_por_id') ?: null,
            'sede_id' => (int) post('sede_id') ?: null,
            'notas' => post('notas') ?: null,
        ];
        if ($d['fuente'] !== 'referido') {
            $d['referido_por_id'] = null;
        }

        $error = match (true) {
            $d['nombre'] === '' => 'Escribe el nombre del cliente.',
            $d['email'] !== null && !Validar::email($d['email']) => 'El correo no es válido.',
            $tipoDoc === 'cedula' && $d['documento'] !== null && !Validar::cedula($d['documento']) => 'La cédula no es válida (11 dígitos con dígito verificador).',
            $tipoDoc === 'rnc' && ($d['documento'] === null || !Validar::rnc($d['documento'])) => 'El RNC no es válido (9 dígitos con dígito verificador).',
            $tipoDoc === 'rnc' && !$d['razon_social'] => 'Escribe la razón social de la empresa; sale en la factura de crédito fiscal.',
            $d['telefono'] !== null && strlen($d['telefono']) < 7 => 'El teléfono parece incompleto.',
            $d['referido_por_id'] !== null && $d['referido_por_id'] === $id => 'Un cliente no puede referirse a sí mismo.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($volver);
        }

        $dup = S::duplicados($d['email'], $d['documento'], $d['telefono'], $id ?? 0);
        if ($dup['bloqueo']) {
            Flash::recordarFormulario();
            $_SESSION['_aviso_duplicado'] = ['id' => $dup['bloqueo']['id'], 'nombre' => $dup['bloqueo']['nombre'], 'motivo' => $dup['bloqueo']['motivo'], 'bloquea' => true];
            redirigir($volver);
        }
        if ($dup['aviso'] && post('confirmar_telefono') !== '1') {
            Flash::recordarFormulario();
            $_SESSION['_aviso_duplicado'] = ['id' => $dup['aviso']['id'], 'nombre' => $dup['aviso']['nombre'], 'motivo' => 'el mismo teléfono', 'bloquea' => false];
            redirigir($volver);
        }
        unset($_SESSION['_aviso_duplicado']);
        return $d;
    }

    public function crear(): never
    {
        $d = $this->datos(null);
        $d['creado_por'] = Auth::id();
        $id = DB::insertar('clientes', $d);
        Actividad::registrar('clientes', 'crear', 'clientes', $id, 'Creó el cliente ' . $d['nombre'], null, $d);
        Flash::limpiarFormulario();
        Flash::ok('Cliente creado.');
        redirigir("/clientes/$id");
    }

    private function buscarCliente(int $id): array
    {
        $c = DB::uno('SELECT c.*, s.nombre AS sede FROM clientes c LEFT JOIN sedes s ON s.id = c.sede_id WHERE c.id = ?', [$id]);
        if (!$c) {
            App::error(404);
        }
        if ($c['fusionado_en_id']) {
            Flash::aviso('Este cliente se fusionó con otro. Te llevamos al registro que quedó.');
            redirigir('/clientes/' . $c['fusionado_en_id']);
        }
        return $c;
    }

    public function ver(string $id): never
    {
        $c = $this->buscarCliente((int) $id);
        $actividad = S::actividad((int) $c['id']);
        View::mostrar('clientes/ficha', [
            'titulo' => $c['nombre'],
            'migas' => ['Clientes' => '/clientes', $c['nombre'] => null],
            'c' => $c,
            'actividad' => $actividad,
            'segmento' => S::segmento($c, $actividad),
            'referido' => $c['referido_por_id'] ? DB::uno('SELECT id, nombre FROM clientes WHERE id = ?', [$c['referido_por_id']]) : null,
            'referidos' => DB::todos('SELECT id, nombre, creado_en FROM clientes WHERE referido_por_id = ? AND activo = 1 ORDER BY creado_en DESC', [$c['id']]),
            'reservas' => DB::todos(
                'SELECT r.estado, r.asistio, s.id AS sesion_id, s.fecha, s.hora_inicio, sv.nombre AS servicio
                   FROM reservas r JOIN sesiones s ON s.id = r.sesion_id JOIN servicios sv ON sv.id = s.servicio_id
                  WHERE r.cliente_id = ? ORDER BY s.fecha DESC, s.hora_inicio DESC LIMIT 8',
                [$c['id']]
            ),
            'compras' => DB::todos(
                'SELECT v.id, v.numero, v.fecha, v.total, v.estado,
                        (SELECT ncf FROM comprobantes k WHERE k.venta_id = v.id AND k.comprobante_origen_id IS NULL LIMIT 1) AS ncf
                   FROM ventas v WHERE v.cliente_id = ? ORDER BY v.fecha DESC LIMIT 8',
                [$c['id']]
            ),
            'historial' => DB::todos(
                "SELECT a.fecha, a.descripcion, u.nombre AS usuario FROM actividad a LEFT JOIN usuarios u ON u.id = a.usuario_id
                  WHERE a.entidad = 'clientes' AND a.entidad_id = ? ORDER BY a.fecha DESC LIMIT 15",
                [$c['id']]
            ),
        ]);
    }

    public function editar(string $id): never
    {
        $c = $this->buscarCliente((int) $id);
        View::mostrar('clientes/formulario', [
            'titulo' => 'Editar cliente',
            'migas' => ['Clientes' => '/clientes', $c['nombre'] => '/clientes/' . $c['id'], 'Editar' => null],
            'cliente' => $c,
            'referido' => $c['referido_por_id'] ? DB::uno('SELECT id, nombre FROM clientes WHERE id = ?', [$c['referido_por_id']]) : null,
            'sedes' => $this->sedes(),
            'aviso' => $this->tomarAviso(),
        ]);
    }

    public function guardar(string $id): never
    {
        $antes = $this->buscarCliente((int) $id);
        $d = $this->datos((int) $id);
        DB::actualizar('clientes', $d, 'id = ?', [$antes['id']]);
        [$a, $dd] = Actividad::diferencias($antes, $d);
        if ($dd) {
            Actividad::registrar('clientes', 'editar', 'clientes', (int) $antes['id'], 'Editó el cliente ' . $d['nombre'], $a, $dd);
        }
        Flash::limpiarFormulario();
        Flash::ok('Cambios guardados.');
        redirigir('/clientes/' . $antes['id']);
    }

    public function estado(string $id): never
    {
        $c = $this->buscarCliente((int) $id);
        $nuevo = (int) $c['activo'] === 1 ? 0 : 1;
        DB::actualizar('clientes', ['activo' => $nuevo], 'id = ?', [$c['id']]);
        Actividad::registrar('clientes', $nuevo ? 'activar' : 'desactivar', 'clientes', (int) $c['id'],
            ($nuevo ? 'Reactivó' : 'Desactivó') . ' el cliente ' . $c['nombre']);
        Flash::ok($nuevo ? 'Cliente reactivado.' : 'Cliente desactivado. Su historial se conserva.');
        redirigir('/clientes/' . $c['id']);
    }

    public function fusionar(string $id): never
    {
        $destino = $this->buscarCliente((int) $id);
        $origenId = (int) post('origen_id');
        $origen = DB::uno('SELECT * FROM clientes WHERE id = ? AND fusionado_en_id IS NULL', [$origenId]);
        if (!$origen || $origenId === (int) $destino['id']) {
            Flash::error('Elige el cliente duplicado que quieres unir a este.');
            redirigir('/clientes/' . $destino['id']);
        }
        S::fusionar((int) $destino['id'], $origenId);
        Actividad::registrar('clientes', 'fusionar', 'clientes', (int) $destino['id'],
            'Unió el cliente duplicado "' . $origen['nombre'] . '" (#' . $origenId . ') en "' . $destino['nombre'] . '"',
            ['duplicado' => $origen['nombre'] . ' #' . $origenId], ['queda' => $destino['nombre'] . ' #' . $destino['id']]);
        Flash::ok('Clientes unidos. El historial de "' . $origen['nombre'] . '" ahora está en este cliente.');
        redirigir('/clientes/' . $destino['id']);
    }

    /** Segmentos e inactivos (PRD §8.2). */
    public function segmentos(): never
    {
        $filas = DB::todos(
            "SELECT c.id, c.nombre, c.telefono, c.whatsapp, c.tipo_documento, c.email,
                    COUNT(r.id) AS visitas, MAX(s.fecha) AS ultima
               FROM clientes c
               LEFT JOIN reservas r ON r.cliente_id = c.id AND r.asistio = 1
               LEFT JOIN sesiones s ON s.id = r.sesion_id
              WHERE c.activo = 1 AND c.fusionado_en_id IS NULL
              GROUP BY c.id"
        );
        $conteo = array_fill_keys(array_keys(S::SEGMENTOS), 0);
        $inactivos = [];
        foreach ($filas as $f) {
            $seg = S::segmento($f, ['visitas' => (int) $f['visitas'], 'ultima' => $f['ultima']]);
            $conteo[$seg]++;
            if ($seg === 'inactivo') {
                $f['dias'] = (int) floor((time() - strtotime($f['ultima'])) / 86400);
                $inactivos[] = $f;
            }
        }
        usort($inactivos, static fn($a, $b) => $b['visitas'] <=> $a['visitas']);

        // Retención: de quienes vinieron el mes pasado, cuántos volvieron este mes
        $mesPasado = [date('Y-m-01', strtotime('first day of last month')), date('Y-m-t', strtotime('last day of last month'))];
        $base = array_column(DB::todos(
            'SELECT DISTINCT r.cliente_id FROM reservas r JOIN sesiones s ON s.id = r.sesion_id WHERE r.asistio = 1 AND s.fecha BETWEEN ? AND ?',
            $mesPasado
        ), 'cliente_id');
        $volvieron = $base ? (int) DB::valor(
            'SELECT COUNT(DISTINCT r.cliente_id) FROM reservas r JOIN sesiones s ON s.id = r.sesion_id
              WHERE r.asistio = 1 AND s.fecha BETWEEN ? AND ? AND r.cliente_id IN (' . implode(',', array_map('intval', $base)) . ')',
            [date('Y-m-01'), date('Y-m-t')]
        ) : 0;

        View::mostrar('clientes/segmentos', [
            'titulo' => 'Segmentos e inactivos',
            'migas' => ['Clientes' => '/clientes', 'Segmentos e inactivos' => null],
            'conteo' => $conteo,
            'total' => count($filas),
            'inactivos' => $inactivos,
            'retencion' => $base ? ['base' => count($base), 'volvieron' => $volvieron] : null,
        ]);
    }
}
