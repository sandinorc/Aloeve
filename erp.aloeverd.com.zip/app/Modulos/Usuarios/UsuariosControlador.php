<?php
declare(strict_types=1);

namespace App\Modulos\Usuarios;

use App\Core\Actividad;
use App\Core\App;
use App\Core\Auth;
use App\Core\DB;
use App\Core\Flash;
use App\Core\Validar;
use App\Core\View;

final class UsuariosControlador
{
    private const POR_PAGINA = 25;

    public function lista(): never
    {
        $q = get('q');
        $rol = (int) get('rol');
        $estado = get('estado');
        $pagina = max(1, (int) get('pagina', '1'));

        $donde = ['1 = 1'];
        $params = [];
        if ($q !== '') {
            $donde[] = '(u.nombre LIKE ? OR u.email LIKE ?)';
            $params[] = "%$q%";
            $params[] = "%$q%";
        }
        if ($rol > 0) {
            $donde[] = 'u.rol_id = ?';
            $params[] = $rol;
        }
        if ($estado === 'activos') {
            $donde[] = 'u.activo = 1';
        } elseif ($estado === 'inactivos') {
            $donde[] = 'u.activo = 0';
        }
        $where = implode(' AND ', $donde);
        $total = (int) DB::valor("SELECT COUNT(*) FROM usuarios u WHERE $where", $params);
        $offset = ($pagina - 1) * self::POR_PAGINA;
        $usuarios = DB::todos(
            "SELECT u.id, u.nombre, u.email, u.activo, u.ultimo_acceso, u.creado_en, u.debe_cambiar_clave,
                    r.nombre AS rol, s.nombre AS sede
               FROM usuarios u
               JOIN roles r ON r.id = u.rol_id
               LEFT JOIN sedes s ON s.id = u.sede_id
              WHERE $where
              ORDER BY u.activo DESC, u.nombre ASC
              LIMIT " . self::POR_PAGINA . " OFFSET $offset",
            $params
        );

        View::mostrar('usuarios/lista', [
            'titulo' => 'Usuarios',
            'migas' => ['Administración' => null, 'Usuarios' => null],
            'usuarios' => $usuarios,
            'roles' => DB::todos('SELECT id, nombre FROM roles ORDER BY id'),
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function nuevo(): never
    {
        View::mostrar('usuarios/formulario', [
            'titulo' => 'Nuevo usuario',
            'migas' => ['Usuarios' => '/usuarios', 'Nuevo' => null],
            'usuario' => null,
            'roles' => DB::todos('SELECT id, clave, nombre, descripcion FROM roles ORDER BY id'),
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
        ]);
    }

    private function datosFormulario(?int $id): array
    {
        $datos = [
            'nombre' => post('nombre'),
            'email' => mb_strtolower(post('email')),
            'rol_id' => (int) post('rol_id'),
            'sede_id' => (int) post('sede_id') ?: null,
        ];
        $error = match (true) {
            $datos['nombre'] === '' => 'Escribe el nombre.',
            !Validar::email($datos['email']) => 'Escribe un correo válido.',
            !DB::valor('SELECT id FROM roles WHERE id = ?', [$datos['rol_id']]) => 'Elige un rol.',
            (bool) DB::valor('SELECT id FROM usuarios WHERE email = ? AND id <> ?', [$datos['email'], $id ?? 0])
                => 'Ya existe un usuario con ese correo.',
            default => null,
        };
        if ($error) {
            Flash::recordarFormulario();
            Flash::error($error);
            redirigir($id ? "/usuarios/$id" : '/usuarios/nuevo');
        }
        return $datos;
    }

    public function crear(): never
    {
        $datos = $this->datosFormulario(null);
        $temporal = Auth::claveTemporal();
        $id = DB::insertar('usuarios', [
            ...$datos,
            'password_hash' => password_hash($temporal, PASSWORD_DEFAULT),
            'debe_cambiar_clave' => 1,
        ]);
        Actividad::registrar('usuarios', 'crear', 'usuarios', $id, 'Creó el usuario ' . $datos['email'], null, $datos);
        $_SESSION['clave_temporal'] = ['id' => $id, 'clave' => $temporal];
        Flash::ok('Usuario creado. Entrégale la contraseña temporal; se le pedirá cambiarla al entrar.');
        redirigir("/usuarios/$id");
    }

    private function buscar(int $id): array
    {
        $u = DB::uno('SELECT u.*, r.clave AS rol_clave FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE u.id = ?', [$id]);
        if (!$u) {
            App::error(404);
        }
        return $u;
    }

    public function editar(string $id): never
    {
        $u = $this->buscar((int) $id);
        $temporal = null;
        if (($_SESSION['clave_temporal']['id'] ?? 0) === (int) $id) {
            $temporal = $_SESSION['clave_temporal']['clave'];
            unset($_SESSION['clave_temporal']);
        }
        View::mostrar('usuarios/formulario', [
            'titulo' => 'Editar usuario',
            'migas' => ['Usuarios' => '/usuarios', $u['nombre'] => null],
            'usuario' => $u,
            'temporal' => $temporal,
            'roles' => DB::todos('SELECT id, clave, nombre, descripcion FROM roles ORDER BY id'),
            'sedes' => DB::todos('SELECT id, nombre FROM sedes WHERE activa = 1 ORDER BY nombre'),
        ]);
    }

    private function adminsActivos(): int
    {
        return (int) DB::valor(
            "SELECT COUNT(*) FROM usuarios u JOIN roles r ON r.id = u.rol_id WHERE r.clave = 'admin' AND u.activo = 1"
        );
    }

    public function guardar(string $id): never
    {
        $id = (int) $id;
        $antes = $this->buscar($id);
        $datos = $this->datosFormulario($id);
        $datos['activo'] = post('activo') === '1' ? 1 : 0;

        $rolAdmin = (int) DB::valor("SELECT id FROM roles WHERE clave = 'admin'");
        $dejaDeSerAdmin = $antes['rol_clave'] === 'admin' && (int) $antes['activo'] === 1
            && ($datos['activo'] === 0 || $datos['rol_id'] !== $rolAdmin);
        if ($dejaDeSerAdmin && $this->adminsActivos() <= 1) {
            Flash::error('No se puede quitar al último Administrador activo. Crea o activa otro Administrador primero.');
            redirigir("/usuarios/$id");
        }
        if ($id === Auth::id() && $datos['activo'] === 0) {
            Flash::error('No puedes desactivar tu propio usuario.');
            redirigir("/usuarios/$id");
        }

        DB::actualizar('usuarios', $datos, 'id = ?', [$id]);
        [$a, $d] = Actividad::diferencias($antes, $datos);
        if ($d) {
            Actividad::registrar('usuarios', 'editar', 'usuarios', $id, 'Editó el usuario ' . $datos['email'], $a, $d);
        }
        Flash::ok('Cambios guardados.');
        redirigir('/usuarios');
    }

    public function restablecerClave(string $id): never
    {
        $u = $this->buscar((int) $id);
        $temporal = Auth::claveTemporal();
        DB::actualizar('usuarios', [
            'password_hash' => password_hash($temporal, PASSWORD_DEFAULT),
            'debe_cambiar_clave' => 1,
        ], 'id = ?', [$u['id']]);
        Actividad::registrar('usuarios', 'restablecer_clave', 'usuarios', (int) $u['id'], 'Restableció la contraseña de ' . $u['email']);
        $_SESSION['clave_temporal'] = ['id' => (int) $u['id'], 'clave' => $temporal];
        Flash::ok('Contraseña restablecida. Entrégale la nueva contraseña temporal.');
        redirigir('/usuarios/' . $u['id']);
    }
}
