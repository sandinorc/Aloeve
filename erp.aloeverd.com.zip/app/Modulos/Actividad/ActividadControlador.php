<?php
declare(strict_types=1);

namespace App\Modulos\Actividad;

use App\Core\DB;
use App\Core\View;

final class ActividadControlador
{
    private const POR_PAGINA = 30;

    private function filtros(): array
    {
        $donde = ['1 = 1'];
        $params = [];
        if (($u = (int) get('usuario')) > 0) {
            $donde[] = 'a.usuario_id = ?';
            $params[] = $u;
        }
        if (($m = get('modulo')) !== '') {
            $donde[] = 'a.modulo = ?';
            $params[] = $m;
        }
        if (($ac = get('accion')) !== '') {
            $donde[] = 'a.accion = ?';
            $params[] = $ac;
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $d = get('desde'))) {
            $donde[] = 'a.fecha >= ?';
            $params[] = $d . ' 00:00:00';
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $h = get('hasta'))) {
            $donde[] = 'a.fecha <= ?';
            $params[] = $h . ' 23:59:59';
        }
        return [implode(' AND ', $donde), $params];
    }

    public function lista(): never
    {
        [$where, $params] = $this->filtros();
        $pagina = max(1, (int) get('pagina', '1'));
        $total = (int) DB::valor("SELECT COUNT(*) FROM actividad a WHERE $where", $params);
        $offset = ($pagina - 1) * self::POR_PAGINA;
        $filas = DB::todos(
            "SELECT a.*, u.nombre AS usuario
               FROM actividad a LEFT JOIN usuarios u ON u.id = a.usuario_id
              WHERE $where ORDER BY a.fecha DESC, a.id DESC
              LIMIT " . self::POR_PAGINA . " OFFSET $offset",
            $params
        );
        View::mostrar('actividad/lista', [
            'titulo' => 'Actividad',
            'migas' => ['Administración' => null, 'Actividad' => null],
            'filas' => $filas,
            'usuarios' => DB::todos('SELECT id, nombre FROM usuarios ORDER BY nombre'),
            'modulos' => array_column(DB::todos('SELECT DISTINCT modulo FROM actividad ORDER BY modulo'), 'modulo'),
            'acciones' => array_column(DB::todos('SELECT DISTINCT accion FROM actividad ORDER BY accion'), 'accion'),
            'total' => $total,
            'pagina' => $pagina,
            'paginas' => max(1, (int) ceil($total / self::POR_PAGINA)),
        ]);
    }

    public function exportar(): never
    {
        [$where, $params] = $this->filtros();
        $st = DB::q(
            "SELECT a.fecha, u.nombre AS usuario, a.modulo, a.accion, a.entidad, a.entidad_id, a.descripcion, a.antes, a.despues, a.ip
               FROM actividad a LEFT JOIN usuarios u ON u.id = a.usuario_id
              WHERE $where ORDER BY a.fecha DESC LIMIT 20000",
            $params
        );
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="actividad-' . date('Ymd-His') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM para que Excel lea los acentos
        fputcsv($out, ['Fecha', 'Usuario', 'Módulo', 'Acción', 'Entidad', 'ID', 'Descripción', 'Antes', 'Después', 'IP']);
        while ($f = $st->fetch()) {
            // Evitar que Excel interprete fórmulas
            $f = array_map(static fn($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $f);
            fputcsv($out, array_values($f));
        }
        fclose($out);
        exit;
    }
}
